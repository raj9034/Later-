package app.later.mobile;

import android.app.Activity;
import android.app.RemoteInput;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import com.getcapacitor.Bridge;
import com.getcapacitor.JSObject;
import com.getcapacitor.PluginHandle;

/**
 * QUICK CAPTURE — the one and only entry point for a submit.
 *
 * WHY THIS EXISTS (root cause of "Saving… then Couldn't save"):
 * the notification's Send action used to be a getBroadcast()
 * PendingIntent aimed at QuickCaptureReceiver, and when the main app
 * wasn't already alive that receiver called startActivity() to boot
 * HeadlessCaptureActivity. Since Android 12, an app targeting SDK 31+
 * may not start an activity from a service or broadcast receiver that a
 * notification tap or ACTION BUTTON triggered (a "notification
 * trampoline"); the system silently blocks it. Later targets SDK 36, so
 * on the device the headless page never even started, nothing ever
 * reported back, and the service's "Saving…" timeout eventually fired.
 *
 * Android's documented remedy is to have the notification launch an
 * Activity DIRECTLY. That is this class. RemoteInput results are
 * delivered to Activity PendingIntents exactly as to broadcast ones.
 *
 * It renders nothing (Theme.Invisible, no task affinity) and is the
 * controller for both routes:
 *
 *  - FAST: the main app's page is alive. Hand it the text and wait for
 *    JS to acknowledge (ackCapture). If nobody acknowledges within
 *    ACK_TIMEOUT_MS — the Activity exists but its page isn't listening
 *    yet, or Android reclaimed the WebView renderer — fall back to the
 *    headless route. The fallback is only legal because this activity is
 *    still visible/foreground at that moment, which is why it stays
 *    alive for the wait instead of finishing immediately. The event
 *    carries a send timestamp and JS ignores anything older than the
 *    timeout, so a page that wakes up late can't double-save a capture
 *    we already re-routed.
 *
 *  - HEADLESS: the main app isn't alive (or the fast path timed out).
 *    Start HeadlessCaptureActivity, then finish.
 */
public class QuickCaptureEntryActivity extends Activity {

    /** Keep in sync with FAST_PATH_MAX_AGE_MS in App.tsx. */
    static final long ACK_TIMEOUT_MS = 3000;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable fallbackRunnable;
    private String capturedText = "";
    private boolean settled = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        if (intent == null || !QuickCaptureNotificationHelper.ACTION_SUBMIT.equals(intent.getAction())) {
            finish();
            return;
        }

        android.os.Bundle results = RemoteInput.getResultsFromIntent(intent);
        CharSequence input = results != null
            ? results.getCharSequence(QuickCaptureNotificationHelper.REMOTE_INPUT_KEY)
            : null;
        // Trim only the ends; never touch the interior (URLs, punctuation
        // and internal whitespace must survive exactly as typed/pasted).
        capturedText = input != null ? input.toString().trim() : "";

        if (capturedText.isEmpty()) {
            // Nothing to save. Put the input notification back so the
            // reply spinner Android shows on submit doesn't just hang.
            QuickCaptureForegroundService.startIfEnabled(this); // re-posts the clean state
            finish();
            return;
        }

        // Re-post immediately: clears Android's reply spinner and gives
        // honest "Saving…" feedback (also removes the reply field so a
        // second submit can't be fired mid-save).
        QuickCaptureForegroundService.showSaving(this, capturedText);

        if (MainActivity.isReachable() && deliverToLiveBridge(capturedText)) {
            // Stay alive (invisibly) until JS acknowledges, or fall back.
            QuickCapturePlugin.setAckListener(() -> mainHandler.post(this::onLiveAck));
            fallbackRunnable = this::onAckTimeout;
            mainHandler.postDelayed(fallbackRunnable, ACK_TIMEOUT_MS);
            return;
        }

        startHeadlessAndFinish();
    }

    private void onLiveAck() {
        if (settled) return;
        settled = true;
        cleanup();
        finish();
    }

    private void onAckTimeout() {
        if (settled) return;
        settled = true;
        QuickCapturePlugin.clearAckListener();
        startHeadlessAndFinish();
    }

    private void startHeadlessAndFinish() {
        try {
            HeadlessCaptureActivity.start(this, capturedText);
        } catch (RuntimeException e) {
            // Even a foreground start can be refused on some builds. Don't
            // leave "Saving…" hanging for the full timeout: fail now, which
            // also puts the text on the clipboard.
            QuickCaptureForegroundService.showFailure(this, capturedText);
        }
        finish();
    }

    private void cleanup() {
        if (fallbackRunnable != null) {
            mainHandler.removeCallbacks(fallbackRunnable);
            fallbackRunnable = null;
        }
        QuickCapturePlugin.clearAckListener();
    }

    @Override
    protected void onDestroy() {
        cleanup();
        super.onDestroy();
    }

    /**
     * Fast path: hand the text straight to the running page over the real
     * Capacitor bridge. Returns false if that isn't possible right now,
     * so the caller can take the headless route instead.
     */
    private static boolean deliverToLiveBridge(String text) {
        MainActivity activity = MainActivity.getCurrentInstance();
        if (activity == null) return false;

        Bridge bridge = activity.getBridge();
        if (bridge == null) return false;

        PluginHandle handle = bridge.getPlugin("QuickCapture");
        if (handle == null || !(handle.getInstance() instanceof QuickCapturePlugin)) return false;

        JSObject data = new JSObject();
        data.put("text", text);
        data.put("sentAt", System.currentTimeMillis());
        ((QuickCapturePlugin) handle.getInstance()).notifyCaptureTextReceived(data);
        return true;
    }
}
