package app.later.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

/**
 * LATER ORB POC — EXPERIMENTAL, TEMPORARY.
 *
 * This service exists ONLY to answer one question: can a focusable
 * TYPE_APPLICATION_OVERLAY read the system clipboard when another app is
 * in the foreground, and if so, does taking that focus visibly disrupt
 * the app underneath? It is not the final Orb. It stores nothing
 * permanently and does not touch any existing Later feature.
 *
 * All diagnostic state is written to a dedicated SharedPreferences file
 * (PREFS_NAME) so OrbPocPlugin can read it back into the JS test screen.
 */
public class OrbPocForegroundService extends Service {

    public static final String PREFS_NAME = "orb_poc_diagnostics";
    private static final String CHANNEL_ID = "orb_poc_channel";
    private static final int NOTIFICATION_ID = 991001;

    private WindowManager windowManager;
    private FrameLayout overlayRoot;
    private TextView overlayText;
    private ClipboardManager clipboardManager;
    private ClipboardManager.OnPrimaryClipChangedListener clipListener;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean overlayAttached = false;

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundWithNotification();
        registerClipboardListener();
        putBool("foregroundServiceActive", true);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        putBool("foregroundServiceActive", false);
        if (clipboardManager != null && clipListener != null) {
            clipboardManager.removePrimaryClipChangedListener(clipListener);
        }
        removeOverlay();
    }

    // ---------------------------------------------------------------
    // Foreground notification (required to keep this service alive
    // while the user tests it — this is the persistent notification
    // the POC spec asked for, nothing hidden).
    // ---------------------------------------------------------------
    private void startForegroundWithNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Orb POC (test only)",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Temporary — Later Orb clipboard-detection experiment");
            nm.createNotificationChannel(channel);
        }

        Notification.Builder builder = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);

        builder
            .setContentTitle("Later Orb POC running")
            .setContentText("Test only — testing clipboard detection")
            .setSmallIcon(getApplicationInfo().icon)
            .setOngoing(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            // Android 14+ requires every FGS to declare its type at
            // startForeground() time when the manifest type is
            // "specialUse" and there isn't a matching typed constant.
            startForeground(NOTIFICATION_ID, builder.build(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, builder.build());
        }
    }

    // ---------------------------------------------------------------
    // Clipboard listener — the actual hypothesis under test.
    // ---------------------------------------------------------------
    private void registerClipboardListener() {
        clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboardManager == null) {
            putBool("clipboardListenerFired", false);
            return;
        }
        clipListener = () -> {
            putBool("clipboardListenerFired", true);
            putLong("lastDetectionTimeMs", System.currentTimeMillis());
            attemptClipboardRead();
        };
        clipboardManager.addPrimaryClipChangedListener(clipListener);
    }

    private void attemptClipboardRead() {
        boolean hasClip = clipboardManager.hasPrimaryClip();
        putBool("hasPrimaryClip", hasClip);

        String text = null;
        boolean readSuccess = false;
        try {
            ClipData clip = clipboardManager.getPrimaryClip();
            if (clip != null && clip.getItemCount() > 0) {
                CharSequence item = clip.getItemAt(0).coerceToText(this);
                if (item != null) {
                    text = item.toString();
                    readSuccess = true;
                }
            }
        } catch (Exception e) {
            readSuccess = false;
        }

        putBool("getPrimaryClipSuccess", readSuccess);
        putString("clipboardText", readSuccess ? truncate(text, 120) : "");

        // Show the transient test bubble on the main thread either way —
        // "CLIPBOARD DETECTED" or "CLIPBOARD BLOCKED" — per spec.
        // (Captured into final locals — text/readSuccess above are
        // reassigned earlier in this method, so they aren't
        // effectively final and can't be captured directly by the
        // lambda below.)
        final boolean finalReadSuccess = readSuccess;
        final String finalText = text;
        mainHandler.post(() -> showOverlayBubble(finalReadSuccess, finalText));
    }

    private static String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() > max ? s.substring(0, max) + "…" : s;
    }

    // ---------------------------------------------------------------
    // The overlay itself. Deliberately FOCUSABLE (no FLAG_NOT_FOCUSABLE)
    // because that is exactly the mechanism being tested — this is not
    // an oversight, it's the point. Shown only transiently on a
    // clipboard event, then auto-removed, to limit how long it can
    // disrupt the app underneath while we're testing.
    // ---------------------------------------------------------------
    private void showOverlayBubble(boolean success, String clipText) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return; // overlay perm model differs pre-M; not worth supporting for a POC
        if (!android.provider.Settings.canDrawOverlays(this)) {
            putBool("overlayCreated", false);
            return;
        }

        removeOverlay(); // clear any previous bubble first

        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        overlayRoot = new FrameLayout(this) {
            @Override
            public void onWindowFocusChanged(boolean hasWindowFocus) {
                super.onWindowFocusChanged(hasWindowFocus);
                // This is the actual answer to "does the overlay obtain
                // window focus" — recorded directly from the framework,
                // not inferred.
                putBool("overlayFocus", hasWindowFocus);
            }
        };
        overlayRoot.setBackgroundColor(Color.parseColor("#DD1F5A46"));
        overlayRoot.setPadding(32, 24, 32, 24);

        overlayText = new TextView(this);
        overlayText.setTextColor(Color.WHITE);
        overlayText.setTextSize(13);
        String label = success ? "CLIPBOARD DETECTED\n" : "CLIPBOARD BLOCKED\n";
        String body = success ? truncate(clipText, 80) : "(no access — see diagnostics)";
        overlayText.setText(label + body);
        overlayRoot.addView(overlayText);

        int overlayType = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            // Intentionally NOT including FLAG_NOT_FOCUSABLE — this is
            // the mechanism under test. FLAG_LAYOUT_NO_LIMITS kept off;
            // this is meant to visibly take focus, not hide from it.
            0,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        params.y = 200;

        try {
            windowManager.addView(overlayRoot, params);
            overlayAttached = true;
            putBool("overlayCreated", true);
        } catch (Exception e) {
            putBool("overlayCreated", false);
            overlayAttached = false;
        }

        // Auto-remove after 6s so the focus-steal window (if any) is as
        // short as possible while still testable.
        mainHandler.postDelayed(this::removeOverlay, 6000);
    }

    private void removeOverlay() {
        if (overlayAttached && windowManager != null && overlayRoot != null) {
            try {
                windowManager.removeView(overlayRoot);
            } catch (Exception ignored) {
            }
        }
        overlayAttached = false;
        overlayRoot = null;
    }

    // ---------------------------------------------------------------
    // SharedPreferences diagnostic bus (in-process, no IPC needed —
    // Service and Plugin run in the same app process).
    // ---------------------------------------------------------------
    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    private void putBool(String key, boolean value) {
        prefs().edit().putBoolean(key, value).apply();
    }

    private void putString(String key, String value) {
        prefs().edit().putString(key, value).apply();
    }

    private void putLong(String key, long value) {
        prefs().edit().putLong(key, value).apply();
    }
}
