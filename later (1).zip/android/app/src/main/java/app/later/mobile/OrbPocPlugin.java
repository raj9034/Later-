package app.later.mobile;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * LATER ORB POC — EXPERIMENTAL, TEMPORARY.
 *
 * Bridges the "Orb POC Test" screen to OrbPocForegroundService. This
 * plugin and its service are the entire POC; nothing else in the app
 * references them, so both can be deleted together with no side
 * effects once the experiment is done.
 */
@CapacitorPlugin(name = "OrbPoc")
public class OrbPocPlugin extends Plugin {

    @PluginMethod
    public void checkOverlayPermission(PluginCall call) {
        boolean granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M
            || Settings.canDrawOverlays(getContext());
        JSObject ret = new JSObject();
        ret.put("granted", granted);
        call.resolve(ret);
    }

    @PluginMethod
    public void requestOverlayPermission(PluginCall call) {
        try {
            Intent intent = new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getContext().getPackageName())
            );
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not open overlay permission screen: " + e.getMessage());
        }
    }

    @PluginMethod
    public void startOrbTest(PluginCall call) {
        try {
            Intent serviceIntent = new Intent(getContext(), OrbPocForegroundService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                getContext().startForegroundService(serviceIntent);
            } else {
                getContext().startService(serviceIntent);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not start Orb POC service: " + e.getMessage());
        }
    }

    @PluginMethod
    public void stopOrbTest(PluginCall call) {
        try {
            getContext().stopService(new Intent(getContext(), OrbPocForegroundService.class));
            // Clear diagnostics so the next run starts clean.
            getContext()
                .getSharedPreferences(OrbPocForegroundService.PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .clear()
                .apply();
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not stop Orb POC service: " + e.getMessage());
        }
    }

    @PluginMethod
    public void getDiagnostics(PluginCall call) {
        SharedPreferences prefs = getContext()
            .getSharedPreferences(OrbPocForegroundService.PREFS_NAME, Context.MODE_PRIVATE);

        JSObject ret = new JSObject();
        ret.put("androidVersion", Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")");
        ret.put("device", Build.MANUFACTURER + " " + Build.MODEL);
        ret.put("overlayPermission", Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(getContext()));
        ret.put("serviceRunning", isServiceRunning());
        ret.put("foregroundServiceActive", prefs.getBoolean("foregroundServiceActive", false));
        ret.put("overlayCreated", prefs.getBoolean("overlayCreated", false));
        ret.put("overlayFocus", prefs.getBoolean("overlayFocus", false));
        ret.put("clipboardListenerFired", prefs.getBoolean("clipboardListenerFired", false));
        ret.put("hasPrimaryClip", prefs.getBoolean("hasPrimaryClip", false));
        ret.put("getPrimaryClipSuccess", prefs.getBoolean("getPrimaryClipSuccess", false));
        ret.put("clipboardText", prefs.getString("clipboardText", ""));
        ret.put("lastDetectionTimeMs", prefs.getLong("lastDetectionTimeMs", 0));
        call.resolve(ret);
    }

    private boolean isServiceRunning() {
        ActivityManager am = (ActivityManager) getContext().getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return false;
        for (ActivityManager.RunningServiceInfo info : am.getRunningServices(Integer.MAX_VALUE)) {
            if (OrbPocForegroundService.class.getName().equals(info.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
}
