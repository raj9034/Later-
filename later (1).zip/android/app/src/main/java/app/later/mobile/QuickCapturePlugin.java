package app.later.mobile;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "QuickCapture")
public class QuickCapturePlugin extends Plugin {

    @Override
    public void load() {
        super.load();
        // The persistent notification should be visible as soon as
        // there's a live app instance to own it — covers first launch
        // and every subsequent app open, in addition to the boot
        // receiver covering the reboot case. Routed through the
        // foreground service (not a plain notify()) so it's genuinely
        // swipe-proof, not just a soft "ongoing" hint — see
        // QuickCaptureForegroundService for why that distinction
        // matters. No-ops automatically if the user has disabled Quick
        // Capture.
        QuickCaptureForegroundService.startIfEnabled(getContext());
    }

    /**
     * Called from QuickCaptureEntryActivity (fast/live path only — the
     * headless path never touches this class at all; see
     * HeadlessCaptureActivity.java, which runs its own instance of this
     * same plugin instead).
     */
    void notifyCaptureTextReceived(JSObject data) {
        notifyListeners("captureTextReceived", data);
    }

    // ---- fast-path acknowledgement -------------------------------------
    // QuickCaptureEntryActivity hands text to the live page and then must
    // know the page really received it (the Activity can exist while its
    // WebView page isn't listening yet, or its renderer was reclaimed).
    // It registers a listener here; the page calls ackCapture() the moment
    // it accepts the text. Static because the Entry activity and the
    // plugin instance live in different places. Only ever one capture in
    // flight: the notification has no input field while "Saving…".
    private static Runnable ackListener;

    static synchronized void setAckListener(Runnable listener) {
        ackListener = listener;
    }

    static synchronized void clearAckListener() {
        ackListener = null;
    }

    private static synchronized Runnable currentAckListener() {
        return ackListener;
    }

    /** Called from JS the instant a fast-path capture is accepted (before it is saved). */
    @PluginMethod
    public void ackCapture(PluginCall call) {
        Runnable listener = currentAckListener();
        if (listener != null) listener.run(); // the listener re-posts to the main thread itself
        call.resolve();
    }

    /**
     * Called from JS (App.tsx's QuickCaptureLiveBridge, or
     * HeadlessCaptureRoot.tsx) once a save attempt has settled, success
     * or failure.
     */
    @PluginMethod
    public void reportResult(PluginCall call) {
        boolean success = call.getBoolean("success", false);
        // `saved` = the memory itself persisted. `success` = everything the
        // user asked for worked (saved AND, if a reminder was requested,
        // the alarm was confirmed). Older callers send only `success`.
        Boolean savedFlag = call.getBoolean("saved");
        boolean saved = savedFlag != null ? savedFlag : success;
        String text = call.getString("text", "");
        String detail = call.getString("detail", "");
        applyResult(getContext(), success, saved, text, detail);
        call.resolve();

        // If this plugin instance belongs to the headless Activity
        // (rather than the real, user-visible MainActivity), its job
        // is done the moment a result has been reported — close it
        // immediately rather than waiting for the safety timeout.
        if (getActivity() instanceof HeadlessCaptureActivity) {
            getActivity().finish();
        }
    }

    /** Shared by PluginMethod.reportResult, from either the live or headless path.
     *  Routes through QuickCaptureForegroundService — the only class allowed to
     *  actually post/update this notification (see that class for why). */
    static void applyResult(
        android.content.Context context,
        boolean success,
        boolean saved,
        String text,
        String detail
    ) {
        if (success) {
            // `detail` here is the confirmed-reminder label, if any.
            QuickCaptureForegroundService.showSaved(context, detail);
        } else if (saved) {
            // Saved, but the requested reminder couldn't be confirmed.
            QuickCaptureForegroundService.showPartial(context, detail);
        } else {
            QuickCaptureForegroundService.showFailure(context, text);
        }
    }

    @PluginMethod
    public void ensureNotificationPosted(PluginCall call) {
        QuickCaptureForegroundService.startIfEnabled(getContext());
        call.resolve();
    }

    @PluginMethod
    public void removeNotification(PluginCall call) {
        QuickCaptureForegroundService.stop(getContext());
        android.app.NotificationManager nm =
            (android.app.NotificationManager) getContext().getSystemService(android.content.Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.cancel(QuickCaptureNotificationHelper.NOTIFICATION_ID);
        }
        call.resolve();
    }

    /**
     * The one on/off switch for the persistent Quick Capture
     * notification — completely separate from Android's own
     * notification permission and from Later's reminder notifications.
     * Disabling this only stops QuickCaptureForegroundService; it never
     * touches notification permission state or reminder scheduling.
     */
    @PluginMethod
    public void setEnabled(PluginCall call) {
        boolean enabled = call.getBoolean("enabled", true);
        QuickCaptureNotificationHelper.setEnabled(getContext(), enabled);
        if (enabled) {
            QuickCaptureForegroundService.startIfEnabled(getContext());
        } else {
            QuickCaptureForegroundService.stop(getContext());
            android.app.NotificationManager nm =
                (android.app.NotificationManager) getContext().getSystemService(android.content.Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.cancel(QuickCaptureNotificationHelper.NOTIFICATION_ID);
            }
        }
        call.resolve();
    }

    @PluginMethod
    public void isEnabled(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("enabled", QuickCaptureNotificationHelper.isEnabled(getContext()));
        call.resolve(ret);
    }
}
