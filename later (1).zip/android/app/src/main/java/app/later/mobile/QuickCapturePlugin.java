package app.later.mobile;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "QuickCapture")
public class QuickCapturePlugin extends Plugin {

    @Override
    public void load() {
        super.load();
        // The persistent notification should be visible as soon as
        // there's a live app instance to own it — covers first launch
        // and every subsequent app open, in addition to the boot
        // receiver covering the reboot case. Routed through the
        // foreground service (not a plain notify()) so it's genuinely
        // swipe-proof, not just a soft "ongoing" hint — see
        // QuickCaptureForegroundService for why that distinction
        // matters. No-ops automatically if the user has disabled Quick
        // Capture.
        QuickCaptureForegroundService.startIfEnabled(getContext());
    }

    /**
     * Called from QuickCaptureReceiver (fast/live path only — the
     * headless path never touches this class at all; see
     * HeadlessCaptureActivity.java, which runs its own instance of this
     * same plugin instead).
     */
    void notifyCaptureTextReceived(JSObject data) {
        notifyListeners("captureTextReceived", data);
    }

    /**
     * Called from JS (App.tsx's QuickCaptureLiveBridge, or
     * HeadlessCaptureRoot.tsx) once a save attempt has settled, success
     * or failure.
     */
    @PluginMethod
    public void reportResult(PluginCall call) {
        boolean success = call.getBoolean("success", false);
        String text = call.getString("text", "");
        applyResult(getContext(), success, text);
        call.resolve();

        // If this plugin instance belongs to the headless Activity
        // (rather than the real, user-visible MainActivity), its job
        // is done the moment a result has been reported — close it
        // immediately rather than waiting for the safety timeout.
        if (getActivity() instanceof HeadlessCaptureActivity) {
            getActivity().finish();
        }
    }

    /** Shared by PluginMethod.reportResult, from either the live or headless path. */
    static void applyResult(android.content.Context context, boolean success, String text) {
        if (success) {
            QuickCaptureNotificationHelper.postSavedConfirmation(context);
        } else {
            QuickCaptureNotificationHelper.postFailureState(context, text);
        }
    }

    @PluginMethod
    public void ensureNotificationPosted(PluginCall call) {
        QuickCaptureForegroundService.startIfEnabled(getContext());
        call.resolve();
    }

    @PluginMethod
    public void removeNotification(PluginCall call) {
        QuickCaptureForegroundService.stop(getContext());
        android.app.NotificationManager nm =
            (android.app.NotificationManager) getContext().getSystemService(android.content.Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.cancel(QuickCaptureNotificationHelper.NOTIFICATION_ID);
        }
        call.resolve();
    }

    /**
     * The one on/off switch for the persistent Quick Capture
     * notification — completely separate from Android's own
     * notification permission and from Later's reminder notifications.
     * Disabling this only stops QuickCaptureForegroundService; it never
     * touches notification permission state or reminder scheduling.
     */
    @PluginMethod
    public void setEnabled(PluginCall call) {
        boolean enabled = call.getBoolean("enabled", true);
        QuickCaptureNotificationHelper.setEnabled(getContext(), enabled);
        if (enabled) {
            QuickCaptureForegroundService.startIfEnabled(getContext());
        } else {
            QuickCaptureForegroundService.stop(getContext());
            android.app.NotificationManager nm =
                (android.app.NotificationManager) getContext().getSystemService(android.content.Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.cancel(QuickCaptureNotificationHelper.NOTIFICATION_ID);
            }
        }
        call.resolve();
    }

    @PluginMethod
    public void isEnabled(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("enabled", QuickCaptureNotificationHelper.isEnabled(getContext()));
        call.resolve(ret);
    }
}
