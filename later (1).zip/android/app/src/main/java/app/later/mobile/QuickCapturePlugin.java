package app.later.mobile;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "QuickCapture")
public class QuickCapturePlugin extends Plugin {

    @Override
    public void load() {
        super.load();
        // The persistent notification should be visible as soon as
        // there's a live app instance to own it — covers first launch
        // and every subsequent app open, in addition to the boot
        // receiver covering the reboot case.
        QuickCaptureNotificationHelper.postCleanState(getContext());
    }

    /**
     * Called from QuickCaptureReceiver (fast/live path only — the
     * headless path never touches this class at all, see
     * HeadlessCaptureRoot.tsx's NativeQuickCapture bridge instead).
     */
    void notifyCaptureTextReceived(JSObject data) {
        notifyListeners("captureTextReceived", data);
    }

    /**
     * Called from JS (App.tsx's QuickCaptureLiveBridge) once a
     * live-path save attempt has settled, success or failure.
     */
    @PluginMethod
    public void reportResult(PluginCall call) {
        boolean success = call.getBoolean("success", false);
        String text = call.getString("text", "");
        applyResult(getContext(), success, text);
        call.resolve();

        // If this plugin instance belongs to the headless Activity
        // (rather than the real, user-visible MainActivity), its job
        // is done the moment a result has been reported — close it
        // immediately rather than waiting for the safety timeout.
        if (getActivity() instanceof HeadlessCaptureActivity) {
            getActivity().finish();
        }
    }

    /** Shared by both PluginMethod.reportResult (JS) and, indirectly
     *  in spirit, the headless JavascriptInterface path (which calls
     *  this same logic natively — see HeadlessCaptureService). */
    static void applyResult(android.content.Context context, boolean success, String text) {
        if (success) {
            QuickCaptureNotificationHelper.postSavedConfirmation(context);
        } else {
            QuickCaptureNotificationHelper.postFailureState(context, text);
        }
    }

    @PluginMethod
    public void ensureNotificationPosted(PluginCall call) {
        QuickCaptureNotificationHelper.postCleanState(getContext());
        call.resolve();
    }

    @PluginMethod
    public void removeNotification(PluginCall call) {
        android.app.NotificationManager nm =
            (android.app.NotificationManager) getContext().getSystemService(android.content.Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.cancel(QuickCaptureNotificationHelper.NOTIFICATION_ID);
        }
        call.resolve();
    }
}
