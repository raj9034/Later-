package app.later.mobile;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import com.getcapacitor.BridgeActivity;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * QUICK CAPTURE — headless processing path.
 *
 * Started by QuickCaptureEntryActivity (never directly from a receiver or
 * service — Android 12+ blocks that for notification-triggered starts)
 * when the real app's page can't take the capture: either
 * MainActivity.isReachable() is false (Activity destroyed, or the process
 * was cold-started to service this notification action), or the live
 * page didn't acknowledge the text in time.
 *
 * This is a REAL BridgeActivity — same Capacitor bridge setup, same
 * https://localhost origin, same shared IndexedDB/Firebase session as
 * MainActivity — deliberately, rather than a hand-rolled WebView, so
 * there's no risk of it silently ending up on a different effective
 * origin than the main app (which would break session sharing in a way
 * that's very hard to detect).
 *
 * What makes it invisible — and why NOT Theme.NoDisplay: an earlier
 * version of this file used android:style/Theme.NoDisplay, which
 * doesn't even exist under that combined name (build failure caught
 * this), and more importantly the real Theme.NoDisplay would have been
 * wrong anyway — it legally requires finish() before onResume()
 * completes on every device API 23+, or the app crashes with
 * IllegalStateException. This activity needs to wait for a Firestore
 * write to settle (up to ~15s) before finishing, which that theme
 * cannot allow. Instead this uses @style/Theme.Invisible (see
 * res/values/styles.xml) — a genuinely translucent, fully transparent
 * window that IS allowed to stay resumed indefinitely, combined with
 * the WebView's own background forced transparent below. The composited
 * result paints nothing perceptible, but honestly: this is "an empty
 * transparent window," not "no window at all." Still meaningfully
 * different from the earlier-rejected "flash then moveTaskToBack"
 * approach, which rendered a real, opaque, visible screen.
 *
 * Lifecycle: onCreate loads the app's normal start URL first (Capacitor
 * always does this automatically as part of BridgeActivity init), then
 * redirects the same WebView to the headless capture URL shortly after.
 * The extra initial load is wasted work but has zero visual cost, since
 * the window is transparent throughout — accepted deliberately rather
 * than guessing at an internal Capacitor start-URL-override hook that
 * could vary by version. Finishes itself as soon as
 * QuickCapturePlugin.reportResult() is called (see that class), or
 * after a hard safety timeout if something goes wrong.
 */
public class HeadlessCaptureActivity extends BridgeActivity {

    private static final long SAFETY_TIMEOUT_MS = 15000;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable safetyTimeoutRunnable;

    public static void start(Context context, String captureText) {
        Intent intent = new Intent(context, HeadlessCaptureActivity.class);
        intent.putExtra("capture_text", captureText);
        intent.setFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_NO_ANIMATION
                | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
        );
        context.startActivity(intent);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(QuickCapturePlugin.class);
        super.onCreate(savedInstanceState);

        // Belt-and-braces on top of the transparent theme: force the
        // WebView's own background transparent too, so even its default
        // white paint before/between page loads never becomes visible.
        if (getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().setBackgroundColor(android.graphics.Color.TRANSPARENT);
        }

        String captureText = getIntent().getStringExtra("capture_text");
        if (captureText == null || captureText.trim().isEmpty()) {
            finish();
            return;
        }

        // Redirect the bridge's own WebView to the headless entry once
        // its normal initial load has had a moment to settle. A fixed
        // short delay is used rather than a page-load callback to avoid
        // depending on an internal Capacitor WebViewClient hook.
        String encoded;
        try {
            encoded = URLEncoder.encode(captureText, StandardCharsets.UTF_8.toString());
        } catch (Exception e) {
            finish();
            return;
        }
        final String targetUrl = "https://localhost/?headless_capture=" + encoded;

        mainHandler.postDelayed(() -> {
            if (getBridge() != null && getBridge().getWebView() != null) {
                getBridge().getWebView().loadUrl(targetUrl);
            } else {
                finish();
            }
        }, 300);

        // Safety net: if the capture pipeline never reports back
        // (crash, unexpected auth hang, etc.), don't leave an invisible
        // Activity/process lingering forever.
        safetyTimeoutRunnable = this::finish;
        mainHandler.postDelayed(safetyTimeoutRunnable, SAFETY_TIMEOUT_MS);
    }

    @Override
    public void onDestroy() {
        if (safetyTimeoutRunnable != null) {
            mainHandler.removeCallbacks(safetyTimeoutRunnable);
        }
        super.onDestroy();
    }
}
