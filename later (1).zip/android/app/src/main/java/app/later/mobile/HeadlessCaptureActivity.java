package app.later.mobile;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import com.getcapacitor.BridgeActivity;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * QUICK CAPTURE — headless processing path.
 *
 * Used only when QuickCaptureReceiver finds MainActivity.isReachable()
 * false — i.e. the real app's Activity/WebView doesn't currently exist
 * (destroyed, or the process was just cold-started by Android
 * specifically to service this notification action).
 *
 * This is a REAL BridgeActivity — same Capacitor bridge setup, same
 * https://localhost origin, same shared IndexedDB/Firebase session as
 * MainActivity — deliberately, rather than a hand-rolled WebView, so
 * there's no risk of it silently ending up on a different effective
 * origin than the main app (which would break session sharing in a way
 * that's very hard to detect).
 *
 * What makes it invisible: android:theme="Theme.Translucent.NoDisplay"
 * in the manifest (a standard, documented Android pattern — the same
 * one used by e.g. NFC/share-target handlers that need a real Activity
 * context without ever showing UI). This produces no window, no
 * transition, no frame the user ever sees — meaningfully different
 * from the earlier-rejected "flash then moveTaskToBack" approach, which
 * did briefly render a real visible window. Here nothing is ever drawn.
 *
 * Lifecycle: onCreate loads the app's normal start URL first (Capacitor
 * always does this automatically as part of BridgeActivity init), then
 * immediately redirects the same WebView to the headless capture URL.
 * The extra initial load is wasted work but zero visual cost, since
 * nothing from this Activity is ever displayed either way — accepted
 * deliberately rather than guessing at an internal Capacitor
 * start-URL-override hook that could vary by version. Finishes itself
 * as soon as QuickCapturePlugin.reportResult() is called (see that
 * class), or after a hard safety timeout if something goes wrong.
 */
public class HeadlessCaptureActivity extends BridgeActivity {

    private static final long SAFETY_TIMEOUT_MS = 15000;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable safetyTimeoutRunnable;

    public static void start(Context context, String captureText) {
        Intent intent = new Intent(context, HeadlessCaptureActivity.class);
        intent.putExtra("capture_text", captureText);
        intent.setFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_NO_ANIMATION
                | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
        );
        context.startActivity(intent);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(QuickCapturePlugin.class);
        super.onCreate(savedInstanceState);

        String captureText = getIntent().getStringExtra("capture_text");
        if (captureText == null || captureText.trim().isEmpty()) {
            finish();
            return;
        }

        // Redirect the bridge's own WebView to the headless entry once
        // its normal initial load has had a moment to settle. A fixed
        // short delay is used rather than a page-load callback to avoid
        // depending on an internal Capacitor WebViewClient hook.
        String encoded;
        try {
            encoded = URLEncoder.encode(captureText, StandardCharsets.UTF_8.toString());
        } catch (Exception e) {
            finish();
            return;
        }
        final String targetUrl = "https://localhost/?headless_capture=" + encoded;

        mainHandler.postDelayed(() -> {
            if (getBridge() != null && getBridge().getWebView() != null) {
                getBridge().getWebView().loadUrl(targetUrl);
            } else {
                finish();
            }
        }, 300);

        // Safety net: if the capture pipeline never reports back
        // (crash, unexpected auth hang, etc.), don't leave an invisible
        // Activity/process lingering forever.
        safetyTimeoutRunnable = this::finish;
        mainHandler.postDelayed(safetyTimeoutRunnable, SAFETY_TIMEOUT_MS);
    }

    @Override
    protected void onDestroy() {
        if (safetyTimeoutRunnable != null) {
            mainHandler.removeCallbacks(safetyTimeoutRunnable);
        }
        super.onDestroy();
    }
}
