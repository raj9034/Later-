package app.later.mobile;

import android.content.Intent;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    // QUICK CAPTURE — lets QuickCaptureReceiver know, without guessing,
    // whether the real app's WebView is currently alive (foregrounded
    // OR merely backgrounded — Capacitor keeps the WebView instance
    // around in both cases; only onDestroy actually tears it down).
    // That's the fast-path/slow-path decision: reachable() true means
    // hand the captured text straight to the live JS via the
    // QuickCapture plugin; false means the Activity/WebView doesn't
    // exist right now and a headless WebView is needed instead.
    private static volatile MainActivity currentInstance;

    public static boolean isReachable() {
        return currentInstance != null;
    }

    public static MainActivity getCurrentInstance() {
        return currentInstance;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(SendIntentPlugin.class);
        registerPlugin(NotificationSettingsPlugin.class);
        registerPlugin(QuickCapturePlugin.class);
        super.onCreate(savedInstanceState);
        currentInstance = this;
    }

    @Override
    protected void onDestroy() {
        if (currentInstance == this) {
            currentInstance = null;
        }
        super.onDestroy();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }
}
