package app.later.mobile;

import android.content.Intent;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(SendIntentPlugin.class);
        registerPlugin(NotificationSettingsPlugin.class);
        // ORB POC — experimental, temporary. Remove this line plus
        // OrbPocPlugin.java and OrbPocForegroundService.java together to
        // fully revert this experiment.
        registerPlugin(OrbPocPlugin.class);
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }
}
