package app.later.mobile;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/**
 * Phase 1 home screen widget: a single "+ Add to Later" tile.
 * Tapping it launches MainActivity with an extra that SendIntentPlugin
 * already reads (see handleIncomingIntent in SendIntentPlugin.java) to
 * route straight to the capture screen.
 *
 * Built with the classic RemoteViews/AppWidgetProvider API (stable since
 * Android 1.5) rather than Jetpack Glance, to avoid Kotlin/Compose
 * toolchain version issues and stay consistent with the rest of this
 * project, which is otherwise pure Java.
 */
public class LaterWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.later_widget_layout);

            Intent intent = new Intent(context, MainActivity.class);
            intent.setAction(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("later_widget_capture", true);

            PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                appWidgetId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent);
            appWidgetManager.updateAppWidget(appWidgetId, views);
        }
    }
}
