package app.later.mobile;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

/**
 * Home screen widget: a single "+ Add to Later" tile with a live pending-
 * items count underneath. Tapping it launches MainActivity with an extra
 * that SendIntentPlugin already reads (see handleIncomingIntent in
 * SendIntentPlugin.java) to open straight into the capture box, focused.
 *
 * The count is written by SendIntentPlugin.updateWidgetCount(), called
 * from JS whenever the pending-items list changes, into a plain
 * SharedPreferences file this provider reads on every update.
 *
 * Built with the classic RemoteViews/AppWidgetProvider API (stable since
 * Android 1.5) rather than Jetpack Glance, to avoid Kotlin/Compose
 * toolchain version issues and stay consistent with the rest of this
 * project, which is otherwise pure Java.
 */
public class LaterWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        SharedPreferences prefs = context.getSharedPreferences("later_widget_prefs", Context.MODE_PRIVATE);
        int pendingCount = prefs.getInt("pending_count", 0);

        for (int appWidgetId : appWidgetIds) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.later_widget_layout);

            if (pendingCount > 0) {
                String label = pendingCount == 1 ? "1 waiting" : (pendingCount + " waiting");
                views.setTextViewText(R.id.widget_count, label);
            } else {
                views.setTextViewText(R.id.widget_count, "");
            }

            Intent intent = new Intent(context, MainActivity.class);
            intent.setAction(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("later_widget_capture", true);

            PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                appWidgetId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent);
            appWidgetManager.updateAppWidget(appWidgetId, views);
        }
    }
}
