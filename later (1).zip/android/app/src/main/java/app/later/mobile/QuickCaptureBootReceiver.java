package app.later.mobile;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Notifications (including ongoing ones) do not survive a reboot —
 * Android clears them all. This is a new, small, single-purpose
 * receiver for exactly that gap; it doesn't touch or duplicate
 * @capacitor/local-notifications' own boot handling for scheduled
 * reminders, which is a separate concern already handled internally by
 * that plugin.
 *
 * Deliberately does nothing else on boot — no auth, no sync, no
 * network. Just re-arms the empty capture notification so it's there
 * next time the user pulls the shade down.
 */
public class QuickCaptureBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            // Respects the same enabled/disabled switch as everywhere
            // else — if the user turned Quick Capture off, reboot must
            // not resurrect it. Routed through the foreground service
            // so the post-reboot notification is genuinely swipe-proof
            // too, not just a plain notify().
            QuickCaptureForegroundService.startIfEnabled(context);
        }
    }
}
