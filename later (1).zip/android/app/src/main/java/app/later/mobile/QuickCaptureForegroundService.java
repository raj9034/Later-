package app.later.mobile;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/**
 * QUICK CAPTURE — persistence owner.
 *
 * A plain notify()'d notification with setOngoing(true) is only a soft
 * hint on modern Android — it can still be swiped away by the user,
 * which is exactly what was reported: swipe it, and it stays gone until
 * the app is reopened. Real swipe-immunity requires the notification be
 * owned by an active foreground service via startForeground(), the same
 * mechanism messaging apps use for their persistent "connected" style
 * notifications. This service's only job is to hold that notification
 * alive; QuickCaptureNotificationHelper still owns all the actual
 * building/content logic and is called from here unchanged.
 *
 * Respects QuickCaptureNotificationHelper.isEnabled() — the single,
 * independent on/off switch for Quick Capture. This has no relationship
 * to Android's own notification permission or to Later's reminder
 * notifications; disabling Quick Capture stops this service and nothing
 * else.
 */
public class QuickCaptureForegroundService extends Service {

    /** Starts the service only if Quick Capture is currently enabled. No-op otherwise. */
    public static void startIfEnabled(Context context) {
        if (!QuickCaptureNotificationHelper.isEnabled(context)) return;
        Intent intent = new Intent(context, QuickCaptureForegroundService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }

    /** Stops the service — used when the user explicitly disables Quick Capture. */
    public static void stop(Context context) {
        context.stopService(new Intent(context, QuickCaptureForegroundService.class));
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Notification notification = QuickCaptureNotificationHelper.buildCleanStateNotification(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                QuickCaptureNotificationHelper.NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            );
        } else {
            startForeground(QuickCaptureNotificationHelper.NOTIFICATION_ID, notification);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // START_STICKY: if the system kills this service under memory
        // pressure, it restarts it and the persistent notification
        // reappears — appropriate for something meant to always be
        // available, same intent as "persistent" in the product spec.
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
