package app.later.mobile;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/**
 * QUICK CAPTURE — persistence owner.
 *
 * A plain notify()'d notification with setOngoing(true) is only a soft
 * hint on modern Android — it can still be swiped away. Real
 * swipe-immunity requires the notification be owned by an active
 * foreground service via startForeground().
 *
 * Ownership rule: this service is the ONLY place that posts to
 * QuickCaptureNotificationHelper.NOTIFICATION_ID, always via
 * startForeground() (the correct way to update a foreground
 * notification's content). Every other class calls the static show*()
 * methods below instead of touching NotificationManager directly.
 *
 * CORRECTION (verified against Android's official Android 14 behavior
 * docs after a real-device report): an earlier version of this comment
 * claimed that updating the notification from outside the service was
 * "the confirmed reason" it stayed swipeable. That was an unverified
 * hypothesis and it was wrong. On Android 14+ a foreground service's
 * setOngoing(true) notification is dismissible by OS design no matter
 * who posts it (still non-dismissible only while the device is locked
 * and on "Clear all"; CallStyle/media/device-policy notifications are
 * exempt but this is none of those). No API can make it truly
 * un-swipeable. So instead every state carries a delete intent; when
 * the user swipes it away the system fires ACTION_DISMISSED at
 * QuickCaptureReceiver, which calls restore() here, and this service —
 * still running, only its notification was dismissed — puts the
 * notification straight back exactly as it was.
 *
 * Respects QuickCaptureNotificationHelper.isEnabled() — the single,
 * independent on/off switch for Quick Capture. This has no relationship
 * to Android's own notification permission or to Later's reminder
 * notifications; disabling Quick Capture stops this service and nothing
 * else.
 */
public class QuickCaptureForegroundService extends Service {

    private static final String ACTION_SHOW_CLEAN = "app.later.mobile.action.QC_SHOW_CLEAN";
    private static final String ACTION_SHOW_SAVED = "app.later.mobile.action.QC_SHOW_SAVED";
    private static final String ACTION_SHOW_FAILURE = "app.later.mobile.action.QC_SHOW_FAILURE";
    private static final String ACTION_SHOW_SAVING = "app.later.mobile.action.QC_SHOW_SAVING";
    private static final String ACTION_SHOW_PARTIAL = "app.later.mobile.action.QC_SHOW_PARTIAL";
    private static final String ACTION_RESTORE = "app.later.mobile.action.QC_RESTORE";
    private static final String EXTRA_TEXT = "text";
    private static final String EXTRA_LABEL = "label";

    private static final long SAVED_REVERT_DELAY_MS = 1800;
    // Long enough to actually read "Reminder set for 10:47 pm".
    private static final long SAVED_WITH_REMINDER_REVERT_DELAY_MS = 6000;
    private static final long PARTIAL_REVERT_DELAY_MS = 20000;
    private static final long FAILURE_REVERT_DELAY_MS = 20000;
    // Must exceed HeadlessCaptureActivity's 15s safety timeout, so a
    // genuinely-slow-but-successful save isn't declared failed early.
    private static final long SAVING_TIMEOUT_MS = 20000;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingRevert;

    // The notification most recently posted, so a swipe-dismissal can be
    // undone by re-posting exactly what the user just dismissed.
    private Notification lastNotification;

    // ---------------------------------------------------------------
    // Static entry points — every other class calls these instead of
    // touching NotificationManager or QuickCaptureNotificationHelper's
    // builders directly.
    // ---------------------------------------------------------------

    /** Starts the service (clean state) only if Quick Capture is currently enabled. No-op otherwise. */
    public static void startIfEnabled(Context context) {
        if (!QuickCaptureNotificationHelper.isEnabled(context)) return;
        startWithAction(context, ACTION_SHOW_CLEAN, null);
    }

    /**
     * Shown the instant text is submitted. Re-posting the notification is
     * what stops Android's reply spinner; `rawText` is kept so that if no
     * result ever arrives, the timeout can fall back to the failure state
     * (which preserves the text on the clipboard) instead of leaving the
     * notification stuck on "Saving…".
     */
    public static void showSaving(Context context, String rawText) {
        if (!QuickCaptureNotificationHelper.isEnabled(context)) return;
        startWithAction(context, ACTION_SHOW_SAVING, rawText);
    }

    /**
     * Called when the user swipes the notification away. Puts back
     * whatever was showing. Uses a plain startService() first: this app
     * already has a running foreground service, so it isn't "idle", and
     * the service only needs to re-post, not to become foreground again.
     * Falls back to startForegroundService() if the service had died.
     */
    public static void restore(Context context) {
        if (!QuickCaptureNotificationHelper.isEnabled(context)) return;
        Intent intent = new Intent(context, QuickCaptureForegroundService.class).setAction(ACTION_RESTORE);
        try {
            context.startService(intent);
        } catch (RuntimeException e) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent);
                }
            } catch (RuntimeException ignored) {
                // Nothing more we're allowed to do from here.
            }
        }
    }

    /** Shows the brief "Saved ✓" state, then this service reverts itself to clean. */
    public static void showSaved(Context context) {
        showSaved(context, null);
    }

    /**
     * "Saved ✓", plus — when the capture also set a reminder — the time it
     * was set for (e.g. "Reminder set for 10:47 pm"). Only ever called
     * after JS has READ BACK the alarm from Android, never on hope.
     */
    public static void showSaved(Context context, String reminderLabel) {
        if (!QuickCaptureNotificationHelper.isEnabled(context)) return;
        startWithAction(context, ACTION_SHOW_SAVED, null, reminderLabel);
    }

    /**
     * The item WAS saved but the reminder it asked for could NOT be
     * confirmed. Deliberately not the failure state: the text must not be
     * copied to the clipboard for re-pasting (that would create a
     * duplicate), and it must not read as a success either.
     */
    public static void showPartial(Context context, String detail) {
        if (!QuickCaptureNotificationHelper.isEnabled(context)) return;
        startWithAction(context, ACTION_SHOW_PARTIAL, null, detail);
    }

    /** Shows the failure/retry state, then this service reverts itself to clean after a longer delay. */
    public static void showFailure(Context context, String rawText) {
        if (!QuickCaptureNotificationHelper.isEnabled(context)) return;
        startWithAction(context, ACTION_SHOW_FAILURE, rawText);
    }

    /** Stops the service entirely — used when the user explicitly disables Quick Capture. */
    public static void stop(Context context) {
        context.stopService(new Intent(context, QuickCaptureForegroundService.class));
    }

    private static void startWithAction(Context context, String action, String text) {
        startWithAction(context, action, text, null);
    }

    private static void startWithAction(Context context, String action, String text, String label) {
        Intent intent = new Intent(context, QuickCaptureForegroundService.class).setAction(action);
        if (text != null) intent.putExtra(EXTRA_TEXT, text);
        if (label != null) intent.putExtra(EXTRA_LABEL, label);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }

    // ---------------------------------------------------------------
    // Instance lifecycle — the ONLY code in the app that calls
    // startForeground() for this notification ID.
    // ---------------------------------------------------------------

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (action == null) action = ACTION_SHOW_CLEAN;

        // A dismissal-restore must NOT touch any running revert/timeout:
        // it only puts back what the user swiped away, in its current state.
        if (ACTION_RESTORE.equals(action)) {
            try {
                postForeground(
                    lastNotification != null
                        ? lastNotification
                        : QuickCaptureNotificationHelper.buildCleanStateNotification(this)
                );
            } catch (RuntimeException e) {
                // If Android refuses to let a service that had died re-enter the
                // foreground from the background, an uncaught exception here would
                // take down the whole app process. Losing the notification until
                // the next app open is the lesser failure.
                stopSelf();
            }
            return START_STICKY;
        }

        cancelPendingRevert();

        switch (action) {
            case ACTION_SHOW_SAVING: {
                String savingText = intent != null ? intent.getStringExtra(EXTRA_TEXT) : "";
                postForeground(QuickCaptureNotificationHelper.buildSavingNotification(this));
                scheduleSavingTimeout(savingText);
                break;
            }
            case ACTION_SHOW_SAVED: {
                String reminderLabel = intent != null ? intent.getStringExtra(EXTRA_LABEL) : null;
                boolean hasLabel = reminderLabel != null && !reminderLabel.isEmpty();
                postForeground(QuickCaptureNotificationHelper.buildSavedConfirmationNotification(this, reminderLabel));
                scheduleRevertToClean(hasLabel ? SAVED_WITH_REMINDER_REVERT_DELAY_MS : SAVED_REVERT_DELAY_MS);
                break;
            }
            case ACTION_SHOW_PARTIAL: {
                String partialDetail = intent != null ? intent.getStringExtra(EXTRA_LABEL) : null;
                postForeground(QuickCaptureNotificationHelper.buildPartialNotification(this, partialDetail));
                scheduleRevertToClean(PARTIAL_REVERT_DELAY_MS);
                break;
            }
            case ACTION_SHOW_FAILURE: {
                String failedText = intent != null ? intent.getStringExtra(EXTRA_TEXT) : "";
                postForeground(QuickCaptureNotificationHelper.buildFailureNotification(this, failedText));
                scheduleRevertToClean(FAILURE_REVERT_DELAY_MS);
                break;
            }
            case ACTION_SHOW_CLEAN:
            default:
                postForeground(QuickCaptureNotificationHelper.buildCleanStateNotification(this));
                break;
        }

        return START_STICKY;
    }

    private void postForeground(Notification notification) {
        lastNotification = notification;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                QuickCaptureNotificationHelper.NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            );
        } else {
            startForeground(QuickCaptureNotificationHelper.NOTIFICATION_ID, notification);
        }
    }

    /**
     * If no result (saved OR failed) arrives within SAVING_TIMEOUT_MS,
     * assume the capture is lost: show the failure state, which copies the
     * text to the clipboard so nothing the user typed is lost. Any real
     * result cancels this via cancelPendingRevert() at the top of
     * onStartCommand.
     */
    private void scheduleSavingTimeout(String rawText) {
        final String textForFailure = rawText != null ? rawText : "";
        pendingRevert = () -> {
            if (!QuickCaptureNotificationHelper.isEnabled(this)) return;
            postForeground(QuickCaptureNotificationHelper.buildFailureNotification(this, textForFailure));
            scheduleRevertToClean(FAILURE_REVERT_DELAY_MS);
        };
        mainHandler.postDelayed(pendingRevert, SAVING_TIMEOUT_MS);
    }

    private void scheduleRevertToClean(long delayMs) {
        pendingRevert = () -> {
            if (!QuickCaptureNotificationHelper.isEnabled(this)) return;
            postForeground(QuickCaptureNotificationHelper.buildCleanStateNotification(this));
        };
        mainHandler.postDelayed(pendingRevert, delayMs);
    }

    private void cancelPendingRevert() {
        if (pendingRevert != null) {
            mainHandler.removeCallbacks(pendingRevert);
            pendingRevert = null;
        }
    }

    @Override
    public void onDestroy() {
        cancelPendingRevert();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
