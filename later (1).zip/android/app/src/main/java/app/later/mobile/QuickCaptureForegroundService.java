package app.later.mobile;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/**
 * QUICK CAPTURE — persistence owner.
 *
 * A plain notify()'d notification with setOngoing(true) is only a soft
 * hint on modern Android — it can still be swiped away. Real
 * swipe-immunity requires the notification be owned by an active
 * foreground service via startForeground().
 *
 * IMPORTANT (fixed after a real-device bug report): the first version
 * of this service only called startForeground() once, in onCreate().
 * Every SUBSEQUENT update (saved confirmation, failure state, reset
 * back to clean) went through QuickCaptureNotificationHelper calling a
 * raw NotificationManager.notify() from OUTSIDE this service — which is
 * the confirmed reason the notification stayed swipeable in practice:
 * updating a foreground-service-owned notification from anywhere other
 * than the service itself decouples it from that protection. Fixed by
 * making this service the ONLY place that ever posts to
 * QuickCaptureNotificationHelper.NOTIFICATION_ID, always via
 * startForeground() again (the officially correct way to update a
 * foreground notification's content without losing its pinned state).
 * Every other class now calls the static show*() methods below instead
 * of touching NotificationManager directly.
 *
 * Respects QuickCaptureNotificationHelper.isEnabled() — the single,
 * independent on/off switch for Quick Capture. This has no relationship
 * to Android's own notification permission or to Later's reminder
 * notifications; disabling Quick Capture stops this service and nothing
 * else.
 */
public class QuickCaptureForegroundService extends Service {

    private static final String ACTION_SHOW_CLEAN = "app.later.mobile.action.QC_SHOW_CLEAN";
    private static final String ACTION_SHOW_SAVED = "app.later.mobile.action.QC_SHOW_SAVED";
    private static final String ACTION_SHOW_FAILURE = "app.later.mobile.action.QC_SHOW_FAILURE";
    private static final String EXTRA_TEXT = "text";

    private static final long SAVED_REVERT_DELAY_MS = 1800;
    private static final long FAILURE_REVERT_DELAY_MS = 20000;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingRevert;

    // ---------------------------------------------------------------
    // Static entry points — every other class calls these instead of
    // touching NotificationManager or QuickCaptureNotificationHelper's
    // builders directly.
    // ---------------------------------------------------------------

    /** Starts the service (clean state) only if Quick Capture is currently enabled. No-op otherwise. */
    public static void startIfEnabled(Context context) {
        if (!QuickCaptureNotificationHelper.isEnabled(context)) return;
        startWithAction(context, ACTION_SHOW_CLEAN, null);
    }

    /** Shows the brief "Saved ✓" state, then this service reverts itself to clean. */
    public static void showSaved(Context context) {
        if (!QuickCaptureNotificationHelper.isEnabled(context)) return;
        startWithAction(context, ACTION_SHOW_SAVED, null);
    }

    /** Shows the failure/retry state, then this service reverts itself to clean after a longer delay. */
    public static void showFailure(Context context, String rawText) {
        if (!QuickCaptureNotificationHelper.isEnabled(context)) return;
        startWithAction(context, ACTION_SHOW_FAILURE, rawText);
    }

    /** Stops the service entirely — used when the user explicitly disables Quick Capture. */
    public static void stop(Context context) {
        context.stopService(new Intent(context, QuickCaptureForegroundService.class));
    }

    private static void startWithAction(Context context, String action, String text) {
        Intent intent = new Intent(context, QuickCaptureForegroundService.class).setAction(action);
        if (text != null) intent.putExtra(EXTRA_TEXT, text);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }

    // ---------------------------------------------------------------
    // Instance lifecycle — the ONLY code in the app that calls
    // startForeground() for this notification ID.
    // ---------------------------------------------------------------

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (action == null) action = ACTION_SHOW_CLEAN;

        cancelPendingRevert();

        switch (action) {
            case ACTION_SHOW_SAVED:
                postForeground(QuickCaptureNotificationHelper.buildSavedConfirmationNotification(this));
                scheduleRevertToClean(SAVED_REVERT_DELAY_MS);
                break;
            case ACTION_SHOW_FAILURE:
                String text = intent != null ? intent.getStringExtra(EXTRA_TEXT) : "";
                postForeground(QuickCaptureNotificationHelper.buildFailureNotification(this, text));
                scheduleRevertToClean(FAILURE_REVERT_DELAY_MS);
                break;
            case ACTION_SHOW_CLEAN:
            default:
                postForeground(QuickCaptureNotificationHelper.buildCleanStateNotification(this));
                break;
        }

        return START_STICKY;
    }

    private void postForeground(Notification notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                QuickCaptureNotificationHelper.NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            );
        } else {
            startForeground(QuickCaptureNotificationHelper.NOTIFICATION_ID, notification);
        }
    }

    private void scheduleRevertToClean(long delayMs) {
        pendingRevert = () -> {
            if (!QuickCaptureNotificationHelper.isEnabled(this)) return;
            postForeground(QuickCaptureNotificationHelper.buildCleanStateNotification(this));
        };
        mainHandler.postDelayed(pendingRevert, delayMs);
    }

    private void cancelPendingRevert() {
        if (pendingRevert != null) {
            mainHandler.removeCallbacks(pendingRevert);
            pendingRevert = null;
        }
    }

    @Override
    public void onDestroy() {
        cancelPendingRevert();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
