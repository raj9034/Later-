package app.later.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * QUICK CAPTURE NOTIFICATION — pure builders only.
 *
 * IMPORTANT (fixed after a real-device bug report): this used to also
 * POST notifications directly via a raw NotificationManager.notify()
 * call, invoked from QuickCapturePlugin/QuickCaptureReceiver — i.e.
 * from OUTSIDE the running QuickCaptureForegroundService. That's the
 * confirmed reason the notification remained swipeable: a foreground
 * service's swipe-immunity comes specifically from the SERVICE calling
 * startForeground(); updating the same notification ID afterward via
 * an external, unrelated notify() call decouples it from that binding,
 * silently reverting it to an ordinary dismissible notification. Only
 * the initial post (from the service's own onCreate) was ever truly
 * protected — every update after that (saved confirmation, failure
 * state, reset to clean) was posted the unprotected way.
 *
 * This class now only BUILDS Notification objects. Only
 * QuickCaptureForegroundService is allowed to actually post/update the
 * notification (always via startForeground(), the correct way to update
 * a foreground notification's content). See that class for the show*()
 * methods other components call instead of anything here.
 *
 * CORRECTION: the paragraph above claims the external notify() was "the
 * confirmed reason" the notification stayed swipeable. That was a
 * hypothesis that was never verified, and it was wrong: on Android 14+
 * a foreground service's setOngoing notification is dismissible by OS
 * design regardless of who posts it (see the ANDROID 14+ NOTE below).
 * Keeping the service as the sole owner is still good hygiene, but it
 * was never what decided swipe-ability.
 */
public class QuickCaptureNotificationHelper {

    /*
     * ANDROID 14+ NOTE (verified against Android's official behavior-change
     * docs after a real-device report): setOngoing(true) — including on a
     * foreground service's notification — no longer makes a notification
     * un-swipeable. It is dismissible by the user, by design; the only
     * exceptions are (a) while the device is locked, (b) "Clear all", and
     * (c) CallStyle / media / device-policy notifications, which this is
     * not and must not pretend to be. There is therefore NO API that makes
     * this notification genuinely un-dismissible on Android 14+.
     *
     * What we do instead: attach a delete intent to every state. When the
     * user swipes it away, Android fires that intent at
     * QuickCaptureReceiver (ACTION_DISMISSED), which asks the foreground
     * service to put the notification straight back. The service is still
     * running the whole time — only its notification was dismissed — so
     * this is a re-post, not a restart.
     */

    static final String CHANNEL_ID = "quick_capture_channel";
    static final int NOTIFICATION_ID = 771001;
    static final String REMOTE_INPUT_KEY = "quick_capture_input";
    static final String ACTION_SUBMIT = "app.later.mobile.ACTION_QUICK_CAPTURE_SUBMIT";
    static final String ACTION_DISMISSED = "app.later.mobile.ACTION_QUICK_CAPTURE_DISMISSED";

    private static final String PREFS_NAME = "quick_capture_settings";
    private static final String PREF_ENABLED = "enabled";

    /**
     * The one on/off switch for the persistent capture notification —
     * completely independent of Android's own per-app notification
     * permission and of Later's reminder-notification channel. Default
     * true (persistent capture is on unless the user explicitly turns
     * it off).
     */
    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(PREF_ENABLED, true);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(PREF_ENABLED, enabled)
            .apply();
    }

    static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CHANNEL_ID) != null) return;

        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID,
            "Later quick capture",
            NotificationManager.IMPORTANCE_LOW // no sound/heads-up — this is a standing input surface, not an alert
        );
        channel.setDescription("A persistent shortcut for capturing something into Later without opening the app.");
        channel.setShowBadge(false);
        nm.createNotificationChannel(channel);
    }

    /**
     * Fired by the system when the user swipes the notification away.
     * Explicit component + FLAG_IMMUTABLE (nothing needs to be written
     * into it). App-initiated cancels (disabling Quick Capture) do NOT
     * fire delete intents, so this can't fight the on/off toggle.
     */
    private static PendingIntent dismissedPendingIntent(Context context) {
        Intent dismissed = new Intent(context, QuickCaptureReceiver.class).setAction(ACTION_DISMISSED);
        return PendingIntent.getBroadcast(
            context,
            2,
            dismissed,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );
    }

    /**
     * Shown the instant text is submitted, before the (possibly slow)
     * save finishes. Two jobs: (1) Android leaves a spinner on a
     * RemoteInput reply until the app re-posts the notification, so
     * without this the spinner ran for the entire save; (2) honest
     * feedback that something is happening. Deliberately has no reply
     * action, so a second submit can't be fired mid-save.
     */
    static Notification buildSavingNotification(Context context) {
        ensureChannel(context);
        return new Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(getIconRes(context))
            .setContentTitle("Later")
            .setContentText("Saving…")
            .setOngoing(true)
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .setDeleteIntent(dismissedPendingIntent(context))
            .build();
    }

    /** The default, ready-for-input state. */
    static Notification buildCleanStateNotification(Context context) {
        ensureChannel(context);

        Intent submitIntent = new Intent(context, QuickCaptureReceiver.class).setAction(ACTION_SUBMIT);
        PendingIntent submitPendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            submitIntent,
            PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        RemoteInput remoteInput = new RemoteInput.Builder(REMOTE_INPUT_KEY)
            .setLabel("What do you want to remember?")
            .build();

        Notification.Action captureAction = new Notification.Action.Builder(
            getIconRes(context),
            "Remember",
            submitPendingIntent
        )
            .addRemoteInput(remoteInput)
            .setAllowGeneratedReplies(false)
            .build();

        return new Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(getIconRes(context))
            .setContentTitle("Later")
            .setContentText("What do you want to remember?")
            .setOngoing(true)
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .setDeleteIntent(dismissedPendingIntent(context))
            .addAction(captureAction)
            .build();
    }

    /** Briefly shown after a successful save, before auto-reverting to the clean state. */
    static Notification buildSavedConfirmationNotification(Context context) {
        ensureChannel(context);
        return new Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(getIconRes(context))
            .setContentTitle("Later")
            .setContentText("Saved ✓")
            .setOngoing(true)
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .setDeleteIntent(dismissedPendingIntent(context))
            .build();
    }

    /**
     * Failure fallback. Android's notification API has no way to
     * re-populate the RemoteInput text field for a retry — that's a
     * real platform limitation, not something worked around here. The
     * honest alternative used instead: the exact text is written to
     * the clipboard (writing is unrestricted; only background *reading*
     * of another app's clipboard is restricted, which is not what this
     * is) and tapping the notification opens Later straight into a
     * blank capture via the same existing widget-tap path — so the
     * user pastes and resubmits through the full, already-reliable
     * capture flow. Nothing new was built in JS for this path.
     */
    static Notification buildFailureNotification(Context context, String rawText) {
        ensureChannel(context);

        ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText("Later capture", rawText));
        }

        Intent openBlankCapture = new Intent(context, MainActivity.class);
        openBlankCapture.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        openBlankCapture.putExtra("later_widget_capture", true); // reuses the existing widget-tap → blank capture path verbatim

        PendingIntent contentIntent = PendingIntent.getActivity(
            context,
            1,
            openBlankCapture,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        return new Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(getIconRes(context))
            .setContentTitle("Couldn't save")
            .setContentText("Copied to clipboard — tap to open Later and paste")
            .setOngoing(true)
            .setShowWhen(false)
            .setContentIntent(contentIntent)
            .setDeleteIntent(dismissedPendingIntent(context))
            .build();
    }

    private static int getIconRes(Context context) {
        // A plain vector, deliberately NOT the app's launcher mipmap.
        // @mipmap/ic_launcher is an <adaptive-icon> (separate
        // foreground/background layers) which is not a valid
        // Notification.Builder.setSmallIcon() input — using it was the
        // actual reason the notification never posted at all, silently,
        // even though the channel was created successfully.
        return R.drawable.ic_quick_capture_notification;
    }
}
