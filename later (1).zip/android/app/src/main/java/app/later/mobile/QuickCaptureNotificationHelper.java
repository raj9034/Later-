package app.later.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

/**
 * QUICK CAPTURE NOTIFICATION.
 *
 * Owns the one persistent, ongoing notification: its clean/ready state,
 * its brief "Saved" confirmation, and its failure state. Called from
 * QuickCaptureReceiver (after a submit), QuickCapturePlugin (when the
 * live/headless save settles), and QuickCaptureBootReceiver (to
 * re-post after reboot, since notifications don't survive a reboot).
 *
 * Deliberately separate from Later's existing reminder-notification
 * system (@capacitor/local-notifications) — different channel,ance
 * different notification ID, different responsibility. Reminder
 * notifications tell the user something; this one is purely an input
 * surface. They must never collide or interfere with each other.
 */
public class QuickCaptureNotificationHelper {

    static final String CHANNEL_ID = "quick_capture_channel";
    static final int NOTIFICATION_ID = 771001;
    static final String REMOTE_INPUT_KEY = "quick_capture_input";
    static final String ACTION_SUBMIT = "app.later.mobile.ACTION_QUICK_CAPTURE_SUBMIT";

    private static final Handler mainHandler = new Handler(Looper.getMainLooper());

    static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CHANNEL_ID) != null) return;

        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID,
            "Later quick capture",
            NotificationManager.IMPORTANCE_LOW // no sound/heads-up — this is a standing input surface, not an alert
        );
        channel.setDescription("A persistent shortcut for capturing something into Later without opening the app.");
        channel.setShowBadge(false);
        nm.createNotificationChannel(channel);
    }

    /** The default, ready-for-input state. Posted on launch, after boot, and after a save settles. */
    public static void postCleanState(Context context) {
        ensureChannel(context);

        Intent submitIntent = new Intent(context, QuickCaptureReceiver.class).setAction(ACTION_SUBMIT);
        PendingIntent submitPendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            submitIntent,
            PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        RemoteInput remoteInput = new RemoteInput.Builder(REMOTE_INPUT_KEY)
            .setLabel("What do you want to remember?")
            .build();

        Notification.Action captureAction = new Notification.Action.Builder(
            getIconRes(context),
            "Remember",
            submitPendingIntent
        )
            .addRemoteInput(remoteInput)
            .setAllowGeneratedReplies(false)
            .build();

        Notification notification = new Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(getIconRes(context))
            .setContentTitle("Later")
            .setContentText("What do you want to remember?")
            .setOngoing(true)
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .addAction(captureAction)
            .build();

        notify(context, notification);
    }

    /** Briefly shown after a successful save, then auto-resets to the clean state. */
    public static void postSavedConfirmation(Context context) {
        Notification notification = new Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(getIconRes(context))
            .setContentTitle("Later")
            .setContentText("Saved ✓")
            .setOngoing(true)
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .build();

        notify(context, notification);

        mainHandler.postDelayed(() -> postCleanState(context), 1800);
    }

    /**
     * Failure fallback. Android's notification API has no way to
     * re-populate the RemoteInput text field for a retry — that's a
     * real platform limitation, not something worked around here. The
     * honest alternative used instead: the exact text is written to
     * the clipboard (writing is unrestricted; only background *reading*
     * of another app's clipboard is restricted, which is not what this
     * is) and tapping the notification opens Later straight into a
     * blank capture via the same existing widget-tap path — so the
     * user pastes and resubmits through the full, already-reliable
     * capture flow. Nothing new was built in JS for this path.
     */
    public static void postFailureState(Context context, String rawText) {
        ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText("Later capture", rawText));
        }

        Intent openBlankCapture = new Intent(context, MainActivity.class);
        openBlankCapture.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        openBlankCapture.putExtra("later_widget_capture", true); // reuses the existing widget-tap → blank capture path verbatim

        PendingIntent contentIntent = PendingIntent.getActivity(
            context,
            1,
            openBlankCapture,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        Notification notification = new Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(getIconRes(context))
            .setContentTitle("Couldn't save")
            .setContentText("Copied to clipboard — tap to open Later and paste")
            .setOngoing(true)
            .setShowWhen(false)
            .setContentIntent(contentIntent)
            .build();

        notify(context, notification);

        // Give the user real time to notice and act before resetting
        // back to the clean input state.
        mainHandler.postDelayed(() -> postCleanState(context), 20000);
    }

    private static void notify(Context context, Notification notification) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(NOTIFICATION_ID, notification);
        }
    }

    private static int getIconRes(Context context) {
        // Reuses the existing app icon — no new drawable asset added.
        return context.getApplicationInfo().icon;
    }
}
