package app.later.mobile;

import android.app.RemoteInput;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.getcapacitor.Bridge;
import com.getcapacitor.JSObject;
import com.getcapacitor.PluginHandle;

/**
 * Fires when the user submits text from the persistent quick-capture
 * notification. Deliberately a plain BroadcastReceiver, not an
 * Activity — this is what makes "no visible app launch on submit"
 * possible at all; a getActivity() PendingIntent would necessarily
 * bring some Activity to the foreground, a getBroadcast() one never
 * does.
 */
public class QuickCaptureReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!QuickCaptureNotificationHelper.ACTION_SUBMIT.equals(intent.getAction())) return;

        Bundle remoteInputResults = RemoteInput.getResultsFromIntent(intent);
        CharSequence input = remoteInputResults != null
            ? remoteInputResults.getCharSequence(QuickCaptureNotificationHelper.REMOTE_INPUT_KEY)
            : null;

        String text = input != null ? input.toString() : null;

        // Empty submit: do nothing, per spec — not even a reset, since
        // the notification is already in its clean state (RemoteInput
        // actions don't stay expanded/edited once dismissed).
        if (text == null || text.trim().isEmpty()) {
            return;
        }

        // Trim only leading/trailing whitespace from the RemoteInput
        // wrapper itself — never touch the interior of the string.
        // URLs, punctuation, and internal whitespace must survive
        // exactly as typed/pasted.
        final String preservedText = text.trim();

        if (MainActivity.isReachable()) {
            deliverToLiveBridge(context, preservedText);
        } else {
            HeadlessCaptureActivity.start(context, preservedText);
        }
    }

    /**
     * Fast path: the real app's WebView is already alive (foregrounded
     * or backgrounded-but-not-destroyed). Hand the text straight to its
     * already-running JS via the real Capacitor bridge — no new WebView,
     * nothing visible changes about whatever app the user is actually
     * looking at.
     */
    private void deliverToLiveBridge(Context fallbackContext, String text) {
        MainActivity activity = MainActivity.getCurrentInstance();
        if (activity == null) {
            // Reachability flipped between the check above and now
            // (rare race, e.g. Activity destroyed mid-call) — fall back
            // to the headless path rather than lose the capture.
            HeadlessCaptureActivity.start(fallbackContext, text);
            return;
        }

        Bridge bridge = activity.getBridge();
        if (bridge == null) {
            HeadlessCaptureActivity.start(activity, text);
            return;
        }

        PluginHandle handle = bridge.getPlugin("QuickCapture");
        if (handle == null || !(handle.getInstance() instanceof QuickCapturePlugin)) {
            HeadlessCaptureActivity.start(activity, text);
            return;
        }

        QuickCapturePlugin plugin = (QuickCapturePlugin) handle.getInstance();
        JSObject data = new JSObject();
        data.put("text", text);
        plugin.notifyCaptureTextReceived(data);
    }
}
