package app.later.mobile;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Handles ONE thing: the user swiping the persistent notification away.
 *
 * Android 14+ lets users dismiss even a foreground service's ongoing
 * notification and offers no way to forbid it, so every notification
 * state carries a delete intent that lands here, and we ask the service
 * to put it straight back (see QuickCaptureForegroundService).
 *
 * This class no longer handles a SUBMIT. It used to, and for a
 * not-yet-running app it then called startActivity() — which Android 12+
 * blocks for a receiver that a notification action triggered ("notification
 * trampoline"), the root cause of captures hanging on "Saving…" and then
 * failing. The Send action now launches QuickCaptureEntryActivity
 * directly. A receiver is fine for this dismissal because it starts no
 * activity.
 */
public class QuickCaptureReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (QuickCaptureNotificationHelper.ACTION_DISMISSED.equals(intent.getAction())) {
            QuickCaptureForegroundService.restore(context);
        }
    }
}
