package app.later.mobile.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import app.later.mobile.MainActivity

val WIDGET_CAPTURE_KEY = ActionParameters.Key<Boolean>("later_widget_capture")

/**
 * Phase 1: a single-tap "Add to Later" home screen widget.
 * Tapping anywhere on the widget opens MainActivity with an extra flag
 * that tells the web app to jump straight to the capture screen.
 */
class LaterWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent {
            WidgetContent()
        }
    }

    @Composable
    private fun WidgetContent() {
        // Grounded Motion palette (forest green on cream), matches the app's light theme.
        val backgroundColor = Color(0xFFF6F3EC)
        val accentColor = Color(0xFF1F5A44)

        Column(
            modifier = GlanceModifier
                .fillMaxSize()
                .background(ColorProvider(backgroundColor))
                .padding(12.dp)
                .clickable(
                    actionStartActivity<MainActivity>(
                        parameters = actionParametersOf(WIDGET_CAPTURE_KEY to true)
                    )
                ),
            verticalAlignment = Alignment.Vertical.CenterVertically,
            horizontalAlignment = Alignment.Horizontal.CenterHorizontally
        ) {
            Text(
                text = "+",
                style = TextStyle(
                    color = ColorProvider(accentColor),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold
                )
            )
            Text(
                text = "Add to Later",
                style = TextStyle(
                    color = ColorProvider(accentColor),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            )
        }
    }
}

/**
 * The receiver Android's widget host talks to. Required boilerplate for Glance:
 * this is what gets referenced from AndroidManifest.xml and res/xml/later_widget_info.xml.
 */
class LaterWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = LaterWidget()
}
