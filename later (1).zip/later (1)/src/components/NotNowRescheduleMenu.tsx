import React, { useState } from 'react';
import { useLater } from '../context/LaterContext';
import {
  getReschedulePresetOptions,
  getDefaultDatetimeLocalString,
  ReschedulePresetOption,
} from '../utils/rescheduleHelper';
import {
  Clock,
  Sun,
  Moon,
  CalendarDays,
  CalendarRange,
  Calendar,
  X,
  Check,
  ArrowLeft,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NotNowRescheduleMenuProps {
  itemId: string;
  itemTitle?: string;
  onClose: () => void;
  onRescheduled?: () => void;
}

export const NotNowRescheduleMenu: React.FC<NotNowRescheduleMenuProps> = ({
  itemId,
  itemTitle,
  onClose,
  onRescheduled,
}) => {
  const { rescheduleItem } = useLater();
  const [showCustomPicker, setShowCustomPicker] = useState(false);
  const [customDateTime, setCustomDateTime] = useState(() => getDefaultDatetimeLocalString(2));

  const presetOptions = getReschedulePresetOptions();

  const handleSelectPreset = (preset: ReschedulePresetOption) => {
    const iso = preset.getIso();
    rescheduleItem(itemId, iso);
    if (onRescheduled) {
      onRescheduled();
    }
    onClose();
  };

  const handleConfirmCustom = () => {
    if (!customDateTime) return;
    const iso = new Date(customDateTime).toISOString();
    rescheduleItem(itemId, iso);
    if (onRescheduled) {
      onRescheduled();
    }
    onClose();
  };

  const renderPresetIcon = (id: string) => {
    switch (id) {
      case 'in_10_minutes':
        return <Clock className="w-4 h-4 text-amber-400/90" />;
      case 'in_1_hour':
        return <Clock className="w-4 h-4 text-[#AAAAAA]" />;
      case 'tonight':
        return <Moon className="w-4 h-4 text-[#818CF8]" />;
      case 'tomorrow':
        return <Sun className="w-4 h-4 text-[#FBBF24]" />;
      case 'this_weekend':
        return <CalendarDays className="w-4 h-4 text-[#34D399]" />;
      case 'next_week':
        return <CalendarRange className="w-4 h-4 text-[#60A5FA]" />;
      default:
        return <Clock className="w-4 h-4 text-[#888888]" />;
    }
  };

  return (
    <div
      id="not-now-reschedule-menu"
      className="p-4 rounded-xl bg-[#171717] border border-[#2B2B2B] shadow-xl text-left space-y-3"
    >
      {/* Header */}
      <div className="flex items-center justify-between pb-2.5 border-b border-[#242424]">
        <div>
          <span className="text-[10px] font-mono uppercase tracking-widest text-[#888888]">
            Not now
          </span>
          <h3 className="text-sm font-medium text-[#F0F0F0]">
            When should I bring this back?
          </h3>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="p-1 rounded-md text-[#777777] hover:text-[#DDDDDD] hover:bg-[#222222] transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {!showCustomPicker ? (
        <div className="space-y-1.5">
          {presetOptions.map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => handleSelectPreset(opt)}
              className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-[#1F1F1F] hover:bg-[#272727] border border-[#282828] hover:border-[#353535] text-left transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                {renderPresetIcon(opt.id)}
                <span className="text-xs font-medium text-[#EDEDED] group-hover:text-[#FFFFFF]">
                  {opt.label}
                </span>
              </div>
              <span className="text-[11px] font-mono text-[#777777] group-hover:text-[#AAAAAA]">
                {opt.sublabel}
              </span>
            </button>
          ))}

          {/* Option 7: Choose date & time */}
          <button
            type="button"
            onClick={() => setShowCustomPicker(true)}
            className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-[#1F1F1F] hover:bg-[#272727] border border-[#282828] hover:border-[#353535] text-left transition-colors cursor-pointer group"
          >
            <div className="flex items-center gap-2.5">
              <Calendar className="w-4 h-4 text-[#A78BFA]" />
              <span className="text-xs font-medium text-[#EDEDED] group-hover:text-[#FFFFFF]">
                Choose date & time
              </span>
            </div>
            <span className="text-[11px] font-mono text-[#777777] group-hover:text-[#AAAAAA]">
              Custom
            </span>
          </button>
        </div>
      ) : (
        <div className="space-y-3 pt-1">
          <div className="flex items-center gap-1.5 text-xs text-[#AAAAAA]">
            <button
              type="button"
              onClick={() => setShowCustomPicker(false)}
              className="p-1 rounded hover:bg-[#242424] text-[#888888] hover:text-[#FFFFFF] cursor-pointer flex items-center gap-1 text-[11px] font-mono"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to presets</span>
            </button>
          </div>

          <div>
            <label className="block text-[11px] font-mono text-[#888888] mb-1.5">
              Select date & time (in your local timezone)
            </label>
            <input
              type="datetime-local"
              value={customDateTime}
              min={getDefaultDatetimeLocalString(0)}
              onChange={(e) => setCustomDateTime(e.target.value)}
              className="w-full bg-[#121212] border border-[#303030] rounded-lg px-3 py-2 text-xs text-[#EDEDED] outline-none focus:border-[#555555]"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#242424]">
            <button
              type="button"
              onClick={() => setShowCustomPicker(false)}
              className="px-3 py-1.5 text-xs text-[#888888] hover:text-[#DDDDDD] cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleConfirmCustom}
              disabled={!customDateTime}
              className="px-4 py-1.5 rounded-lg bg-[#EDEDED] text-[#0A0A0A] font-medium text-xs hover:bg-[#FFFFFF] cursor-pointer disabled:opacity-40 flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Reschedule</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
