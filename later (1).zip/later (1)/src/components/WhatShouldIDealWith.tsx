import React from 'react';
import { useLater } from '../context/LaterContext';
import { SavedItem } from '../types';
import { formatReminderTime } from '../utils/timeScheduler';
import { Bell, RotateCcw, Clock, AlertCircle, Sparkles, Check } from 'lucide-react';
import { motion } from 'motion/react';

interface SurfacedPriorityItem {
  item: SavedItem;
  score: number;
  badgeLabel: string;
  iconType: 'bell' | 'repeat' | 'clock' | 'alert' | 'sparkles';
  accentColor: string;
}

const ACTION_KEYWORDS = [
  'tax',
  'taxes',
  'receipt',
  'receipts',
  'application',
  'invoice',
  'submit',
  'pay',
  'doctor',
  'dentist',
  'interview',
  'flight',
  'passport',
  'visa',
  'rent',
  'bill',
  'exam',
  'exams',
  'urgent',
  'asap',
];

export const WhatShouldIDealWith: React.FC = () => {
  const { items, setSelectedItem, toggleDone, setPendingItemForSchedule } = useLater();

  const now = new Date();

  // Evaluate candidate items for intelligent resurfacing
  const evaluatedItems: SurfacedPriorityItem[] = [];

  items.forEach((item) => {
    // Skip completed or archived items
    if (item.isDone || item.isArchived) return;

    let score = 0;
    let badgeLabel = '';
    let iconType: 'bell' | 'repeat' | 'clock' | 'alert' | 'sparkles' = 'bell';
    let accentColor = '#FFAA33';

    const postponeCount = item.postponeCount || 0;
    const itemTitleLower = (item.title || '').toLowerCase();
    const itemRawLower = (item.rawInput || '').toLowerCase();
    const isActionableContent =
      item.contentType === 'task' ||
      item.contentType === 'event' ||
      item.intent === 'complete' ||
      item.intent === 'call' ||
      item.intent === 'buy' ||
      ACTION_KEYWORDS.some((kw) => itemTitleLower.includes(kw) || itemRawLower.includes(kw));

    const scheduledTime = item.reminderTime || item.scheduledFor || item.reminder?.scheduledAt;

    if (scheduledTime) {
      const schedDate = new Date(scheduledTime);
      const diffMs = schedDate.getTime() - now.getTime();
      const diffHours = diffMs / (1000 * 60 * 60);

      const isToday =
        schedDate.getDate() === now.getDate() &&
        schedDate.getMonth() === now.getMonth() &&
        schedDate.getFullYear() === now.getFullYear();

      // Rule 1 & 2: Items scheduled for today or approaching
      if (isToday) {
        const timeFormatted = schedDate.toLocaleTimeString('en-US', {
          hour: 'numeric',
          minute: '2-digit',
        });

        if (diffHours <= 0) {
          // Overdue or due now
          score = 120;
          badgeLabel = `Due · Today at ${timeFormatted}`;
          iconType = 'bell';
          accentColor = '#FFAA33';
        } else if (diffHours <= 2) {
          // Approaching in under 2 hours
          score = 115;
          badgeLabel = `Approaching · Today at ${timeFormatted}`;
          iconType = 'bell';
          accentColor = '#FFAA33';
        } else {
          // Scheduled for today
          score = 100;
          badgeLabel = `Today · ${timeFormatted}`;
          iconType = 'bell';
          accentColor = '#FFAA33';
        }
      } else if (diffHours > 0 && diffHours <= 6) {
        // Approaching within 6 hours (e.g. early tomorrow)
        score = 90;
        badgeLabel = `Approaching · ${formatReminderTime(scheduledTime)}`;
        iconType = 'clock';
        accentColor = '#FFAA33';
      }
    }

    // Rule 3: Items that have been postponed/rescheduled repeatedly
    if (postponeCount >= 2) {
      const postponeScore = 95 + postponeCount * 5;
      // If postpone score is higher or equal, surface with postponement badge
      if (postponeScore >= score) {
        score = postponeScore;
        badgeLabel = `You've postponed this ${postponeCount} times`;
        iconType = 'repeat';
        accentColor = '#00DD77';
      }
    } else if (postponeCount === 1 && score < 70) {
      score = 70;
      badgeLabel = 'Postponed 1 time';
      iconType = 'repeat';
      accentColor = '#888888';
    }

    // Rule 4: Long-unresolved actionable items (created >= 3 days ago)
    if (score < 80 && isActionableContent && item.createdAt) {
      const createdDate = new Date(item.createdAt);
      const daysUnresolved = Math.floor((now.getTime() - createdDate.getTime()) / (1000 * 60 * 60 * 24));
      if (daysUnresolved >= 3) {
        const unresolvedScore = 65 + Math.min(daysUnresolved * 2, 20);
        if (unresolvedScore > score) {
          score = unresolvedScore;
          badgeLabel = `Unresolved for ${daysUnresolved} days`;
          iconType = 'clock';
          accentColor = '#888888';
        }
      }
    }

    // Rule 5: Actionable items that appear important based on actual content
    if (score < 60 && isActionableContent) {
      const hasImportantKeyword = ACTION_KEYWORDS.some(
        (kw) => itemTitleLower.includes(kw) || itemRawLower.includes(kw)
      );
      if (hasImportantKeyword) {
        score = 60;
        badgeLabel = 'Important action item';
        iconType = 'alert';
        accentColor = '#FFAA33';
      }
    }

    // Rule 6: Recently captured items that appear time-sensitive (< 24h old)
    if (score < 50 && item.createdAt) {
      const createdDate = new Date(item.createdAt);
      const hoursOld = (now.getTime() - createdDate.getTime()) / (1000 * 60 * 60);
      if (hoursOld < 24 && isActionableContent) {
        score = 50;
        badgeLabel = 'Recently captured · Action needed';
        iconType = 'sparkles';
        accentColor = '#00DD77';
      }
    }

    // Only include items that crossed the threshold
    if (score >= 45) {
      evaluatedItems.push({
        item,
        score,
        badgeLabel,
        iconType,
        accentColor,
      });
    }
  });

  // Sort by score descending and take the top 3-4 items
  const surfacedList = evaluatedItems
    .sort((a, b) => b.score - a.score)
    .slice(0, 4);

  if (surfacedList.length === 0) {
    return null;
  }

  return (
    <div
      id="what-should-i-deal-with-section"
      className="w-full mb-6 rounded-xl bg-[#111111] border border-[#222222] p-3.5 space-y-3"
    >
      {/* Section Header */}
      <div className="flex items-center justify-between px-0.5">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono font-semibold tracking-wider text-[#FFAA33] uppercase">
            WHAT SHOULD I DEAL WITH?
          </span>
        </div>
        <span className="text-[10px] font-mono text-[#666666]">
          {surfacedList.length} priority {surfacedList.length === 1 ? 'item' : 'items'}
        </span>
      </div>

      {/* Surfaced Items Grid / List */}
      <div className="space-y-2">
        {surfacedList.map(({ item, badgeLabel, iconType, accentColor }) => {
          return (
            <motion.div
              key={`deal-with-${item.id}`}
              id={`resurfaced-item-${item.id}`}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              className="group relative flex items-center justify-between p-2.5 px-3 rounded-lg bg-[#161616] border border-[#242424] hover:border-[#333333] hover:bg-[#1A1A1A] transition-all cursor-pointer"
              onClick={() => setSelectedItem(item)}
            >
              {/* Left Details */}
              <div className="flex items-start gap-2.5 min-w-0 flex-1 mr-3">
                <div className="mt-0.5 shrink-0">
                  {iconType === 'bell' && <Bell className="w-3.5 h-3.5" style={{ color: accentColor }} />}
                  {iconType === 'repeat' && <RotateCcw className="w-3.5 h-3.5" style={{ color: accentColor }} />}
                  {iconType === 'clock' && <Clock className="w-3.5 h-3.5" style={{ color: accentColor }} />}
                  {iconType === 'alert' && <AlertCircle className="w-3.5 h-3.5" style={{ color: accentColor }} />}
                  {iconType === 'sparkles' && <Sparkles className="w-3.5 h-3.5" style={{ color: accentColor }} />}
                </div>

                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium text-[#EDEDED] truncate group-hover:text-[#FFFFFF] transition-colors">
                    {item.title}
                  </p>
                  <p className="text-[11px] font-mono text-[#888888] mt-0.5 flex items-center gap-1">
                    {badgeLabel}
                  </p>
                </div>
              </div>

              {/* Right Quick Actions */}
              <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                {/* Reschedule Button */}
                <button
                  id={`reschedule-resurfaced-btn-${item.id}`}
                  type="button"
                  onClick={() => setPendingItemForSchedule(item)}
                  className="p-1.5 rounded-md text-[#666666] hover:text-[#FFAA33] hover:bg-[#222222] transition-colors cursor-pointer"
                  title="Reschedule / Change time"
                >
                  <Clock className="w-3.5 h-3.5" />
                </button>

                {/* Complete Button */}
                <button
                  id={`complete-resurfaced-btn-${item.id}`}
                  type="button"
                  onClick={() => toggleDone(item.id)}
                  className="p-1.5 rounded-md text-[#666666] hover:text-[#00DD77] hover:bg-[#222222] transition-colors cursor-pointer"
                  title="Mark as completed"
                >
                  <Check className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
