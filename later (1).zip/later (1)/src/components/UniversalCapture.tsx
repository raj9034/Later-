import React, { useState, useRef, useMemo } from 'react';
import { useLater } from '../context/LaterContext';
import { ItemReminder } from '../types';
import { parseNaturalDateTime, formatDateTimeHint } from '../utils/naturalLanguageTime';
import {
  ArrowUp,
  Image as ImageIcon,
  Clipboard,
  X,
  Clock,
  Calendar,
  Sparkles,
  Check,
  RotateCcw,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const UniversalCapture: React.FC = () => {
  const { saveItem } = useLater();
  const [content, setContent] = useState('');
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [isFocused, setIsFocused] = useState(false);
  const [showScheduler, setShowScheduler] = useState(false);
  const [manualReminder, setManualReminder] = useState<ItemReminder | null>(null);
  const [ignoreDetectedTime, setIgnoreDetectedTime] = useState(false);

  // Custom Date/Time input state for the scheduler popover
  const [customDate, setCustomDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().slice(0, 10);
  });
  const [customTime, setCustomTime] = useState('09:00');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Real-time natural language date/time parsing
  const detectedTime = useMemo(() => {
    if (!content.trim() || ignoreDetectedTime) return null;
    const res = parseNaturalDateTime(content);
    return res.hasExplicitTime ? res : null;
  }, [content, ignoreDetectedTime]);

  const handleSave = () => {
    const trimmed = content.trim();
    if (!trimmed && !attachedImage) return;

    let reminderToSave: ItemReminder | null | undefined = undefined;

    if (manualReminder) {
      reminderToSave = manualReminder;
    } else if (ignoreDetectedTime) {
      reminderToSave = {
        type: 'none',
        reminderStatus: 'waiting',
      };
    }

    saveItem(trimmed, attachedImage || undefined, reminderToSave);

    setContent('');
    setAttachedImage(null);
    setManualReminder(null);
    setIgnoreDetectedTime(false);
    setShowScheduler(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSave();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setAttachedImage(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePasteClipboard = async () => {
    try {
      if (navigator.clipboard) {
        const clipboardItems = await navigator.clipboard.read().catch(() => null);
        if (clipboardItems) {
          for (const item of clipboardItems) {
            const imageType = item.types.find((t) => t.startsWith('image/'));
            if (imageType) {
              const blob = await item.getType(imageType);
              const reader = new FileReader();
              reader.onload = (event) => {
                if (event.target?.result) {
                  setAttachedImage(event.target.result as string);
                }
              };
              reader.readAsDataURL(blob);
              return;
            }
          }
        }

        const text = await navigator.clipboard.readText();
        if (text) {
          setContent((prev) => (prev ? `${prev} ${text}` : text));
          setIgnoreDetectedTime(false);
        }
      }
    } catch {
      // Permission fallback
    }
  };

  // Preset Handlers
  const handleSelectPreset = (preset: 'later_today' | 'tonight' | 'tomorrow_morning' | 'tomorrow_evening' | 'this_weekend' | 'next_week') => {
    const now = new Date();
    const target = new Date();

    if (preset === 'later_today') {
      if (now.getHours() < 16) {
        target.setHours(17, 0, 0, 0); // 5:00 PM
      } else {
        target.setTime(now.getTime() + 3 * 60 * 60 * 1000); // in 3 hours
      }
    } else if (preset === 'tonight') {
      if (now.getHours() >= 20) {
        target.setTime(now.getTime() + 2 * 60 * 60 * 1000);
      } else {
        target.setHours(20, 30, 0, 0);
      }
    } else if (preset === 'tomorrow_morning') {
      target.setDate(target.getDate() + 1);
      target.setHours(9, 0, 0, 0);
    } else if (preset === 'tomorrow_evening') {
      target.setDate(target.getDate() + 1);
      target.setHours(19, 0, 0, 0);
    } else if (preset === 'this_weekend') {
      const day = now.getDay();
      const diff = (6 - day + 7) % 7 || 7;
      target.setDate(target.getDate() + diff);
      target.setHours(10, 0, 0, 0);
    } else if (preset === 'next_week') {
      const day = now.getDay();
      const diff = (1 - day + 7) % 7 || 7;
      target.setDate(target.getDate() + diff);
      target.setHours(9, 0, 0, 0);
    }

    setManualReminder({
      type: 'scheduled',
      scheduledAt: target.toISOString(),
      reminderStatus: 'waiting',
    });
    setIgnoreDetectedTime(false);
    setShowScheduler(false);
  };

  const handleApplyCustom = () => {
    if (!customDate || !customTime) return;
    const [year, month, day] = customDate.split('-').map(Number);
    const [hours, minutes] = customTime.split(':').map(Number);

    const targetDate = new Date(year, month - 1, day, hours, minutes, 0, 0);
    setManualReminder({
      type: 'scheduled',
      scheduledAt: targetDate.toISOString(),
      reminderStatus: 'waiting',
    });
    setIgnoreDetectedTime(false);
    setShowScheduler(false);
  };

  const handleClearReminder = () => {
    setManualReminder(null);
    setIgnoreDetectedTime(true);
    setShowScheduler(false);
  };

  const openSchedulerWithPrefill = () => {
    const baseDate = manualReminder?.scheduledAt
      ? new Date(manualReminder.scheduledAt)
      : detectedTime?.scheduledAt
      ? new Date(detectedTime.scheduledAt)
      : (() => {
          const d = new Date();
          d.setDate(d.getDate() + 1);
          d.setHours(9, 0, 0, 0);
          return d;
        })();

    setCustomDate(
      `${baseDate.getFullYear()}-${String(baseDate.getMonth() + 1).padStart(2, '0')}-${String(
        baseDate.getDate()
      ).padStart(2, '0')}`
    );
    setCustomTime(
      `${String(baseDate.getHours()).padStart(2, '0')}:${String(baseDate.getMinutes()).padStart(
        2,
        '0'
      )}`
    );
    setShowScheduler(true);
  };

  return (
    <div id="universal-capture-container" className="w-full relative">
      <div
        className={`relative rounded-xl bg-[#141414] border transition-all duration-150 ${
          isFocused
            ? 'border-[#383838] shadow-[0_0_20px_rgba(0,0,0,0.5)]'
            : 'border-[#202020] hover:border-[#2A2A2A]'
        }`}
      >
        {/* Screenshot / Photo Attachment Preview */}
        {attachedImage && (
          <div className="p-3 pb-0 flex items-center gap-3">
            <div className="relative w-16 h-16 rounded-lg overflow-hidden border border-[#2D2D2D] bg-[#0A0A0A]">
              <img
                src={attachedImage}
                alt="Captured"
                className="w-full h-full object-cover"
              />
              <button
                id="remove-attached-image-btn"
                type="button"
                onClick={() => setAttachedImage(null)}
                className="absolute top-1 right-1 p-0.5 rounded-full bg-[#000000]/80 text-[#FFFFFF] hover:bg-[#000000] cursor-pointer"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <div className="text-xs text-[#888888]">
              <p className="text-[#CCCCCC] font-medium">Screenshot attached</p>
              <p>Type a note or press remember</p>
            </div>
          </div>
        )}

        {/* Input Area */}
        <textarea
          id="universal-capture-textarea"
          ref={textareaRef}
          value={content}
          onChange={(e) => {
            setContent(e.target.value);
            if (ignoreDetectedTime) setIgnoreDetectedTime(false);
          }}
          onKeyDown={handleKeyDown}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          placeholder="What do you want to remember later?"
          rows={isFocused || content || attachedImage ? 2 : 1}
          className="w-full bg-transparent px-4 py-3.5 text-sm text-[#EDEDED] placeholder-[#555555] resize-none outline-none font-sans leading-relaxed"
        />

        {/* Detected / Selected Time Indicator Banner */}
        {(manualReminder?.scheduledAt || detectedTime) && (
          <div className="px-3 pb-2 pt-0 flex items-center gap-2 flex-wrap">
            {manualReminder?.scheduledAt ? (
              <div
                id="manual-reminder-badge"
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#1C1A14] border border-[#4A3B18] text-[#FFAA33] text-xs font-mono"
              >
                <Clock className="w-3 h-3 text-[#FFAA33]" />
                <button
                  type="button"
                  onClick={openSchedulerWithPrefill}
                  className="hover:underline cursor-pointer"
                >
                  {formatDateTimeHint(new Date(manualReminder.scheduledAt))}
                </button>
                <button
                  id="clear-manual-reminder-btn"
                  type="button"
                  onClick={() => setManualReminder(null)}
                  className="p-0.5 rounded hover:bg-[#2E2410] text-[#DDAA33] hover:text-[#FFFFFF] cursor-pointer ml-1"
                  title="Remove manual schedule"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ) : detectedTime ? (
              <div
                id="detected-reminder-badge"
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#1A1A1A] border border-[#2E2E2E] text-[#CCCCCC] text-xs font-mono"
              >
                <Sparkles className="w-3 h-3 text-[#00DD77]" />
                <span>
                  {detectedTime.timeHint || 'Scheduled'}
                </span>
                <button
                  id="edit-detected-reminder-btn"
                  type="button"
                  onClick={openSchedulerWithPrefill}
                  className="ml-1 text-[11px] text-[#888888] hover:text-[#FFFFFF] underline cursor-pointer"
                >
                  Edit
                </button>
                <button
                  id="dismiss-detected-reminder-btn"
                  type="button"
                  onClick={() => setIgnoreDetectedTime(true)}
                  className="p-0.5 rounded hover:bg-[#252525] text-[#777777] hover:text-[#FFFFFF] cursor-pointer ml-1"
                  title="Don't set reminder"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ) : null}
          </div>
        )}

        {/* Bottom Actions Row */}
        <div className="flex items-center justify-between px-3 pb-2.5 pt-1 border-t border-[#1C1C1C]">
          <div className="flex items-center gap-1.5">
            {/* Attach Image / Screenshot */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />
            <button
              id="capture-screenshot-btn"
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-1.5 rounded-md text-[#777777] hover:text-[#DDDDDD] hover:bg-[#1E1E1E] transition-colors cursor-pointer flex items-center gap-1 text-xs"
              title="Attach screenshot or photo"
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline text-[11px]">Screenshot</span>
            </button>

            {/* Paste from clipboard */}
            <button
              id="capture-paste-btn"
              type="button"
              onClick={handlePasteClipboard}
              className="p-1.5 rounded-md text-[#777777] hover:text-[#DDDDDD] hover:bg-[#1E1E1E] transition-colors cursor-pointer flex items-center gap-1 text-xs"
              title="Paste from clipboard"
            >
              <Clipboard className="w-3.5 h-3.5" />
              <span className="hidden sm:inline text-[11px]">Paste</span>
            </button>

            {/* Set Time Trigger Button */}
            <button
              id="capture-set-time-btn"
              type="button"
              onClick={openSchedulerWithPrefill}
              className={`p-1.5 px-2 rounded-md transition-colors cursor-pointer flex items-center gap-1.5 text-xs ${
                manualReminder || detectedTime
                  ? 'text-[#FFAA33] bg-[#221A0F] border border-[#3A2D14]'
                  : 'text-[#777777] hover:text-[#DDDDDD] hover:bg-[#1E1E1E]'
              }`}
              title="Set reminder time"
            >
              <Clock className="w-3.5 h-3.5" />
              <span className="text-[11px]">
                {manualReminder ? 'Change time' : 'Set time'}
              </span>
            </button>
          </div>

          {/* Save Action Button */}
          <button
            id="capture-save-btn"
            type="button"
            onClick={handleSave}
            disabled={!content.trim() && !attachedImage}
            className={`flex items-center justify-center p-1.5 px-3 rounded-lg text-xs font-medium transition-all ${
              content.trim() || attachedImage
                ? 'bg-[#EAEAEA] text-[#0A0A0A] hover:bg-[#FFFFFF] cursor-pointer shadow-sm'
                : 'bg-[#1C1C1C] text-[#555555] cursor-not-allowed'
            }`}
          >
            <span>Remember</span>
            <ArrowUp className="w-3.5 h-3.5 ml-1" />
          </button>
        </div>
      </div>

      {/* Scheduler Popover / Dropdown Modal */}
      <AnimatePresence>
        {showScheduler && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="w-full max-w-sm rounded-xl bg-[#141414] border border-[#282828] shadow-2xl p-4 text-[#EDEDED]"
            >
              <div className="flex items-center justify-between pb-3 border-b border-[#222222]">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-[#FFAA33]" />
                  <h3 className="text-sm font-semibold text-[#FFFFFF]">Schedule Reminder</h3>
                </div>
                <button
                  id="close-scheduler-modal-btn"
                  type="button"
                  onClick={() => setShowScheduler(false)}
                  className="p-1 rounded-md text-[#777777] hover:text-[#FFFFFF] hover:bg-[#202020] cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Quick Presets Grid */}
              <div className="mt-3 space-y-1.5">
                <p className="text-[11px] font-mono text-[#777777] uppercase">Quick Presets</p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    id="preset-later-today-btn"
                    type="button"
                    onClick={() => handleSelectPreset('later_today')}
                    className="p-2.5 rounded-lg bg-[#1A1A1A] border border-[#262626] hover:border-[#383838] hover:bg-[#222222] text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-medium text-[#EEEEEE]">Later today</p>
                    <p className="text-[10px] text-[#777777] font-mono mt-0.5">5:00 PM / +3h</p>
                  </button>

                  <button
                    id="preset-tonight-btn"
                    type="button"
                    onClick={() => handleSelectPreset('tonight')}
                    className="p-2.5 rounded-lg bg-[#1A1A1A] border border-[#262626] hover:border-[#383838] hover:bg-[#222222] text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-medium text-[#EEEEEE]">Tonight</p>
                    <p className="text-[10px] text-[#777777] font-mono mt-0.5">8:30 PM</p>
                  </button>

                  <button
                    id="preset-tomorrow-morning-btn"
                    type="button"
                    onClick={() => handleSelectPreset('tomorrow_morning')}
                    className="p-2.5 rounded-lg bg-[#1A1A1A] border border-[#262626] hover:border-[#383838] hover:bg-[#222222] text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-medium text-[#EEEEEE]">Tomorrow morning</p>
                    <p className="text-[10px] text-[#777777] font-mono mt-0.5">9:00 AM</p>
                  </button>

                  <button
                    id="preset-tomorrow-evening-btn"
                    type="button"
                    onClick={() => handleSelectPreset('tomorrow_evening')}
                    className="p-2.5 rounded-lg bg-[#1A1A1A] border border-[#262626] hover:border-[#383838] hover:bg-[#222222] text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-medium text-[#EEEEEE]">Tomorrow evening</p>
                    <p className="text-[10px] text-[#777777] font-mono mt-0.5">7:00 PM</p>
                  </button>

                  <button
                    id="preset-weekend-btn"
                    type="button"
                    onClick={() => handleSelectPreset('this_weekend')}
                    className="p-2.5 rounded-lg bg-[#1A1A1A] border border-[#262626] hover:border-[#383838] hover:bg-[#222222] text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-medium text-[#EEEEEE]">This weekend</p>
                    <p className="text-[10px] text-[#777777] font-mono mt-0.5">Saturday 10:00 AM</p>
                  </button>

                  <button
                    id="preset-next-week-btn"
                    type="button"
                    onClick={() => handleSelectPreset('next_week')}
                    className="p-2.5 rounded-lg bg-[#1A1A1A] border border-[#262626] hover:border-[#383838] hover:bg-[#222222] text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-medium text-[#EEEEEE]">Next week</p>
                    <p className="text-[10px] text-[#777777] font-mono mt-0.5">Monday 9:00 AM</p>
                  </button>
                </div>
              </div>

              {/* Exact Date & Time Picker */}
              <div className="mt-4 pt-3 border-t border-[#222222] space-y-2">
                <p className="text-[11px] font-mono text-[#777777] uppercase">Custom Date & Time</p>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-[#666666] block mb-1">Date</label>
                    <input
                      id="custom-date-input"
                      type="date"
                      value={customDate}
                      onChange={(e) => setCustomDate(e.target.value)}
                      className="w-full bg-[#1A1A1A] border border-[#2C2C2C] rounded-lg px-2.5 py-1.5 text-xs text-[#FFFFFF] outline-none focus:border-[#444444] font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-[#666666] block mb-1">Time</label>
                    <input
                      id="custom-time-input"
                      type="time"
                      value={customTime}
                      onChange={(e) => setCustomTime(e.target.value)}
                      className="w-full bg-[#1A1A1A] border border-[#2C2C2C] rounded-lg px-2.5 py-1.5 text-xs text-[#FFFFFF] outline-none focus:border-[#444444] font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-[#222222] flex items-center justify-between gap-2">
                <button
                  id="clear-reminder-btn"
                  type="button"
                  onClick={handleClearReminder}
                  className="px-3 py-1.5 rounded-lg text-xs text-[#888888] hover:text-[#DDDDDD] hover:bg-[#202020] transition-colors cursor-pointer flex items-center gap-1"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>No reminder</span>
                </button>

                <button
                  id="apply-custom-time-btn"
                  type="button"
                  onClick={handleApplyCustom}
                  className="px-4 py-1.5 rounded-lg bg-[#EAEAEA] text-[#0A0A0A] hover:bg-[#FFFFFF] text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Set time</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
