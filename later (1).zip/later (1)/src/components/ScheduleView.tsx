import React from 'react';
import { useLater } from '../context/LaterContext';
import { SavedItem } from '../types';
import { TimelineItemRow } from './TimelineItemRow';
import { Calendar } from 'lucide-react';

export const ScheduleView: React.FC = () => {
  const { items } = useLater();

  // Filter unarchived items that have scheduled times, sort strictly chronologically
  const scheduledItems = items
    .filter((i) => !i.isArchived && (i.reminderTime || i.scheduledFor))
    .sort((a, b) => {
      const timeA = new Date(a.reminderTime || a.scheduledFor!).getTime();
      const timeB = new Date(b.reminderTime || b.scheduledFor!).getTime();
      return timeA - timeB;
    });

  // Group by specific calendar day / label
  const groupedByDay: { label: string; items: SavedItem[] }[] = [];

  const now = new Date();
  const todayStr = now.toDateString();

  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toDateString();

  scheduledItems.forEach((item) => {
    const rawTime = item.reminderTime || item.scheduledFor!;
    const itemDate = new Date(rawTime);
    const itemDateStr = itemDate.toDateString();

    let dayLabel = '';
    if (itemDateStr === todayStr) {
      dayLabel = 'Today';
    } else if (itemDateStr === tomorrowStr) {
      dayLabel = 'Tomorrow';
    } else {
      dayLabel = itemDate.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'short',
        day: 'numeric',
      });
    }

    const existingGroup = groupedByDay.find((g) => g.label === dayLabel);
    if (existingGroup) {
      existingGroup.items.push(item);
    } else {
      groupedByDay.push({ label: dayLabel, items: [item] });
    }
  });

  return (
    <div className="w-full space-y-6 pt-2 pb-16">
      <div className="flex items-center justify-between px-3 py-1">
        <span className="text-xs font-mono text-[#888888]">Future Schedule</span>
        <span className="text-xs font-mono text-[#555555]">
          {scheduledItems.length} reminders
        </span>
      </div>

      {groupedByDay.length === 0 ? (
        <div className="py-16 text-center">
          <Calendar className="w-8 h-8 mx-auto text-[#333333] mb-3" />
          <p className="text-sm text-[#777777]">No scheduled reminders</p>
          <p className="text-xs text-[#444444] mt-1 font-mono">
            Items saved with dates will appear here chronologically
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {groupedByDay.map((group) => (
            <div key={group.label} className="space-y-1">
              <div className="flex items-center gap-2 px-3 py-1">
                <span className="text-[11px] font-mono font-medium tracking-wider text-[#D0D0D0]">
                  {group.label}
                </span>
                <div className="h-px flex-1 bg-[#1A1A1A]" />
                <span className="text-[10px] font-mono text-[#555555]">
                  {group.items.length}
                </span>
              </div>

              <div className="divide-y divide-[#161616]">
                {group.items.map((item) => (
                  <TimelineItemRow key={item.id} item={item} />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
