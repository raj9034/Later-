import React, { useState } from 'react';
import { useLater } from '../context/LaterContext';
import {
  getPendingRecallItems,
  getMemoryMomentHeading,
  getMemoryMomentSubtext,
} from '../utils/reminderService';
import { getReschedulePresetOptions } from '../utils/rescheduleHelper';
import { PendingRecallModal } from './PendingRecallModal';
import {
  Play,
  Camera,
  MapPin,
  FileText,
  Phone,
  ExternalLink,
  ArrowRight,
  Clock,
  Sparkles,
  Calendar,
} from 'lucide-react';
import { motion } from 'motion/react';

export const MemoryMoment: React.FC = () => {
  const { items, setSelectedItem, openItem, rescheduleItem } = useLater();
  const [showAllModal, setShowAllModal] = useState(false);
  const [activeSnoozeId, setActiveSnoozeId] = useState<string | null>(null);

  const pendingItems = getPendingRecallItems(items);
  const presetOptions = getReschedulePresetOptions();

  if (pendingItems.length === 0) {
    return null;
  }

  const renderIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Play className="w-3 h-3 fill-current" />;
      case 'screenshot':
      case 'image':
        return <Camera className="w-3 h-3" />;
      case 'place':
        return <MapPin className="w-3 h-3" />;
      case 'person':
      case 'phone_number':
        return <Phone className="w-3 h-3" />;
      case 'link':
      case 'article':
      case 'product':
        return <ExternalLink className="w-3 h-3" />;
      default:
        return <FileText className="w-3 h-3" />;
    }
  };

  const handleSelectPreset = (itemId: string, iso: string, e: React.MouseEvent) => {
    e.stopPropagation();
    rescheduleItem(itemId, iso);
    setActiveSnoozeId(null);
  };

  // Case 1: Single item surfaced
  if (pendingItems.length === 1) {
    const item = pendingItems[0];
    const heading = getMemoryMomentHeading(item);
    const subtext = getMemoryMomentSubtext(item);
    const isSnoozing = activeSnoozeId === item.id;

    return (
      <div id="memory-moment-card" className="mb-6">
        <div className="rounded-xl bg-[#141414] border border-[#262626] p-4 shadow-sm transition-all hover:border-[#333333]">
          {/* Header */}
          <div className="flex items-center justify-between gap-2 pb-2.5 mb-2.5 border-b border-[#202020]">
            <div className="flex items-center gap-1.5">
              <span className="text-amber-400/90 text-xs select-none">✦</span>
              <span className="text-[11px] font-mono tracking-widest uppercase text-[#AAAAAA] font-semibold">
                From your memory
              </span>
            </div>
            <span className="text-[11px] font-mono text-[#666666]">
              {subtext}
            </span>
          </div>

          {/* Context phrase */}
          <div className="text-xs font-medium text-[#D8C7A0] mb-2">
            {heading}
          </div>

          {/* Item Content Preview */}
          <div
            onClick={() => setSelectedItem(item)}
            className="flex items-center justify-between gap-3 p-2.5 rounded-lg bg-[#191919] border border-[#242424] hover:bg-[#1F1F1F] transition-colors cursor-pointer group"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-7 h-7 rounded bg-[#242424] flex items-center justify-center text-[#999999] group-hover:text-[#E0E0E0] shrink-0">
                {renderIcon(item.contentType || item.type)}
              </div>
              <div className="min-w-0">
                <div className="text-xs font-medium text-[#EEEEEE] group-hover:text-[#FFFFFF] truncate">
                  {item.title}
                </div>
                {item.summary && item.summary !== item.title && (
                  <div className="text-[11px] text-[#777777] truncate">
                    {item.summary}
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  if (item.url) {
                    openItem(item.id);
                  } else {
                    setSelectedItem(item);
                  }
                }}
                className="px-2.5 py-1 rounded bg-[#282828] hover:bg-[#333333] text-[#E0E0E0] text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1"
              >
                <span>Open</span>
                <ArrowRight className="w-3 h-3 text-[#888888]" />
              </button>
            </div>
          </div>

          {/* Footer calm action */}
          <div className="flex items-center justify-end pt-2 mt-1 relative">
            <button
              type="button"
              onClick={() => setActiveSnoozeId(isSnoozing ? null : item.id)}
              className="text-[11px] font-mono text-[#777777] hover:text-[#CCCCCC] flex items-center gap-1 cursor-pointer"
            >
              <Clock className="w-3 h-3" />
              <span>Not now</span>
            </button>

            {isSnoozing && (
              <div className="absolute right-0 bottom-full mb-1 w-48 bg-[#202020] border border-[#333333] rounded-lg shadow-xl py-1 z-20 text-[11px] font-mono">
                <div className="px-2.5 py-1 text-[10px] text-[#777777] border-b border-[#2A2A2A]">
                  When should I bring this back?
                </div>
                {presetOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={(e) => handleSelectPreset(item.id, opt.getIso(), e)}
                    className="w-full px-2.5 py-1.5 text-left text-[#CCCCCC] hover:bg-[#2A2A2A] hover:text-[#FFFFFF] flex items-center justify-between"
                  >
                    <span>{opt.label}</span>
                    <span className="text-[10px] text-[#666666]">{opt.sublabel}</span>
                  </button>
                ))}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedItem(item);
                    setActiveSnoozeId(null);
                  }}
                  className="w-full px-2.5 py-1.5 text-left text-[#A78BFA] hover:bg-[#2A2A2A] border-t border-[#2A2A2A] flex items-center justify-between"
                >
                  <span>Choose date & time</span>
                  <Calendar className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Case 2: Multiple items surfaced (>1)
  const previewItems = pendingItems.slice(0, 3);

  return (
    <>
      <div id="memory-moment-multi-card" className="mb-6">
        <div className="rounded-xl bg-[#141414] border border-[#262626] p-4 shadow-sm transition-all hover:border-[#333333]">
          {/* Header */}
          <div className="flex items-center justify-between pb-2.5 mb-2 border-b border-[#202020]">
            <div className="flex items-center gap-1.5">
              <span className="text-amber-400/90 text-xs select-none">✦</span>
              <span className="text-[11px] font-mono tracking-widest uppercase text-[#AAAAAA] font-semibold">
                From your memory
              </span>
            </div>

            <button
              type="button"
              onClick={() => setShowAllModal(true)}
              className="text-[11px] font-mono text-[#D8C7A0] hover:text-[#FFFFFF] transition-colors cursor-pointer flex items-center gap-1"
            >
              <span>See all ({pendingItems.length})</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <p className="text-xs text-[#999999] mb-3">
            A few things are waiting for you.
          </p>

          {/* Up to 3 preview items */}
          <div className="space-y-1.5">
            {previewItems.map((item) => (
              <div
                key={item.id}
                onClick={() => setSelectedItem(item)}
                className="flex items-center justify-between gap-3 p-2 rounded-lg bg-[#181818] border border-[#222222] hover:bg-[#1E1E1E] transition-colors cursor-pointer group"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-6 h-6 rounded bg-[#222222] flex items-center justify-center text-[#888888] group-hover:text-[#E0E0E0] shrink-0">
                    {renderIcon(item.contentType || item.type)}
                  </div>
                  <div className="text-xs font-medium text-[#CCCCCC] group-hover:text-[#FFFFFF] truncate">
                    {item.title}
                  </div>
                </div>

                <div className="text-[10px] font-mono text-[#666666] shrink-0">
                  {getMemoryMomentSubtext(item)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Modal for full list */}
      <PendingRecallModal
        isOpen={showAllModal}
        onClose={() => setShowAllModal(false)}
      />
    </>
  );
};
