import React from 'react';
import { useLater } from '../context/LaterContext';
import { SwipeView } from '../types';

const VIEWS: SwipeView[] = [
  'ALL',
  'LINKS',
  'SCREENSHOTS',
  'NOTES',
  'TASKS',
  'PEOPLE',
  'PLACES',
];

export const HorizontalSwipeNav: React.FC = () => {
  const { activeSwipeView, setActiveSwipeView, items } = useLater();

  const getCountForView = (view: SwipeView): number => {
    const unarchived = items.filter((i) => !i.isArchived);
    if (view === 'ALL') return unarchived.length;
    if (view === 'LINKS')
      return unarchived.filter((i) => {
        const t = i.contentType || i.type;
        return t === 'link' || t === 'video' || t === 'product' || t === 'article';
      }).length;
    if (view === 'SCREENSHOTS')
      return unarchived.filter((i) => {
        const t = i.contentType || i.type;
        return t === 'screenshot' || t === 'image';
      }).length;
    if (view === 'NOTES')
      return unarchived.filter((i) => {
        const t = i.contentType || i.type;
        return t === 'note' || t === 'idea';
      }).length;
    if (view === 'TASKS')
      return unarchived.filter((i) => {
        const t = i.contentType || i.type;
        return t === 'task' || t === 'event';
      }).length;
    if (view === 'PEOPLE')
      return unarchived.filter((i) => {
        const t = i.contentType || i.type;
        return t === 'person' || t === 'phone_number';
      }).length;
    if (view === 'PLACES')
      return unarchived.filter((i) => {
        const t = i.contentType || i.type;
        return t === 'place';
      }).length;
    return 0;
  };

  return (
    <div className="w-full overflow-x-auto no-scrollbar py-2 border-b border-[#181818]">
      <div className="flex items-center gap-1.5 px-0.5 min-w-max">
        {VIEWS.map((view) => {
          const isActive = activeSwipeView === view;
          const count = getCountForView(view);

          return (
            <button
              key={view}
              onClick={() => setActiveSwipeView(view)}
              className={`px-3 py-1 rounded-full text-xs font-mono transition-all cursor-pointer flex items-center gap-1.5 ${
                isActive
                  ? 'bg-[#222222] text-[#F0F0F0] border border-[#333333]'
                  : 'text-[#666666] hover:text-[#AAAAAA] hover:bg-[#141414] border border-transparent'
              }`}
            >
              <span>{view}</span>
              {count > 0 && (
                <span
                  className={`text-[10px] ${
                    isActive ? 'text-[#AAAAAA]' : 'text-[#555555]'
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
