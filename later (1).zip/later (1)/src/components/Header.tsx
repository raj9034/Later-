import React, { useState, useEffect } from 'react';
import { useLater } from '../context/LaterContext';
import { Calendar, Layers, RotateCcw, Search } from 'lucide-react';

interface HeaderProps {
  onOpenSearch?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSearch }) => {
  const { items, viewMode, setViewMode, resetData, isSearchOpen, setIsSearchOpen } = useLater();
  const [showOptions, setShowOptions] = useState(false);

  const activeCount = items.filter((i) => !i.isArchived && !i.isDone).length;

  const handleOpenSearch = () => {
    if (onOpenSearch) onOpenSearch();
    setIsSearchOpen(true);
  };

  // Keyboard shortcut listener (Cmd+K or Ctrl+K or /)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in an input or textarea
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA'
      ) {
        return;
      }

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        handleOpenSearch();
      } else if (e.key === '/' && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        handleOpenSearch();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <header className="sticky top-0 z-30 bg-[#0D0D0D]/90 backdrop-blur-md border-b border-[#1A1A1A] py-3.5 px-4 sm:px-6">
      <div className="max-w-xl mx-auto flex items-center justify-between">
        {/* Left: Brand + Subtle status */}
        <div className="flex items-baseline gap-2.5">
          <h1 className="text-[17px] font-semibold tracking-tight text-[#F0F0F0]">
            Later
          </h1>
          <span className="text-xs font-mono text-[#555555]">
            {activeCount === 0 ? 'empty' : `${activeCount} in memory`}
          </span>
        </div>

        {/* Right: Search, View mode toggle & reset */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Clearly Visible Universal Recall Search Button */}
          <button
            id="header-recall-search-btn"
            type="button"
            onClick={handleOpenSearch}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-medium bg-[#161616] text-[#E0E0E0] hover:text-[#FFFFFF] hover:bg-[#222222] border border-[#2D2D2D] hover:border-[#444444] shadow-sm transition-all cursor-pointer"
            title="Recall Search (⌘K or /)"
          >
            <Search className="w-3.5 h-3.5 text-[#AAAAAA]" />
            <span className="text-xs font-medium text-[#DCDCDC]">Search</span>
          </button>

          <button
            id="header-view-mode-toggle-btn"
            type="button"
            onClick={() => setViewMode(viewMode === 'grouped' ? 'schedule' : 'grouped')}
            className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer border ${
              viewMode === 'schedule'
                ? 'bg-[#222222] text-[#FFFFFF] border-[#333333]'
                : 'bg-[#141414] text-[#888888] border-[#1F1F1F] hover:text-[#CCCCCC]'
            }`}
            title={viewMode === 'grouped' ? 'Switch to Schedule view' : 'Switch to Memory Timeline'}
          >
            {viewMode === 'grouped' ? (
              <>
                <Calendar className="w-3.5 h-3.5 text-[#AAAAAA]" />
                <span>Schedule</span>
              </>
            ) : (
              <>
                <Layers className="w-3.5 h-3.5 text-[#AAAAAA]" />
                <span>Timeline</span>
              </>
            )}
          </button>

          <button
            id="header-options-btn"
            type="button"
            onClick={() => setShowOptions(!showOptions)}
            className="p-1.5 text-[#666666] hover:text-[#AAAAAA] rounded hover:bg-[#1A1A1A] transition-colors text-xs font-mono"
            title="Options"
          >
            •••
          </button>

          {showOptions && (
            <div className="absolute right-4 top-12 w-44 bg-[#161616] border border-[#262626] rounded-lg shadow-2xl py-1 z-50 animate-in fade-in zoom-in-95">
              <button
                type="button"
                onClick={() => {
                  resetData();
                  setShowOptions(false);
                }}
                className="w-full text-left px-3 py-2 text-xs text-[#999999] hover:text-[#FFFFFF] hover:bg-[#202020] flex items-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset demo memory</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

