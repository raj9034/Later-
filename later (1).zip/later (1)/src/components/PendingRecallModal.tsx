import React, { useState } from 'react';
import { useLater } from '../context/LaterContext';
import { SavedItem } from '../types';
import {
  getPendingRecallItems,
  getMemoryMomentHeading,
  getMemoryMomentSubtext,
} from '../utils/reminderService';
import { getReschedulePresetOptions } from '../utils/rescheduleHelper';
import {
  X,
  Sparkles,
  ExternalLink,
  Play,
  Camera,
  MapPin,
  FileText,
  Phone,
  CheckCircle2,
  Clock,
  ArrowRight,
  Calendar,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface PendingRecallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PendingRecallModal: React.FC<PendingRecallModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { items, setSelectedItem, openItem, toggleDone, rescheduleItem } = useLater();
  const [reschedulingItemId, setReschedulingItemId] = useState<string | null>(null);

  const pendingItems = getPendingRecallItems(items);
  const presetOptions = getReschedulePresetOptions();

  if (!isOpen) return null;

  const renderIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Play className="w-3.5 h-3.5 fill-current" />;
      case 'screenshot':
      case 'image':
        return <Camera className="w-3.5 h-3.5" />;
      case 'place':
        return <MapPin className="w-3.5 h-3.5" />;
      case 'person':
      case 'phone_number':
        return <Phone className="w-3.5 h-3.5" />;
      case 'link':
      case 'article':
      case 'product':
        return <ExternalLink className="w-3.5 h-3.5" />;
      default:
        return <FileText className="w-3.5 h-3.5" />;
    }
  };

  const handleSelectPreset = (itemId: string, iso: string) => {
    rescheduleItem(itemId, iso);
    setReschedulingItemId(null);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-[#000000]/80 backdrop-blur-xs"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          className="relative w-full max-w-lg bg-[#141414] border-t sm:border border-[#262626] rounded-t-2xl sm:rounded-2xl p-5 shadow-2xl z-10 max-h-[85vh] flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-[#202020] shrink-0">
            <div className="flex items-center gap-2">
              <span className="text-amber-400/90 text-xs">✦</span>
              <h3 className="text-xs font-mono font-medium text-[#E0E0E0] uppercase tracking-wider">
                From Your Memory
              </h3>
              <span className="text-[11px] font-mono text-[#666666]">
                ({pendingItems.length})
              </span>
            </div>

            <button
              onClick={onClose}
              className="p-1 rounded text-[#777777] hover:text-[#DDDDDD] hover:bg-[#1E1E1E] transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-[#888888] my-3 shrink-0">
            Items you wanted to remember that have resurfaced. Take a look or postpone for later.
          </p>

          {/* List of Surfaced Items */}
          <div className="overflow-y-auto space-y-2.5 flex-1 pr-0.5 py-1">
            {pendingItems.length === 0 ? (
              <div className="py-12 text-center text-xs text-[#666666]">
                All memories are resting peacefully.
              </div>
            ) : (
              pendingItems.map((item) => {
                const heading = getMemoryMomentHeading(item);
                const subtext = getMemoryMomentSubtext(item);
                const isPickingReschedule = reschedulingItemId === item.id;

                return (
                  <div
                    key={item.id}
                    className="p-3.5 rounded-xl bg-[#181818] border border-[#242424] hover:border-[#303030] transition-all flex flex-col gap-2.5"
                  >
                    {/* Top row: heading and type */}
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-medium text-[#B89B5F]">
                        {heading}
                      </span>
                      <span className="text-[10px] font-mono text-[#666666]">
                        {subtext}
                      </span>
                    </div>

                    {/* Main content click opens detail */}
                    <div
                      onClick={() => {
                        setSelectedItem(item);
                        onClose();
                      }}
                      className="flex items-start gap-3 cursor-pointer group"
                    >
                      <div className="w-7 h-7 rounded-lg bg-[#202020] border border-[#2B2B2B] flex items-center justify-center text-[#999999] shrink-0 mt-0.5 group-hover:text-[#FFFFFF]">
                        {renderIcon(item.contentType || item.type)}
                      </div>

                      <div className="min-w-0 flex-1">
                        <h4 className="text-xs sm:text-[13px] font-medium text-[#EDEDED] group-hover:text-[#FFFFFF] leading-snug line-clamp-2">
                          {item.title}
                        </h4>
                        {item.summary && item.summary !== item.title && (
                          <p className="text-[11px] text-[#777777] line-clamp-1 mt-0.5">
                            {item.summary}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Bottom Action Bar */}
                    <div className="flex items-center justify-between pt-2 border-t border-[#202020] mt-0.5">
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            if (item.url) {
                              openItem(item.id);
                            } else {
                              setSelectedItem(item);
                              onClose();
                            }
                          }}
                          className="px-2.5 py-1 rounded bg-[#222222] hover:bg-[#2C2C2C] text-[#E0E0E0] text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1"
                        >
                          <span>Open</span>
                          <ArrowRight className="w-3 h-3 text-[#888888]" />
                        </button>

                        <button
                          type="button"
                          onClick={() => toggleDone(item.id)}
                          className="px-2.5 py-1 rounded hover:bg-[#1E1E1E] text-[#888888] hover:text-[#4ADE80] text-[11px] transition-colors cursor-pointer flex items-center gap-1"
                        >
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Done</span>
                        </button>
                      </div>

                      {/* Not now / Reschedule toggle */}
                      <div className="relative">
                        <button
                          type="button"
                          onClick={() =>
                            setReschedulingItemId(isPickingReschedule ? null : item.id)
                          }
                          className="px-2 py-1 rounded hover:bg-[#1E1E1E] text-[#888888] hover:text-[#CCCCCC] text-[11px] font-mono transition-colors cursor-pointer flex items-center gap-1"
                        >
                          <Clock className="w-3 h-3" />
                          <span>Not now</span>
                        </button>

                        {/* Quick Reschedule Options */}
                        {isPickingReschedule && (
                          <div className="absolute right-0 bottom-full mb-1.5 w-48 bg-[#1F1F1F] border border-[#333333] rounded-lg shadow-xl py-1 z-20 text-[11px] font-mono">
                            <div className="px-2.5 py-1 text-[10px] text-[#777777] border-b border-[#2A2A2A]">
                              When should I bring this back?
                            </div>
                            {presetOptions.map((opt) => (
                              <button
                                key={opt.id}
                                onClick={() => handleSelectPreset(item.id, opt.getIso())}
                                className="w-full px-2.5 py-1.5 text-left text-[#CCCCCC] hover:bg-[#282828] hover:text-[#FFFFFF] flex items-center justify-between"
                              >
                                <span>{opt.label}</span>
                                <span className="text-[10px] text-[#666666]">{opt.sublabel}</span>
                              </button>
                            ))}
                            <button
                              onClick={() => {
                                setSelectedItem(item);
                                setReschedulingItemId(null);
                                onClose();
                              }}
                              className="w-full px-2.5 py-1.5 text-left text-[#A78BFA] hover:bg-[#282828] border-t border-[#2A2A2A] flex items-center justify-between"
                            >
                              <span>Choose date & time</span>
                              <Calendar className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="pt-3 border-t border-[#202020] text-center shrink-0">
            <button
              onClick={onClose}
              className="text-xs font-mono text-[#777777] hover:text-[#CCCCCC] cursor-pointer"
            >
              Close
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
