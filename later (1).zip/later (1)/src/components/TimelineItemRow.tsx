import React, { useState } from 'react';
import { SavedItem } from '../types';
import { useLater } from '../context/LaterContext';
import { formatItemReminderLabel } from '../utils/reminderService';
import { getAutoArchiveTimeRemaining } from '../utils/autoArchiveService';
import {
  Play,
  Camera,
  MapPin,
  CheckCircle2,
  ExternalLink,
  Phone,
  FileText,
  Clock,
  Archive,
  Check,
  Timer,
} from 'lucide-react';

interface TimelineItemRowProps {
  item: SavedItem;
}

export const TimelineItemRow: React.FC<TimelineItemRowProps> = ({ item }) => {
  const { setSelectedItem, toggleDone, snoozeItem, archiveItem } = useLater();
  const [showQuickSnooze, setShowQuickSnooze] = useState(false);

  // Derive Type Icon
  const renderTypeIcon = () => {
    if (item.imageAttachment) {
      return (
        <div className="w-8 h-8 rounded-md overflow-hidden bg-[#181818] border border-[#262626] shrink-0">
          <img
            src={item.imageAttachment}
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
      );
    }

    const type = item.contentType || item.type;

    switch (type) {
      case 'video':
        return (
          <div className="w-8 h-8 rounded-md bg-[#161616] border border-[#222222] flex items-center justify-center text-[#999999] shrink-0">
            <Play className="w-3.5 h-3.5 fill-current" />
          </div>
        );
      case 'person':
      case 'phone_number':
        return (
          <div className="w-8 h-8 rounded-md bg-[#161616] border border-[#222222] flex items-center justify-center text-[#999999] shrink-0">
            <Phone className="w-3.5 h-3.5" />
          </div>
        );
      case 'place':
        return (
          <div className="w-8 h-8 rounded-md bg-[#161616] border border-[#222222] flex items-center justify-center text-[#999999] shrink-0">
            <MapPin className="w-3.5 h-3.5" />
          </div>
        );
      case 'task':
      case 'event':
        return (
          <div className="w-8 h-8 rounded-md bg-[#161616] border border-[#222222] flex items-center justify-center text-[#999999] shrink-0">
            <Check className="w-3.5 h-3.5 stroke-[2.5]" />
          </div>
        );
      case 'link':
      case 'article':
      case 'product':
        return (
          <div className="w-8 h-8 rounded-md bg-[#161616] border border-[#222222] flex items-center justify-center text-[#999999] shrink-0">
            <ExternalLink className="w-3.5 h-3.5" />
          </div>
        );
      case 'screenshot':
      case 'image':
        return (
          <div className="w-8 h-8 rounded-md bg-[#161616] border border-[#222222] flex items-center justify-center text-[#999999] shrink-0">
            <Camera className="w-3.5 h-3.5" />
          </div>
        );
      case 'note':
      case 'idea':
      default:
        return (
          <div className="w-8 h-8 rounded-md bg-[#161616] border border-[#222222] flex items-center justify-center text-[#999999] shrink-0">
            <FileText className="w-3.5 h-3.5" />
          </div>
        );
    }
  };

  const reminderText = formatItemReminderLabel(item);

  return (
    <div
      className={`group relative flex items-center justify-between py-3 px-3 rounded-xl border border-transparent hover:border-[#1E1E1E] hover:bg-[#121212] transition-colors cursor-pointer ${
        item.isDone ? 'opacity-40 line-through' : ''
      }`}
      onClick={() => setSelectedItem(item)}
    >
      {/* Left: Icon & Content */}
      <div className="flex items-center gap-3 min-w-0 flex-1 pr-3">
        {renderTypeIcon()}

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <p className="text-sm font-medium text-[#EDEDED] truncate group-hover:text-[#FFFFFF]">
              {item.title}
            </p>
            {item.intent && (
              <span className="hidden sm:inline-block px-1.5 py-0.2 rounded text-[9px] font-mono uppercase bg-[#181818] text-[#777777] border border-[#242424]">
                {item.intent}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 mt-0.5 text-xs text-[#666666] font-mono truncate">
            {item.isDone ? (
              <span className="flex items-center gap-1 text-[#4ADE80]">
                <Timer className="w-3 h-3" />
                <span>{getAutoArchiveTimeRemaining(item)?.label || 'Auto-archives in 24h'}</span>
              </span>
            ) : (
              <>
                {item.sourceDomain && (
                  <span className="text-[#888888]">{item.sourceDomain} ·</span>
                )}
                {item.extractedMeta?.phoneNumber && (
                  <span className="text-[#888888]">{item.extractedMeta.phoneNumber} ·</span>
                )}
                <span className="text-[#AAAAAA]">{reminderText}</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Right: Quick actions on hover / tap */}
      <div
        className="flex items-center gap-1 opacity-80 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Toggle Done */}
        <button
          onClick={() => toggleDone(item.id)}
          className={`p-1.5 rounded-md hover:bg-[#1E1E1E] text-[#666666] hover:text-[#00DD77] transition-colors ${
            item.isDone ? 'text-[#00DD77]' : ''
          }`}
          title={item.isDone ? 'Mark undone' : 'Mark done'}
        >
          <CheckCircle2 className="w-4 h-4" />
        </button>

        {/* Quick Reschedule / Snooze */}
        <div className="relative">
          <button
            onClick={() => setShowQuickSnooze(!showQuickSnooze)}
            className="p-1.5 rounded-md hover:bg-[#1E1E1E] text-[#666666] hover:text-[#EDEDED] transition-colors"
            title="Remind me later"
          >
            <Clock className="w-4 h-4" />
          </button>

          {showQuickSnooze && (
            <div className="absolute right-0 top-8 w-36 bg-[#181818] border border-[#282828] rounded-lg shadow-2xl py-1 z-40">
              <button
                onClick={() => {
                  snoozeItem(item.id, 'tonight');
                  setShowQuickSnooze(false);
                }}
                className="w-full text-left px-3 py-1.5 text-xs text-[#999999] hover:text-[#FFFFFF] hover:bg-[#222222]"
              >
                Tonight
              </button>
              <button
                onClick={() => {
                  snoozeItem(item.id, 'tomorrow');
                  setShowQuickSnooze(false);
                }}
                className="w-full text-left px-3 py-1.5 text-xs text-[#999999] hover:text-[#FFFFFF] hover:bg-[#222222]"
              >
                Tomorrow
              </button>
              <button
                onClick={() => {
                  snoozeItem(item.id, 'this_weekend');
                  setShowQuickSnooze(false);
                }}
                className="w-full text-left px-3 py-1.5 text-xs text-[#999999] hover:text-[#FFFFFF] hover:bg-[#222222]"
              >
                This weekend
              </button>
              <button
                onClick={() => {
                  snoozeItem(item.id, 'next_week');
                  setShowQuickSnooze(false);
                }}
                className="w-full text-left px-3 py-1.5 text-xs text-[#999999] hover:text-[#FFFFFF] hover:bg-[#222222]"
              >
                Next week
              </button>
            </div>
          )}
        </div>

        {/* Quick Archive */}
        <button
          onClick={() => archiveItem(item.id)}
          className="p-1.5 rounded-md hover:bg-[#1E1E1E] text-[#666666] hover:text-[#EE5555] transition-colors"
          title="Archive"
        >
          <Archive className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
