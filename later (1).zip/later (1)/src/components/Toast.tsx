import React from 'react';
import { useLater } from '../context/LaterContext';
import { motion, AnimatePresence } from 'motion/react';
import { Check } from 'lucide-react';

export const Toast: React.FC = () => {
  const { toastMessage } = useLater();

  return (
    <AnimatePresence>
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 pointer-events-none">
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="flex items-center gap-2 px-3.5 py-2 rounded-full bg-[#1F1F1F] border border-[#333333] text-xs font-mono text-[#F0F0F0] shadow-2xl"
          >
            <Check className="w-3.5 h-3.5 text-[#00DD77]" />
            <span>{toastMessage}</span>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
