import React from 'react';
import { Youtube, Globe, FileText, CheckCircle2, Link2, Sparkles } from 'lucide-react';

interface CapturePreviewProps {
  content: string;
}

export const CapturePreview: React.FC<CapturePreviewProps> = ({ content }) => {
  const trimmed = content.trim();

  // Detect Type
  const isYouTube = /(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)/i.test(trimmed);
  const isUrl = /^https?:\/\/[^\s]+$/i.test(trimmed);
  const isMultiLine = trimmed.includes('\n');

  let domain = '';
  if (isUrl || isYouTube) {
    try {
      const parsed = new URL(trimmed.startsWith('http') ? trimmed : `https://${trimmed}`);
      domain = parsed.hostname.replace(/^www\./, '');
    } catch {
      domain = 'web link';
    }
  }

  return (
    <div id="instant-capture-preview-box" className="rounded-lg bg-[#0E0E0E] border border-[#252525] p-3 text-xs">
      <div className="flex items-center justify-between gap-2 mb-1.5">
        <div className="flex items-center gap-1.5">
          {isYouTube ? (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#2D1212] text-[#FF6B6B] border border-[#481E1E] text-[10px] font-mono font-medium">
              <Youtube className="w-3 h-3 text-[#FF4444]" />
              <span>YouTube Video</span>
            </span>
          ) : isUrl ? (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#13222D] text-[#70C0FF] border border-[#1E3547] text-[10px] font-mono font-medium">
              <Globe className="w-3 h-3 text-[#4DA6FF]" />
              <span>{domain || 'Web Link'}</span>
            </span>
          ) : isMultiLine ? (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#1E1E1E] text-[#AAAAAA] border border-[#2E2E2E] text-[10px] font-mono font-medium">
              <FileText className="w-3 h-3 text-[#888888]" />
              <span>Multi-line Note</span>
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#1B221B] text-[#7EE081] border border-[#263826] text-[10px] font-mono font-medium">
              <Sparkles className="w-3 h-3 text-[#52C41A]" />
              <span>Copied Text</span>
            </span>
          )}
        </div>
        <span className="text-[10px] text-[#666666] font-mono">
          {trimmed.length} chars
        </span>
      </div>

      <div className="text-[#E0E0E0] line-clamp-3 font-sans break-words text-[13px] leading-relaxed">
        {trimmed}
      </div>
    </div>
  );
};
