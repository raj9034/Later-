import React, { useState, useEffect, useRef } from 'react';
import { useLater } from '../../context/LaterContext';
import { CapturePreview } from './CapturePreview';
import {
  Clipboard,
  X,
  ArrowUpRight,
  Check,
  Edit2,
  RefreshCw,
} from 'lucide-react';

interface ClipboardCaptureProps {
  onClose: () => void;
}

const SAMPLE_PRESETS = [
  {
    label: 'YouTube link',
    text: 'https://youtube.com/watch?v=dQw4w9WgXcQ - Japanese Woodworking Masterclass',
  },
  {
    label: 'Article URL',
    text: 'https://news.ycombinator.com/item?id=40000000 Deep Dive into Local AI Models',
  },
  {
    label: 'Meeting note',
    text: 'Review Q3 financial roadmap with Sarah tomorrow at 10am',
  },
];

export const ClipboardCapture: React.FC<ClipboardCaptureProps> = ({ onClose }) => {
  const { saveItem } = useLater();
  const [clipboardContent, setClipboardContent] = useState<string>('');
  const [isReadingClipboard, setIsReadingClipboard] = useState<boolean>(true);
  const [clipboardDenied, setClipboardDenied] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [isSaved, setIsSaved] = useState<boolean>(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const closeTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const readSystemClipboard = async () => {
    setIsReadingClipboard(true);
    setClipboardDenied(false);

    try {
      if (!navigator.clipboard || !navigator.clipboard.readText) {
        setClipboardDenied(true);
        setIsReadingClipboard(false);
        return;
      }

      const text = await navigator.clipboard.readText();
      if (text && text.trim()) {
        setClipboardContent(text.trim());
        setClipboardDenied(false);
      } else {
        setClipboardContent('');
        setClipboardDenied(true);
      }
    } catch (err) {
      console.warn('Clipboard read failed or permission denied:', err);
      setClipboardDenied(true);
    } finally {
      setIsReadingClipboard(false);
    }
  };

  useEffect(() => {
    readSystemClipboard();
    return () => {
      if (closeTimeoutRef.current) {
        clearTimeout(closeTimeoutRef.current);
      }
    };
  }, []);

  const handleSaveToLater = () => {
    const textToSave = clipboardContent.trim();
    if (!textToSave) return;

    // Send through the real AI categorization pipeline
    saveItem(textToSave);
    setIsSaved(true);

    // Auto collapse after confirmation
    if (closeTimeoutRef.current) {
      clearTimeout(closeTimeoutRef.current);
    }
    closeTimeoutRef.current = setTimeout(() => {
      onClose();
    }, 1100);
  };

  const handleUsePreset = (presetText: string) => {
    setClipboardContent(presetText);
    setClipboardDenied(false);
    setIsEditing(false);
  };

  if (isSaved) {
    return (
      <div id="instant-capture-success-card" className="p-5 flex flex-col items-center justify-center text-center py-7">
        <div className="w-10 h-10 rounded-full bg-[#172E19] border border-[#2B542E] flex items-center justify-center text-[#4ADE80] mb-2.5 shadow-[0_0_20px_rgba(74,222,128,0.2)] animate-in zoom-in-95 duration-200">
          <Check className="w-5 h-5 stroke-[2.5]" />
        </div>
        <h4 className="text-sm font-medium text-[#EDEDED] mb-0.5">Saved for Later</h4>
        <p className="text-[11px] text-[#888888]">Analyzed and scheduled by AI</p>
      </div>
    );
  }

  return (
    <div id="instant-capture-card-inner" className="p-3.5 flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#202020] pb-2.5">
        <div className="flex items-center gap-1.5">
          <div className="w-5 h-5 rounded-full bg-[#1C1C1C] flex items-center justify-center text-[#CCCCCC]">
            <Clipboard className="w-3 h-3 text-[#CCCCCC]" />
          </div>
          <span className="text-xs font-semibold text-[#EEEEEE] tracking-tight">
            Save from clipboard
          </span>
        </div>
        <button
          id="instant-capture-close-btn"
          type="button"
          onClick={onClose}
          className="p-1 text-[#777777] hover:text-[#DDDDDD] hover:bg-[#1E1E1E] rounded transition-colors cursor-pointer"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Detected Content Preview or Fallback Paste Input */}
      {clipboardContent && !isEditing ? (
        <div className="flex flex-col gap-2">
          <CapturePreview content={clipboardContent} />
          <div className="flex items-center justify-between text-[11px]">
            <button
              id="instant-capture-edit-btn"
              type="button"
              onClick={() => {
                setIsEditing(true);
                setTimeout(() => textareaRef.current?.focus(), 50);
              }}
              className="flex items-center gap-1 text-[#888888] hover:text-[#CCCCCC] transition-colors cursor-pointer"
            >
              <Edit2 className="w-3 h-3" />
              <span>Edit text</span>
            </button>

            <button
              id="instant-capture-reload-btn"
              type="button"
              onClick={readSystemClipboard}
              className="flex items-center gap-1 text-[#888888] hover:text-[#CCCCCC] transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Re-read clipboard</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          <div className="text-[11px] text-[#888888] flex items-center justify-between">
            <span>Paste or enter copied link/text</span>
            <button
              type="button"
              onClick={readSystemClipboard}
              className="text-[#3B82F6] hover:underline cursor-pointer"
            >
              Paste from clipboard
            </button>
          </div>
          <textarea
            id="instant-capture-custom-textarea"
            ref={textareaRef}
            value={clipboardContent}
            onChange={(e) => setClipboardContent(e.target.value)}
            placeholder="Paste URL, YouTube video, notes, or article..."
            rows={3}
            className="w-full rounded-lg bg-[#0E0E0E] border border-[#282828] focus:border-[#444444] px-3 py-2 text-xs text-[#EDEDED] placeholder-[#555555] resize-none outline-none font-sans leading-relaxed"
          />

          {/* Quick Simulation Presets for Testing */}
          <div className="flex flex-col gap-1 pt-1">
            <span className="text-[10px] text-[#555555] uppercase tracking-wider font-mono">
              Quick Test Simulation
            </span>
            <div className="flex flex-wrap gap-1.5">
              {SAMPLE_PRESETS.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleUsePreset(preset.text)}
                  className="px-2 py-1 rounded bg-[#161616] hover:bg-[#222222] border border-[#262626] text-[10px] text-[#AAAAAA] hover:text-[#FFFFFF] transition-colors cursor-pointer text-left"
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex items-center justify-end gap-2 pt-1 border-t border-[#1C1C1C]">
        <button
          id="instant-capture-cancel-btn"
          type="button"
          onClick={onClose}
          className="px-3 py-1.5 rounded-lg text-xs font-medium text-[#888888] hover:text-[#EEEEEE] hover:bg-[#1E1E1E] transition-colors cursor-pointer"
        >
          Cancel
        </button>
        <button
          id="instant-capture-save-btn"
          type="button"
          onClick={handleSaveToLater}
          disabled={!clipboardContent.trim()}
          className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
            clipboardContent.trim()
              ? 'bg-[#EAEAEA] text-[#0A0A0A] hover:bg-[#FFFFFF] cursor-pointer shadow-[0_2px_8px_rgba(255,255,255,0.12)]'
              : 'bg-[#1F1F1F] text-[#555555] cursor-not-allowed'
          }`}
        >
          <span>Save to Later</span>
          <ArrowUpRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
