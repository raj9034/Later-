import React, { useState } from 'react';
import { useLater } from '../context/LaterContext';
import { formatItemReminderLabel, calculateFlexibleTarget, normalizeItemReminder } from '../utils/reminderService';
import { getAutoArchiveTimeRemaining } from '../utils/autoArchiveService';
import { SavedItem, FlexiblePeriod, ItemReminder } from '../types';
import { NotNowRescheduleMenu } from './NotNowRescheduleMenu';
import {
  X,
  ExternalLink,
  Phone,
  Clock,
  CheckCircle2,
  Archive,
  Trash2,
  Play,
  Camera,
  MapPin,
  FileText,
  Check,
  Sparkles,
  ArrowRight,
  Timer,
  Sun,
  Moon,
  CalendarDays,
  CalendarRange,
  Calendar,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const ItemDetailSheet: React.FC = () => {
  const {
    selectedItem,
    setSelectedItem,
    items,
    openItem,
    setReminderForItem,
    toggleDone,
    archiveItem,
    deleteItem,
  } = useLater();

  const [showNotNowMenu, setShowNotNowMenu] = useState(false);
  const [showReminderEditor, setShowReminderEditor] = useState(false);
  const [editorTab, setEditorTab] = useState<'flexible' | 'specific' | 'none'>('flexible');
  const [customDateTime, setCustomDateTime] = useState('');

  if (!selectedItem) return null;

  const item = selectedItem;
  const reminder = normalizeItemReminder(item);
  const reminderLabel = formatItemReminderLabel(item);

  // Retrieve actual related memory objects
  const relatedMemories: SavedItem[] = (item.relatedMemoryIds || [])
    .map((id) => items.find((it) => it.id === id && !it.isArchived))
    .filter((it): it is SavedItem => Boolean(it))
    .slice(0, 3);

  const handleSetFlexible = (period: FlexiblePeriod) => {
    const target = calculateFlexibleTarget(period);
    setReminderForItem(item.id, {
      type: 'flexible',
      flexiblePeriod: period,
      scheduledAt: target.iso,
      reminderStatus: 'waiting',
    });
    setShowReminderEditor(false);
  };

  const handleSetSpecificPreset = (preset: 'today_evening' | 'tomorrow_morning' | 'tomorrow_evening') => {
    const d = new Date();
    if (preset === 'today_evening') {
      d.setHours(19, 0, 0, 0);
      if (d.getTime() <= Date.now()) {
        d.setHours(21, 0, 0, 0);
      }
    } else if (preset === 'tomorrow_morning') {
      d.setDate(d.getDate() + 1);
      d.setHours(9, 0, 0, 0);
    } else if (preset === 'tomorrow_evening') {
      d.setDate(d.getDate() + 1);
      d.setHours(19, 0, 0, 0);
    }

    setReminderForItem(item.id, {
      type: 'scheduled',
      scheduledAt: d.toISOString(),
      reminderStatus: 'waiting',
    });
    setShowReminderEditor(false);
  };

  const handleSetCustomTime = () => {
    if (!customDateTime) return;
    setReminderForItem(item.id, {
      type: 'scheduled',
      scheduledAt: new Date(customDateTime).toISOString(),
      reminderStatus: 'waiting',
    });
    setShowReminderEditor(false);
  };

  const handleRemoveReminder = () => {
    setReminderForItem(item.id, {
      type: 'none',
      reminderStatus: 'waiting',
    });
    setShowReminderEditor(false);
  };

  const renderTypeIcon = (type: string, isSmall = false) => {
    const size = isSmall ? 'w-3.5 h-3.5' : 'w-4 h-4';
    switch (type) {
      case 'video':
        return <Play className={`${size} fill-current`} />;
      case 'person':
      case 'phone_number':
        return <Phone className={size} />;
      case 'place':
        return <MapPin className={size} />;
      case 'task':
      case 'event':
        return <Check className={`${size} stroke-[2.5]`} />;
      case 'screenshot':
      case 'image':
        return <Camera className={size} />;
      case 'link':
      case 'article':
      case 'product':
        return <ExternalLink className={size} />;
      case 'note':
      case 'idea':
      default:
        return <FileText className={size} />;
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setSelectedItem(null)}
          className="absolute inset-0 bg-[#000000]/80 backdrop-blur-xs"
        />

        {/* Sheet / Modal */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 24 }}
          className="relative w-full max-w-lg bg-[#131313] border-t sm:border border-[#242424] rounded-t-2xl sm:rounded-2xl p-5 sm:p-6 shadow-2xl z-10 max-h-[88vh] overflow-y-auto"
        >
          {/* Header Bar */}
          <div className="flex items-center justify-between pb-3 border-b border-[#1E1E1E]">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-[#1C1C1C] text-[#AAAAAA] border border-[#282828] flex items-center gap-1.5">
                {renderTypeIcon(item.contentType || item.type, true)}
                <span>{item.contentType || item.type}</span>
              </span>

              {item.intent && (
                <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-[#18201C] text-[#3CD070] border border-[#203426]">
                  {item.intent}
                </span>
              )}

              {item.isDone && (
                <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-[#183322] text-[#00DD77] border border-[#20442E]">
                  Completed
                </span>
              )}
            </div>

            <button
              onClick={() => setSelectedItem(null)}
              className="p-1 rounded text-[#666666] hover:text-[#DDDDDD] hover:bg-[#1E1E1E] transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Recalled Memory Notice */}
          {reminder.reminderStatus === 'pending_recall' && (
            <div className="mt-3 px-3 py-2 rounded-lg bg-[#1C1914] border border-[#3D3220] flex items-center justify-between text-xs text-[#E5D3B0]">
              <div className="flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Ready from your memory</span>
              </div>
              <button
                type="button"
                onClick={() => setShowNotNowMenu(true)}
                className="font-mono text-[11px] text-amber-300 underline hover:text-[#FFFFFF] cursor-pointer"
              >
                Not now
              </button>
            </div>
          )}

          {/* Auto-archive Notice when marked Done */}
          {item.isDone && (
            <div className="mt-3 px-3 py-2 rounded-lg bg-[#141C16] border border-[#1E3024] flex items-center justify-between text-xs text-[#8CD4A2]">
              <div className="flex items-center gap-2">
                <Timer className="w-3.5 h-3.5 text-[#00DD77]" />
                <span>Auto-archives 24 hours after completion</span>
              </div>
              <span className="font-mono text-[11px] text-[#A6E8BA]">
                {getAutoArchiveTimeRemaining(item)?.label || 'Auto-archives in 24h'}
              </span>
            </div>
          )}

          {/* Attached Image / Screenshot */}
          {item.imageAttachment && (
            <div className="mt-4 rounded-xl overflow-hidden border border-[#262626] bg-[#0A0A0A] max-h-72 flex items-center justify-center">
              <img
                src={item.imageAttachment}
                alt="Captured visual"
                className="w-full h-auto object-contain max-h-72"
              />
            </div>
          )}

          {/* Title and Summary */}
          <div className="mt-4 space-y-2">
            <h2 className="text-base sm:text-lg font-medium text-[#EDEDED] leading-snug">
              {item.title}
            </h2>

            {item.summary && item.summary !== item.title && (
              <p className="text-xs text-[#999999] leading-relaxed">
                {item.summary}
              </p>
            )}

            <div className="flex flex-wrap items-center gap-2.5 text-xs font-mono text-[#777777] pt-1">
              {item.sourceDomain && (
                <span>
                  Source: <span className="text-[#AAAAAA]">{item.sourceDomain}</span>
                </span>
              )}
              {item.extractedMeta?.phoneNumber && (
                <span>
                  Phone: <span className="text-[#AAAAAA]">{item.extractedMeta.phoneNumber}</span>
                </span>
              )}
              {item.extractedMeta?.address && (
                <span>
                  Location: <span className="text-[#AAAAAA]">{item.extractedMeta.address}</span>
                </span>
              )}
            </div>
          </div>

          {/* Original raw content */}
          {item.rawInput && item.rawInput !== item.title && (
            <div className="mt-3.5">
              <div className="text-[11px] font-mono text-[#666666] mb-1">Original input</div>
              <div className="p-3 rounded-lg bg-[#181818] border border-[#222222] text-xs font-mono text-[#888888] break-all leading-relaxed">
                {item.rawInput}
              </div>
            </div>
          )}

          {/* Reminder Status & Management */}
          <div className="mt-4 pt-3.5 border-t border-[#1C1C1C]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-mono">
                {reminder.reminderStatus === 'pending_recall' ? (
                  <span className="text-amber-400">✦</span>
                ) : reminder.type === 'none' ? (
                  <Sparkles className="w-3.5 h-3.5 text-[#666666]" />
                ) : (
                  <Clock className="w-3.5 h-3.5 text-[#888888]" />
                )}
                <span
                  className={
                    reminder.reminderStatus === 'pending_recall'
                      ? 'text-[#D8C7A0] font-medium'
                      : 'text-[#CCCCCC]'
                  }
                >
                  {reminderLabel}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowReminderEditor(!showReminderEditor)}
                  className="text-xs font-mono text-[#888888] hover:text-[#FFFFFF] underline cursor-pointer"
                >
                  {showReminderEditor ? 'Close' : 'Change reminder'}
                </button>
              </div>
            </div>

            {/* Reminder Options Panel */}
            {showReminderEditor && (
              <div className="mt-3 p-3.5 rounded-xl bg-[#171717] border border-[#282828] space-y-3">
                {/* Mode tabs */}
                <div className="grid grid-cols-3 gap-1 p-1 bg-[#1F1F1F] rounded-lg border border-[#2A2A2A]">
                  <button
                    type="button"
                    onClick={() => setEditorTab('flexible')}
                    className={`py-1 text-xs rounded font-medium transition-all text-center cursor-pointer ${
                      editorTab === 'flexible'
                        ? 'bg-[#2D2D2D] text-[#FFFFFF]'
                        : 'text-[#888888] hover:text-[#CCCCCC]'
                    }`}
                  >
                    Flexible
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditorTab('specific')}
                    className={`py-1 text-xs rounded font-medium transition-all text-center cursor-pointer ${
                      editorTab === 'specific'
                        ? 'bg-[#2D2D2D] text-[#FFFFFF]'
                        : 'text-[#888888] hover:text-[#CCCCCC]'
                    }`}
                  >
                    Specific
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditorTab('none')}
                    className={`py-1 text-xs rounded font-medium transition-all text-center cursor-pointer ${
                      editorTab === 'none'
                        ? 'bg-[#2D2D2D] text-[#FFFFFF]'
                        : 'text-[#888888] hover:text-[#CCCCCC]'
                    }`}
                  >
                    No time
                  </button>
                </div>

                {editorTab === 'flexible' && (
                  <div className="grid grid-cols-2 gap-1.5 pt-1">
                    <button
                      onClick={() => handleSetFlexible('later_today')}
                      className="px-3 py-2 rounded-lg bg-[#202020] hover:bg-[#2A2A2A] text-xs text-[#CCCCCC] text-left cursor-pointer flex items-center gap-2"
                    >
                      <Clock className="w-3.5 h-3.5 text-[#888888]" />
                      <span>Later today</span>
                    </button>
                    <button
                      onClick={() => handleSetFlexible('tomorrow')}
                      className="px-3 py-2 rounded-lg bg-[#202020] hover:bg-[#2A2A2A] text-xs text-[#CCCCCC] text-left cursor-pointer flex items-center gap-2"
                    >
                      <Sun className="w-3.5 h-3.5 text-[#888888]" />
                      <span>Tomorrow</span>
                    </button>
                    <button
                      onClick={() => handleSetFlexible('weekend')}
                      className="px-3 py-2 rounded-lg bg-[#202020] hover:bg-[#2A2A2A] text-xs text-[#CCCCCC] text-left cursor-pointer flex items-center gap-2"
                    >
                      <CalendarDays className="w-3.5 h-3.5 text-[#888888]" />
                      <span>This weekend</span>
                    </button>
                    <button
                      onClick={() => handleSetFlexible('next_week')}
                      className="px-3 py-2 rounded-lg bg-[#202020] hover:bg-[#2A2A2A] text-xs text-[#CCCCCC] text-left cursor-pointer flex items-center gap-2"
                    >
                      <CalendarRange className="w-3.5 h-3.5 text-[#888888]" />
                      <span>Next week</span>
                    </button>
                  </div>
                )}

                {editorTab === 'specific' && (
                  <div className="space-y-2 pt-1">
                    <div className="grid grid-cols-2 gap-1.5">
                      <button
                        onClick={() => handleSetSpecificPreset('today_evening')}
                        className="px-3 py-2 rounded-lg bg-[#202020] hover:bg-[#2A2A2A] text-xs text-[#CCCCCC] text-left cursor-pointer flex items-center gap-2"
                      >
                        <Moon className="w-3.5 h-3.5 text-[#888888]" />
                        <span>Today 7:00 PM</span>
                      </button>
                      <button
                        onClick={() => handleSetSpecificPreset('tomorrow_morning')}
                        className="px-3 py-2 rounded-lg bg-[#202020] hover:bg-[#2A2A2A] text-xs text-[#CCCCCC] text-left cursor-pointer flex items-center gap-2"
                      >
                        <Sun className="w-3.5 h-3.5 text-[#888888]" />
                        <span>Tomorrow 9:00 AM</span>
                      </button>
                    </div>

                    <div className="pt-1.5 flex items-center gap-2">
                      <input
                        type="datetime-local"
                        value={customDateTime}
                        onChange={(e) => setCustomDateTime(e.target.value)}
                        className="flex-1 bg-[#121212] border border-[#2C2C2C] rounded px-2.5 py-1.5 text-xs text-[#EDEDED] outline-none"
                      />
                      <button
                        onClick={handleSetCustomTime}
                        disabled={!customDateTime}
                        className="px-3 py-1.5 rounded bg-[#EDEDED] text-[#0A0A0A] text-xs font-medium cursor-pointer disabled:opacity-40"
                      >
                        Set
                      </button>
                    </div>
                  </div>
                )}

                {editorTab === 'none' && (
                  <div className="pt-1 space-y-2">
                    <p className="text-[11px] text-[#777777]">
                      Saves item in your Later memory without reminders.
                    </p>
                    <button
                      onClick={handleRemoveReminder}
                      className="w-full py-2 px-3 rounded-lg bg-[#222222] hover:bg-[#2C2C2C] text-xs text-[#EDEDED] font-medium transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-400/90" />
                      <span>Save in memory (No reminder)</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Connected / Related Memories */}
          {relatedMemories.length > 0 && (
            <div className="mt-5 pt-3.5 border-t border-[#1C1C1C]">
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-[11px] font-mono text-[#777777] uppercase tracking-wider">
                  Related Memories
                </span>
                <span className="text-[10px] font-mono text-[#555555]">
                  {relatedMemories.length} connected
                </span>
              </div>

              <div className="space-y-1.5">
                {relatedMemories.map((rel) => (
                  <div
                    key={rel.id}
                    onClick={() => setSelectedItem(rel)}
                    className="flex items-center justify-between p-2.5 rounded-lg bg-[#171717] hover:bg-[#1F1F1F] border border-[#222222] hover:border-[#303030] transition-colors cursor-pointer group"
                  >
                    <div className="flex items-center gap-2.5 min-w-0 flex-1 pr-2">
                      <div className="w-6 h-6 rounded bg-[#202020] border border-[#2A2A2A] flex items-center justify-center text-[#888888] shrink-0 group-hover:text-[#CCCCCC]">
                        {renderTypeIcon(rel.contentType || rel.type, true)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-medium text-[#DCDCDC] group-hover:text-[#FFFFFF] truncate">
                          {rel.title}
                        </p>
                        <p className="text-[10px] font-mono text-[#666666] truncate mt-0.5">
                          {formatItemReminderLabel(rel)}
                        </p>
                      </div>
                    </div>

                    <ArrowRight className="w-3.5 h-3.5 text-[#555555] group-hover:text-[#AAAAAA] shrink-0" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Not Now Reschedule Menu */}
          {showNotNowMenu && (
            <div className="mt-4 pt-3.5 border-t border-[#1C1C1C]">
              <NotNowRescheduleMenu
                itemId={item.id}
                itemTitle={item.title}
                onClose={() => setShowNotNowMenu(false)}
                onRescheduled={() => {
                  setShowNotNowMenu(false);
                }}
              />
            </div>
          )}

          {/* Action Buttons Footer */}
          <div className="mt-5 pt-4 border-t border-[#1C1C1C] flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              {(item.url || item.extractedMeta?.phoneNumber) && (
                <button
                  id="detail-action-open"
                  onClick={() => openItem(item.id)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#EAEAEA] hover:bg-[#FFFFFF] text-[#0D0D0D] text-xs font-medium transition-colors cursor-pointer"
                >
                  {item.extractedMeta?.phoneNumber ? (
                    <>
                      <Phone className="w-3.5 h-3.5" />
                      <span>Call {item.extractedMeta.personName || 'Contact'}</span>
                    </>
                  ) : (
                    <>
                      <span>Open</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              )}

              <button
                id="detail-action-done"
                onClick={() => toggleDone(item.id)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#1C1C1C] hover:bg-[#252525] border border-[#2B2B2B] text-xs font-medium text-[#CCCCCC] hover:text-[#FFFFFF] transition-colors cursor-pointer"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-[#00DD77]" />
                <span>{item.isDone ? 'Mark undone' : 'Done'}</span>
              </button>

              <button
                id="detail-action-not-now"
                onClick={() => setShowNotNowMenu(!showNotNowMenu)}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border text-xs font-medium transition-colors cursor-pointer ${
                  reminder.reminderStatus === 'pending_recall' || showNotNowMenu
                    ? 'bg-[#241F16] border-[#443722] text-[#F3E2BD] hover:bg-[#2C251A]'
                    : 'bg-[#1C1C1C] hover:bg-[#252525] border-[#2B2B2B] text-[#CCCCCC] hover:text-[#FFFFFF]'
                }`}
              >
                <Clock className="w-3.5 h-3.5 text-amber-400/90" />
                <span>Not now</span>
              </button>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => archiveItem(item.id)}
                className="p-2 rounded-lg text-[#666666] hover:text-[#FFAA33] hover:bg-[#1E1E1E] transition-colors cursor-pointer"
                title="Archive"
              >
                <Archive className="w-4 h-4" />
              </button>
              <button
                onClick={() => deleteItem(item.id)}
                className="p-2 rounded-lg text-[#666666] hover:text-[#EE5555] hover:bg-[#1E1E1E] transition-colors cursor-pointer"
                title="Delete permanently"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
