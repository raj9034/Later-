import React, { useRef } from 'react';
import { useLater } from '../context/LaterContext';
import { getTimeBucket } from '../utils/timeScheduler';
import { SavedItem, SwipeView, TimeBucket } from '../types';
import { TimelineItemRow } from './TimelineItemRow';
import { MemoryMoment } from './MemoryMoment';
import { WhatShouldIDealWith } from './WhatShouldIDealWith';
import { motion, AnimatePresence } from 'motion/react';

const ORDERED_BUCKETS: TimeBucket[] = [
  'NOW',
  'TODAY',
  'TONIGHT',
  'TOMORROW',
  'THIS WEEK',
  'LATER',
];

const SWIPE_ORDER: SwipeView[] = [
  'ALL',
  'LINKS',
  'SCREENSHOTS',
  'NOTES',
  'TASKS',
  'PEOPLE',
  'PLACES',
];

export const TimelineList: React.FC = () => {
  const { items, activeSwipeView, setActiveSwipeView } = useLater();
  const touchStartX = useRef<number | null>(null);

  // Filter unarchived items according to active swipe view
  const filteredItems = items.filter((item) => {
    if (item.isArchived) return false;
    if (activeSwipeView === 'ALL') return true;
    const t = item.contentType || item.type;
    if (activeSwipeView === 'LINKS')
      return t === 'link' || t === 'video' || t === 'product' || t === 'article';
    if (activeSwipeView === 'SCREENSHOTS')
      return t === 'screenshot' || t === 'image';
    if (activeSwipeView === 'NOTES')
      return t === 'note' || t === 'idea';
    if (activeSwipeView === 'TASKS')
      return t === 'task' || t === 'event';
    if (activeSwipeView === 'PEOPLE')
      return t === 'person' || t === 'phone_number';
    if (activeSwipeView === 'PLACES')
      return t === 'place';
    return true;
  });

  // Group items by time bucket
  const grouped: Record<TimeBucket, SavedItem[]> = {
    NOW: [],
    TODAY: [],
    TONIGHT: [],
    TOMORROW: [],
    'THIS WEEK': [],
    LATER: [],
  };

  filteredItems.forEach((item) => {
    const bucket = getTimeBucket(item.reminderTime || item.scheduledFor);
    grouped[bucket].push(item);
  });

  // Handle horizontal swipe gestures
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const diff = e.changedTouches[0].clientX - touchStartX.current;
    touchStartX.current = null;

    if (Math.abs(diff) > 50) {
      const currentIndex = SWIPE_ORDER.indexOf(activeSwipeView);
      if (diff < 0 && currentIndex < SWIPE_ORDER.length - 1) {
        // Swiped left -> next view
        setActiveSwipeView(SWIPE_ORDER[currentIndex + 1]);
      } else if (diff > 0 && currentIndex > 0) {
        // Swiped right -> previous view
        setActiveSwipeView(SWIPE_ORDER[currentIndex - 1]);
      }
    }
  };

  return (
    <div
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      className="w-full space-y-6 pt-2 pb-16"
    >
      {/* Calm In-App Memory Moment for surfaced memories */}
      {activeSwipeView === 'ALL' && <MemoryMoment />}

      {/* Intelligent Priority Resurfacing */}
      {activeSwipeView === 'ALL' && <WhatShouldIDealWith />}

      <AnimatePresence mode="wait">
        <motion.div
          key={activeSwipeView}
          initial={{ opacity: 0, x: 8 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -8 }}
          transition={{ duration: 0.14 }}
          className="space-y-6"
        >
          {filteredItems.length === 0 ? (
            <div className="py-16 text-center">
              <p className="text-sm text-[#777777]">Nothing saved here yet</p>
              <p className="text-xs text-[#444444] mt-1 font-mono">
                Capture links, notes, screenshots, or places above
              </p>
            </div>
          ) : (
            ORDERED_BUCKETS.map((bucket) => {
              const bucketItems = grouped[bucket];
              if (bucketItems.length === 0) return null;

              return (
                <div key={bucket} className="space-y-1">
                  {/* Bucket Header */}
                  <div className="flex items-center gap-2 px-3 py-1">
                    <span
                      className={`text-[11px] font-mono font-medium tracking-wider ${
                        bucket === 'NOW'
                          ? 'text-[#FFAA33]'
                          : bucket === 'TODAY' || bucket === 'TONIGHT'
                          ? 'text-[#E0E0E0]'
                          : 'text-[#666666]'
                      }`}
                    >
                      {bucket}
                    </span>
                    <div className="h-px flex-1 bg-[#1A1A1A]" />
                    <span className="text-[10px] font-mono text-[#555555]">
                      {bucketItems.length}
                    </span>
                  </div>

                  {/* List of items */}
                  <div className="divide-y divide-[#161616]">
                    {bucketItems.map((item) => (
                      <TimelineItemRow key={item.id} item={item} />
                    ))}
                  </div>
                </div>
              );
            })
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
