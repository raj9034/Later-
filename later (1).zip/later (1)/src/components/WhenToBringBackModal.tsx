import React, { useState } from 'react';
import { useLater } from '../context/LaterContext';
import { SchedulePreset, FlexiblePeriod, ItemReminder } from '../types';
import { calculateFlexibleTarget } from '../utils/reminderService';
import {
  Clock,
  Moon,
  Sun,
  CalendarDays,
  CalendarRange,
  Calendar,
  Sparkles,
  X,
  Check,
  Compass,
  Bell,
  Hourglass,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type TabMode = 'flexible' | 'specific' | 'none';

export const WhenToBringBackModal: React.FC = () => {
  const { pendingItemForSchedule, setPendingItemForSchedule, setReminderForItem } = useLater();

  const [activeTab, setActiveTab] = useState<TabMode>('flexible');
  const [showCustomPicker, setShowCustomPicker] = useState(false);
  const [customDateTime, setCustomDateTime] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    d.setHours(19, 0, 0, 0);
    return d.toISOString().slice(0, 16);
  });

  if (!pendingItemForSchedule) return null;

  const item = pendingItemForSchedule;

  const handleFlexibleSelect = (period: FlexiblePeriod) => {
    const target = calculateFlexibleTarget(period);
    const reminder: ItemReminder = {
      type: 'flexible',
      flexiblePeriod: period,
      scheduledAt: target.iso,
      reminderStatus: 'waiting',
    };
    setReminderForItem(item.id, reminder);
    setPendingItemForSchedule(null);
  };

  const handleSpecificPreset = (preset: 'today_evening' | 'tomorrow_morning' | 'tomorrow_evening') => {
    const d = new Date();
    if (preset === 'today_evening') {
      d.setHours(19, 0, 0, 0);
      if (d.getTime() <= Date.now()) {
        d.setHours(21, 0, 0, 0);
      }
    } else if (preset === 'tomorrow_morning') {
      d.setDate(d.getDate() + 1);
      d.setHours(9, 0, 0, 0);
    } else if (preset === 'tomorrow_evening') {
      d.setDate(d.getDate() + 1);
      d.setHours(19, 0, 0, 0);
    }

    const reminder: ItemReminder = {
      type: 'scheduled',
      scheduledAt: d.toISOString(),
      reminderStatus: 'waiting',
    };
    setReminderForItem(item.id, reminder);
    setPendingItemForSchedule(null);
  };

  const handleCustomConfirm = () => {
    if (!customDateTime) return;
    const iso = new Date(customDateTime).toISOString();
    const reminder: ItemReminder = {
      type: 'scheduled',
      scheduledAt: iso,
      reminderStatus: 'waiting',
    };
    setReminderForItem(item.id, reminder);
    setPendingItemForSchedule(null);
  };

  const handleNoTimeSelect = () => {
    const reminder: ItemReminder = {
      type: 'none',
      reminderStatus: 'waiting',
    };
    setReminderForItem(item.id, reminder);
    setPendingItemForSchedule(null);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setPendingItemForSchedule(null)}
          className="absolute inset-0 bg-[#000000]/75 backdrop-blur-xs"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 24 }}
          transition={{ duration: 0.18, ease: 'easeOut' }}
          className="relative w-full max-w-md bg-[#141414] border-t sm:border border-[#262626] rounded-t-2xl sm:rounded-2xl p-5 shadow-2xl z-10"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-[#202020]">
            <div>
              <p className="text-[11px] font-mono uppercase tracking-widest text-[#888888]">
                Save to Later
              </p>
              <h3 className="text-sm sm:text-base font-medium text-[#F0F0F0] mt-0.5">
                When should this be brought back?
              </h3>
            </div>
            <button
              onClick={() => setPendingItemForSchedule(null)}
              className="p-1 rounded text-[#777777] hover:text-[#DDDDDD] hover:bg-[#1F1F1F] transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Quick item excerpt */}
          <div className="py-2 px-3 my-3 rounded-lg bg-[#181818] border border-[#242424] text-xs text-[#AAAAAA] truncate">
            {item.title}
          </div>

          {/* Mode Selector Tabs */}
          <div className="grid grid-cols-3 gap-1 p-1 bg-[#1A1A1A] rounded-lg border border-[#242424] mb-3">
            <button
              type="button"
              onClick={() => {
                setActiveTab('flexible');
                setShowCustomPicker(false);
              }}
              className={`py-1.5 px-2 text-xs rounded-md font-medium transition-all text-center cursor-pointer ${
                activeTab === 'flexible'
                  ? 'bg-[#282828] text-[#FFFFFF] shadow-xs'
                  : 'text-[#888888] hover:text-[#CCCCCC]'
              }`}
            >
              Flexible time
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('specific')}
              className={`py-1.5 px-2 text-xs rounded-md font-medium transition-all text-center cursor-pointer ${
                activeTab === 'specific'
                  ? 'bg-[#282828] text-[#FFFFFF] shadow-xs'
                  : 'text-[#888888] hover:text-[#CCCCCC]'
              }`}
            >
              Specific time
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('none');
                setShowCustomPicker(false);
              }}
              className={`py-1.5 px-2 text-xs rounded-md font-medium transition-all text-center cursor-pointer ${
                activeTab === 'none'
                  ? 'bg-[#282828] text-[#FFFFFF] shadow-xs'
                  : 'text-[#888888] hover:text-[#CCCCCC]'
              }`}
            >
              No time
            </button>
          </div>

          {/* TAB 1: FLEXIBLE TIME */}
          {activeTab === 'flexible' && (
            <div className="space-y-1.5">
              <p className="text-[11px] text-[#777777] mb-2">
                Resurfaces naturally in your memory without rigid alarms.
              </p>

              <button
                type="button"
                onClick={() => handleFlexibleSelect('later_today')}
                className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg bg-[#181818]/70 hover:bg-[#202020] border border-[#222222] hover:border-[#2E2E2E] text-left transition-colors cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <Clock className="w-4 h-4 text-[#888888] group-hover:text-[#CCCCCC]" />
                  <span className="text-xs font-medium text-[#EDEDED]">Later today</span>
                </div>
                <span className="text-[11px] font-mono text-[#666666] group-hover:text-[#888888]">
                  In a few hours
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleFlexibleSelect('tomorrow')}
                className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg bg-[#181818]/70 hover:bg-[#202020] border border-[#222222] hover:border-[#2E2E2E] text-left transition-colors cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <Sun className="w-4 h-4 text-[#888888] group-hover:text-[#CCCCCC]" />
                  <span className="text-xs font-medium text-[#EDEDED]">Tomorrow</span>
                </div>
                <span className="text-[11px] font-mono text-[#666666] group-hover:text-[#888888]">
                  Next morning
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleFlexibleSelect('weekend')}
                className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg bg-[#181818]/70 hover:bg-[#202020] border border-[#222222] hover:border-[#2E2E2E] text-left transition-colors cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <CalendarDays className="w-4 h-4 text-[#888888] group-hover:text-[#CCCCCC]" />
                  <span className="text-xs font-medium text-[#EDEDED]">This weekend</span>
                </div>
                <span className="text-[11px] font-mono text-[#666666] group-hover:text-[#888888]">
                  Saturday morning
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleFlexibleSelect('next_week')}
                className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg bg-[#181818]/70 hover:bg-[#202020] border border-[#222222] hover:border-[#2E2E2E] text-left transition-colors cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <CalendarRange className="w-4 h-4 text-[#888888] group-hover:text-[#CCCCCC]" />
                  <span className="text-xs font-medium text-[#EDEDED]">Next week</span>
                </div>
                <span className="text-[11px] font-mono text-[#666666] group-hover:text-[#888888]">
                  Monday morning
                </span>
              </button>
            </div>
          )}

          {/* TAB 2: SPECIFIC TIME */}
          {activeTab === 'specific' && (
            <div>
              {!showCustomPicker ? (
                <div className="space-y-1.5">
                  <p className="text-[11px] text-[#777777] mb-2">
                    Notifies you gently at the precise scheduled time.
                  </p>

                  <button
                    type="button"
                    onClick={() => handleSpecificPreset('today_evening')}
                    className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg bg-[#181818]/70 hover:bg-[#202020] border border-[#222222] hover:border-[#2E2E2E] text-left transition-colors cursor-pointer group"
                  >
                    <div className="flex items-center gap-3">
                      <Moon className="w-4 h-4 text-[#888888] group-hover:text-[#CCCCCC]" />
                      <span className="text-xs font-medium text-[#EDEDED]">Today</span>
                    </div>
                    <span className="text-[11px] font-mono text-[#666666] group-hover:text-[#888888]">
                      7:00 PM
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSpecificPreset('tomorrow_morning')}
                    className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg bg-[#181818]/70 hover:bg-[#202020] border border-[#222222] hover:border-[#2E2E2E] text-left transition-colors cursor-pointer group"
                  >
                    <div className="flex items-center gap-3">
                      <Sun className="w-4 h-4 text-[#888888] group-hover:text-[#CCCCCC]" />
                      <span className="text-xs font-medium text-[#EDEDED]">Tomorrow</span>
                    </div>
                    <span className="text-[11px] font-mono text-[#666666] group-hover:text-[#888888]">
                      9:00 AM
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSpecificPreset('tomorrow_evening')}
                    className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg bg-[#181818]/70 hover:bg-[#202020] border border-[#222222] hover:border-[#2E2E2E] text-left transition-colors cursor-pointer group"
                  >
                    <div className="flex items-center gap-3">
                      <Moon className="w-4 h-4 text-[#888888] group-hover:text-[#CCCCCC]" />
                      <span className="text-xs font-medium text-[#EDEDED]">Tomorrow evening</span>
                    </div>
                    <span className="text-[11px] font-mono text-[#666666] group-hover:text-[#888888]">
                      7:00 PM
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowCustomPicker(true)}
                    className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg bg-[#181818]/70 hover:bg-[#202020] border border-[#222222] hover:border-[#2E2E2E] text-left transition-colors cursor-pointer group"
                  >
                    <div className="flex items-center gap-3">
                      <Calendar className="w-4 h-4 text-[#888888] group-hover:text-[#CCCCCC]" />
                      <span className="text-xs font-medium text-[#EDEDED]">
                        Custom date & time
                      </span>
                    </div>
                    <span className="text-[11px] font-mono text-[#666666] group-hover:text-[#888888]">
                      Pick exact time
                    </span>
                  </button>
                </div>
              ) : (
                <div className="space-y-3 pt-1">
                  <div>
                    <label className="block text-xs font-mono text-[#888888] mb-1.5">
                      Select date & time
                    </label>
                    <input
                      type="datetime-local"
                      value={customDateTime}
                      onChange={(e) => setCustomDateTime(e.target.value)}
                      className="w-full bg-[#181818] border border-[#2A2A2A] rounded-lg px-3 py-2 text-xs text-[#EDEDED] outline-none focus:border-[#444444]"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#202020]">
                    <button
                      type="button"
                      onClick={() => setShowCustomPicker(false)}
                      className="px-3 py-1.5 text-xs text-[#888888] hover:text-[#DDDDDD] cursor-pointer"
                    >
                      Back
                    </button>
                    <button
                      type="button"
                      onClick={handleCustomConfirm}
                      className="px-4 py-1.5 rounded-md bg-[#EDEDED] text-[#0D0D0D] font-medium text-xs hover:bg-[#FFFFFF] cursor-pointer flex items-center gap-1"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Set reminder</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: NO TIME / REMEMBER */}
          {activeTab === 'none' && (
            <div className="p-4 rounded-xl bg-[#181818] border border-[#242424] text-center space-y-3">
              <div className="w-10 h-10 rounded-full bg-[#222222] border border-[#2C2C2C] flex items-center justify-center text-amber-400/90 mx-auto">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-medium text-[#EDEDED]">
                  Save without a specific time
                </h4>
                <p className="text-[11px] text-[#777777] mt-1 max-w-xs mx-auto leading-relaxed">
                  Saved in your Later memory. You can search for it anytime or let Later surface it when relevant.
                </p>
              </div>

              <button
                type="button"
                onClick={handleNoTimeSelect}
                className="w-full py-2 px-4 rounded-lg bg-[#252525] hover:bg-[#2F2F2F] text-[#EDEDED] text-xs font-medium transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5 text-[#4ADE80]" />
                <span>Save to memory for someday</span>
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
