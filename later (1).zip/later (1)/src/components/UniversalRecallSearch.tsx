import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useLater } from '../context/LaterContext';
import { SavedItem } from '../types';
import { formatReminderTime } from '../utils/timeScheduler';
import {
  Search,
  X,
  ArrowLeft,
  Play,
  ExternalLink,
  Camera,
  FileText,
  Phone,
  MapPin,
  Check,
  Sparkles,
} from 'lucide-react';

interface UniversalRecallSearchProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UniversalRecallSearch: React.FC<UniversalRecallSearchProps> = ({
  isOpen,
  onClose,
}) => {
  const { items, setSelectedItem, openItem } = useLater();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-focus input when opened
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  // Handle escape key to close
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Universal Search Filter across all fields
  const filteredItems = useMemo(() => {
    const trimmed = query.trim().toLowerCase();
    if (!trimmed) return [];

    const terms = trimmed.split(/\s+/).filter(Boolean);

    return items.filter((item) => {
      // Build searchable haystack
      const haystackParts: string[] = [
        item.title || '',
        item.summary || '',
        item.rawInput || '',
        item.rawContent || '',
        item.url || '',
        item.sourceDomain || '',
        item.contentType || '',
        item.type || '',
        item.intent || '',
        ...(item.topics || []),
        ...(item.places || []),
        ...(item.people || []),
        item.extractedMeta?.platform || '',
        item.extractedMeta?.personName || '',
        item.extractedMeta?.phoneNumber || '',
        item.extractedMeta?.address || '',
        item.extractedMeta?.price || '',
        item.extractedMeta?.timeHint || '',
      ];

      const fullHaystack = haystackParts.join(' ').toLowerCase();

      // All search terms must match somewhere in the item
      return terms.every((term) => fullHaystack.includes(term));
    });
  }, [items, query]);

  if (!isOpen) return null;

  // Natural Action on result click
  const handleItemClick = (item: SavedItem) => {
    if (item.url && (item.contentType === 'video' || item.contentType === 'link' || item.contentType === 'article' || item.contentType === 'product')) {
      // Natural action for video / web link is opening it
      openItem(item.id);
    } else {
      // Natural action for note, screenshot, person, place, task is opening detail sheet
      setSelectedItem(item);
    }
    onClose();
  };

  const renderItemTypeIcon = (item: SavedItem) => {
    if (item.imageAttachment) {
      return (
        <div className="w-7 h-7 rounded-md overflow-hidden bg-[#181818] border border-[#262626] shrink-0">
          <img
            src={item.imageAttachment}
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
      );
    }

    const type = item.contentType || item.type;

    switch (type) {
      case 'video':
        return (
          <div className="w-7 h-7 rounded-md bg-[#2B1414] border border-[#3E1E1E] flex items-center justify-center text-[#FF5555] shrink-0">
            <Play className="w-3 h-3 fill-current" />
          </div>
        );
      case 'person':
      case 'phone_number':
        return (
          <div className="w-7 h-7 rounded-md bg-[#161616] border border-[#262626] flex items-center justify-center text-[#999999] shrink-0">
            <Phone className="w-3 h-3" />
          </div>
        );
      case 'place':
        return (
          <div className="w-7 h-7 rounded-md bg-[#161616] border border-[#262626] flex items-center justify-center text-[#999999] shrink-0">
            <MapPin className="w-3 h-3" />
          </div>
        );
      case 'task':
      case 'event':
        return (
          <div className="w-7 h-7 rounded-md bg-[#161616] border border-[#262626] flex items-center justify-center text-[#999999] shrink-0">
            <Check className="w-3 h-3 stroke-[2.5]" />
          </div>
        );
      case 'link':
      case 'article':
      case 'product':
        return (
          <div className="w-7 h-7 rounded-md bg-[#13222D] border border-[#1E3547] flex items-center justify-center text-[#70C0FF] shrink-0">
            <ExternalLink className="w-3 h-3" />
          </div>
        );
      case 'screenshot':
      case 'image':
        return (
          <div className="w-7 h-7 rounded-md bg-[#161616] border border-[#262626] flex items-center justify-center text-[#999999] shrink-0">
            <Camera className="w-3 h-3" />
          </div>
        );
      case 'note':
      case 'idea':
      default:
        return (
          <div className="w-7 h-7 rounded-md bg-[#161616] border border-[#262626] flex items-center justify-center text-[#999999] shrink-0">
            <FileText className="w-3 h-3" />
          </div>
        );
    }
  };

  return (
    <div
      id="universal-recall-search-overlay"
      className="fixed inset-0 z-[70] bg-[#0A0A0A]/95 backdrop-blur-md flex flex-col items-center animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      {/* Search Header Container */}
      <div className="w-full max-w-xl px-4 sm:px-6 pt-4 pb-3 border-b border-[#1A1A1A]">
        <div className="flex items-center gap-2.5 bg-[#141414] border border-[#262626] focus-within:border-[#404040] rounded-xl px-3.5 py-2.5 transition-colors shadow-lg">
          {/* Back/Close button */}
          <button
            id="recall-search-back-btn"
            type="button"
            onClick={onClose}
            className="text-[#777777] hover:text-[#EEEEEE] p-0.5 rounded transition-colors cursor-pointer"
            title="Close search (Esc)"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          {/* Search Icon */}
          <Search className="w-4 h-4 text-[#555555] shrink-0" />

          {/* Input field */}
          <input
            id="recall-search-input"
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search your Later"
            className="w-full bg-transparent text-sm text-[#F0F0F0] placeholder-[#555555] outline-none font-sans"
            autoComplete="off"
            spellCheck="false"
          />

          {/* Clear button */}
          {query && (
            <button
              id="recall-search-clear-btn"
              type="button"
              onClick={() => {
                setQuery('');
                inputRef.current?.focus();
              }}
              className="p-1 text-[#666666] hover:text-[#FFFFFF] hover:bg-[#202020] rounded-full transition-colors cursor-pointer"
              title="Clear text"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Results / Suggestion Body */}
      <div className="w-full max-w-xl flex-1 overflow-y-auto px-4 sm:px-6 py-4">
        {query.trim() ? (
          filteredItems.length > 0 ? (
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between px-2 pb-1 text-[11px] font-mono text-[#666666]">
                <span>
                  {filteredItems.length} {filteredItems.length === 1 ? 'match' : 'matches'}
                </span>
                <span>Tap to recall</span>
              </div>

              {filteredItems.map((item) => {
                const reminderText = formatReminderTime(item.reminderTime || item.scheduledFor);
                return (
                  <div
                    key={item.id}
                    id={`recall-result-${item.id}`}
                    onClick={() => handleItemClick(item)}
                    className="group flex items-center justify-between py-2.5 px-3 rounded-xl border border-[#1C1C1C] bg-[#121212] hover:border-[#2C2C2C] hover:bg-[#181818] transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1 pr-2">
                      {renderItemTypeIcon(item)}

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium text-[#EAEAEA] group-hover:text-[#FFFFFF] truncate">
                            {item.title}
                          </p>
                          {item.intent && (
                            <span className="hidden sm:inline-block px-1.5 py-0.2 rounded text-[9px] font-mono uppercase bg-[#181818] text-[#777777] border border-[#242424]">
                              {item.intent}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2 mt-0.5 text-xs text-[#666666] font-mono truncate">
                          {item.sourceDomain && (
                            <span className="text-[#888888]">{item.sourceDomain} ·</span>
                          )}
                          {item.places && item.places.length > 0 && (
                            <span className="text-[#888888]">{item.places.join(', ')} ·</span>
                          )}
                          {item.people && item.people.length > 0 && (
                            <span className="text-[#888888]">{item.people.join(', ')} ·</span>
                          )}
                          <span className="text-[#AAAAAA]">{reminderText}</span>
                        </div>
                      </div>
                    </div>

                    {/* Action Icon Hint */}
                    <div className="text-[#666666] group-hover:text-[#DDDDDD] p-1 transition-colors">
                      {item.url ? (
                        <ExternalLink className="w-3.5 h-3.5" />
                      ) : (
                        <FileText className="w-3.5 h-3.5" />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            /* Empty State */
            <div
              id="recall-search-empty-state"
              className="py-16 flex flex-col items-center justify-center text-center px-4"
            >
              <div className="w-10 h-10 rounded-full bg-[#161616] border border-[#242424] flex items-center justify-center text-[#555555] mb-3">
                <Search className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-medium text-[#EDEDED] mb-1">
                Nothing found yet
              </h3>
              <p className="text-xs text-[#777777] max-w-xs leading-relaxed">
                Try another word from what you remember.
              </p>
            </div>
          )
        ) : (
          /* Initial Guidance State */
          <div className="py-10 flex flex-col items-center text-center px-4">
            <div className="w-8 h-8 rounded-full bg-[#141414] border border-[#222222] flex items-center justify-center text-[#666666] mb-2.5">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            <p className="text-xs text-[#777777] mb-4 max-w-xs">
              Type any word you remember — a place, name, topic, note fragment, or website.
            </p>

            {/* Quick Keyword Example Suggestions */}
            <div className="flex flex-wrap items-center justify-center gap-1.5 max-w-sm">
              {['kyoto', 'woodworking', 'keyboard', 'design', 'arjun'].map((term) => (
                <button
                  key={term}
                  type="button"
                  onClick={() => setQuery(term)}
                  className="px-2.5 py-1 rounded-md bg-[#141414] hover:bg-[#1E1E1E] border border-[#222222] text-[11px] text-[#888888] hover:text-[#CCCCCC] font-mono transition-colors cursor-pointer"
                >
                  "{term}"
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
