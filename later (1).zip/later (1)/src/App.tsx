/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { LaterProvider, useLater } from './context/LaterContext';
import { Header } from './components/Header';
import { UniversalCapture } from './components/UniversalCapture';
import { HorizontalSwipeNav } from './components/HorizontalSwipeNav';
import { TimelineList } from './components/TimelineList';
import { ScheduleView } from './components/ScheduleView';
import { WhenToBringBackModal } from './components/WhenToBringBackModal';
import { ItemDetailSheet } from './components/ItemDetailSheet';
import { Toast } from './components/Toast';
import { InstantCaptureOrb } from './components/instant-capture/InstantCaptureOrb';
import { UniversalRecallSearch } from './components/UniversalRecallSearch';

const HomeScreen: React.FC = () => {
  const { viewMode, isSearchOpen, setIsSearchOpen } = useLater();

  return (
    <div className="min-h-screen bg-[#0D0D0D] text-[#EDEDED] flex flex-col font-sans relative selection:bg-[#2A2A2A] selection:text-[#FFFFFF]">
      {/* Toast Feedback */}
      <Toast />

      {/* Floating Instant Capture Orb for Cross-App Clipboard Experience */}
      <InstantCaptureOrb />

      {/* Universal Recall Search Overlay */}
      <UniversalRecallSearch
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
      />

      {/* Header */}
      <Header />

      {/* Main Single Stream Experience */}
      <main className="flex-1 w-full max-w-xl mx-auto px-4 sm:px-6 pt-5 flex flex-col gap-4">
        {/* Dominant Universal Capture */}
        <section>
          <UniversalCapture />
        </section>

        {/* Horizontal Perspective Horizon */}
        {viewMode === 'grouped' && (
          <section>
            <HorizontalSwipeNav />
          </section>
        )}

        {/* Main Content Stream: Grouped Timeline or Agenda Schedule */}
        <section className="flex-1">
          {viewMode === 'grouped' ? <TimelineList /> : <ScheduleView />}
        </section>
      </main>

      {/* Interactive Sheets */}
      <WhenToBringBackModal />
      <ItemDetailSheet />
    </div>
  );
};

export default function App() {
  return (
    <LaterProvider>
      <HomeScreen />
    </LaterProvider>
  );
}
