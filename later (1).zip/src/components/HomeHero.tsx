import React, { useMemo } from 'react';
import { useLater } from '../context/LaterContext';
import { Inbox, BellRing, Link2, StickyNote, Leaf } from 'lucide-react';

/**
 * Editorial hero headline for the Home tab — a date-stamped, oversized
 * serif headline with a mixed-color accent word, in the spirit of confident
 * "Grounded Motion" branding rather than a generic app dashboard greeting.
 * The headline itself is data-driven (reflects actual pending item count)
 * so it earns its place instead of being decorative filler text.
 *
 * Below it: a 4-up stats row (Items / Reminders / Links / Notes — all real,
 * computed numbers using the exact same contentType classification
 * TimelineList's own LINKS/NOTES filters use, so these agree with what
 * tapping those filters actually shows), a small decorative leaf accent
 * and encouragement note, and a closing quote card. The quote card uses a
 * CSS gradient rather than a stock photo (no network access to source a
 * licensed image, and a real app shouldn't ship one of unclear license).
 */
export const HomeHero: React.FC = () => {
  const { items } = useLater();

  const dateStamp = useMemo(() => {
    const d = new Date();
    return d
      .toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })
      .toUpperCase();
  }, []);

  const pendingCount = useMemo(
    () => items.filter((i) => !i.isDone && !i.isArchived).length,
    [items]
  );

  const totalCount = useMemo(
    () => items.filter((i) => !i.isArchived).length,
    [items]
  );

  const reminderCount = useMemo(
    () => items.filter((i) => !i.isArchived && (i.reminderTime || i.scheduledFor)).length,
    [items]
  );

  // Matches TimelineList's own LINKS/NOTES contentType classification
  // exactly, so these stat counts agree with what tapping those filter
  // tabs actually shows — not a separately-invented definition.
  const linksCount = useMemo(
    () =>
      items.filter((i) => {
        if (i.isArchived) return false;
        const t = i.contentType || i.type;
        return t === 'link' || t === 'video' || t === 'product' || t === 'article';
      }).length,
    [items]
  );

  const notesCount = useMemo(
    () =>
      items.filter((i) => {
        if (i.isArchived) return false;
        const t = i.contentType || i.type;
        return t === 'note' || t === 'idea';
      }).length,
    [items]
  );

  const { lead, accent } = useMemo(() => {
    if (pendingCount === 0) {
      return { lead: 'A clean slate.', accent: 'Capture something.' };
    }
    if (pendingCount === 1) {
      return { lead: 'One thing is', accent: 'waiting on you.' };
    }
    return { lead: `${pendingCount} things are`, accent: 'waiting on you.' };
  }, [pendingCount]);

  // Each stat card gets its own distinct pastel identity (background tint
  // + matching icon color). Colors deepened/saturated from the original
  // pastel picks — measured directly against a user screenshot showing
  // the Reminders card (sage-soft, #E8F1EB) blending into the mint page
  // background (~#F3F9F5, only ~35 total RGB-channel difference) badly
  // enough to look "dull/dirty" rather than like a distinct card. Boosted
  // saturation on all four via HSL math so they read clearly against the
  // mint backdrop while staying pastel in character, not garish.
  const stats = [
    {
      icon: Inbox,
      count: totalCount,
      label: totalCount === 1 ? 'Item' : 'Items',
      cardClass: 'stat-card-items',
    },
    {
      icon: BellRing,
      count: reminderCount,
      label: reminderCount === 1 ? 'Reminder' : 'Reminders',
      cardClass: 'stat-card-reminders',
    },
    {
      icon: Link2,
      count: linksCount,
      label: linksCount === 1 ? 'Link' : 'Links',
      cardClass: 'stat-card-links',
    },
    {
      icon: StickyNote,
      count: notesCount,
      label: notesCount === 1 ? 'Note' : 'Notes',
      cardClass: 'stat-card-notes',
    },
  ];

  return (
    <div className="pt-1 pb-1">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="type-label text-[var(--accent)] mb-2">{dateStamp}</p>
          <h1 className="type-page-title text-[var(--text-primary)]">
            {lead}{' '}
            <span className="type-headline-accent">{accent}</span>
          </h1>
          <p className="type-body-sm text-[var(--text-secondary)] mt-1.5">
            Small steps today. A calmer tomorrow. ♡
          </p>
        </div>

        {/* Small decorative leaf accent + handwritten-style encouragement,
            in the spirit of the reference design's plant illustration —
            built from an existing icon rather than a sourced image.
            Fixed from a previous "hidden xs:flex" which never showed on
            any real device since xs isn't a defined breakpoint here. */}
        <div className="flex sm:flex flex-col items-end gap-1.5 pt-1 shrink-0 max-w-[90px]">
          <Leaf className="w-7 h-7 text-[var(--sage)] rotate-[18deg]" strokeWidth={1.5} />
          <p className="font-onboarding-serif italic text-[11px] text-[var(--text-tertiary)] text-right leading-tight">
            You're doing<br />great. ♡
          </p>
        </div>
      </div>

      {/* Stats row — clean, compact vertical cards, each with its own
          pastel identity matching the reference exactly. Real, computed
          numbers, not decorative. */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5">
        {stats.map(({ icon: Icon, count, label, cardClass }) => (
          <div
            key={label}
            className={`flex flex-col gap-2 px-4 py-3.5 rounded-2xl ${cardClass}`}
            style={{ boxShadow: 'var(--elevation-1)' }}
          >
            <Icon className="w-5 h-5" strokeWidth={2} />
            <div>
              <span className="type-display text-[var(--text-primary)] !text-[22px] block leading-none">
                {count}
              </span>
              <span className="type-caption text-[var(--text-secondary)]">{label}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

/**
 * Closing quote card for the bottom of the Home feed — a calm, encouraging
 * moment that reinforces "your life is remembered for you" rather than a
 * productivity-dashboard tone. Rendered as its own export so App.tsx can
 * place it at the end of the Home tab's content, after the timeline list,
 * matching the reference design's placement.
 */
export const HomeQuoteCard: React.FC = () => {
  return (
    <div
      className="relative overflow-hidden rounded-3xl p-6 mt-2"
      style={{
        background:
          'linear-gradient(160deg, #2A4A3C 0%, #1F5A46 45%, #C89A42 100%)',
      }}
    >
      <p className="type-body font-semibold text-white/95 leading-snug max-w-[75%]">
        A more organized you, a calmer tomorrow.
      </p>
      <p className="type-caption text-white/70 mt-2 max-w-[70%]">
        Progress lives in the little things. ♡
      </p>
    </div>
  );
};
