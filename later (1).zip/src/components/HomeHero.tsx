import React, { useMemo } from 'react';
import { useLater } from '../context/LaterContext';

/**
 * Editorial hero headline for the Home tab — a date-stamped, oversized
 * headline with a mixed-color accent word, in the spirit of confident
 * "Grounded Motion" branding rather than a generic app dashboard greeting.
 * The headline itself is data-driven (reflects actual pending item count)
 * so it earns its place instead of being decorative filler text.
 */
export const HomeHero: React.FC = () => {
  const { items } = useLater();

  const dateStamp = useMemo(() => {
    const d = new Date();
    return d
      .toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })
      .toUpperCase();
  }, []);

  const pendingCount = useMemo(
    () => items.filter((i) => !i.isDone && !i.isArchived).length,
    [items]
  );

  const { lead, accent } = useMemo(() => {
    if (pendingCount === 0) {
      return { lead: 'A clean slate.', accent: 'Capture something.' };
    }
    if (pendingCount === 1) {
      return { lead: 'One thing is', accent: 'waiting on you.' };
    }
    return { lead: `${pendingCount} things are`, accent: 'waiting on you.' };
  }, [pendingCount]);

  return (
    <div className="pt-1 pb-1">
      <p className="type-label text-[var(--accent)] mb-1.5">{dateStamp}</p>
      <h1 className="type-page-title text-[var(--text-primary)]">
        {lead}{' '}
        <span className="type-headline-accent">{accent}</span>
      </h1>
    </div>
  );
};
