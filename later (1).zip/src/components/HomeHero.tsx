import React, { useMemo } from 'react';
import { useLater } from '../context/LaterContext';

/**
 * Editorial hero headline for the Home tab — a date-stamped, oversized
 * headline with a mixed-color accent word, in the spirit of confident
 * "Grounded Motion" branding rather than a generic app dashboard greeting.
 * The headline itself is data-driven (reflects actual pending item count)
 * so it earns its place instead of being decorative filler text.
 *
 * A compact stats row sits underneath (Items saved / Reminders set) —
 * both real, derivable numbers — so the hero's lower half isn't empty
 * whitespace and gives a quick at-a-glance sense of "how much is in here"
 * before scrolling into the list.
 */
export const HomeHero: React.FC = () => {
  const { items } = useLater();

  const dateStamp = useMemo(() => {
    const d = new Date();
    return d
      .toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })
      .toUpperCase();
  }, []);

  const pendingCount = useMemo(
    () => items.filter((i) => !i.isDone && !i.isArchived).length,
    [items]
  );

  const totalCount = useMemo(
    () => items.filter((i) => !i.isArchived).length,
    [items]
  );

  const reminderCount = useMemo(
    () => items.filter((i) => !i.isArchived && (i.reminderTime || i.scheduledFor)).length,
    [items]
  );

  const { lead, accent } = useMemo(() => {
    if (pendingCount === 0) {
      return { lead: 'A clean slate.', accent: 'Capture something.' };
    }
    if (pendingCount === 1) {
      return { lead: 'One thing is', accent: 'waiting on you.' };
    }
    return { lead: `${pendingCount} things are`, accent: 'waiting on you.' };
  }, [pendingCount]);

  return (
    <div className="pt-1 pb-1">
      <p className="type-label text-[var(--accent)] mb-1.5">{dateStamp}</p>
      <h1 className="type-page-title text-[var(--text-primary)]">
        {lead}{' '}
        <span className="type-headline-accent">{accent}</span>
      </h1>

      {/* Stats row — fills the space under the headline with real,
          glanceable numbers instead of leaving it empty */}
      <div className="flex items-center gap-2 mt-3.5">
        <div className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-[var(--clay-soft)] border border-[rgba(193,102,63,0.18)]">
          <span className="type-display text-[var(--clay-deep)] dark:text-[var(--clay)] !text-[18px]">
            {totalCount}
          </span>
          <span className="type-caption text-[var(--clay-deep)] dark:text-[var(--clay)] opacity-80">
            {totalCount === 1 ? 'Item' : 'Items'}
          </span>
        </div>
        <div className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-[var(--sage-soft)] border border-[rgba(124,139,111,0.16)]">
          <span className="type-display text-[#4B5940] dark:text-[var(--sage)] !text-[18px]">
            {reminderCount}
          </span>
          <span className="type-caption text-[#4B5940] dark:text-[var(--sage)] opacity-80">
            {reminderCount === 1 ? 'Reminder' : 'Reminders'}
          </span>
        </div>
      </div>
    </div>
  );
};
