import React, { useMemo } from 'react';
import { useLater } from '../context/LaterContext';
import { Inbox, BellRing } from 'lucide-react';

/**
 * Editorial hero headline for the Home tab — a date-stamped, oversized
 * serif headline with a mixed-color accent word, in the spirit of confident
 * "Grounded Motion" branding rather than a generic app dashboard greeting.
 * The headline itself is data-driven (reflects actual pending item count)
 * so it earns its place instead of being decorative filler text.
 *
 * A compact stats row sits underneath (Items saved / Reminders set) —
 * both real, derivable numbers — so the hero's lower half isn't empty
 * whitespace and gives a quick at-a-glance sense of "how much is in here"
 * before scrolling into the list. Redesigned per the homepage visual
 * brief: clean vertical stat cards (icon, big number, label) on bright
 * white surfaces with a green icon accent, replacing the previous warm
 * horizontal pill treatment.
 */
export const HomeHero: React.FC = () => {
  const { items } = useLater();

  const dateStamp = useMemo(() => {
    const d = new Date();
    return d
      .toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })
      .toUpperCase();
  }, []);

  const pendingCount = useMemo(
    () => items.filter((i) => !i.isDone && !i.isArchived).length,
    [items]
  );

  const totalCount = useMemo(
    () => items.filter((i) => !i.isArchived).length,
    [items]
  );

  const reminderCount = useMemo(
    () => items.filter((i) => !i.isArchived && (i.reminderTime || i.scheduledFor)).length,
    [items]
  );

  const { lead, accent } = useMemo(() => {
    if (pendingCount === 0) {
      return { lead: 'A clean slate.', accent: 'Capture something.' };
    }
    if (pendingCount === 1) {
      return { lead: 'One thing is', accent: 'waiting on you.' };
    }
    return { lead: `${pendingCount} things are`, accent: 'waiting on you.' };
  }, [pendingCount]);

  return (
    <div className="pt-1 pb-1">
      <p className="type-label text-[var(--accent)] mb-2">{dateStamp}</p>
      <h1 className="type-page-title text-[var(--text-primary)]">
        {lead}{' '}
        <span className="type-headline-accent">{accent}</span>
      </h1>

      {/* Stats row — clean, compact vertical cards on bright surfaces with
          a green icon accent, per the homepage visual brief. Real,
          computed numbers, not decorative. */}
      <div className="grid grid-cols-2 gap-3 mt-5">
        <div className="flex flex-col gap-2 px-4 py-3.5 rounded-2xl bg-[var(--surface-elevated)] border border-[var(--border)]" style={{ boxShadow: 'var(--elevation-1)' }}>
          <div className="w-8 h-8 rounded-xl bg-[var(--accent-soft)] flex items-center justify-center">
            <Inbox className="w-4 h-4 text-[var(--accent)]" />
          </div>
          <div>
            <span className="type-display text-[var(--text-primary)] !text-[22px] block leading-none">
              {totalCount}
            </span>
            <span className="type-caption text-[var(--text-secondary)]">
              {totalCount === 1 ? 'Item' : 'Items'}
            </span>
          </div>
        </div>
        <div className="flex flex-col gap-2 px-4 py-3.5 rounded-2xl bg-[var(--surface-elevated)] border border-[var(--border)]" style={{ boxShadow: 'var(--elevation-1)' }}>
          <div className="w-8 h-8 rounded-xl bg-[var(--accent-soft)] flex items-center justify-center">
            <BellRing className="w-4 h-4 text-[var(--accent)]" />
          </div>
          <div>
            <span className="type-display text-[var(--text-primary)] !text-[22px] block leading-none">
              {reminderCount}
            </span>
            <span className="type-caption text-[var(--text-secondary)]">
              {reminderCount === 1 ? 'Reminder' : 'Reminders'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
