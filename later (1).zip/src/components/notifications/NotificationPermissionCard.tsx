import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, BellOff, X } from 'lucide-react';

interface NotificationPermissionCardProps {
  variant: 'ask' | 'blocked';
  title: string;
  description: string;
  primaryLabel: string;
  secondaryLabel: string;
  onPrimary: () => void;
  onSecondary: () => void;
  /** 'floating' = compact, non-blocking card with no backdrop (the
   * app-open recovery nudge). 'modal' = centered dialog with backdrop,
   * for the moment tied to a specific action like creating a reminder. */
  presentation?: 'floating' | 'modal';
}

/**
 * Shared visual shell for every notification-permission recovery prompt,
 * styled to match the existing ExactAlarmPermissionDialog exactly (same
 * card, spacing, buttons, animation) so this reads as a natural Later
 * component rather than a new design system.
 */
export const NotificationPermissionCard: React.FC<NotificationPermissionCardProps> = ({
  variant,
  title,
  description,
  primaryLabel,
  secondaryLabel,
  onPrimary,
  onSecondary,
  presentation = 'floating',
}) => {
  const Icon = variant === 'blocked' ? BellOff : Bell;

  const card = (
    <motion.div
      initial={{ opacity: 0, y: presentation === 'floating' ? -16 : 24, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: presentation === 'floating' ? -12 : 12, scale: 0.98 }}
      transition={{ duration: 0.22, ease: [0, 0, 0.2, 1] }}
      className="relative w-full max-w-sm rounded-3xl bg-[var(--surface-elevated)] border border-[var(--border)] shadow-2xl p-5 flex flex-col gap-3.5"
    >
      <button
        type="button"
        onClick={onSecondary}
        className="absolute top-4 right-4 p-1.5 rounded-full text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
        aria-label={secondaryLabel}
      >
        <X className="w-4 h-4" />
      </button>

      <div className="w-11 h-11 rounded-2xl glass-icon-square flex items-center justify-center text-[var(--accent)]">
        <Icon className="w-5 h-5" />
      </div>

      <div className="space-y-1.5 pr-4">
        <h2 className="type-heading-lg text-[var(--text-primary)]">{title}</h2>
        <p className="type-body-sm text-[var(--text-secondary)] leading-relaxed">{description}</p>
      </div>

      <div className="flex items-center gap-2.5 pt-1">
        <button
          type="button"
          onClick={onSecondary}
          className="flex-1 px-4 py-2.5 rounded-2xl bg-[var(--surface)] border border-[var(--border)] text-[var(--text-primary)] type-button hover:bg-[var(--surface-sunken)] active:scale-[0.98] press-interactive transition-all cursor-pointer"
        >
          {secondaryLabel}
        </button>
        <button
          type="button"
          onClick={onPrimary}
          className="flex-1 px-4 py-2.5 rounded-2xl bg-[var(--accent)] text-[var(--bg)] type-button font-semibold active:scale-[0.98] press-interactive transition-all cursor-pointer shadow-sm"
        >
          {primaryLabel}
        </button>
      </div>
    </motion.div>
  );

  if (presentation === 'modal') {
    return (
      <AnimatePresence>
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center p-4"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-0 bg-black/55 backdrop-blur-[2px]"
            onClick={onSecondary}
          />
          {card}
        </div>
      </AnimatePresence>
    );
  }

  // Floating, non-blocking: no backdrop, positioned below the header so
  // the rest of the app stays fully visible and usable behind it.
  return (
    <AnimatePresence>
      <div
        role="dialog"
        aria-modal="false"
        className="fixed top-[calc(env(safe-area-inset-top,0px)+68px)] inset-x-4 z-40 flex justify-center pointer-events-none"
      >
        <div className="pointer-events-auto w-full max-w-sm">{card}</div>
      </div>
    </AnimatePresence>
  );
};
