import React, { useEffect, useState, useCallback } from 'react';
import { Capacitor } from '@capacitor/core';
import { NotificationPermissionCard } from './NotificationPermissionCard';
import {
  getNotificationPermissionStatus,
  hasRequestedNotificationPermissionBefore,
  attemptEnableNotifications,
  openNotificationSettings,
} from '../../utils/notificationPermission';

interface NotificationRecoveryPromptProps {
  /** Onboarding hasn't been completed yet (still in progress, or this is
   * a brand-new session before it's decided) — never show over it. */
  suppressForOnboarding: boolean;
}

/**
 * The general "you opened Later and notifications are off" nudge (CASE 2),
 * including its escalation to the "Android is blocking this" explanation
 * (CASE 4) and re-checking permission whenever the app returns to the
 * foreground (CASE 7, e.g. coming back from Settings).
 *
 * Purely a UI-layer controller: it never schedules anything and never
 * touches reminder/notification-channel logic — it only reads live
 * permission status and offers the existing attemptEnableNotifications /
 * openNotificationSettings actions.
 */
export const NotificationRecoveryPrompt: React.FC<NotificationRecoveryPromptProps> = ({
  suppressForOnboarding,
}) => {
  const [status, setStatus] = useState<'unknown' | 'granted' | 'denied' | 'prompt'>('unknown');
  const [visible, setVisible] = useState(false);
  const [dismissedThisSession, setDismissedThisSession] = useState(false);

  const refreshStatus = useCallback(async () => {
    if (!Capacitor.isNativePlatform()) return;
    const current = await getNotificationPermissionStatus();
    setStatus(current);
  }, []);

  // Initial check on mount, then re-check every time the app returns to
  // the foreground — this is what lets a permission change made outside
  // the app (in Android Settings) be detected without polling.
  useEffect(() => {
    refreshStatus();
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') refreshStatus();
    };
    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('focus', refreshStatus);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('focus', refreshStatus);
    };
  }, [refreshStatus]);

  // Decide visibility purely from state — granted always wins (hides it
  // immediately, including mid-session if the user just enabled it), and
  // it only ever shows once per session even if the app keeps resuming.
  useEffect(() => {
    if (status === 'granted') {
      setVisible(false);
      return;
    }
    if (status === 'unknown') return;
    if (suppressForOnboarding) return;
    if (dismissedThisSession) return;
    setVisible(true);
  }, [status, suppressForOnboarding, dismissedThisSession]);

  if (!visible) return null;

  const isBlocked = hasRequestedNotificationPermissionBefore();

  const handlePrimary = async () => {
    if (isBlocked) {
      await openNotificationSettings();
      // Leave visible=true; the next foreground refresh (CASE 7) will
      // hide it automatically once the user actually grants it.
      return;
    }
    const result = await attemptEnableNotifications();
    if (result.granted) {
      setStatus('granted');
      setVisible(false);
    } else if (result.routedToSettings) {
      // stay visible — will now show the "blocked" copy on next render
    } else {
      // Denied via the real dialog just now — don't keep nagging this
      // session; it'll reappear (now in "blocked" mode) next app open.
      setDismissedThisSession(true);
      setVisible(false);
    }
  };

  const handleSecondary = () => {
    setDismissedThisSession(true);
    setVisible(false);
  };

  return isBlocked ? (
    <NotificationPermissionCard
      variant="blocked"
      title="Notifications are turned off"
      description="Android is currently blocking Later's notification permission. Turn notifications back on in Settings so your reminders can reach you."
      primaryLabel="Open Settings"
      secondaryLabel="Not now"
      onPrimary={handlePrimary}
      onSecondary={handleSecondary}
      presentation="floating"
    />
  ) : (
    <NotificationPermissionCard
      variant="ask"
      title="Keep Later close"
      description="Your reminders need notifications to find you at the right time."
      primaryLabel="Turn on notifications"
      secondaryLabel="Not now"
      onPrimary={handlePrimary}
      onSecondary={handleSecondary}
      presentation="floating"
    />
  );
};
