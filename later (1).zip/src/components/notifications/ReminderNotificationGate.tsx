import React from 'react';
import { NotificationPermissionCard } from './NotificationPermissionCard';
import {
  hasRequestedNotificationPermissionBefore,
  attemptEnableNotifications,
} from '../../utils/notificationPermission';

interface ReminderNotificationGateProps {
  /** Present only while LaterContext is waiting on the user's choice —
   * see setReminderForItem, which awaits this exact resolve() before
   * continuing to actually schedule the reminder. */
  pending: { resolve: () => void } | null;
}

/**
 * The compact prompt shown the moment a user sets a reminder (via
 * ItemDetailSheet, WhenToBringBackModal, etc.) while notifications are
 * off, instead of silently scheduling something that can never notify
 * them. Both choices ultimately let the reminder go through — this never
 * traps the user — the only difference is whether we also try to turn
 * notifications on first.
 */
export const ReminderNotificationGate: React.FC<ReminderNotificationGateProps> = ({ pending }) => {
  if (!pending) return null;

  const isBlocked = hasRequestedNotificationPermissionBefore();

  const handleTurnOn = async () => {
    try {
      await attemptEnableNotifications();
    } catch {
      // never block the reminder on a permission-flow failure
    }
    pending.resolve();
  };

  const handleContinue = () => {
    pending.resolve();
  };

  return isBlocked ? (
    <NotificationPermissionCard
      variant="blocked"
      title="Notifications are turned off"
      description="Android is currently blocking Later's notification permission. Turn notifications back on in Settings so this reminder can reach you."
      primaryLabel="Open Settings"
      secondaryLabel="Continue without notifications"
      onPrimary={handleTurnOn}
      onSecondary={handleContinue}
      presentation="modal"
    />
  ) : (
    <NotificationPermissionCard
      variant="ask"
      title="Turn on notifications"
      description="Later needs notifications to remind you when it matters."
      primaryLabel="Turn on notifications"
      secondaryLabel="Continue without notifications"
      onPrimary={handleTurnOn}
      onSecondary={handleContinue}
      presentation="modal"
    />
  );
};
