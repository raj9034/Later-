import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion } from 'motion/react';
import { useLater } from '../context/LaterContext';
import { useAuth } from '../context/AuthContext';
import { SavedItem } from '../types';
import { formatReminderTime } from '../utils/timeScheduler';
import { useScrollIntoViewOnFocus } from '../utils/useScrollIntoViewOnFocus';
import {
  Search,
  X,
  Play,
  ExternalLink,
  Camera,
  FileText,
  Phone,
  MapPin,
  Check,
  Leaf,
  Clock,
  Dumbbell,
  User,
  Plane,
  Laptop,
  Menu,
  Star,
  ChevronRight,
} from 'lucide-react';

interface UniversalRecallSearchProps {
  onClose: () => void;
  onOpenMenu?: () => void;
  onOpenProfile?: () => void;
}

const SEARCH_CATEGORIES = [
  { key: 'places', name: 'Places', meta: 'Kyoto · Goa · Cafés', term: 'places', icon: MapPin },
  { key: 'workouts', name: 'Workouts', meta: 'Routines · Progress', term: 'workout', icon: Dumbbell },
  { key: 'design', name: 'Design', meta: 'References · Figma', term: 'design', icon: FileText },
  { key: 'people', name: 'People', meta: 'Notes · Reminders', term: 'people', icon: User },
  { key: 'trips', name: 'Trips', meta: 'Maps · Itinerary', term: 'trip', icon: Plane },
  { key: 'tech', name: 'Tech', meta: 'Gadgets · Reviews', term: 'tech', icon: Laptop },
] as const;

const RECENT_SEARCHES_KEY = 'later_recent_searches';
const MAX_RECENT_SEARCHES = 6;

export const UniversalRecallSearch: React.FC<UniversalRecallSearchProps> = ({
  onClose,
  onOpenMenu,
  onOpenProfile,
}) => {
  const { items, setSelectedItem, openItem } = useLater();
  const { user } = useAuth();
  const [query, setQuery] = useState('');
  const [isInputFocused, setIsInputFocused] = useState(false);
  const [isTopBarScrolled, setIsTopBarScrolled] = useState(false);
  const scrollBodyRef = useRef<HTMLDivElement>(null);
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(RECENT_SEARCHES_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });
  const [activeFilter, setActiveFilter] = useState<'all' | 'link' | 'screenshot' | 'note' | 'urgent' | 'important' | 'chill'>('all');
  const inputRef = useRef<HTMLInputElement>(null);
  const handleFocusScroll = useScrollIntoViewOnFocus();

  const saveRecentSearch = (term: string) => {
    const trimmed = term.trim();
    if (!trimmed) return;
    setRecentSearches((prev) => {
      const next = [trimmed, ...prev.filter((t) => t.toLowerCase() !== trimmed.toLowerCase())].slice(
        0,
        MAX_RECENT_SEARCHES
      );
      try {
        localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(next));
      } catch {
        // Non-fatal: recent searches just won't persist this session
      }
      return next;
    });
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
    try {
      localStorage.removeItem(RECENT_SEARCHES_KEY);
    } catch {
      // Non-fatal
    }
  };

  // Auto-focus input on mount — this component only mounts while Search is
  // the active screen, so "mounted" already means "open".
  useEffect(() => {
    setTimeout(() => {
      inputRef.current?.focus();
    }, 50);
  }, []);

  // Handle escape key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  // Universal Search Filter across all fields, plus optional type/tag filter
  const filteredItems = useMemo(() => {
    const trimmed = query.trim().toLowerCase();

    const base = !trimmed
      ? items
      : items.filter((item) => {
          const terms = trimmed.split(/\s+/).filter(Boolean);
          const haystackParts: string[] = [
            item.title || '',
            item.summary || '',
            item.rawInput || '',
            item.rawContent || '',
            item.url || '',
            item.sourceDomain || '',
            item.contentType || '',
            item.type || '',
            item.intent || '',
            ...(item.topics || []),
            ...(item.places || []),
            ...(item.people || []),
            item.extractedMeta?.platform || '',
            item.extractedMeta?.personName || '',
            item.extractedMeta?.phoneNumber || '',
            item.extractedMeta?.address || '',
            item.extractedMeta?.price || '',
            item.extractedMeta?.timeHint || '',
          ];
          const fullHaystack = haystackParts.join(' ').toLowerCase();
          return terms.every((term) => fullHaystack.includes(term));
        });

    if (activeFilter === 'all') return trimmed ? base : [];

    const filteredByType = base.filter((item) => {
      const type = item.contentType || item.type;
      const tag = item.urgencyTag || item.urgency;
      if (activeFilter === 'link') return type === 'link' || type === 'article' || type === 'product' || type === 'video';
      if (activeFilter === 'screenshot') return type === 'screenshot' || type === 'image';
      if (activeFilter === 'note') return type === 'note' || type === 'idea';
      if (activeFilter === 'urgent') return tag === 'urgent';
      if (activeFilter === 'important') return tag === 'important';
      if (activeFilter === 'chill') return tag === 'chill';
      return true;
    });

    return filteredByType;
  }, [items, query, activeFilter]);

  const isFiltering = query.trim().length > 0 || activeFilter !== 'all';

  // Natural Action on result click
  const handleItemClick = (item: SavedItem) => {
    if (query.trim()) {
      saveRecentSearch(query);
    }
    if (item.url && (item.contentType === 'video' || item.contentType === 'link' || item.contentType === 'article' || item.contentType === 'product')) {
      // Natural action for video / web link is opening it
      openItem(item.id);
    } else {
      // Natural action for note, screenshot, person, place, task is opening detail sheet
      setSelectedItem(item);
    }
    onClose();
  };

  const renderItemTypeIcon = (item: SavedItem) => {
    if (item.imageAttachment) {
      return (
        <div className="w-8 h-8 rounded-lg overflow-hidden glass-icon-square shrink-0">
          <img
            src={item.imageAttachment}
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
      );
    }

    const type = item.contentType || item.type;

    switch (type) {
      case 'video':
        return (
          <div className="w-8 h-8 rounded-lg glass-icon-square flex items-center justify-center text-[var(--destructive)] shrink-0">
            <Play className="w-3.5 h-3.5 fill-current" />
          </div>
        );
      case 'person':
      case 'phone_number':
        return (
          <div className="w-8 h-8 rounded-lg glass-icon-square flex items-center justify-center text-[var(--text-secondary)] shrink-0">
            <Phone className="w-3.5 h-3.5" />
          </div>
        );
      case 'place':
        return (
          <div className="w-8 h-8 rounded-lg glass-icon-square flex items-center justify-center text-[var(--text-secondary)] shrink-0">
            <MapPin className="w-3.5 h-3.5" />
          </div>
        );
      case 'task':
      case 'event':
        return (
          <div className="w-8 h-8 rounded-lg glass-icon-square flex items-center justify-center text-[var(--text-secondary)] shrink-0">
            <Check className="w-3.5 h-3.5 stroke-[2.5]" />
          </div>
        );
      case 'link':
      case 'article':
      case 'product':
        return (
          <div className="w-8 h-8 rounded-lg glass-icon-square flex items-center justify-center text-[var(--accent)] shrink-0">
            <ExternalLink className="w-3.5 h-3.5" />
          </div>
        );
      case 'screenshot':
      case 'image':
        return (
          <div className="w-8 h-8 rounded-lg glass-icon-square flex items-center justify-center text-[var(--text-secondary)] shrink-0">
            <Camera className="w-3.5 h-3.5" />
          </div>
        );
      case 'note':
      case 'idea':
      default:
        return (
          <div className="w-8 h-8 rounded-lg glass-icon-square flex items-center justify-center text-[var(--text-secondary)] shrink-0">
            <FileText className="w-3.5 h-3.5" />
          </div>
        );
    }
  };

  const displayName = user?.displayName?.trim();
  const photoURL = user?.photoURL;
  const avatarInitial = (displayName?.[0] || user?.email?.[0] || '?').toUpperCase();

  const handleBodyScroll = (e: React.UIEvent<HTMLDivElement>) => {
    setIsTopBarScrolled(e.currentTarget.scrollTop > 4);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0, transition: { duration: 0.22, ease: [0, 0, 0.2, 1] } }}
      className="later-search-v2 w-full flex flex-col flex-1 relative"
      id="universal-recall-search-screen"
      style={{
        background: 'var(--bg-gradient)',
      }}
    >
      {/* Subtle grain texture, scoped to this screen rather than a global
          fixed overlay */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.06] dark:opacity-[0.05]"
        style={{
          mixBlendMode: 'overlay',
          backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><filter id="n"><feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="3" stitchTiles="stitch"/></filter><rect width="100%" height="100%" filter="url(%23n)"/></svg>')`,
          backgroundRepeat: 'repeat',
        }}
        aria-hidden="true"
      />

      {/* Top bar — compact "Search" identity (menu, title + tagline,
          avatar), same structural pattern as Home's Header but scoped to
          this screen's own file/stylesheet rather than reusing the shared
          <Header/> component (which has no "search" tab variant). Border
          appears only once the body below has scrolled. Same markup in
          both themes — search-redesign.css (light) and search-dark.css
          (dark) each recolor it; layout/structure never branches. */}
      <div
        className={`search-topbar sticky top-0 z-30 w-full px-4 sm:px-6 ${isTopBarScrolled ? 'is-scrolled' : ''}`}
        style={{ paddingTop: 'calc(12px + env(safe-area-inset-top, 0px))', paddingBottom: '12px' }}
      >
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              type="button"
              onClick={onOpenMenu}
              className="search-menu-btn shrink-0 w-9 h-9 rounded-full flex items-center justify-center cursor-pointer active:scale-[0.94] press-interactive"
              aria-label="Open menu"
            >
              <Menu className="w-4.5 h-4.5" />
            </button>
            <div className="min-w-0">
              <h1 className="search-title font-onboarding-serif text-[17px] font-medium leading-none truncate">
                Search
              </h1>
              <p className="search-subtitle text-[10px] mt-1 truncate">
                Find what matters, instantly.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenProfile}
            className="search-avatar-btn shrink-0 w-9 h-9 rounded-full overflow-hidden flex items-center justify-center font-display font-bold text-sm cursor-pointer"
            aria-label="Profile"
          >
            {photoURL ? (
              <img src={photoURL} alt="" className="w-full h-full object-cover" />
            ) : (
              avatarInitial
            )}
          </button>
        </div>
      </div>

      {/* Search bar — full-width pill, emerald focus ring, clear button
          appears once typing starts. */}
      <div className="w-full px-4 sm:px-6 pt-1 pb-3">
        <div
          className={`search-input-pill flex items-center gap-3 px-4 py-3 ${isInputFocused ? 'is-focused' : ''}`}
        >
          <Search className="search-icon w-5 h-5 shrink-0" />

          <input
            id="recall-search-input"
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={(e) => {
              setIsInputFocused(true);
              handleFocusScroll(e);
            }}
            onBlur={() => setIsInputFocused(false)}
            placeholder="Search your Later"
            className="w-full bg-transparent type-body outline-none font-body"
            autoComplete="off"
            spellCheck="false"
          />

          {query && (
            <button
              id="recall-search-clear-btn"
              type="button"
              onClick={() => {
                setQuery('');
                inputRef.current?.focus();
              }}
              className="search-clear-btn shrink-0 rounded-full flex items-center justify-center cursor-pointer active:scale-[0.92] press-interactive"
              title="Clear text"
              aria-label="Clear text"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Type/tag filter chips — lets people narrow by kind the way
          Google Keep's search filters do, without typing anything. */}
      <div className="w-full px-4 sm:px-6 pb-3 flex items-center gap-2 overflow-x-auto no-scrollbar">
        {(
          [
            { key: 'all', label: 'All' },
            { key: 'link', label: 'Links' },
            { key: 'screenshot', label: 'Screenshots' },
            { key: 'note', label: 'Notes' },
            { key: 'urgent', label: 'Priority' },
            { key: 'important', label: 'Important' },
            { key: 'chill', label: 'Chill' },
          ] as const
        ).map((f) => (
          <button
            key={f.key}
            type="button"
            onClick={() => setActiveFilter(f.key)}
            className={`search-filter-chip shrink-0 whitespace-nowrap transition-all duration-[var(--duration-fast)] ease-[var(--ease-standard)] cursor-pointer active:scale-[0.96] press-interactive ${
              activeFilter === f.key ? 'is-active' : ''
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Results / Suggestion Body */}
      <div
        ref={scrollBodyRef}
        onScroll={handleBodyScroll}
        className="w-full flex-1 overflow-y-auto px-4 sm:px-6 py-1"
      >
              {isFiltering ? (
                filteredItems.length > 0 ? (
                  <div className="search-results-list flex flex-col gap-2">
                    <div className="search-results-count flex items-center justify-between px-2 pb-1 type-label text-[var(--text-secondary)] font-body">
                      <span>
                        <span className="count-num">{filteredItems.length}</span>{' '}
                        {filteredItems.length === 1 ? 'match' : 'matches'}
                      </span>
                      <span className="search-results-hint">Tap to recall</span>
                    </div>

                    {filteredItems.map((item) => {
                      const reminderText = formatReminderTime(item.reminderTime || item.scheduledFor);
                      return (
                        <div
                          key={item.id}
                          id={`recall-result-${item.id}`}
                          onClick={() => handleItemClick(item)}
                          className="search-result-row group relative flex items-center justify-between py-3.5 px-4 rounded-2xl glass-resting transition-all duration-[var(--duration-fast)] ease-[var(--ease-standard)] cursor-pointer select-none active:scale-[0.99] press-interactive"
                        >
                          <div className="flex items-center gap-3 min-w-0 flex-1 pr-2">
                            {renderItemTypeIcon(item)}

                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2 min-w-0">
                                <p className="type-body font-medium text-[var(--text-primary)] truncate min-w-0 flex-1 group-hover:text-[var(--text-primary)]">
                                  {item.title}
                                </p>
                                {item.intent && (
                                  <span className="hidden sm:inline-block px-2 py-0.5 rounded-full type-caption uppercase bg-[var(--surface-sunken)] text-[var(--text-tertiary)] border border-[var(--border)] shrink-0 whitespace-nowrap text-[10px] font-mono">
                                    {item.intent}
                                  </span>
                                )}
                              </div>

                              <div className="flex items-center gap-1.5 mt-0.5 type-caption text-[var(--text-tertiary)] truncate min-w-0 font-body">
                                {item.sourceDomain && (
                                  <span className="text-[var(--text-secondary)]">{item.sourceDomain} ·</span>
                                )}
                                {item.places && item.places.length > 0 && (
                                  <span className="text-[var(--text-secondary)]">{item.places.join(', ')} ·</span>
                                )}
                                {item.people && item.people.length > 0 && (
                                  <span className="text-[var(--text-secondary)]">{item.people.join(', ')} ·</span>
                                )}
                                <span className="text-[var(--text-secondary)]">{reminderText}</span>
                              </div>
                            </div>
                          </div>

                          {/* Action Icon Hint */}
                          <div className="text-[var(--text-secondary)] group-hover:text-[var(--text-primary)] p-1.5 rounded-lg transition-colors">
                            {item.url ? (
                              <ExternalLink className="w-4 h-4" />
                            ) : (
                              <FileText className="w-4 h-4" />
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  /* Empty State */
                  <div
                    id="recall-search-empty-state"
                    className="py-16 flex flex-col items-center justify-center text-center px-4"
                  >
                    <div className="search-empty-icon w-12 h-12 rounded-2xl glass-resting flex items-center justify-center text-[var(--text-secondary)] mb-3 shadow-xs">
                      <Search className="w-5 h-5" />
                    </div>
                    <h3 className="type-heading-md font-display font-semibold text-[var(--text-primary)] mb-1">
                      Nothing found yet
                    </h3>
                    <p className="type-body-sm text-[var(--text-secondary)] max-w-xs leading-relaxed font-body">
                      Try another word from what you remember.
                    </p>
                  </div>
                )
              ) : (
                /* Initial Guidance State — Hero Panel + Browse By Category
                   grid + Recent Searches. Same markup in both themes;
                   search-redesign.css (light) / search-dark.css (dark)
                   recolor it. Replaces the old "Search like you think"
                   card and "Try searching for" grid, which duplicated
                   Home content. */
                <div className="flex flex-col gap-6 pb-4">
                  {/* Hero panel — soft mint/emerald gradient, leaf mark,
                      "Search like you think" eyebrow. */}
                  <div className="search-hero-panel relative overflow-hidden rounded-3xl p-5">
                    <Leaf
                      className="search-hero-leaf absolute top-4 right-4 w-11 h-11"
                      strokeWidth={1.5}
                    />
                    <div className="flex items-center gap-1.5">
                      <Star className="search-hero-eyebrow w-3 h-3 shrink-0" strokeWidth={2.5} />
                      <span className="search-hero-eyebrow type-caption font-bold uppercase">
                        Search like you think
                      </span>
                    </div>
                    <h2 className="search-hero-title font-onboarding-serif mt-2 leading-tight">
                      Type any word you remember.
                    </h2>
                    <p className="search-hero-body type-body-sm mt-2 leading-relaxed">
                      A place, name, topic, note fragment, or website — Later finds it.
                    </p>
                  </div>

                  {/* Browse by category — tap a tile to search that
                      category. */}
                  <div>
                    <div className="search-section-label uppercase mb-3">
                      Browse by category
                    </div>
                    <div className="grid grid-cols-2 gap-2.5">
                      {SEARCH_CATEGORIES.map(({ key, name, meta, term, icon: Icon }) => (
                        <button
                          key={key}
                          type="button"
                          onClick={() => setQuery(term)}
                          className={`search-category-tile search-category-${key} relative overflow-hidden select-none transition-all duration-[var(--duration-fast)] ease-[var(--ease-standard)] cursor-pointer active:scale-[0.98] press-interactive text-left`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="search-category-icon w-[34px] h-[34px] rounded-xl flex items-center justify-center">
                              <Icon className="w-4 h-4" strokeWidth={2} />
                            </span>
                            <span className="search-category-arrow w-[22px] h-[22px] rounded-full flex items-center justify-center">
                              <ChevronRight className="w-3.5 h-3.5" strokeWidth={2.5} />
                            </span>
                          </div>
                          <div className="search-category-name font-onboarding-serif mt-2.5">
                            {name}
                          </div>
                          <div className="search-category-meta mt-0.5">{meta}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Recent searches — only appears once any exist. */}
                  {recentSearches.length > 0 && (
                    <div>
                      <div className="search-section-label uppercase mb-3">
                        Recent searches
                      </div>
                      <div className="flex flex-col gap-2">
                        {recentSearches.map((term) => (
                          <button
                            key={term}
                            type="button"
                            onClick={() => setQuery(term)}
                            className="search-recent-row flex items-center gap-3 px-[14px] py-3 cursor-pointer text-left"
                          >
                            <span className="search-recent-icon w-7 h-7 flex items-center justify-center shrink-0">
                              <Clock className="w-3.5 h-3.5" />
                            </span>
                            <span className="search-recent-term truncate flex-1">
                              {term}
                            </span>
                            <ChevronRight className="search-recent-chevron w-4 h-4 shrink-0" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
    </motion.div>
  );
};

