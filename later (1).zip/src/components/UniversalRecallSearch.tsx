import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion } from 'motion/react';
import { useLater } from '../context/LaterContext';
import { SavedItem } from '../types';
import { formatReminderTime } from '../utils/timeScheduler';
import { useScrollIntoViewOnFocus } from '../utils/useScrollIntoViewOnFocus';
import {
  Search,
  X,
  ArrowLeft,
  Play,
  ExternalLink,
  Camera,
  FileText,
  Phone,
  MapPin,
  Check,
  Sparkles,
  SlidersHorizontal,
  Leaf,
  Clock,
  Dumbbell,
  User,
  Plane,
  Laptop,
  ArrowUpRight,
} from 'lucide-react';

interface UniversalRecallSearchProps {
  onClose: () => void;
}

const RECENT_SEARCHES_KEY = 'later_recent_searches';
const MAX_RECENT_SEARCHES = 6;

export const UniversalRecallSearch: React.FC<UniversalRecallSearchProps> = ({
  onClose,
}) => {
  const { items, setSelectedItem, openItem } = useLater();
  const [query, setQuery] = useState('');
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(RECENT_SEARCHES_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });
  const [activeFilter, setActiveFilter] = useState<'all' | 'link' | 'screenshot' | 'note' | 'urgent' | 'important' | 'chill'>('all');
  const inputRef = useRef<HTMLInputElement>(null);
  const handleFocusScroll = useScrollIntoViewOnFocus();

  const saveRecentSearch = (term: string) => {
    const trimmed = term.trim();
    if (!trimmed) return;
    setRecentSearches((prev) => {
      const next = [trimmed, ...prev.filter((t) => t.toLowerCase() !== trimmed.toLowerCase())].slice(
        0,
        MAX_RECENT_SEARCHES
      );
      try {
        localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(next));
      } catch {
        // Non-fatal: recent searches just won't persist this session
      }
      return next;
    });
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
    try {
      localStorage.removeItem(RECENT_SEARCHES_KEY);
    } catch {
      // Non-fatal
    }
  };

  // Auto-focus input on mount — this component only mounts while Search is
  // the active screen, so "mounted" already means "open".
  useEffect(() => {
    setTimeout(() => {
      inputRef.current?.focus();
    }, 50);
  }, []);

  // Handle escape key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  // Universal Search Filter across all fields, plus optional type/tag filter
  const filteredItems = useMemo(() => {
    const trimmed = query.trim().toLowerCase();

    const base = !trimmed
      ? items
      : items.filter((item) => {
          const terms = trimmed.split(/\s+/).filter(Boolean);
          const haystackParts: string[] = [
            item.title || '',
            item.summary || '',
            item.rawInput || '',
            item.rawContent || '',
            item.url || '',
            item.sourceDomain || '',
            item.contentType || '',
            item.type || '',
            item.intent || '',
            ...(item.topics || []),
            ...(item.places || []),
            ...(item.people || []),
            item.extractedMeta?.platform || '',
            item.extractedMeta?.personName || '',
            item.extractedMeta?.phoneNumber || '',
            item.extractedMeta?.address || '',
            item.extractedMeta?.price || '',
            item.extractedMeta?.timeHint || '',
          ];
          const fullHaystack = haystackParts.join(' ').toLowerCase();
          return terms.every((term) => fullHaystack.includes(term));
        });

    if (activeFilter === 'all') return trimmed ? base : [];

    const filteredByType = base.filter((item) => {
      const type = item.contentType || item.type;
      const tag = item.urgencyTag || item.urgency;
      if (activeFilter === 'link') return type === 'link' || type === 'article' || type === 'product' || type === 'video';
      if (activeFilter === 'screenshot') return type === 'screenshot' || type === 'image';
      if (activeFilter === 'note') return type === 'note' || type === 'idea';
      if (activeFilter === 'urgent') return tag === 'urgent';
      if (activeFilter === 'important') return tag === 'important';
      if (activeFilter === 'chill') return tag === 'chill';
      return true;
    });

    return filteredByType;
  }, [items, query, activeFilter]);

  const isFiltering = query.trim().length > 0 || activeFilter !== 'all';

  // Natural Action on result click
  const handleItemClick = (item: SavedItem) => {
    if (query.trim()) {
      saveRecentSearch(query);
    }
    if (item.url && (item.contentType === 'video' || item.contentType === 'link' || item.contentType === 'article' || item.contentType === 'product')) {
      // Natural action for video / web link is opening it
      openItem(item.id);
    } else {
      // Natural action for note, screenshot, person, place, task is opening detail sheet
      setSelectedItem(item);
    }
    onClose();
  };

  const renderItemTypeIcon = (item: SavedItem) => {
    if (item.imageAttachment) {
      return (
        <div className="w-8 h-8 rounded-lg overflow-hidden glass-icon-square shrink-0">
          <img
            src={item.imageAttachment}
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
      );
    }

    const type = item.contentType || item.type;

    switch (type) {
      case 'video':
        return (
          <div className="w-8 h-8 rounded-lg glass-icon-square flex items-center justify-center text-[var(--destructive)] shrink-0">
            <Play className="w-3.5 h-3.5 fill-current" />
          </div>
        );
      case 'person':
      case 'phone_number':
        return (
          <div className="w-8 h-8 rounded-lg glass-icon-square flex items-center justify-center text-[var(--text-secondary)] shrink-0">
            <Phone className="w-3.5 h-3.5" />
          </div>
        );
      case 'place':
        return (
          <div className="w-8 h-8 rounded-lg glass-icon-square flex items-center justify-center text-[var(--text-secondary)] shrink-0">
            <MapPin className="w-3.5 h-3.5" />
          </div>
        );
      case 'task':
      case 'event':
        return (
          <div className="w-8 h-8 rounded-lg glass-icon-square flex items-center justify-center text-[var(--text-secondary)] shrink-0">
            <Check className="w-3.5 h-3.5 stroke-[2.5]" />
          </div>
        );
      case 'link':
      case 'article':
      case 'product':
        return (
          <div className="w-8 h-8 rounded-lg glass-icon-square flex items-center justify-center text-[var(--accent)] shrink-0">
            <ExternalLink className="w-3.5 h-3.5" />
          </div>
        );
      case 'screenshot':
      case 'image':
        return (
          <div className="w-8 h-8 rounded-lg glass-icon-square flex items-center justify-center text-[var(--text-secondary)] shrink-0">
            <Camera className="w-3.5 h-3.5" />
          </div>
        );
      case 'note':
      case 'idea':
      default:
        return (
          <div className="w-8 h-8 rounded-lg glass-icon-square flex items-center justify-center text-[var(--text-secondary)] shrink-0">
            <FileText className="w-3.5 h-3.5" />
          </div>
        );
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0, transition: { duration: 0.22, ease: [0, 0, 0.2, 1] } }}
      className="w-full flex flex-col flex-1 relative"
      id="universal-recall-search-screen"
      style={{
        background: 'var(--bg-gradient)',
      }}
    >
      {/* Subtle grain texture, scoped to this screen rather than a global
          fixed overlay */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.06] dark:opacity-[0.05]"
        style={{
          mixBlendMode: 'overlay',
          backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><filter id="n"><feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="3" stitchTiles="stitch"/></filter><rect width="100%" height="100%" filter="url(%23n)"/></svg>')`,
          backgroundRepeat: 'repeat',
        }}
        aria-hidden="true"
      />

      {/* Search Header — cloned from the reference: large serif "Later"
          wordmark (bigger than the Home tab's header), a search-specific
          tagline, and a decorative leaf + handwritten note in the
          top-right, on a very light mint-tinted backdrop rather than
          Home's warm cream. This is a distinct visual identity for the
          Search tab, matching the reference exactly rather than reusing
          Home's <Header/> component. */}
      <div
        className="w-full px-4 sm:px-6 relative overflow-hidden"
        style={{ paddingTop: 'calc(14px + env(safe-area-inset-top, 0px))', paddingBottom: '14px' }}
      >
        <Leaf
          className="absolute -top-2 right-2 w-24 h-24 text-[var(--sage)] opacity-40 rotate-[35deg] pointer-events-none"
          strokeWidth={1}
        />
        <div className="relative flex items-start justify-between gap-3">
          <div>
            <h1 className="font-onboarding-serif text-[32px] font-bold text-[var(--accent-deep)] leading-none tracking-tight">
              Later
            </h1>
            <p className="type-body-sm text-[var(--text-secondary)] mt-1.5">
              Find what matters, instantly.
            </p>
          </div>
          <p className="font-onboarding-serif italic text-[13px] text-[var(--accent-deep)] text-right leading-snug pt-1 pr-6 max-w-[130px]">
            Your memories<br />are here. ♡
          </p>
        </div>
      </div>

      {/* Search bar — green-outlined pill matching the reference exactly,
          with a back button for navigation and a filter/sliders icon on
          the right (opens the same type/tag filter chips already below,
          rather than a separate hidden panel — keeps one real mechanism
          instead of two that could drift out of sync). */}
      <div className="w-full px-4 sm:px-6 pb-3 flex items-center gap-2.5 relative">
        <button
          id="recall-search-back-btn"
          type="button"
          onClick={onClose}
          className="shrink-0 flex items-center justify-center w-9 h-9 rounded-full bg-[var(--surface-elevated)] text-[var(--text-primary)] hover:bg-[var(--surface-sunken)] transition-all duration-[var(--duration-fast)] ease-[var(--ease-standard)] cursor-pointer active:scale-[0.94] press-interactive"
          title="Close search (Esc)"
          aria-label="Close search"
        >
          <ArrowLeft className="w-4.5 h-4.5" />
        </button>

        <div className="flex items-center gap-3 px-4 py-3 relative flex-1 rounded-full bg-white border-[1.5px] border-[var(--accent-deep)]">
          <Search className="w-4 h-4 text-[var(--text-secondary)] shrink-0" />

          <input
            id="recall-search-input"
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={handleFocusScroll}
            placeholder="Search your Later"
            className="w-full bg-transparent type-body text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] outline-none font-body"
            autoComplete="off"
            spellCheck="false"
          />

          {query ? (
            <button
              id="recall-search-clear-btn"
              type="button"
              onClick={() => {
                setQuery('');
                inputRef.current?.focus();
              }}
              className="p-1.5 text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-elevated)] rounded-full transition-all duration-[var(--duration-fast)] ease-[var(--ease-standard)] cursor-pointer active:scale-[0.92] press-interactive shrink-0"
              title="Clear text"
              aria-label="Clear text"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          ) : (
            <SlidersHorizontal className="w-4 h-4 text-[var(--accent-deep)] shrink-0" />
          )}
        </div>
      </div>

            {/* Type/tag filter chips — lets people narrow by kind the way
                Google Keep's search filters do, without typing anything */}
            <div className="w-full px-4 sm:px-6 pb-2 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
              {(
                [
                  { key: 'all', label: 'All' },
                  { key: 'link', label: 'Links' },
                  { key: 'screenshot', label: 'Screenshots' },
                  { key: 'note', label: 'Notes' },
                  { key: 'urgent', label: 'Priority' },
                  { key: 'important', label: 'Important' },
                  { key: 'chill', label: 'Chill' },
                ] as const
              ).map((f) => (
                <button
                  key={f.key}
                  type="button"
                  onClick={() => setActiveFilter(f.key)}
                  className={`shrink-0 px-3 py-1.5 rounded-full type-caption font-semibold whitespace-nowrap transition-all duration-[var(--duration-fast)] ease-[var(--ease-standard)] cursor-pointer active:scale-[0.96] press-interactive ${
                    activeFilter === f.key
                      ? 'bg-[var(--accent)] text-[var(--bg)]'
                      : 'glass-resting text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* Results / Suggestion Body */}
            <div className="w-full flex-1 overflow-y-auto px-4 sm:px-6 py-4">
              {isFiltering ? (
                filteredItems.length > 0 ? (
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center justify-between px-2 pb-1 type-label text-[var(--text-secondary)] font-body">
                      <span>
                        {filteredItems.length} {filteredItems.length === 1 ? 'match' : 'matches'}
                      </span>
                      <span>Tap to recall</span>
                    </div>

                    {filteredItems.map((item) => {
                      const reminderText = formatReminderTime(item.reminderTime || item.scheduledFor);
                      return (
                        <div
                          key={item.id}
                          id={`recall-result-${item.id}`}
                          onClick={() => handleItemClick(item)}
                          className="group relative flex items-center justify-between py-3.5 px-4 rounded-2xl glass-resting transition-all duration-[var(--duration-fast)] ease-[var(--ease-standard)] cursor-pointer select-none active:scale-[0.99] press-interactive"
                        >
                          <div className="flex items-center gap-3 min-w-0 flex-1 pr-2">
                            {renderItemTypeIcon(item)}

                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2 min-w-0">
                                <p className="type-body font-medium text-[var(--text-primary)] truncate min-w-0 flex-1 group-hover:text-[var(--text-primary)]">
                                  {item.title}
                                </p>
                                {item.intent && (
                                  <span className="hidden sm:inline-block px-2 py-0.5 rounded-full type-caption uppercase bg-[var(--surface-sunken)] text-[var(--text-tertiary)] border border-[var(--border)] shrink-0 whitespace-nowrap text-[10px] font-mono">
                                    {item.intent}
                                  </span>
                                )}
                              </div>

                              <div className="flex items-center gap-1.5 mt-0.5 type-caption text-[var(--text-tertiary)] truncate min-w-0 font-body">
                                {item.sourceDomain && (
                                  <span className="text-[var(--text-secondary)]">{item.sourceDomain} ·</span>
                                )}
                                {item.places && item.places.length > 0 && (
                                  <span className="text-[var(--text-secondary)]">{item.places.join(', ')} ·</span>
                                )}
                                {item.people && item.people.length > 0 && (
                                  <span className="text-[var(--text-secondary)]">{item.people.join(', ')} ·</span>
                                )}
                                <span className="text-[var(--text-secondary)]">{reminderText}</span>
                              </div>
                            </div>
                          </div>

                          {/* Action Icon Hint */}
                          <div className="text-[var(--text-secondary)] group-hover:text-[var(--text-primary)] p-1.5 rounded-lg transition-colors">
                            {item.url ? (
                              <ExternalLink className="w-4 h-4" />
                            ) : (
                              <FileText className="w-4 h-4" />
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  /* Empty State */
                  <div
                    id="recall-search-empty-state"
                    className="py-16 flex flex-col items-center justify-center text-center px-4"
                  >
                    <div className="w-12 h-12 rounded-2xl glass-resting flex items-center justify-center text-[var(--text-secondary)] mb-3 shadow-xs">
                      <Search className="w-5 h-5" />
                    </div>
                    <h3 className="type-heading-md font-display font-semibold text-[var(--text-primary)] mb-1">
                      Nothing found yet
                    </h3>
                    <p className="type-body-sm text-[var(--text-secondary)] max-w-xs leading-relaxed font-body">
                      Try another word from what you remember.
                    </p>
                  </div>
                )
              ) : (
                /* Initial Guidance State — hero card + suggestions always
                   shown (matching the reference's fixed section order),
                   with recent searches appearing below when any exist,
                   rather than the previous either/or swap between recent
                   searches and the hero+suggestions block. */
                <div className="flex flex-col gap-6 pb-4">
                  {/* "Search like you think" hero card — soft mint
                      gradient, serif headline with accent-colored second
                      half, sticky-note category illustration on the
                      right, cloned from the reference. */}
                  <div
                    className="relative overflow-hidden rounded-3xl p-5"
                    style={{
                      background: 'linear-gradient(135deg, #FBFDFC 0%, #EAF4EE 60%, #DCEDE3 100%)',
                    }}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-[var(--accent-deep)] shrink-0" />
                          <h3 className="font-onboarding-serif text-[19px] font-bold text-[var(--text-primary)] leading-tight">
                            Search like <span className="text-[var(--accent-deep)]">you think.</span>
                          </h3>
                        </div>
                        <p className="type-body-sm text-[var(--text-secondary)] mt-2 leading-relaxed">
                          Type any word you remember — a place, name, topic, note fragment, or website.
                        </p>
                      </div>
                      <div className="flex flex-col shrink-0">
                        <Leaf className="w-6 h-6 text-[var(--sage)] self-end -mb-1 rotate-[-15deg]" strokeWidth={1.5} />
                        <div className="bg-white rounded-lg shadow-sm px-2.5 py-2 flex flex-col gap-1 border border-[var(--border)]">
                          {['Ideas', 'Places', 'People', 'Links', 'Notes'].map((w) => (
                            <span key={w} className="type-caption text-[var(--text-secondary)] text-[10px] whitespace-nowrap">
                              {w}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* "Try searching for" — static example suggestions,
                      each with a meaning-matched icon in a mint chip
                      rather than plain quoted text. */}
                  <div>
                    <div className="flex items-center justify-between px-1 mb-3">
                      <div className="flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-[var(--accent-deep)]" />
                        <span className="type-body-sm font-semibold text-[var(--text-primary)]">
                          Try searching for
                        </span>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2.5">
                      {[
                        { term: 'kyoto', icon: MapPin },
                        { term: 'workout', icon: Dumbbell },
                        { term: 'design', icon: FileText },
                        { term: 'arjun', icon: User },
                        { term: 'goa trip', icon: Plane },
                        { term: 'keyboard', icon: Laptop },
                      ].map(({ term, icon: Icon }) => (
                        <button
                          key={term}
                          type="button"
                          onClick={() => setQuery(term)}
                          className="flex items-center gap-2.5 px-3 py-2.5 rounded-full bg-white border border-[var(--border)] select-none transition-all duration-[var(--duration-fast)] ease-[var(--ease-standard)] cursor-pointer active:scale-[0.97] press-interactive hover:border-[var(--accent)]"
                        >
                          <span className="w-7 h-7 rounded-full bg-[var(--sage-soft)] flex items-center justify-center shrink-0">
                            <Icon className="w-3.5 h-3.5 text-[var(--accent-deep)]" />
                          </span>
                          <span className="type-caption font-semibold text-[var(--text-primary)] whitespace-nowrap uppercase text-[11px]">
                            "{term}"
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Recent searches — only appears once any exist,
                      matching the reference's own "Recent searches" list
                      style (colored icon chip, timestamp-style subtext,
                      arrow-out affordance). */}
                  {recentSearches.length > 0 && (
                    <div>
                      <div className="flex items-center justify-between px-1 mb-2.5">
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-[var(--accent-deep)]" />
                          <span className="type-body-sm font-semibold text-[var(--text-primary)]">
                            Recent searches
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={clearRecentSearches}
                          className="type-caption text-[var(--accent-deep)] hover:underline cursor-pointer font-semibold"
                        >
                          Clear all
                        </button>
                      </div>
                      <div className="flex flex-col">
                        {recentSearches.map((term, i) => (
                          <button
                            key={term}
                            type="button"
                            onClick={() => setQuery(term)}
                            className={`flex items-center gap-3 py-3 cursor-pointer text-left ${
                              i !== recentSearches.length - 1 ? 'border-b border-[var(--divider)]' : ''
                            }`}
                          >
                            <span className="w-9 h-9 rounded-full bg-[var(--sage-soft)] flex items-center justify-center shrink-0">
                              <Search className="w-4 h-4 text-[var(--accent-deep)]" />
                            </span>
                            <span className="type-body-sm text-[var(--text-primary)] truncate flex-1 font-medium">
                              {term}
                            </span>
                            <ArrowUpRight className="w-4 h-4 text-[var(--text-tertiary)] shrink-0" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
    </motion.div>
  );
};

