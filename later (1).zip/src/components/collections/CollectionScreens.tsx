import React, { useMemo, useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  MoreVertical,
  Check,
  Trash2,
  X,
  Leaf,
  GraduationCap,
  Plane,
  Heart,
  Briefcase,
  Lightbulb,
  Dumbbell,
  Home as HomeIcon,
  Users,
  Star,
  Coffee,
  Folder,
  FolderOpen,
  Pencil,
  Palette,
  Image as ImageIcon,
  ListChecks,
} from 'lucide-react';
import { useLater } from '../../context/LaterContext';
import { SavedItem } from '../../types';
import {
  useCollections,
  Collection,
  CollectionIcon,
  CollectionColor,
  COLLECTION_ICON_ORDER,
  COLLECTION_COLOR_ORDER,
  COLLECTION_COLOR_SWATCHES,
  collectionColorTint,
} from '../../context/CollectionContext';
import { TimelineItemRow } from '../TimelineItemRow';

const COLLECTION_ICON_COMPONENTS: Record<CollectionIcon, React.ComponentType<{ className?: string }>> = {
  leaf: Leaf,
  graduation: GraduationCap,
  plane: Plane,
  heart: Heart,
  briefcase: Briefcase,
  idea: Lightbulb,
  dumbbell: Dumbbell,
  home: HomeIcon,
  people: Users,
  star: Star,
  coffee: Coffee,
  folder: Folder,
};

export const CollectionIconChip: React.FC<{
  icon: CollectionIcon;
  color: CollectionColor;
  size?: 'sm' | 'md' | 'lg';
}> = ({ icon, color, size = 'md' }) => {
  const IconCmp = COLLECTION_ICON_COMPONENTS[icon] || Folder;
  const dims = size === 'lg' ? 'w-14 h-14 rounded-[18px]' : size === 'sm' ? 'w-9 h-9 rounded-xl' : 'w-11 h-11 rounded-2xl';
  const iconDims = size === 'lg' ? 'w-6 h-6' : size === 'sm' ? 'w-4 h-4' : 'w-5 h-5';
  return (
    <div
      className={`${dims} shrink-0 flex items-center justify-center`}
      style={{ backgroundColor: collectionColorTint(color, 0.16) }}
    >
      <IconCmp className={iconDims} style={{ color: COLLECTION_COLOR_SWATCHES[color] }} />
    </div>
  );
};

const IconPicker: React.FC<{ value: CollectionIcon; onChange: (i: CollectionIcon) => void; color: CollectionColor }> = ({
  value,
  onChange,
  color,
}) => (
  <div className="grid grid-cols-4 gap-2.5">
    {COLLECTION_ICON_ORDER.map((icon) => {
      const IconCmp = COLLECTION_ICON_COMPONENTS[icon];
      const active = value === icon;
      return (
        <button
          key={icon}
          type="button"
          onClick={() => onChange(icon)}
          aria-label={icon}
          className="w-12 h-12 rounded-2xl flex items-center justify-center cursor-pointer transition-all active:scale-90"
          style={{
            backgroundColor: active ? collectionColorTint(color, 0.2) : 'var(--surface-sunken)',
            boxShadow: active ? `0 0 0 1.5px ${COLLECTION_COLOR_SWATCHES[color]}` : 'none',
          }}
        >
          <IconCmp
            className="w-5 h-5"
            style={{ color: active ? COLLECTION_COLOR_SWATCHES[color] : 'var(--text-secondary)' }}
          />
        </button>
      );
    })}
  </div>
);

const ColorPicker: React.FC<{ value: CollectionColor; onChange: (c: CollectionColor) => void }> = ({
  value,
  onChange,
}) => (
  <div className="flex flex-wrap gap-2.5">
    {COLLECTION_COLOR_ORDER.map((color) => (
      <button
        key={color}
        type="button"
        onClick={() => onChange(color)}
        aria-label={color}
        className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 transition-transform active:scale-90 cursor-pointer"
        style={{
          backgroundColor: COLLECTION_COLOR_SWATCHES[color],
          boxShadow: value === color ? `0 0 0 2px var(--surface), 0 0 0 4px ${COLLECTION_COLOR_SWATCHES[color]}` : 'none',
        }}
      >
        {value === color && (
          <Check
            className="w-4 h-4 stroke-[3]"
            style={{ color: ['mint', 'lavender', 'peach', 'pink', 'sky'].includes(color) ? '#211E1B' : '#fff' }}
          />
        )}
      </button>
    ))}
  </div>
);

/** Shared create/edit surface. Rename, Change icon and Change color from
 * the collection options menu all open this same form — it already holds
 * all three fields, so three near-identical single-field sheets would add
 * nothing functionally. */
export const CollectionEditorSheet: React.FC<{
  editingCollection?: Collection;
  onClose: () => void;
  onDeleted?: () => void;
}> = ({ editingCollection, onClose, onDeleted }) => {
  const { createCollection, renameCollection, recolorCollection, reiconCollection, deleteCollection } =
    useCollections();
  const [name, setName] = useState(editingCollection?.name || '');
  const [icon, setIcon] = useState<CollectionIcon>(editingCollection?.icon || 'leaf');
  const [color, setColor] = useState<CollectionColor>(editingCollection?.color || 'green');
  const [confirmDelete, setConfirmDelete] = useState(false);

  const handleSave = () => {
    if (!name.trim()) return;
    if (editingCollection) {
      renameCollection(editingCollection.id, name);
      recolorCollection(editingCollection.id, color);
      reiconCollection(editingCollection.id, icon);
    } else {
      createCollection(name, icon, color);
    }
    onClose();
  };

  const handleDelete = () => {
    if (!editingCollection) return;
    if (!confirmDelete) {
      setConfirmDelete(true);
      return;
    }
    deleteCollection(editingCollection.id);
    onClose();
    onDeleted?.();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 sheet-backdrop" onClick={onClose} />
      <div className="relative w-full max-w-sm bg-[var(--surface)] border-t sm:border border-[var(--border)] rounded-t-[24px] sm:rounded-[24px] elevation-3 z-10 p-5 space-y-5 max-h-[85vh] overflow-y-auto">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="type-heading-lg font-semibold text-[var(--text-primary)]">
              {editingCollection ? 'Edit collection' : 'Create collection'}
            </h3>
            {!editingCollection && (
              <p className="type-caption text-[var(--text-secondary)] mt-0.5">
                Give your collection a name and style.
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 shrink-0 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center gap-3">
          <CollectionIconChip icon={icon} color={color} size="lg" />
          <div className="flex-1 min-w-0">
            <label className="type-caption text-[11px] font-medium text-[var(--text-tertiary)] uppercase tracking-wider block mb-1.5">
              Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSave()}
              placeholder="e.g. NEET PG 2026"
              autoFocus
              maxLength={40}
              className="w-full px-3.5 py-2.5 rounded-2xl bg-[var(--surface-sunken)] border border-[var(--border)] outline-none text-[var(--text-primary)] type-body font-medium"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="type-caption text-[11px] font-medium text-[var(--text-tertiary)] uppercase tracking-wider block">
            Choose an icon
          </label>
          <IconPicker value={icon} onChange={setIcon} color={color} />
        </div>

        <div className="space-y-2">
          <label className="type-caption text-[11px] font-medium text-[var(--text-tertiary)] uppercase tracking-wider block">
            Choose a color
          </label>
          <ColorPicker value={color} onChange={setColor} />
        </div>

        <div className="flex items-center gap-2 pt-1">
          <button
            type="button"
            onClick={handleSave}
            disabled={!name.trim()}
            className="flex-1 py-3 rounded-2xl bg-[var(--accent)] text-white type-button font-semibold cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-[0.98]"
          >
            {editingCollection ? 'Save changes' : 'Create collection'}
          </button>
          {editingCollection && (
            <button
              type="button"
              onClick={handleDelete}
              className={`px-4 py-3 rounded-2xl border type-button font-medium cursor-pointer transition-all active:scale-[0.98] flex items-center gap-1.5 ${
                confirmDelete
                  ? 'bg-[var(--destructive)] border-[var(--destructive)] text-white'
                  : 'border-[var(--border)] text-[var(--destructive)]'
              }`}
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{confirmDelete ? 'Confirm' : 'Delete'}</span>
            </button>
          )}
        </div>
        {editingCollection && confirmDelete && (
          <p className="type-caption text-[var(--text-tertiary)] -mt-2">
            This removes the collection only — its memories are kept.
          </p>
        )}
      </div>
    </div>
  );
};

/** Toggle-list of every active memory — checking/unchecking adds or
 * removes it from this collection. Serves both the "Add memories" and
 * "Remove memories" menu entries, since they're the same operation from
 * opposite starting states. */
const MemoryMembershipPicker: React.FC<{
  collectionId: string;
  onClose: () => void;
}> = ({ collectionId, onClose }) => {
  const { items } = useLater();
  const { addMemoryToCollection, removeMemoryFromCollection } = useCollections();
  const activeItems = useMemo(
    () =>
      items
        .filter((i) => !i.isArchived)
        .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()),
    [items]
  );

  const toggle = (item: SavedItem) => {
    const inCollection = (item.collectionIds || []).includes(collectionId);
    if (inCollection) {
      removeMemoryFromCollection(item.id, collectionId);
    } else {
      addMemoryToCollection(item.id, collectionId);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 sheet-backdrop" onClick={onClose} />
      <div className="relative w-full max-w-sm bg-[var(--surface)] border-t sm:border border-[var(--border)] rounded-t-[24px] sm:rounded-[24px] elevation-3 z-10 p-5 space-y-4 max-h-[75vh] flex flex-col">
        <div className="flex items-center justify-between shrink-0">
          <h3 className="type-heading-lg font-semibold text-[var(--text-primary)]">Manage memories</h3>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <p className="type-caption text-[var(--text-secondary)] -mt-2 shrink-0">
          Tap to add or remove a memory from this collection.
        </p>

        <div className="flex-1 overflow-y-auto space-y-2 -mx-1 px-1">
          {activeItems.length === 0 ? (
            <p className="type-body-sm text-[var(--text-secondary)] text-center py-8">No memories saved yet.</p>
          ) : (
            activeItems.map((item) => {
              const inCollection = (item.collectionIds || []).includes(collectionId);
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => toggle(item)}
                  className={`w-full min-h-[48px] flex items-center gap-3 px-3.5 py-2.5 rounded-2xl border transition-colors cursor-pointer text-left ${
                    inCollection
                      ? 'bg-[var(--accent-soft)] border-[var(--accent)]/30'
                      : 'bg-[var(--surface-sunken)] border-[var(--border)]'
                  }`}
                >
                  <span className="type-body-sm font-medium text-[var(--text-primary)] flex-1 truncate">
                    {item.title || item.summary || item.rawInput || 'Untitled memory'}
                  </span>
                  {inCollection && <Check className="w-4 h-4 text-[var(--accent)] stroke-[3] shrink-0" />}
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

const CollectionOptionsSheet: React.FC<{
  col: Collection;
  onClose: () => void;
  onEdit: () => void;
  onManageMemories: () => void;
  onDeleted: () => void;
}> = ({ col, onClose, onEdit, onManageMemories, onDeleted }) => {
  const { deleteCollection } = useCollections();
  const [confirmDelete, setConfirmDelete] = useState(false);

  const handleDelete = () => {
    if (!confirmDelete) {
      setConfirmDelete(true);
      return;
    }
    deleteCollection(col.id);
    onClose();
    onDeleted();
  };

  const Row: React.FC<{ icon: React.ReactNode; label: string; onClick: () => void; destructive?: boolean }> = ({
    icon,
    label,
    onClick,
    destructive,
  }) => (
    <button
      type="button"
      onClick={onClick}
      className={`w-full min-h-[48px] flex items-center gap-3 px-1.5 py-2.5 rounded-xl cursor-pointer text-left transition-colors hover:bg-[var(--surface-resting-hover)] ${
        destructive ? 'text-[var(--destructive)]' : 'text-[var(--text-primary)]'
      }`}
    >
      <span className={destructive ? 'text-[var(--destructive)]' : 'text-[var(--text-secondary)]'}>{icon}</span>
      <span className="type-body font-medium">{label}</span>
    </button>
  );

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 sheet-backdrop" onClick={onClose} />
      <div className="relative w-full max-w-sm bg-[var(--surface)] border-t sm:border border-[var(--border)] rounded-t-[24px] sm:rounded-[24px] elevation-3 z-10 p-5 space-y-1">
        <div className="flex items-center justify-between pb-3 mb-1 border-b border-[var(--divider)]">
          <div className="flex items-center gap-3 min-w-0">
            <CollectionIconChip icon={col.icon} color={col.color} size="sm" />
            <span className="type-heading font-semibold text-[var(--text-primary)] truncate">{col.name}</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 shrink-0 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <Row icon={<Pencil className="w-4 h-4" />} label="Rename" onClick={onEdit} />
        <Row icon={<ImageIcon className="w-4 h-4" />} label="Change icon" onClick={onEdit} />
        <Row icon={<Palette className="w-4 h-4" />} label="Change color" onClick={onEdit} />
        <Row icon={<Plus className="w-4 h-4" />} label="Add memories" onClick={onManageMemories} />
        <Row icon={<ListChecks className="w-4 h-4" />} label="Remove memories" onClick={onManageMemories} />
        <div className="pt-1 mt-1 border-t border-[var(--divider)]">
          <Row
            icon={<Trash2 className="w-4 h-4" />}
            label={confirmDelete ? 'Tap again to confirm delete' : 'Delete collection'}
            onClick={handleDelete}
            destructive
          />
        </div>
      </div>
    </div>
  );
};

type ContentFilter = 'all' | 'notes' | 'links' | 'screenshots';

const matchesContentFilter = (item: SavedItem, filter: ContentFilter): boolean => {
  if (filter === 'all') return true;
  const t = item.contentType || item.type;
  if (filter === 'notes') return t === 'note' || t === 'idea';
  if (filter === 'links') return t === 'link' || t === 'video' || t === 'product' || t === 'article';
  if (filter === 'screenshots') return t === 'screenshot' || t === 'image';
  return true;
};

const CollectionDetailScreen: React.FC<{
  col: Collection;
  onBack: () => void;
  onDeleted: () => void;
}> = ({ col, onBack, onDeleted }) => {
  const { items } = useLater();
  const [filter, setFilter] = useState<ContentFilter>('all');
  const [showOptions, setShowOptions] = useState(false);
  const [showEditor, setShowEditor] = useState(false);
  const [showMemoryPicker, setShowMemoryPicker] = useState(false);

  const collectionItems = useMemo(
    () => items.filter((i) => !i.isArchived && (i.collectionIds || []).includes(col.id)),
    [items, col.id]
  );
  const filtered = useMemo(
    () => collectionItems.filter((i) => matchesContentFilter(i, filter)),
    [collectionItems, filter]
  );

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between gap-2 pb-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            type="button"
            onClick={onBack}
            className="w-9 h-9 shrink-0 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] cursor-pointer active:scale-95"
            aria-label="Back"
          >
            <ChevronLeft className="w-4.5 h-4.5" />
          </button>
          <CollectionIconChip icon={col.icon} color={col.color} size="sm" />
          <div className="min-w-0">
            <h2 className="type-heading-lg font-semibold text-[var(--text-primary)] truncate">{col.name}</h2>
            <p className="type-caption text-[var(--text-secondary)]">{collectionItems.length} memories</p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setShowOptions(true)}
          className="w-9 h-9 shrink-0 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] cursor-pointer"
          aria-label="Collection options"
        >
          <MoreVertical className="w-4 h-4" />
        </button>
      </div>

      <div className="pb-3 -mx-1 overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-1.5 px-0.5 min-w-max">
          {(
            [
              ['all', 'All'],
              ['notes', 'Notes'],
              ['links', 'Links'],
              ['screenshots', 'Images'],
            ] as [ContentFilter, string][]
          ).map(([value, label]) => (
            <button
              key={value}
              type="button"
              onClick={() => setFilter(value)}
              className={`px-3.5 py-1.5 rounded-full type-caption font-semibold cursor-pointer transition-colors ${
                filter === value
                  ? 'bg-[var(--accent)] text-white'
                  : 'bg-[var(--surface-elevated)] border border-[var(--border)] text-[var(--text-secondary)]'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-3 pb-24">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 text-center px-6 py-16">
            <FolderOpen className="w-8 h-8 text-[var(--text-tertiary)]" />
            <p className="type-body font-semibold text-[var(--text-primary)]">Nothing here yet</p>
            <button
              type="button"
              onClick={() => setShowMemoryPicker(true)}
              className="mt-1 px-4 py-2.5 rounded-2xl bg-[var(--accent)] text-white type-button font-semibold cursor-pointer active:scale-[0.98] transition-all"
            >
              Add memories
            </button>
          </div>
        ) : (
          filtered.map((item, idx) => <TimelineItemRow key={item.id} item={item} index={idx} />)
        )}
      </div>

      <button
        type="button"
        onClick={() => setShowMemoryPicker(true)}
        className="fixed bottom-24 right-5 z-30 w-14 h-14 rounded-full bg-[var(--accent)] text-white flex items-center justify-center elevation-3 cursor-pointer active:scale-95 transition-all"
        aria-label="Add memories to collection"
      >
        <Plus className="w-6 h-6" />
      </button>

      {showOptions && (
        <CollectionOptionsSheet
          col={col}
          onClose={() => setShowOptions(false)}
          onEdit={() => {
            setShowOptions(false);
            setShowEditor(true);
          }}
          onManageMemories={() => {
            setShowOptions(false);
            setShowMemoryPicker(true);
          }}
          onDeleted={onDeleted}
        />
      )}
      {showEditor && <CollectionEditorSheet editingCollection={col} onClose={() => setShowEditor(false)} onDeleted={onDeleted} />}
      {showMemoryPicker && (
        <MemoryMembershipPicker collectionId={col.id} onClose={() => setShowMemoryPicker(false)} />
      )}
    </div>
  );
};

/** Bottom-nav destination root — owns its own list/detail navigation
 * locally (mirrors ScheduleView's self-contained internal tab state)
 * rather than plumbing through the app-level sidebar view state, since
 * Collections is a primary tab, not a drill-down from the sidebar. */
export const CollectionsScreen: React.FC = () => {
  const { collections, countForCollection } = useCollections();
  const [openId, setOpenId] = useState<string | null>(null);
  const [showEditor, setShowEditor] = useState(false);
  const [menuOpenFor, setMenuOpenFor] = useState<string | null>(null);
  const [optionsForId, setOptionsForId] = useState<string | null>(null);

  const openCollection = collections.find((c) => c.id === openId);
  if (openCollection) {
    return (
      <CollectionDetailScreen
        col={openCollection}
        onBack={() => setOpenId(null)}
        onDeleted={() => setOpenId(null)}
      />
    );
  }

  const optionsCollection = collections.find((c) => c.id === optionsForId);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between gap-3 pb-1">
        <div className="min-w-0">
          <h2 className="type-heading-lg font-semibold text-[var(--text-primary)]">Collections</h2>
          <p className="type-caption text-[var(--text-secondary)] mt-0.5">Keep related memories together.</p>
        </div>
        <button
          type="button"
          onClick={() => setShowEditor(true)}
          className="w-10 h-10 shrink-0 rounded-full bg-[var(--accent)] text-white flex items-center justify-center cursor-pointer active:scale-95 transition-all"
          aria-label="New collection"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto pt-4 pb-6">
        {collections.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 text-center px-6 py-16">
            <div className="w-12 h-12 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-tertiary)]">
              <FolderOpen className="w-5 h-5" />
            </div>
            <p className="type-body font-semibold text-[var(--text-primary)]">No collections yet</p>
            <p className="type-body-sm text-[var(--text-secondary)] max-w-[240px]">
              Group your memories, ideas and plans in one place.
            </p>
            <button
              type="button"
              onClick={() => setShowEditor(true)}
              className="mt-1 px-4 py-2.5 rounded-2xl bg-[var(--accent)] text-white type-button font-semibold cursor-pointer active:scale-[0.98] transition-all flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>New collection</span>
            </button>
          </div>
        ) : (
          <div className="space-y-2.5">
            {collections.map((col) => (
              <div
                key={col.id}
                className="relative w-full min-h-[64px] flex items-center gap-3 px-3.5 py-3 rounded-2xl bg-[var(--surface)] border border-[var(--border-subtle)] hover:bg-[var(--surface-resting-hover)] transition-colors"
              >
                <button
                  type="button"
                  onClick={() => setOpenId(col.id)}
                  className="flex items-center gap-3 flex-1 min-w-0 text-left cursor-pointer"
                >
                  <CollectionIconChip icon={col.icon} color={col.color} />
                  <div className="min-w-0 flex-1">
                    <p className="type-body font-semibold text-[var(--text-primary)] truncate">{col.name}</p>
                    <p className="type-caption text-[var(--text-tertiary)]">
                      {countForCollection(col.id)} {countForCollection(col.id) === 1 ? 'memory' : 'memories'}
                    </p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)] shrink-0" />
                </button>
                <button
                  type="button"
                  onClick={() => setMenuOpenFor(menuOpenFor === col.id ? null : col.id)}
                  className="w-8 h-8 shrink-0 rounded-full flex items-center justify-center text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-elevated)] cursor-pointer"
                  aria-label="Collection options"
                >
                  <MoreVertical className="w-4 h-4" />
                </button>
                {menuOpenFor === col.id && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setMenuOpenFor(null)} />
                    <div className="absolute right-2 top-14 z-20 w-44 rounded-2xl bg-[var(--surface-elevated)] border border-[var(--border)] elevation-3 py-1.5 overflow-hidden">
                      <button
                        type="button"
                        onClick={() => {
                          setOptionsForId(col.id);
                          setMenuOpenFor(null);
                        }}
                        className="w-full text-left px-3.5 py-2.5 type-body-sm text-[var(--text-primary)] hover:bg-[var(--surface-resting-hover)] cursor-pointer"
                      >
                        Collection options
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {showEditor && <CollectionEditorSheet onClose={() => setShowEditor(false)} />}
      {optionsCollection && (
        <CollectionOptionsSheet
          col={optionsCollection}
          onClose={() => setOptionsForId(null)}
          onEdit={() => {
            setOptionsForId(null);
            setOpenId(optionsCollection.id);
            setShowEditor(true);
          }}
          onManageMemories={() => {
            setOptionsForId(null);
            setOpenId(optionsCollection.id);
          }}
          onDeleted={() => setOptionsForId(null)}
        />
      )}
    </div>
  );
};

/** Used from Memory Detail's "+ Add to collection" control — mirrors
 * TagPickerSheet, but for collections. */
export const CollectionPickerSheet: React.FC<{
  itemId: string;
  currentCollectionIds: string[];
  onClose: () => void;
}> = ({ itemId, currentCollectionIds, onClose }) => {
  const { collections, addMemoryToCollection, removeMemoryFromCollection } = useCollections();
  const [creating, setCreating] = useState(false);

  const toggle = (collectionId: string) => {
    if (currentCollectionIds.includes(collectionId)) {
      removeMemoryFromCollection(itemId, collectionId);
    } else {
      addMemoryToCollection(itemId, collectionId);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 sheet-backdrop" onClick={onClose} />
      <div className="relative w-full max-w-sm bg-[var(--surface)] border-t sm:border border-[var(--border)] rounded-t-[24px] sm:rounded-[24px] elevation-3 z-10 p-5 space-y-4 max-h-[70vh] flex flex-col">
        <div className="flex items-center justify-between shrink-0">
          <h3 className="type-heading-lg font-semibold text-[var(--text-primary)]">Add to collection</h3>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-2 -mx-1 px-1">
          {collections.length === 0 && !creating && (
            <p className="type-body-sm text-[var(--text-secondary)] text-center py-6">
              No collections yet — create your first one below.
            </p>
          )}
          {collections.map((col) => {
            const active = currentCollectionIds.includes(col.id);
            return (
              <button
                key={col.id}
                type="button"
                onClick={() => toggle(col.id)}
                className={`w-full min-h-[48px] flex items-center gap-3 px-3 py-2 rounded-2xl border transition-colors cursor-pointer text-left ${
                  active
                    ? 'bg-[var(--accent-soft)] border-[var(--accent)]/30'
                    : 'bg-[var(--surface-sunken)] border-[var(--border)]'
                }`}
              >
                <CollectionIconChip icon={col.icon} color={col.color} size="sm" />
                <span className="type-body font-medium text-[var(--text-primary)] flex-1 truncate">{col.name}</span>
                {active && <Check className="w-4 h-4 text-[var(--accent)] stroke-[3] shrink-0" />}
              </button>
            );
          })}
        </div>

        {creating ? (
          <InlineCreateCollectionRow onDone={() => setCreating(false)} />
        ) : (
          <button
            type="button"
            onClick={() => setCreating(true)}
            className="shrink-0 w-full py-3 rounded-2xl border border-dashed border-[var(--border)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:border-[var(--border-strong)] type-button font-medium cursor-pointer transition-all flex items-center justify-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>New collection</span>
          </button>
        )}
      </div>
    </div>
  );
};

const InlineCreateCollectionRow: React.FC<{ onDone: () => void }> = ({ onDone }) => {
  const { createCollection } = useCollections();
  const [name, setName] = useState('');
  const [color, setColor] = useState<CollectionColor>('green');
  const [icon, setIcon] = useState<CollectionIcon>('leaf');

  const handleCreate = () => {
    if (!name.trim()) return;
    createCollection(name, icon, color);
    onDone();
  };

  return (
    <div className="shrink-0 space-y-2.5 p-3 rounded-2xl bg-[var(--surface-sunken)] border border-[var(--border)]">
      <div className="flex items-center gap-2">
        <CollectionIconChip icon={icon} color={color} size="sm" />
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
          placeholder="New collection name"
          autoFocus
          maxLength={40}
          className="flex-1 bg-transparent outline-none text-[var(--text-primary)] type-body-sm font-medium"
        />
      </div>
      <div className="flex flex-wrap gap-1.5">
        {COLLECTION_COLOR_ORDER.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setColor(c)}
            aria-label={c}
            className="w-6 h-6 rounded-full shrink-0 cursor-pointer transition-transform active:scale-90"
            style={{
              backgroundColor: COLLECTION_COLOR_SWATCHES[c],
              boxShadow: color === c ? `0 0 0 2px var(--surface-sunken), 0 0 0 3.5px ${COLLECTION_COLOR_SWATCHES[c]}` : 'none',
            }}
          />
        ))}
      </div>
      <div className="flex flex-wrap gap-1.5">
        {COLLECTION_ICON_ORDER.slice(0, 8).map((i) => {
          const IconCmp = COLLECTION_ICON_COMPONENTS[i];
          return (
            <button
              key={i}
              type="button"
              onClick={() => setIcon(i)}
              className="w-7 h-7 rounded-lg flex items-center justify-center cursor-pointer"
              style={{
                backgroundColor: icon === i ? collectionColorTint(color, 0.25) : 'var(--surface-elevated)',
              }}
            >
              <IconCmp
                className="w-3.5 h-3.5"
                style={{ color: icon === i ? COLLECTION_COLOR_SWATCHES[color] : 'var(--text-tertiary)' }}
              />
            </button>
          );
        })}
      </div>
      <div className="flex items-center gap-2 pt-0.5">
        <button
          type="button"
          onClick={handleCreate}
          disabled={!name.trim()}
          className="flex-1 py-2 rounded-xl bg-[var(--accent)] text-white type-body-sm font-semibold cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Create
        </button>
        <button
          type="button"
          onClick={onDone}
          className="px-3 py-2 rounded-xl text-[var(--text-secondary)] type-body-sm font-medium cursor-pointer"
        >
          Cancel
        </button>
      </div>
    </div>
  );
};
