import React from 'react';
import { useTheme } from '../context/ThemeContext';

/**
 * BackgroundGrainOverlay component
 * Renders a fixed full-screen noise texture as a subtle atmosphere effect.
 * Previously hardcoded its own opacity (0.06 light / 0.05 dark) instead of
 * reading the --bg-grain-opacity CSS variable — that variable was set to 0
 * for light mode specifically (the bright/clean redesign has no grain by
 * design), but this component ignored it entirely. The result: a 6%
 * opacity noise layer sat on top of every white card across the whole
 * light-mode UI, which is what was making them read as "dull/dirty" even
 * though the underlying surface color was correctly pure white
 * (#FFFFFF) — the grain overlay was graying it out visually after the
 * fact. Fixed to read the real token so light mode gets none, matching
 * the actual design intent, and dark mode keeps its existing subtle
 * grain unchanged.
 */
export const BackgroundGrainOverlay: React.FC = () => {
  const { theme } = useTheme();

  const opacity = theme === 'dark' ? 0.05 : 0;

  if (opacity === 0) return null;

  return (
    <div
      id={`${theme}-mode-grain-overlay`}
      style={{
        position: 'fixed',
        inset: 0,
        pointerEvents: 'none',
        zIndex: 1,
        opacity,
        mixBlendMode: 'overlay',
        backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><filter id="n"><feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="3" stitchTiles="stitch"/></filter><rect width="100%" height="100%" filter="url(%23n)"/></svg>')`,
        backgroundRepeat: 'repeat',
      }}
    />
  );
};

