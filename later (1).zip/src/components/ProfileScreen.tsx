import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useLater } from '../context/LaterContext';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { openExactAlarmSettings } from '../utils/nativeNotifications';
import { Capacitor } from '@capacitor/core';
import { QuickCapture } from '../lib/quickCapture';
import {
  attemptEnableNotifications,
  getNotificationPermissionStatus,
  openNotificationSettings,
  NotificationPermissionStatus,
} from '../utils/notificationPermission';
import { computeStreakDays, countCapturedThisWeek, countReturningSoon } from '../utils/profileStats';
import { BottomSheet } from './ui/BottomSheet';
import '../styles/profile-v2.css';
import {
  UserPlus,
  LogIn,
  LogOut,
  HelpCircle,
  Sun,
  Moon,
  RotateCcw,
  Sparkles,
  ChevronRight,
  Heart,
  ShieldCheck,
  AlarmClock,
  Pencil,
  Camera,
  Mail,
  Cloud,
  Infinity as InfinityIcon,
  Zap,
  Bell,
  Contrast,
  Plus,
  Clock,
  Check,
} from 'lucide-react';

interface ProfileScreenProps {
  onOpenHelp: () => void;
  onReplayTour: () => void;
  /** Switches the bottom nav to Home. Used by the "Capture" quick-action tile. */
  onGoToCapture?: () => void;
}

const CONTRAST_KEY = 'later_profile_contrast_v1';
const MOTION_KEY = 'later_profile_reduced_motion_v1';

/**
 * The placeholder avatar mark. Deliberately NOT a stock photo or anyone's
 * likeness — it's an abstract two-tone glyph that only ever appears until
 * the person adds their own photo via Edit profile, at which point their
 * real photo replaces it everywhere this component is used.
 */
const AvatarGlyph: React.FC<{ size: number }> = ({ size }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" fill="none" aria-hidden="true">
    <circle cx="50" cy="50" r="50" fill="var(--p2-emerald-mid)" />
    <path d="M50 0a50 50 0 0 1 0 100z" fill="var(--p2-emerald-light)" fillOpacity="0.55" />
    <path d="M50 14a36 36 0 0 1 0 72z" fill="var(--p2-emerald-light)" fillOpacity="0.35" />
  </svg>
);

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  onOpenHelp,
  onReplayTour,
  onGoToCapture,
}) => {
  const { items, resetData, showToast, setSelectedItem } = useLater();
  const { user, openAuthModal, signOutUser, updateDisplayName, updatePhoto } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const [quickCaptureEnabled, setQuickCaptureEnabled] = useState(true);
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    QuickCapture.isEnabled()
      .then((res) => setQuickCaptureEnabled(res.enabled))
      .catch(() => {});
  }, []);

  const handleToggleQuickCapture = () => {
    if (quickCaptureEnabled) {
      const confirmed = window.confirm(
        'Disable Quick Capture?\n\nThis only removes the persistent "What do you want to remember?" notification. It does not affect Later\'s notification permission or your reminder notifications — those keep working exactly as before. You can turn Quick Capture back on any time from here.'
      );
      if (!confirmed) return;
      QuickCapture.setEnabled({ enabled: false }).catch(() => {});
      setQuickCaptureEnabled(false);
    } else {
      QuickCapture.setEnabled({ enabled: true }).catch(() => {});
      setQuickCaptureEnabled(true);
    }
  };

  // Live, authoritative notification permission (same source of truth the
  // rest of the app's recovery flow uses) — not a decorative badge.
  const [notifStatus, setNotifStatus] = useState<NotificationPermissionStatus | null>(null);
  const refreshNotifStatus = () => {
    getNotificationPermissionStatus().then(setNotifStatus).catch(() => setNotifStatus(null));
  };
  useEffect(() => {
    refreshNotifStatus();
  }, []);
  const handleNotificationsRow = async () => {
    if (notifStatus === 'granted') {
      await openNotificationSettings();
    } else {
      await attemptEnableNotifications();
    }
    refreshNotifStatus();
  };

  // Real, working accessibility preferences, persisted per device. Scoped
  // to this screen's own tokens (below) — the rest of the app doesn't yet
  // have matching high-contrast/reduced-motion styles to key off.
  const [contrastOn, setContrastOn] = useState(() => {
    try { return localStorage.getItem(CONTRAST_KEY) === '1'; } catch { return false; }
  });
  const [motionReduced, setMotionReduced] = useState(() => {
    try { return localStorage.getItem(MOTION_KEY) === '1'; } catch { return false; }
  });
  const [isAccessibilitySheetOpen, setIsAccessibilitySheetOpen] = useState(false);
  const toggleContrast = () => {
    setContrastOn((prev) => {
      const next = !prev;
      try { localStorage.setItem(CONTRAST_KEY, next ? '1' : '0'); } catch {}
      return next;
    });
  };
  const toggleMotion = () => {
    setMotionReduced((prev) => {
      const next = !prev;
      try { localStorage.setItem(MOTION_KEY, next ? '1' : '0'); } catch {}
      return next;
    });
  };

  const [isAboutSheetOpen, setIsAboutSheetOpen] = useState(false);
  const [isEditSheetOpen, setIsEditSheetOpen] = useState(false);
  const [isRecentSheetOpen, setIsRecentSheetOpen] = useState(false);
  const [nameDraft, setNameDraft] = useState('');
  const [isSavingName, setIsSavingName] = useState(false);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [localPhotoPreview, setLocalPhotoPreview] = useState<string | null>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);

  // Real, computed stats — nothing here is a fabricated demo number.
  const activeItems = useMemo(() => items.filter((i) => !i.isArchived), [items]);
  const totalCount = activeItems.length;
  const reminderCount = useMemo(
    () => activeItems.filter((i) => i.reminderTime || i.scheduledFor).length,
    [activeItems]
  );
  const streakDays = useMemo(() => computeStreakDays(items), [items]);
  const thisWeekCount = useMemo(() => countCapturedThisWeek(items), [items]);
  const returningSoonCount = useMemo(() => countReturningSoon(items), [items]);
  const recentItems = useMemo(
    () =>
      [...activeItems]
        .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
        .slice(0, 8),
    [activeItems]
  );

  const handleSignOut = async () => {
    const result = await signOutUser();
    showToast(result.success ? 'Signed out' : result.error || 'Sign out failed — please try again');
  };

  const handleResetDemo = () => {
    const confirmed = window.confirm(
      "Reset demo memory?\n\nThis clears all demo data on this device. This can't be undone."
    );
    if (!confirmed) return;
    resetData();
  };

  const handleGoToCapture = () => {
    onGoToCapture?.();
    window.setTimeout(() => {
      document.getElementById('universal-capture-textarea')?.focus();
    }, 260);
  };

  const handleStarredTile = () => {
    showToast('Starring your most important memories is coming in a future update.');
  };

  const displayName = user?.displayName?.trim();
  const photoURL = user?.photoURL;

  const startEditingName = () => {
    setNameDraft(displayName || '');
    setIsEditSheetOpen(true);
  };
  const closeEditSheet = () => {
    setIsEditSheetOpen(false);
    setNameDraft('');
    setLocalPhotoPreview(null);
  };
  const saveNameEdit = async () => {
    if (!nameDraft.trim() || isSavingName) return;
    setIsSavingName(true);
    const result = await updateDisplayName(nameDraft);
    setIsSavingName(false);
    if (result.success) {
      showToast('Name updated');
      setIsEditSheetOpen(false);
    } else {
      showToast(result.error || 'Could not update name');
    }
  };
  const handlePhotoSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const previewUrl = URL.createObjectURL(file);
    setLocalPhotoPreview(previewUrl);
    setIsUploadingPhoto(true);
    const result = await updatePhoto(file);
    setIsUploadingPhoto(false);
    if (result.success) {
      showToast('Profile photo updated');
    } else {
      showToast(result.error || 'Could not upload photo');
    }
    setLocalPhotoPreview(null);
  };

  const notifOn = notifStatus === 'granted';
  const notifSubtitle =
    notifStatus === 'granted'
      ? 'Reminders can reach you'
      : notifStatus === 'denied'
      ? 'Blocked — tap to open settings'
      : 'Tap to allow reminders';

  return (
    <div id="profile-screen" className="p2-root p2-page-bg" data-contrast={contrastOn ? "high" : "normal"} data-motion={motionReduced ? "reduced" : "normal"}>
      <div className="w-full max-w-xl mx-auto px-4 sm:px-6 pt-2 pb-6 flex flex-col gap-4">
        {/* ---- hero -------------------------------------------------- */}
        <div className="pt-3 pb-1">
          <span className="p2-hero-eyebrow">Your space</span>
          <h1 className="p2-hero-title p2-heading">Profile.</h1>
          <p className="p2-hero-sub">Your memories, your calm, your rules.</p>
        </div>

        {/* ---- identity card ------------------------------------------ */}
        <section id="profile-account-card" className="p2-card">
          {user ? (
            <div className="pt-7 pb-2 px-5 flex flex-col items-center text-center">
              <div className="p2-avatar-wrap">
                <span className="p2-avatar-ring" aria-hidden="true" />
                <div className="p2-avatar">
                  {photoURL ? <img src={photoURL} alt="" /> : <AvatarGlyph size={108} />}
                </div>
                <button
                  type="button"
                  onClick={startEditingName}
                  className="p2-avatar-badge"
                  aria-label="Edit profile photo"
                >
                  <Plus className="w-4 h-4" strokeWidth={2.5} />
                </button>
              </div>

              <p className="p2-name p2-heading">{displayName || 'Add your name'}</p>
              <p className="p2-email">{user.email}</p>

              <span className="p2-sync-pill">
                <span className="p2-sync-dot" aria-hidden="true" />
                Synced across devices
              </span>

              <button id="profile-edit-btn" type="button" onClick={startEditingName} className="p2-edit-btn">
                <Pencil className="w-3.5 h-3.5" />
                Edit profile
              </button>

              <div className="p2-stats w-full">
                <div className="p2-stat">
                  <p className="p2-stat__num p2-heading">{totalCount}</p>
                  <p className="p2-stat__label">Memories</p>
                </div>
                <div className="p2-stat">
                  <p className="p2-stat__num p2-heading">{reminderCount}</p>
                  <p className="p2-stat__label">Reminders</p>
                </div>
                <div className="p2-stat">
                  <p className="p2-stat__num p2-heading">
                    {streakDays}
                    <em>d</em>
                  </p>
                  <p className="p2-stat__label">Streak</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="pt-7 pb-2 px-5 flex flex-col items-center text-center">
              <div className="p2-avatar-wrap">
                <span className="p2-avatar-ring" aria-hidden="true" />
                <div className="p2-avatar">
                  <AvatarGlyph size={108} />
                </div>
              </div>

              <p className="p2-name p2-heading">Guest</p>
              <p className="p2-email">Memories stay on this device only</p>

              <span className="p2-badge p2-badge--warn" style={{ marginTop: 12 }}>
                Not synced across devices
              </span>

              <div className="flex items-center gap-2 w-full mt-4">
                <button
                  id="profile-create-account-btn"
                  type="button"
                  onClick={() => openAuthModal('create')}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-full"
                  style={{ background: 'var(--p2-ink)', color: 'var(--p2-cream)', fontWeight: 600, fontSize: 14 }}
                >
                  <UserPlus className="w-4 h-4" />
                  Create account
                </button>
                <button
                  id="profile-sign-in-btn"
                  type="button"
                  onClick={() => openAuthModal('signin')}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-full border"
                  style={{ background: 'transparent', borderColor: 'var(--p2-line)', color: 'var(--p2-ink)', fontWeight: 600, fontSize: 14 }}
                >
                  <LogIn className="w-4 h-4" />
                  Sign in
                </button>
              </div>

              <div className="grid grid-cols-3 gap-2 pt-4 mt-4 w-full" style={{ borderTop: '1px solid var(--p2-line)' }}>
                {[
                  { icon: Cloud, label: 'Sync across devices' },
                  { icon: ShieldCheck, label: 'Keep your data safe' },
                  { icon: InfinityIcon, label: 'Access everywhere' },
                ].map(({ icon: Icon, label }) => (
                  <div key={label} className="flex flex-col items-center text-center gap-1.5">
                    <Icon className="w-5 h-5" style={{ color: 'var(--p2-emerald)' }} />
                    <span style={{ fontSize: 11.5, color: 'var(--p2-ink-muted)', lineHeight: 1.3 }}>{label}</span>
                  </div>
                ))}
              </div>

              <div className="p2-stats w-full">
                <div className="p2-stat">
                  <p className="p2-stat__num p2-heading">{totalCount}</p>
                  <p className="p2-stat__label">Memories</p>
                </div>
                <div className="p2-stat">
                  <p className="p2-stat__num p2-heading">{reminderCount}</p>
                  <p className="p2-stat__label">Reminders</p>
                </div>
                <div className="p2-stat">
                  <p className="p2-stat__num p2-heading">
                    {streakDays}
                    <em>d</em>
                  </p>
                  <p className="p2-stat__label">Streak</p>
                </div>
              </div>
            </div>
          )}
        </section>

        {/* ---- quick actions ------------------------------------------ */}
        <div className="p2-quick-grid">
          <button type="button" className="p2-tile" onClick={handleGoToCapture}>
            <span className="p2-tile__icon" style={{ background: 'var(--p2-mint)' }}>
              <Plus className="w-5 h-5" style={{ color: 'var(--p2-emerald)' }} strokeWidth={2.25} />
            </span>
            <span className="p2-tile__label">Capture</span>
          </button>
          <button type="button" className="p2-tile" onClick={handleStarredTile}>
            <span className="p2-tile__icon" style={{ background: 'var(--p2-pink)' }}>
              <Heart className="w-5 h-5" style={{ color: '#c0483f' }} strokeWidth={2} />
            </span>
            <span className="p2-tile__label">Starred</span>
          </button>
          <button type="button" className="p2-tile" onClick={() => setIsRecentSheetOpen(true)}>
            <span className="p2-tile__icon" style={{ background: 'var(--p2-blue)' }}>
              <Clock className="w-5 h-5" style={{ color: '#3f5f8a' }} strokeWidth={2} />
            </span>
            <span className="p2-tile__label">Recent</span>
          </button>
        </div>

        {/* ---- mini stat cards ------------------------------------------ */}
        <div className="p2-mini-grid">
          <div className="p2-mini" style={{ background: 'var(--p2-mint)' }}>
            <span className="p2-mini__eyebrow">This week</span>
            <span className="p2-mini__num p2-heading">{thisWeekCount}</span>
            <span className="p2-mini__caption">memories captured</span>
          </div>
          <div className="p2-mini" style={{ background: 'var(--p2-peach)' }}>
            <span className="p2-mini__eyebrow">Returning soon</span>
            <span className="p2-mini__num p2-heading">{returningSoonCount}</span>
            <span className="p2-mini__caption">in the next 24h</span>
          </div>
        </div>

        {/* ---- preferences ------------------------------------------ */}
        <div className="pt-1 flex flex-col gap-2">
          <div className="p2-section-head">
            <span className="p2-eyebrow">Preferences</span>
            <h2 className="p2-section-title p2-heading">Make it yours</h2>
          </div>
          <section id="profile-app-settings-card" className="p2-card">
            <button id="profile-toggle-theme-btn" type="button" onClick={toggleTheme} className="p2-row">
              <span className="p2-row__icon" style={{ background: 'var(--p2-yellow)' }}>
                {theme === 'light' ? (
                  <Sun className="w-[18px] h-[18px]" style={{ color: 'var(--p2-gold)' }} />
                ) : (
                  <Moon className="w-[18px] h-[18px]" style={{ color: 'var(--p2-emerald)' }} />
                )}
              </span>
              <span className="p2-row__text">
                <span className="p2-row__title">Appearance</span>
                <span className="p2-row__subtitle">{theme === 'light' ? 'Light mode' : 'Dark mode'}</span>
              </span>
              <ChevronRight className="w-4 h-4 p2-row__chevron" />
            </button>

            {Capacitor.isNativePlatform() && (
              <button id="profile-quick-capture-btn" type="button" onClick={handleToggleQuickCapture} className="p2-row">
                <span className="p2-row__icon" style={{ background: 'var(--p2-mint)' }}>
                  <Zap className="w-[18px] h-[18px]" style={{ color: 'var(--p2-emerald)' }} />
                </span>
                <span className="p2-row__text">
                  <span className="p2-row__title">Quick Capture</span>
                  <span className="p2-row__subtitle">Save from notification shade</span>
                </span>
                <span className={`p2-badge ${quickCaptureEnabled ? '' : 'p2-badge--off'}`}>
                  {quickCaptureEnabled ? 'On' : 'Off'}
                </span>
                <ChevronRight className="w-4 h-4 p2-row__chevron" />
              </button>
            )}

            <button id="profile-notifications-btn" type="button" onClick={handleNotificationsRow} className="p2-row">
              <span className="p2-row__icon" style={{ background: 'var(--p2-blue)' }}>
                <Bell className="w-[18px] h-[18px]" style={{ color: '#3f5f8a' }} />
              </span>
              <span className="p2-row__text">
                <span className="p2-row__title">Notifications</span>
                <span className="p2-row__subtitle">{notifSubtitle}</span>
              </span>
              {notifStatus !== null && (
                <span className={`p2-badge ${notifOn ? '' : 'p2-badge--off'}`}>{notifOn ? 'On' : 'Off'}</span>
              )}
              <ChevronRight className="w-4 h-4 p2-row__chevron" />
            </button>

            {Capacitor.isNativePlatform() && (
              <button id="profile-exact-alarm-btn" type="button" onClick={openExactAlarmSettings} className="p2-row">
                <span className="p2-row__icon" style={{ background: 'var(--p2-mint)' }}>
                  <AlarmClock className="w-[18px] h-[18px]" style={{ color: 'var(--p2-emerald)' }} />
                </span>
                <span className="p2-row__text">
                  <span className="p2-row__title">Exact-time reminders</span>
                  <span className="p2-row__subtitle">Grant exact-alarm permission</span>
                </span>
                <ChevronRight className="w-4 h-4 p2-row__chevron" />
              </button>
            )}

            <button id="profile-accessibility-btn" type="button" onClick={() => setIsAccessibilitySheetOpen(true)} className="p2-row">
              <span className="p2-row__icon" style={{ background: 'var(--p2-peach)' }}>
                <Contrast className="w-[18px] h-[18px]" style={{ color: '#b6693a' }} />
              </span>
              <span className="p2-row__text">
                <span className="p2-row__title">Accessibility</span>
                <span className="p2-row__subtitle">
                  {contrastOn ? 'High contrast' : 'Standard contrast'} · {motionReduced ? 'reduced motion' : 'full motion'}
                </span>
              </span>
              <ChevronRight className="w-4 h-4 p2-row__chevron" />
            </button>
          </section>
        </div>

        {/* ---- support ------------------------------------------ */}
        <div className="pt-1 flex flex-col gap-2">
          <div className="p2-section-head">
            <span className="p2-eyebrow">Support</span>
            <h2 className="p2-section-title p2-heading">Help &amp; about</h2>
          </div>
          <section id="profile-help-card" className="p2-card">
            <button id="profile-help-btn" type="button" onClick={onOpenHelp} className="p2-row">
              <span className="p2-row__icon" style={{ background: 'var(--p2-mint)' }}>
                <HelpCircle className="w-[18px] h-[18px]" style={{ color: 'var(--p2-emerald)' }} />
              </span>
              <span className="p2-row__text">
                <span className="p2-row__title">How Later works</span>
                <span className="p2-row__subtitle">Everything you need to know</span>
              </span>
              <ChevronRight className="w-4 h-4 p2-row__chevron" />
            </button>

            <button id="profile-replay-tour-btn" type="button" onClick={onReplayTour} className="p2-row">
              <span className="p2-row__icon" style={{ background: 'var(--p2-yellow)' }}>
                <Sparkles className="w-[18px] h-[18px]" style={{ color: 'var(--p2-gold)' }} />
              </span>
              <span className="p2-row__text">
                <span className="p2-row__title">Replay feature tour</span>
                <span className="p2-row__subtitle">Take a quick tour of Later</span>
              </span>
              <ChevronRight className="w-4 h-4 p2-row__chevron" />
            </button>

            <button id="profile-about-btn" type="button" onClick={() => setIsAboutSheetOpen(true)} className="p2-row">
              <span className="p2-row__icon" style={{ background: 'var(--p2-pink)' }}>
                <Heart className="w-[18px] h-[18px]" style={{ color: '#c0483f' }} />
              </span>
              <span className="p2-row__text">
                <span className="p2-row__title">About Later</span>
                <span className="p2-row__subtitle">Our mission, story, and more</span>
              </span>
              <ChevronRight className="w-4 h-4 p2-row__chevron" />
            </button>

            <a
              id="profile-feedback-btn"
              href="mailto:godsfavorite903@gmail.com?subject=Later%20app%20feedback"
              className="p2-row"
            >
              <span className="p2-row__icon" style={{ background: 'var(--p2-blue)' }}>
                <Mail className="w-[18px] h-[18px]" style={{ color: '#3f5f8a' }} />
              </span>
              <span className="p2-row__text">
                <span className="p2-row__title">Send feedback</span>
                <span className="p2-row__subtitle">Help us make Later better</span>
              </span>
              <ChevronRight className="w-4 h-4 p2-row__chevron" />
            </a>
          </section>
        </div>

        {/* ---- danger zone ------------------------------------------ */}
        <div className="pt-1 flex flex-col gap-2">
          <div className="p2-section-head">
            <span className="p2-eyebrow p2-eyebrow--danger">Careful</span>
            <h2 className="p2-section-title p2-section-title--danger p2-heading">Danger zone</h2>
          </div>
          <section id="profile-danger-card" className="p2-card">
            <button id="profile-reset-demo-btn" type="button" onClick={handleResetDemo} className="p2-row">
              <span className="p2-row__icon" style={{ background: 'var(--p2-danger-tile)' }}>
                <RotateCcw className="w-[18px] h-[18px]" style={{ color: 'var(--p2-danger)' }} />
              </span>
              <span className="p2-row__text">
                <span className="p2-row__title">Reset demo memory</span>
                <span className="p2-row__subtitle">Clear all demo data</span>
              </span>
              <ChevronRight className="w-4 h-4" style={{ color: 'var(--p2-danger)', opacity: 0.6 }} />
            </button>

            <button id="profile-sign-out-btn" type="button" onClick={handleSignOut} className="p2-row">
              <span className="p2-row__icon" style={{ background: 'var(--p2-danger-tile)' }}>
                <LogOut className="w-[18px] h-[18px]" style={{ color: 'var(--p2-danger)' }} />
              </span>
              <span className="p2-row__text">
                <span className="p2-row__title">Sign out</span>
                <span className="p2-row__subtitle">See you soon</span>
              </span>
              <ChevronRight className="w-4 h-4" style={{ color: 'var(--p2-danger)', opacity: 0.6 }} />
            </button>
          </section>
        </div>

        {/* ---- quote card ------------------------------------------ */}
        <div className="p2-quote">
          <span className="p2-quote__mark">&ldquo;</span>
          <p className="p2-quote__text">
            A more organized you,
            <br />a <em>calmer</em> tomorrow.
          </p>
          <div className="p2-quote__divider" />
          <p className="p2-quote__foot">
            <Heart className="w-3.5 h-3.5" style={{ color: 'var(--p2-gold)' }} />
            Progress lives in the little things.
          </p>
        </div>

        {/* ---- footer ------------------------------------------ */}
        <div className="p2-footer">
          <p className="p2-footer__word">Later</p>
          <p className="p2-footer__tag">Save it now. Decide later.</p>
          <div className="p2-footer__rule" />
          <p className="p2-footer__ver">Made with care · v1.0</p>
        </div>
      </div>

      {/* ---- Edit profile sheet ------------------------------------------ */}
      {user && (
        <BottomSheet
          isOpen={isEditSheetOpen}
          onClose={closeEditSheet}
          title="Edit profile"
          maxWidth="sm"
          footerAction={
            <button
              type="button"
              onClick={saveNameEdit}
              disabled={isSavingName || !nameDraft.trim()}
              className="w-full py-3 rounded-2xl type-body font-semibold disabled:opacity-40 transition-opacity cursor-pointer active:scale-[0.98]"
              style={{ background: 'var(--p2-emerald)', color: '#fff' }}
            >
              {isSavingName ? 'Saving…' : 'Save changes'}
            </button>
          }
        >
          <div className="p2-root flex flex-col items-center pb-2" data-contrast={contrastOn ? "high" : "normal"} data-motion={motionReduced ? "reduced" : "normal"}>
            <input ref={photoInputRef} type="file" accept="image/*" onChange={handlePhotoSelected} className="hidden" />
            <button
              type="button"
              onClick={() => photoInputRef.current?.click()}
              disabled={isUploadingPhoto}
              className="relative group cursor-pointer disabled:cursor-wait"
              style={{ background: 'transparent' }}
              aria-label="Change profile photo"
            >
              <div className="p2-sheet-avatar-wrap">
                <div className="p2-avatar" style={{ width: 96, height: 96, opacity: isUploadingPhoto ? 0.5 : 1 }}>
                  {localPhotoPreview || photoURL ? (
                    <img src={localPhotoPreview || photoURL} alt="" />
                  ) : (
                    <AvatarGlyph size={96} />
                  )}
                </div>
                <span className="p2-avatar-badge" style={{ width: 30, height: 30 }}>
                  <Camera className="w-3.5 h-3.5" />
                </span>
              </div>
            </button>
            <p className="type-caption text-[var(--text-tertiary)] mt-3 text-center max-w-[280px]" style={{ color: 'var(--p2-ink-muted)' }}>
              {isUploadingPhoto ? 'Uploading…' : 'Tap the photo to change it — this is entirely your choice.'}
            </p>
          </div>

          <div className="p2-root" data-contrast={contrastOn ? "high" : "normal"} data-motion={motionReduced ? "reduced" : "normal"}>
            <label htmlFor="profile-name-input" className="type-label block mb-2" style={{ color: 'var(--p2-ink-muted)' }}>
              Your name
            </label>
            <input
              id="profile-name-input"
              autoFocus
              type="text"
              value={nameDraft}
              onChange={(e) => setNameDraft(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') saveNameEdit(); }}
              placeholder="What should Later call you?"
              maxLength={40}
              className="w-full rounded-2xl px-4 py-3.5 outline-none transition-colors"
              style={{ background: 'var(--p2-cream)', border: '1px solid var(--p2-line)', color: 'var(--p2-ink)', fontFamily: 'Inter, sans-serif' }}
            />
            <p className="type-caption mt-2" style={{ color: 'var(--p2-ink-muted)' }}>
              This is shown across Later — on your Profile and anywhere your name appears.
            </p>
          </div>
        </BottomSheet>
      )}

      {/* ---- Accessibility sheet ------------------------------------------ */}
      <BottomSheet isOpen={isAccessibilitySheetOpen} onClose={() => setIsAccessibilitySheetOpen(false)} title="Accessibility" maxWidth="sm">
        <div className="p2-root flex flex-col gap-1" data-contrast={contrastOn ? "high" : "normal"} data-motion={motionReduced ? "reduced" : "normal"}>
          <div className="p2-toggle-row">
            <span>
              <span className="p2-row__title block">High contrast</span>
              <span className="p2-row__subtitle">Stronger text and borders on this screen</span>
            </span>
            <button
              type="button"
              onClick={toggleContrast}
              aria-pressed={contrastOn}
              className="p2-badge"
              style={contrastOn ? undefined : { background: 'transparent', border: '1px solid var(--p2-line)', color: 'var(--p2-ink-faint)' }}
            >
              {contrastOn && <Check className="w-3 h-3 inline mr-1" style={{ verticalAlign: -1 }} />}
              {contrastOn ? 'On' : 'Off'}
            </button>
          </div>
          <div className="p2-toggle-row">
            <span>
              <span className="p2-row__title block">Reduced motion</span>
              <span className="p2-row__subtitle">Turns off animation on this screen</span>
            </span>
            <button
              type="button"
              onClick={toggleMotion}
              aria-pressed={motionReduced}
              className="p2-badge"
              style={motionReduced ? undefined : { background: 'transparent', border: '1px solid var(--p2-line)', color: 'var(--p2-ink-faint)' }}
            >
              {motionReduced && <Check className="w-3 h-3 inline mr-1" style={{ verticalAlign: -1 }} />}
              {motionReduced ? 'On' : 'Off'}
            </button>
          </div>
          <p className="type-caption mt-3" style={{ color: 'var(--p2-ink-muted)' }}>
            These apply to the Profile screen. Your device's own accessibility settings (text size, system reduced motion) are respected everywhere else in Later.
          </p>
        </div>
      </BottomSheet>

      {/* ---- Recent sheet ------------------------------------------ */}
      <BottomSheet isOpen={isRecentSheetOpen} onClose={() => setIsRecentSheetOpen(false)} title="Recently captured" maxWidth="sm">
        <div className="p2-root flex flex-col" data-contrast={contrastOn ? "high" : "normal"} data-motion={motionReduced ? "reduced" : "normal"}>
          {recentItems.length === 0 ? (
            <p className="p2-row__subtitle" style={{ padding: '12px 2px' }}>Nothing captured yet.</p>
          ) : (
            recentItems.map((item) => (
              <button
                key={item.id}
                type="button"
                className="p2-row"
                style={{ padding: '14px 4px' }}
                onClick={() => {
                  setIsRecentSheetOpen(false);
                  setSelectedItem(item);
                }}
              >
                <span className="p2-row__text">
                  <span className="p2-row__title" style={{ display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                    {item.rawInput || item.title || 'Untitled memory'}
                  </span>
                  <span className="p2-row__subtitle">
                    {item.createdAt ? new Date(item.createdAt).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : ''}
                  </span>
                </span>
                <ChevronRight className="w-4 h-4 p2-row__chevron" />
              </button>
            ))
          )}
        </div>
      </BottomSheet>

      {/* ---- About Later sheet ------------------------------------------ */}
      <BottomSheet isOpen={isAboutSheetOpen} onClose={() => setIsAboutSheetOpen(false)} title="About Later" maxWidth="sm">
        <div className="p2-root space-y-3 pb-2" data-contrast={contrastOn ? "high" : "normal"} data-motion={motionReduced ? "reduced" : "normal"}>
          <p className="type-body leading-relaxed" style={{ color: 'var(--p2-ink-muted)' }}>
            Later started from a simple frustration: the best ideas, links, and
            things worth remembering almost always show up at the wrong time —
            mid-scroll, mid-conversation, mid-commute. Most apps ask you to file
            them away immediately, under a folder, a tag, a project. Later
            doesn't.
          </p>
          <p className="type-body leading-relaxed" style={{ color: 'var(--p2-ink-muted)' }}>
            You just save it. Later quietly figures out what it is, when it
            probably matters, and brings it back to you at the right
            moment — not a rigid to-do list, more like a second memory that
            never gets overwhelmed and never forgets.
          </p>
          <p className="type-body leading-relaxed" style={{ color: 'var(--p2-ink-muted)' }}>
            We built Later to feel calm, not urgent. Intelligent, not
            demanding. It's meant to reduce the mental tax of "I need to
            remember this," not add another inbox to manage.
          </p>
        </div>
      </BottomSheet>
    </div>
  );
};
