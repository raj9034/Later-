import React, { useMemo, useRef, useState } from 'react';
import { useLater } from '../context/LaterContext';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { openExactAlarmSettings } from '../utils/nativeNotifications';
import { Capacitor } from '@capacitor/core';
import { BottomSheet } from './ui/BottomSheet';
import { HomeQuoteCard } from './HomeHero';
import {
  UserPlus,
  LogIn,
  LogOut,
  HelpCircle,
  Sun,
  Moon,
  RotateCcw,
  Sparkles,
  ChevronRight,
  Heart,
  ShieldCheck,
  AlarmClock,
  Pencil,
  Camera,
  Leaf,
  Mail,
  Cloud,
  Infinity as InfinityIcon,
  Database,
  Calendar,
} from 'lucide-react';

interface ProfileScreenProps {
  onOpenHelp: () => void;
  onReplayTour: () => void;
}

/**
 * Profile / About screen. Cloned from a reference design: identity +
 * account card, a real "Support Later" feedback link, two labeled +
 * grouped settings cards (App settings / Help & About) matching the
 * reference's section structure, and a closing quote card. "About Later"
 * lives in a BottomSheet rather than an always-expanded page-length card,
 * and the demo testimonials section from an earlier pass was removed to
 * match the reference exactly (it wasn't part of the target design).
 */
export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  onOpenHelp,
  onReplayTour,
}) => {
  const { items, resetData, showToast } = useLater();
  const { user, openAuthModal, signOutUser, updateDisplayName, updatePhoto } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [isAboutSheetOpen, setIsAboutSheetOpen] = useState(false);
  const [isEditSheetOpen, setIsEditSheetOpen] = useState(false);
  const [nameDraft, setNameDraft] = useState('');
  const [isSavingName, setIsSavingName] = useState(false);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [localPhotoPreview, setLocalPhotoPreview] = useState<string | null>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);

  // Real, computed stats — same basis as the Home hero's stat chips, not
  // fabricated numbers. "Collections" isn't shown because the app has no
  // collections concept yet.
  const totalCount = useMemo(() => items.filter((i) => !i.isArchived).length, [items]);
  const reminderCount = useMemo(
    () => items.filter((i) => !i.isArchived && (i.reminderTime || i.scheduledFor)).length,
    [items]
  );

  const handleSignOut = async () => {
    const result = await signOutUser();
    if (result.success) {
      showToast('Signed out');
    } else {
      showToast(result.error || 'Sign out failed — please try again');
    }
  };

  // Google Sign-In gives us a real display name and photo for free; email
  // sign-up doesn't — so for email accounts, editing the display name here
  // is how they get a real name to show instead of just their email.
  const displayName = user?.displayName?.trim();
  const photoURL = user?.photoURL;
  const avatarInitial = (displayName?.[0] || user?.email?.[0] || '?').toUpperCase();

  const startEditingName = () => {
    setNameDraft(displayName || '');
    setIsEditSheetOpen(true);
  };

  const closeEditSheet = () => {
    setIsEditSheetOpen(false);
    setNameDraft('');
    setLocalPhotoPreview(null);
  };

  const saveNameEdit = async () => {
    if (!nameDraft.trim() || isSavingName) return;
    setIsSavingName(true);
    const result = await updateDisplayName(nameDraft);
    setIsSavingName(false);
    if (result.success) {
      showToast('Name updated');
      setIsEditSheetOpen(false);
    } else {
      showToast(result.error || 'Could not update name');
    }
  };

  const handlePhotoSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // allow re-selecting the same file later
    if (!file) return;

    // Show an instant local preview (object URL) while the real upload
    // happens in the background, so the sheet doesn't feel frozen during
    // the network round-trip to Firebase Storage.
    const previewUrl = URL.createObjectURL(file);
    setLocalPhotoPreview(previewUrl);
    setIsUploadingPhoto(true);

    const result = await updatePhoto(file);
    setIsUploadingPhoto(false);

    if (result.success) {
      showToast('Profile photo updated');
      setLocalPhotoPreview(null); // real photoURL from user object takes over
    } else {
      showToast(result.error || 'Could not upload photo');
      setLocalPhotoPreview(null);
    }
  };

  return (
    <div
      id="profile-screen"
      className="w-full max-w-xl mx-auto px-4 sm:px-6 pt-2 pb-8 flex flex-col gap-6"
    >
      {/* Header block — leaf + tagline treatment matches Home/Search/
          Schedule exactly, per the reference. */}
      <div className="pt-2 relative">
        <Leaf
          className="absolute -top-2 right-0 w-14 h-14 text-[var(--sage)] opacity-30 rotate-[20deg] pointer-events-none"
          strokeWidth={1}
        />
        <h1 className="type-page-title text-[var(--text-primary)]">Profile</h1>
        <p className="type-body-sm text-[var(--text-secondary)] mt-1">
          Your space, your memories.
        </p>
      </div>

      {/* Identity block — centered avatar and name, matching the standard
          mobile-profile pattern (large photo, name below it, actions
          below that) instead of cramming avatar+name+edit+sign-out into
          one tight row. */}
      <section
        id="profile-account-card"
        className="rounded-3xl border border-[var(--border)] bg-[var(--surface-elevated)] overflow-hidden"
        style={{ boxShadow: 'var(--elevation-1)' }}
      >
        {user ? (
          <>
            <div className="pt-7 pb-5 px-5 flex flex-col items-center text-center">
              {photoURL ? (
                <img
                  src={photoURL}
                  alt=""
                  className="w-20 h-20 rounded-full object-cover border-2 border-[var(--accent)]/25"
                />
              ) : (
                <div className="w-20 h-20 rounded-full bg-[var(--accent)] flex items-center justify-center text-[var(--bg)] font-display font-bold text-3xl">
                  {avatarInitial}
                </div>
              )}

              <p className="mt-3.5 type-heading font-semibold text-[var(--text-primary)]">
                {displayName || 'Add your name'}
              </p>
              <p className="type-caption text-[var(--text-tertiary)] mt-0.5">
                {user.email}
              </p>

              <button
                id="profile-edit-btn"
                type="button"
                onClick={startEditingName}
                className="mt-4 flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-[var(--surface-elevated)] border border-[var(--border)] text-[var(--text-primary)] type-caption font-semibold hover:bg-[var(--surface-sunken)] active:scale-[0.98] press-interactive transition-all cursor-pointer"
              >
                <Pencil className="w-3.5 h-3.5" />
                Edit profile
                <ChevronRight className="w-3.5 h-3.5 -mr-1 text-[var(--text-tertiary)]" />
              </button>
            </div>

            {/* Stats row — real, computed numbers rather than decorative.
                Nested in its own bordered box (not a full nested card fill,
                per "no dim/grey/tinted cards") to match the reference's
                inset stats strip inside the account card. Only two cells
                because that's what's real: there's no "favorites/starred"
                concept in the data model yet, so a third stat here would
                be a fabricated number — same rule the rest of this screen
                already follows for e.g. Collections. */}
            <div className="px-5 pb-5">
              <div className="rounded-2xl border border-[var(--border)] grid grid-cols-2 divide-x divide-[var(--border)]">
                <div className="px-4 py-3.5 flex flex-col items-center gap-1">
                  <Database className="w-4.5 h-4.5 text-[var(--accent-deep)]" strokeWidth={1.75} />
                  <p className="type-display text-[var(--text-primary)] !text-[19px] leading-none">
                    {totalCount}
                  </p>
                  <p className="type-caption text-[var(--text-secondary)]">
                    {totalCount === 1 ? 'Memory' : 'Memories'}
                  </p>
                </div>
                <div className="px-4 py-3.5 flex flex-col items-center gap-1">
                  <Calendar className="w-4.5 h-4.5 text-[var(--accent-deep)]" strokeWidth={1.75} />
                  <p className="type-display text-[var(--text-primary)] !text-[19px] leading-none">
                    {reminderCount}
                  </p>
                  <p className="type-caption text-[var(--text-secondary)]">
                    {reminderCount === 1 ? 'Reminder' : 'Reminders'}
                  </p>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="p-5">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-14 h-14 rounded-full bg-[var(--sage-soft)] flex items-center justify-center shrink-0 relative">
                <UserPlus className="w-6 h-6 text-[var(--accent-deep)]" />
                <span className="absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full bg-[var(--accent)] flex items-center justify-center">
                  <Leaf className="w-2.5 h-2.5 text-white" />
                </span>
              </div>
              <div>
                <p className="type-body font-semibold text-[var(--text-primary)]">
                  You're using Later as a guest
                </p>
                <p className="type-body-sm text-[var(--text-secondary)] mt-1">
                  Create an account to sync your memories across devices.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 mb-4">
              <button
                id="profile-create-account-btn"
                type="button"
                onClick={() => openAuthModal('create')}
                className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-2xl bg-[var(--accent)] text-white type-body-sm font-semibold active:scale-[0.98] press-interactive transition-all cursor-pointer"
              >
                <UserPlus className="w-4 h-4" />
                Create account
              </button>
              <button
                id="profile-sign-in-btn"
                type="button"
                onClick={() => openAuthModal('signin')}
                className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-2xl bg-[var(--surface)] border border-[var(--border)] text-[var(--text-primary)] type-body-sm font-semibold hover:bg-[var(--surface-sunken)] active:scale-[0.98] press-interactive transition-all cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                Sign in
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-4 border-t border-[var(--border)]">
              {[
                { icon: Cloud, label: 'Sync across devices' },
                { icon: ShieldCheck, label: 'Keep your data safe' },
                { icon: InfinityIcon, label: 'Access your memories everywhere' },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex flex-col items-center text-center gap-1.5">
                  <Icon className="w-5 h-5 text-[var(--accent-deep)]" />
                  <span className="type-caption text-[var(--text-secondary)] leading-tight">
                    {label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Support Later — real mailto feedback link (no Play Store listing
          exists since this app distributes via direct APK, so "leave a
          review" would be dishonest chrome; a feedback email is the real
          equivalent). */}
      <section
        id="profile-support-card"
        className="rounded-3xl border border-[var(--border)] bg-[var(--surface-elevated)] p-4 flex items-center gap-3"
        style={{ boxShadow: 'var(--elevation-1)' }}
      >
        <div className="w-11 h-11 rounded-2xl bg-[var(--sage-soft)] flex items-center justify-center shrink-0">
          <Leaf className="w-5 h-5 text-[var(--accent-deep)]" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="type-body font-semibold text-[var(--text-primary)]">Support Later</p>
          <p className="type-caption text-[var(--text-secondary)] mt-0.5">
            Help us build a calmer, more mindful internet.
          </p>
        </div>
        <a
          href="mailto:godsfavorite903@gmail.com?subject=Later%20app%20feedback"
          className="shrink-0 flex items-center gap-1 px-3.5 py-2 rounded-full bg-[var(--sage-soft)] text-[var(--accent-deep)] type-caption font-semibold cursor-pointer active:scale-95 transition-transform"
        >
          <Mail className="w-3.5 h-3.5" />
          Send feedback
        </a>
      </section>

      {/* App settings — a labeled section header + one grouped card,
          matching the reference's "App settings" structure exactly.
          Appearance and reminder delivery are the two settings that
          genuinely exist and work in this app; Notifications/Preferences
          rows from the reference were left out (as agreed earlier) since
          neither has a real screen behind it yet. */}
      <div className="pt-1">
        <h2 className="type-section-title font-onboarding-serif text-[var(--text-primary)] px-1">
          Preferences
        </h2>
        <p className="type-caption text-[var(--text-tertiary)] px-1 mb-2.5">
          Customize your experience.
        </p>
        <section
          id="profile-app-settings-card"
          className="rounded-3xl border border-[var(--border)] bg-[var(--surface-elevated)] overflow-hidden divide-y divide-[var(--divider)]"
          style={{ boxShadow: 'var(--elevation-1)' }}
        >
          <button
            id="profile-toggle-theme-btn"
            type="button"
            onClick={toggleTheme}
            className="w-full flex items-center justify-between px-5 py-4 hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[var(--gold-soft)] flex items-center justify-center shrink-0">
                {theme === 'light' ? (
                  <Sun className="w-4.5 h-4.5 text-[var(--gold-warm)]" />
                ) : (
                  <Moon className="w-4.5 h-4.5 text-[var(--accent)]" />
                )}
              </div>
              <div className="text-left">
                <span className="type-body text-[var(--text-primary)] font-medium block">
                  Appearance
                </span>
                <span className="type-caption text-[var(--text-tertiary)]">
                  {theme === 'light' ? 'Light mode' : 'Dark mode'}
                </span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)]" />
          </button>

          {Capacitor.isNativePlatform() && (
            <button
              id="profile-exact-alarm-btn"
              type="button"
              onClick={openExactAlarmSettings}
              className="w-full flex items-center justify-between px-5 py-4 hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-[var(--accent-soft)] flex items-center justify-center shrink-0">
                  <AlarmClock className="w-4.5 h-4.5 text-[var(--accent)]" />
                </div>
                <div className="text-left">
                  <span className="type-body text-[var(--text-primary)] font-medium block">
                    Reminder permissions
                  </span>
                  <span className="type-caption text-[var(--text-tertiary)]">
                    Grant exact-alarm permission in Settings
                  </span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)]" />
            </button>
          )}
        </section>
      </div>

      {/* Help & About — second labeled section + card, matching the
          reference's separate grouping. "About Later" moved from an
          always-expanded paragraph block into a compact row (like
          everything else here) that opens a BottomSheet with the full
          story — this is the concrete fix for "small cards, not big
          cards": the content didn't need to be removed, just presented
          the same compact way as every other row instead of permanently
          taking up a large chunk of the page. */}
      <div className="pt-1">
        <h2 className="type-section-title font-onboarding-serif text-[var(--text-primary)] px-1">
          Help &amp; about
        </h2>
        <p className="type-caption text-[var(--text-tertiary)] px-1 mb-2.5">
          Learn, explore and stay connected.
        </p>
        <section
          id="profile-help-card"
          className="rounded-3xl border border-[var(--border)] bg-[var(--surface-elevated)] overflow-hidden divide-y divide-[var(--divider)]"
          style={{ boxShadow: 'var(--elevation-1)' }}
        >
          <button
            id="profile-help-btn"
            type="button"
            onClick={onOpenHelp}
            className="w-full flex items-center justify-between px-5 py-4 hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[var(--sage-soft)] flex items-center justify-center shrink-0">
                <HelpCircle className="w-4.5 h-4.5 text-[var(--sage)]" />
              </div>
              <div className="text-left">
                <span className="type-body text-[var(--text-primary)] font-medium block">
                  How Later Works &amp; FAQ
                </span>
                <span className="type-caption text-[var(--text-tertiary)]">
                  Everything you need to know
                </span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)]" />
          </button>

          <button
            id="profile-replay-tour-btn"
            type="button"
            onClick={onReplayTour}
            className="w-full flex items-center justify-between px-5 py-4 hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[var(--gold-soft)] flex items-center justify-center shrink-0">
                <Sparkles className="w-4.5 h-4.5 text-[var(--gold-warm)]" />
              </div>
              <div className="text-left">
                <span className="type-body text-[var(--text-primary)] font-medium block">
                  Replay feature tour
                </span>
                <span className="type-caption text-[var(--text-tertiary)]">
                  Take a quick tour of Later
                </span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)]" />
          </button>

          <button
            id="profile-about-btn"
            type="button"
            onClick={() => setIsAboutSheetOpen(true)}
            className="w-full flex items-center justify-between px-5 py-4 hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#FDF1EF] flex items-center justify-center shrink-0">
                <Heart className="w-4.5 h-4.5 text-[#D64545]" />
              </div>
              <div className="text-left">
                <span className="type-body text-[var(--text-primary)] font-medium block">
                  About Later
                </span>
                <span className="type-caption text-[var(--text-tertiary)]">
                  Our mission, story, and more
                </span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)]" />
          </button>
        </section>
      </div>

      {/* Danger zone — separated out from Help & About and visually
          distinct (red-tinted, not grey) per the reference, matching the
          existing #FDF1EF / #D64545 red pairing already used for the
          About Later icon elsewhere on this screen. Sign out moved here
          from the identity card, matching the reference's grouping. */}
      <div className="pt-1">
        <h2 className="type-section-title font-onboarding-serif text-[#D64545] px-1">
          Danger zone
        </h2>
        <p className="type-caption text-[#D64545]/70 px-1 mb-2.5">
          Only if you need to.
        </p>
        <section
          id="profile-danger-card"
          className="rounded-3xl border border-[#D64545]/15 bg-[#FDF1EF] dark:bg-[rgba(214,69,69,0.10)] dark:border-[rgba(214,69,69,0.22)] overflow-hidden divide-y divide-[#D64545]/10"
          style={{ boxShadow: 'var(--elevation-1)' }}
        >
          <button
            id="profile-reset-demo-btn"
            type="button"
            onClick={resetData}
            className="w-full flex items-center justify-between px-5 py-4 hover:bg-[#D64545]/5 transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-white/60 dark:bg-[rgba(214,69,69,0.16)] flex items-center justify-center shrink-0">
                <RotateCcw className="w-4.5 h-4.5 text-[#D64545]" />
              </div>
              <div className="text-left">
                <span className="type-body text-[var(--text-primary)] font-medium block">
                  Reset demo memory
                </span>
                <span className="type-caption text-[var(--text-tertiary)]">
                  Clear all demo data
                </span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#D64545]/60" />
          </button>

          <button
            id="profile-sign-out-btn"
            type="button"
            onClick={handleSignOut}
            className="w-full flex items-center justify-between px-5 py-4 hover:bg-[#D64545]/5 transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-white/60 dark:bg-[rgba(214,69,69,0.16)] flex items-center justify-center shrink-0">
                <LogOut className="w-4.5 h-4.5 text-[#D64545]" />
              </div>
              <span className="type-body text-[var(--text-primary)] font-medium">
                Sign out
              </span>
            </div>
            <ChevronRight className="w-4 h-4 text-[#D64545]/60" />
          </button>
        </section>
      </div>

      <HomeQuoteCard />

      <p className="type-caption text-[var(--text-tertiary)] text-center pb-2">
        Later · Save it now. Decide later.
      </p>

      {/* Edit Profile sheet — a real, full-width field the person can
          actually see themselves typing into, instead of a cramped inline
          input squeezed next to other buttons. */}
      {user && (
        <BottomSheet
          isOpen={isEditSheetOpen}
          onClose={closeEditSheet}
          title="Edit profile"
          maxWidth="sm"
          footerAction={
            <button
              type="button"
              onClick={saveNameEdit}
              disabled={isSavingName || !nameDraft.trim()}
              className="w-full py-3 rounded-2xl bg-[var(--accent)] text-[var(--bg)] type-body font-semibold disabled:opacity-40 transition-opacity cursor-pointer active:scale-[0.98] press-interactive"
            >
              {isSavingName ? 'Saving…' : 'Save changes'}
            </button>
          }
        >
          <div className="flex flex-col items-center pb-2">
            <input
              ref={photoInputRef}
              type="file"
              accept="image/*"
              onChange={handlePhotoSelected}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => photoInputRef.current?.click()}
              disabled={isUploadingPhoto}
              className="relative group cursor-pointer disabled:cursor-wait"
              aria-label="Change profile photo"
            >
              {localPhotoPreview || photoURL ? (
                <img
                  src={localPhotoPreview || photoURL}
                  alt=""
                  className={`w-20 h-20 rounded-full object-cover border-2 border-[var(--accent)]/25 ${isUploadingPhoto ? 'opacity-50' : ''}`}
                />
              ) : (
                <div className={`w-20 h-20 rounded-full bg-[var(--accent)] flex items-center justify-center text-[var(--bg)] font-display font-bold text-3xl ${isUploadingPhoto ? 'opacity-50' : ''}`}>
                  {avatarInitial}
                </div>
              )}
              <span className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-[var(--surface-elevated)] border-2 border-[var(--accent-soft)] flex items-center justify-center shadow-sm group-active:scale-95 transition-transform">
                <Camera className="w-3.5 h-3.5 text-[var(--accent-deep)] dark:text-[var(--accent)]" />
              </span>
            </button>
            <p className="type-caption text-[var(--text-tertiary)] mt-3 text-center max-w-[280px]">
              {isUploadingPhoto ? 'Uploading…' : 'Tap the photo to change it'}
            </p>
          </div>

          <div>
            <label htmlFor="profile-name-input" className="type-label text-[var(--text-secondary)] block mb-2">
              Your name
            </label>
            <input
              id="profile-name-input"
              autoFocus
              type="text"
              value={nameDraft}
              onChange={(e) => setNameDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') saveNameEdit();
              }}
              placeholder="What should Later call you?"
              maxLength={40}
              className="w-full bg-[var(--surface-elevated)] border border-[var(--border)] rounded-2xl px-4 py-3.5 type-body text-[var(--text-primary)] outline-none focus:border-[var(--accent)] transition-colors"
            />
            <p className="type-caption text-[var(--text-tertiary)] mt-2">
              This is shown across Later — on your Profile and anywhere your name appears.
            </p>
          </div>
        </BottomSheet>
      )}

      {/* About Later — the full founder-story copy, unchanged from before,
          just moved out of an always-expanded page-length card into a
          sheet that opens from the compact row above. No content was
          removed, only repositioned. */}
      <BottomSheet
        isOpen={isAboutSheetOpen}
        onClose={() => setIsAboutSheetOpen(false)}
        title="About Later"
        maxWidth="sm"
      >
        <div className="space-y-3 pb-2">
          <p className="type-body text-[var(--text-secondary)] leading-relaxed">
            Later started from a simple frustration: the best ideas, links, and
            things worth remembering almost always show up at the wrong time —
            mid-scroll, mid-conversation, mid-commute. Most apps ask you to file
            them away immediately, under a folder, a tag, a project. Later
            doesn't.
          </p>
          <p className="type-body text-[var(--text-secondary)] leading-relaxed">
            You just save it. Later quietly figures out what it is, when it
            probably matters, and brings it back to you at the right
            moment — not a rigid to-do list, more like a second memory that
            never gets overwhelmed and never forgets.
          </p>
          <p className="type-body text-[var(--text-secondary)] leading-relaxed">
            We built Later to feel calm, not urgent. Intelligent, not
            demanding. It's meant to reduce the mental tax of "I need to
            remember this," not add another inbox to manage.
          </p>
        </div>
      </BottomSheet>
    </div>
  );
};
