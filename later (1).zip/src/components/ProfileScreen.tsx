import React, { useMemo, useState } from 'react';
import { useLater } from '../context/LaterContext';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { openExactAlarmSettings } from '../utils/nativeNotifications';
import { Capacitor } from '@capacitor/core';
import { BottomSheet } from './ui/BottomSheet';
import {
  UserPlus,
  LogIn,
  LogOut,
  HelpCircle,
  Sun,
  Moon,
  RotateCcw,
  Sparkles,
  ChevronRight,
  Heart,
  ShieldCheck,
  Quote,
  AlarmClock,
  Pencil,
} from 'lucide-react';

interface ProfileScreenProps {
  onOpenHelp: () => void;
  onReplayTour: () => void;
}

/**
 * Profile / About screen. Consolidates everything that previously lived in
 * the header dropdown (account, theme, help, replay tour, reset demo) plus
 * new trust-building content: founder story, product philosophy, and
 * demo-labeled testimonials, per the redesign brief.
 */
export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  onOpenHelp,
  onReplayTour,
}) => {
  const { items, resetData, showToast } = useLater();
  const { user, openAuthModal, signOutUser, updateDisplayName } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [isAboutExpanded, setIsAboutExpanded] = useState(false);
  const [isEditSheetOpen, setIsEditSheetOpen] = useState(false);
  const [nameDraft, setNameDraft] = useState('');
  const [isSavingName, setIsSavingName] = useState(false);

  // Real, computed stats — same basis as the Home hero's stat chips, not
  // fabricated numbers. "Collections" isn't shown because the app has no
  // collections concept yet.
  const totalCount = useMemo(() => items.filter((i) => !i.isArchived).length, [items]);
  const reminderCount = useMemo(
    () => items.filter((i) => !i.isArchived && (i.reminderTime || i.scheduledFor)).length,
    [items]
  );

  const handleSignOut = async () => {
    const result = await signOutUser();
    if (result.success) {
      showToast('Signed out');
    } else {
      showToast(result.error || 'Sign out failed — please try again');
    }
  };

  // Google Sign-In gives us a real display name and photo for free; email
  // sign-up doesn't — so for email accounts, editing the display name here
  // is how they get a real name to show instead of just their email.
  const displayName = user?.displayName?.trim();
  const photoURL = user?.photoURL;
  const avatarInitial = (displayName?.[0] || user?.email?.[0] || '?').toUpperCase();

  const startEditingName = () => {
    setNameDraft(displayName || '');
    setIsEditSheetOpen(true);
  };

  const closeEditSheet = () => {
    setIsEditSheetOpen(false);
    setNameDraft('');
  };

  const saveNameEdit = async () => {
    if (!nameDraft.trim() || isSavingName) return;
    setIsSavingName(true);
    const result = await updateDisplayName(nameDraft);
    setIsSavingName(false);
    if (result.success) {
      showToast('Name updated');
      setIsEditSheetOpen(false);
    } else {
      showToast(result.error || 'Could not update name');
    }
  };

  return (
    <div
      id="profile-screen"
      className="w-full max-w-xl mx-auto px-4 sm:px-6 pt-2 pb-8 flex flex-col gap-6"
    >
      {/* Header block */}
      <div className="pt-2">
        <h1 className="type-page-title text-[var(--text-primary)]">Profile</h1>
        <p className="type-body-sm text-[var(--text-secondary)] mt-1">
          Your account, preferences, and the story behind Later.
        </p>
      </div>

      {/* Identity block — centered avatar and name, matching the standard
          mobile-profile pattern (large photo, name below it, actions
          below that) instead of cramming avatar+name+edit+sign-out into
          one tight row. */}
      <section
        id="profile-account-card"
        className="rounded-3xl border border-[var(--accent)]/15 bg-[var(--accent-soft)] overflow-hidden"
      >
        {user ? (
          <>
            <div className="pt-7 pb-5 px-5 flex flex-col items-center text-center">
              <button
                type="button"
                onClick={startEditingName}
                className="relative group cursor-pointer"
                aria-label="Edit profile"
              >
                {photoURL ? (
                  <img
                    src={photoURL}
                    alt=""
                    className="w-20 h-20 rounded-full object-cover border-2 border-[var(--accent)]/25"
                  />
                ) : (
                  <div className="w-20 h-20 rounded-full bg-[var(--accent)] flex items-center justify-center text-[var(--bg)] font-display font-bold text-3xl">
                    {avatarInitial}
                  </div>
                )}
                <span className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-[var(--surface-elevated)] border-2 border-[var(--accent-soft)] flex items-center justify-center shadow-sm group-active:scale-95 transition-transform">
                  <Pencil className="w-3.5 h-3.5 text-[var(--accent-deep)] dark:text-[var(--accent)]" />
                </span>
              </button>

              <button
                type="button"
                onClick={startEditingName}
                className="mt-3.5 cursor-pointer"
              >
                <p className="type-heading font-semibold text-[var(--text-primary)]">
                  {displayName || 'Add your name'}
                </p>
                <p className="type-caption text-[var(--text-tertiary)] mt-0.5">
                  {user.email}
                </p>
              </button>

              <button
                id="profile-sign-out-btn"
                type="button"
                onClick={handleSignOut}
                className="mt-4 flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-[var(--surface-elevated)] border border-[var(--border)] text-[var(--text-primary)] type-caption font-semibold hover:bg-[var(--surface-sunken)] active:scale-[0.98] press-interactive transition-all cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                Sign out
              </button>
            </div>

            {/* Stats row — real, computed numbers rather than decorative */}
            <div className="grid grid-cols-2 divide-x divide-[var(--accent)]/15 border-t border-[var(--accent)]/15">
              <div className="px-5 py-3.5 text-center">
                <p className="type-display text-[var(--accent-deep)] dark:text-[var(--accent)] !text-[20px]">
                  {totalCount}
                </p>
                <p className="type-caption text-[var(--accent-deep)] dark:text-[var(--accent)] opacity-80">
                  {totalCount === 1 ? 'Item' : 'Items'}
                </p>
              </div>
              <div className="px-5 py-3.5 text-center">
                <p className="type-display text-[var(--accent-deep)] dark:text-[var(--accent)] !text-[20px]">
                  {reminderCount}
                </p>
                <p className="type-caption text-[var(--accent-deep)] dark:text-[var(--accent)] opacity-80">
                  {reminderCount === 1 ? 'Reminder' : 'Reminders'}
                </p>
              </div>
            </div>
          </>
        ) : (
          <div className="p-5">
            <p className="type-body font-semibold text-[var(--text-primary)]">
              You're using Later as a guest
            </p>
            <p className="type-body-sm text-[var(--text-secondary)] mt-1 mb-4">
              Create an account to sync your memories across devices.
            </p>
            <div className="flex items-center gap-2">
              <button
                id="profile-create-account-btn"
                type="button"
                onClick={() => openAuthModal('create')}
                className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-2xl bg-[var(--accent)] text-[var(--bg)] type-body-sm font-semibold active:scale-[0.98] press-interactive transition-all cursor-pointer"
              >
                <UserPlus className="w-4 h-4" />
                Create account
              </button>
              <button
                id="profile-sign-in-btn"
                type="button"
                onClick={() => openAuthModal('signin')}
                className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-2xl bg-[var(--surface-elevated)] border border-[var(--border)] text-[var(--text-primary)] type-body-sm font-semibold hover:bg-[var(--surface-sunken)] active:scale-[0.98] press-interactive transition-all cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                Sign in
              </button>
            </div>
          </div>
        )}
      </section>

      {/* Preferences card — each row's icon sits in its own tinted chip
          instead of a bare icon floating on white */}
      <section
        id="profile-preferences-card"
        className="rounded-3xl border border-[var(--border)] bg-[var(--surface-elevated)] overflow-hidden divide-y divide-[var(--divider)]"
      >
        <button
          id="profile-toggle-theme-btn"
          type="button"
          onClick={toggleTheme}
          className="w-full flex items-center justify-between px-5 py-4 hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[var(--gold-soft)] flex items-center justify-center shrink-0">
              {theme === 'light' ? (
                <Sun className="w-4.5 h-4.5 text-[var(--gold-warm)]" />
              ) : (
                <Moon className="w-4.5 h-4.5 text-[var(--accent)]" />
              )}
            </div>
            <span className="type-body text-[var(--text-primary)] font-medium">
              {theme === 'light' ? 'Switch to Dark mode' : 'Switch to Light mode'}
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)]" />
        </button>

        {Capacitor.isNativePlatform() && (
          <button
            id="profile-exact-alarm-btn"
            type="button"
            onClick={openExactAlarmSettings}
            className="w-full flex items-center justify-between px-5 py-4 hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[var(--accent-soft)] flex items-center justify-center shrink-0">
                <AlarmClock className="w-4.5 h-4.5 text-[var(--accent)]" />
              </div>
              <div className="text-left">
                <span className="type-body text-[var(--text-primary)] font-medium block">
                  On-time reminder delivery
                </span>
                <span className="type-caption text-[var(--text-tertiary)]">
                  Grant exact-alarm permission in Settings
                </span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)]" />
          </button>
        )}

        <button
          id="profile-help-btn"
          type="button"
          onClick={onOpenHelp}
          className="w-full flex items-center justify-between px-5 py-4 hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[var(--sage-soft)] flex items-center justify-center shrink-0">
              <HelpCircle className="w-4.5 h-4.5 text-[var(--sage)]" />
            </div>
            <span className="type-body text-[var(--text-primary)] font-medium">
              How Later Works &amp; FAQ
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)]" />
        </button>

        <button
          id="profile-replay-tour-btn"
          type="button"
          onClick={onReplayTour}
          className="w-full flex items-center justify-between px-5 py-4 hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[var(--gold-soft)] flex items-center justify-center shrink-0">
              <Sparkles className="w-4.5 h-4.5 text-[var(--gold-warm)]" />
            </div>
            <span className="type-body text-[var(--text-primary)] font-medium">
              Replay feature tour
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)]" />
        </button>

        <button
          id="profile-reset-demo-btn"
          type="button"
          onClick={resetData}
          className="w-full flex items-center justify-between px-5 py-4 hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[var(--clay-soft)] flex items-center justify-center shrink-0">
              <RotateCcw className="w-4.5 h-4.5 text-[var(--clay)]" />
            </div>
            <span className="type-body text-[var(--text-primary)] font-medium">
              Reset demo memory
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)]" />
        </button>
      </section>

      {/* About / Founder story — warm serif heading to match the rest of
          the app's editorial headline treatment, clay-tinted accent */}
      <section
        id="profile-about-card"
        className="rounded-3xl border border-[var(--border)] bg-[var(--surface-elevated)] p-5"
      >
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-xl bg-[var(--clay-soft)] flex items-center justify-center shrink-0">
            <Heart className="w-4 h-4 text-[var(--clay)]" />
          </div>
          <h2 className="type-section-title font-onboarding-serif text-[var(--text-primary)]">About Later</h2>
        </div>

        <p className="type-body text-[var(--text-secondary)] leading-relaxed">
          Later started from a simple frustration: the best ideas, links, and
          things worth remembering almost always show up at the wrong time —
          mid-scroll, mid-conversation, mid-commute. Most apps ask you to file
          them away immediately, under a folder, a tag, a project. Later
          doesn't.
        </p>

        {isAboutExpanded && (
          <div className="mt-3 space-y-3">
            <p className="type-body text-[var(--text-secondary)] leading-relaxed">
              You just save it. Later quietly figures out what it is, when it
              probably matters, and brings it back to you at the right
              moment — not a rigid to-do list, more like a second memory that
              never gets overwhelmed and never forgets.
            </p>
            <p className="type-body text-[var(--text-secondary)] leading-relaxed">
              We built Later to feel calm, not urgent. Intelligent, not
              demanding. It's meant to reduce the mental tax of "I need to
              remember this," not add another inbox to manage.
            </p>
          </div>
        )}

        <button
          id="profile-about-expand-btn"
          type="button"
          onClick={() => setIsAboutExpanded((v) => !v)}
          className="mt-3 type-body-sm font-semibold text-[var(--clay)] cursor-pointer"
        >
          {isAboutExpanded ? 'Show less' : 'Read more'}
        </button>
      </section>

      {/* Trust / testimonials — clearly marked as demo content, sage tint
          to visually separate it from the founder-story card above */}
      <section
        id="profile-testimonials-card"
        className="rounded-3xl border border-[var(--sage)]/20 bg-[var(--sage-soft)] p-5"
      >
        <div className="flex items-center gap-2 mb-1">
          <div className="w-8 h-8 rounded-xl bg-[var(--surface-elevated)] flex items-center justify-center shrink-0">
            <ShieldCheck className="w-4 h-4 text-[var(--sage)]" />
          </div>
          <h2 className="type-section-title text-[var(--text-primary)]">
            What people are saying
          </h2>
        </div>
        <p className="type-caption text-[var(--text-tertiary)] mb-4 ml-10">
          Sample feedback shown for demo purposes — not verified public reviews.
        </p>

        <div className="space-y-3">
          {[
            {
              quote:
                "I stopped losing links in a dozen different apps. Later just remembers for me.",
              name: 'Demo user',
            },
            {
              quote:
                "It doesn't feel like another to-do list. It feels like it's actually paying attention.",
              name: 'Demo user',
            },
          ].map((t, i) => (
            <div
              key={i}
              className="rounded-2xl bg-[var(--surface-elevated)] border border-[var(--border)] p-4"
            >
              <Quote className="w-3.5 h-3.5 text-[var(--sage)] mb-1.5" />
              <p className="type-body-sm text-[var(--text-secondary)] italic leading-relaxed">
                "{t.quote}"
              </p>
              <p className="type-caption text-[var(--text-tertiary)] mt-2 font-mono">
                — {t.name}
              </p>
            </div>
          ))}
        </div>
      </section>

      <p className="type-caption text-[var(--text-tertiary)] text-center pb-2">
        Later · Save it now. Decide later.
      </p>

      {/* Edit Profile sheet — a real, full-width field the person can
          actually see themselves typing into, instead of a cramped inline
          input squeezed next to other buttons. */}
      {user && (
        <BottomSheet
          isOpen={isEditSheetOpen}
          onClose={closeEditSheet}
          title="Edit profile"
          maxWidth="sm"
          footerAction={
            <button
              type="button"
              onClick={saveNameEdit}
              disabled={isSavingName || !nameDraft.trim()}
              className="w-full py-3 rounded-2xl bg-[var(--accent)] text-[var(--bg)] type-body font-semibold disabled:opacity-40 transition-opacity cursor-pointer active:scale-[0.98] press-interactive"
            >
              {isSavingName ? 'Saving…' : 'Save changes'}
            </button>
          }
        >
          <div className="flex flex-col items-center pb-2">
            {photoURL ? (
              <img
                src={photoURL}
                alt=""
                className="w-20 h-20 rounded-full object-cover border-2 border-[var(--accent)]/25"
              />
            ) : (
              <div className="w-20 h-20 rounded-full bg-[var(--accent)] flex items-center justify-center text-[var(--bg)] font-display font-bold text-3xl">
                {avatarInitial}
              </div>
            )}
            {photoURL ? (
              <p className="type-caption text-[var(--text-tertiary)] mt-3 text-center max-w-[280px]">
                Your photo comes from Google Sign-In — Later doesn't have photo uploads yet.
              </p>
            ) : (
              <p className="type-caption text-[var(--text-tertiary)] mt-3 text-center max-w-[280px]">
                Photo uploads aren't available yet — set your name below for now.
              </p>
            )}
          </div>

          <div>
            <label htmlFor="profile-name-input" className="type-label text-[var(--text-secondary)] block mb-2">
              Your name
            </label>
            <input
              id="profile-name-input"
              autoFocus
              type="text"
              value={nameDraft}
              onChange={(e) => setNameDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') saveNameEdit();
              }}
              placeholder="What should Later call you?"
              maxLength={40}
              className="w-full bg-[var(--surface-elevated)] border border-[var(--border)] rounded-2xl px-4 py-3.5 type-body text-[var(--text-primary)] outline-none focus:border-[var(--accent)] transition-colors"
            />
            <p className="type-caption text-[var(--text-tertiary)] mt-2">
              This is shown across Later — on your Profile and anywhere your name appears.
            </p>
          </div>
        </BottomSheet>
      )}
    </div>
  );
};
