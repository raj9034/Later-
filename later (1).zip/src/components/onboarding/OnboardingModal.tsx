import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useLater } from '../../context/LaterContext';
import { useAuth, ONBOARDING_STORAGE_KEY } from '../../context/AuthContext';
import { sounds } from '../../utils/audio';
import { HelpFaqModal } from './HelpFaqModal';
import { requestNotificationPermission } from '../../utils/nativeNotifications';
import {
  ArrowRight,
  HelpCircle,
  X,
  Bell,
  Sparkles,
  Layers,
  Send,
} from 'lucide-react';

interface OnboardingModalProps {
  forceOpen?: boolean;
  onClose?: () => void;
}

type Step =
  | 'splash'
  | 'value-1'
  | 'value-2'
  | 'value-3'
  | 'how-it-works'
  | 'try-it'
  | 'permission'
  | 'auth';

const STEP_ORDER: Step[] = [
  'value-1',
  'value-2',
  'value-3',
  'how-it-works',
  'try-it',
  'permission',
  'auth',
];

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ forceOpen = false, onClose }) => {
  const { saveItem, showToast, isSharedLaunch } = useLater();
  const {
    user,
    loading: authLoading,
    hasSeenOnboarding,
    markOnboardingComplete,
    signIn,
    signInWithGoogle,
    createAccount,
  } = useAuth();

  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isFaqOpen, setIsFaqOpen] = useState<boolean>(false);
  const [step, setStep] = useState<Step>('splash');
  const [firstMemoryText, setFirstMemoryText] = useState<string>('');
  const [tapHintDismissed, setTapHintDismissed] = useState<boolean>(false);

  const [authMode, setAuthMode] = useState<'options' | 'email'>('options');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);

  useEffect(() => {
    if (forceOpen) {
      setIsOpen(true);
      setStep('value-1');
      return;
    }

    if (isSharedLaunch) {
      setIsOpen(false);
      return;
    }

    if (authLoading) return;

    if (user) {
      if (hasSeenOnboarding === true) {
        setIsOpen(false);
      } else if (hasSeenOnboarding === false) {
        setIsOpen(true);
        setStep('splash');
      }
    } else {
      try {
        const completed = localStorage.getItem(ONBOARDING_STORAGE_KEY);
        if (!completed) {
          setIsOpen(true);
          setStep('splash');
        } else {
          setIsOpen(false);
        }
      } catch {
        setIsOpen(true);
        setStep('splash');
      }
    }
  }, [forceOpen, authLoading, user, hasSeenOnboarding]);

  useEffect(() => {
    if (isOpen && step === 'splash') {
      const timer = setTimeout(() => setStep('value-1'), 1400);
      return () => clearTimeout(timer);
    }
  }, [isOpen, step]);

  const handleComplete = async () => {
    try {
      localStorage.setItem(ONBOARDING_STORAGE_KEY, 'true');
    } catch {
      // ignore
    }
    await markOnboardingComplete();
    setIsOpen(false);
    sounds.playSaveChime();
    if (onClose) onClose();
  };

  const handleRequestNotifications = async () => {
    try {
      await requestNotificationPermission();
    } catch {
      // Permission dialogs can be dismissed or fail silently on some devices;
      // onboarding should never get stuck on this, so we proceed regardless.
    }
    if (firstMemoryText.trim()) {
      saveItem(firstMemoryText.trim());
      showToast('First memory captured and scheduled');
    }
    setStep('auth');
  };

  const handleGoogleSignIn = async () => {
    setAuthError(null);
    setIsGoogleLoading(true);
    const result = await signInWithGoogle();
    setIsGoogleLoading(false);
    if (result.success) {
      handleComplete();
    } else {
      setAuthError(result.error || 'Google sign-in failed. Please try again.');
    }
  };

  const handleEmailContinue = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) {
      setAuthError('Please enter both an email and a password.');
      return;
    }
    setAuthError(null);
    setIsAuthLoading(true);

    const signInResult = await signIn(email, password);
    if (signInResult.success) {
      setIsAuthLoading(false);
      handleComplete();
      return;
    }

    if (signInResult.error?.includes('No account found')) {
      const createResult = await createAccount(email, password);
      setIsAuthLoading(false);
      if (createResult.success) {
        handleComplete();
      } else {
        setAuthError(createResult.error || 'Could not create an account. Please try again.');
      }
      return;
    }

    setIsAuthLoading(false);
    setAuthError(signInResult.error || 'Sign-in failed. Please check your details.');
  };

  const handleSkipAuth = () => {
    handleComplete();
  };

  if (!isOpen) return null;

  const currentIndex = STEP_ORDER.indexOf(step);

  return (
    <div id="onboarding-overlay" className="onboarding-fullscreen">
      <div id="onboarding-container" className="w-full h-full flex flex-col relative">
        {step !== 'splash' && (
          <div className="px-5 pt-4 pb-2 flex items-center gap-2 shrink-0">
            <div className="flex-1 flex items-center gap-1.5">
              {STEP_ORDER.map((s, i) => (
                <div
                  key={s}
                  className="h-1 flex-1 rounded-full transition-colors duration-300"
                  style={{
                    background: i <= currentIndex ? 'var(--accent)' : 'var(--border-subtle)',
                  }}
                />
              ))}
            </div>
            <button
              id="onboarding-help-faq-btn"
              type="button"
              onClick={() => {
                sounds.playTap();
                setIsFaqOpen(true);
              }}
              className="p-1.5 rounded-full text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-elevated)] transition-colors cursor-pointer shrink-0"
              aria-label="Need help?"
            >
              <HelpCircle className="w-4 h-4" />
            </button>
            {step !== 'auth' && (
              <button
                id="onboarding-skip-btn"
                type="button"
                onClick={handleSkipAuth}
                className="p-1.5 rounded-full text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-elevated)] transition-colors cursor-pointer shrink-0"
                aria-label="Skip onboarding"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        )}

        <AnimatePresence mode="wait">
          {step === 'splash' && (
            <motion.div
              key="splash"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1, transition: { duration: 0.4, ease: [0, 0, 0.2, 1] } }}
              exit={{ opacity: 0, transition: { duration: 0.3 } }}
              className="flex-1 flex flex-col items-center justify-center text-center px-8"
            >
              <motion.div
                initial={{ scale: 0.85, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                className="w-16 h-16 rounded-2xl bg-[var(--accent)] flex items-center justify-center mb-5"
              >
                <Layers className="w-7 h-7 text-white" />
              </motion.div>
              <motion.h1
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.2 }}
                className="type-page-title text-[var(--text-primary)]"
              >
                Later
              </motion.h1>
            </motion.div>
          )}

          {step === 'value-1' && (
            <ValueScreen
              key="value-1"
              accentBg="var(--accent)"
              textColor="#FFFFFF"
              headline="Never lose a good idea again."
              onNext={() => setStep('value-2')}
            />
          )}

          {step === 'value-2' && (
            <ValueScreen
              key="value-2"
              accentBg="var(--accent-soft)"
              textColor="var(--text-primary)"
              headline="Say when it matters. Later remembers the rest."
              onNext={() => setStep('value-3')}
            />
          )}

          {step === 'value-3' && (
            <ValueScreen
              key="value-3"
              accentBg="var(--surface-elevated)"
              textColor="var(--text-primary)"
              headline="It finds you again, right when you need it."
              onNext={() => setStep('how-it-works')}
            />
          )}

          {step === 'how-it-works' && (
            <motion.div
              key="how-it-works"
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0, transition: { duration: 0.3 } }}
              exit={{ opacity: 0, x: -16, transition: { duration: 0.2 } }}
              className="flex-1 flex flex-col px-6 pt-6"
            >
              <h2 className="type-onboarding-headline text-[var(--text-primary)] mb-2">
                How it works
              </h2>
              <p className="type-body text-[var(--text-secondary)] mb-8">
                Capture anything, tell Later when it matters
              </p>

              <div className="flex-1 flex flex-col gap-3 justify-center">
                <div className="p-4 rounded-2xl bg-[var(--surface-elevated)] border border-[var(--border)] flex items-start gap-3">
                  <div className="w-8 h-8 rounded-xl bg-[var(--accent-soft)] flex items-center justify-center shrink-0">
                    <Sparkles className="w-4 h-4 text-[var(--accent)]" />
                  </div>
                  <div>
                    <h3 className="type-heading text-[var(--text-primary)]">Capture it</h3>
                    <p className="type-body-sm text-[var(--text-secondary)] mt-0.5">
                      A thought, a link, a screenshot — anything worth remembering
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-[var(--surface-elevated)] border border-[var(--border)] flex items-start gap-3">
                  <div className="w-8 h-8 rounded-xl bg-[var(--accent-soft)] flex items-center justify-center shrink-0">
                    <Bell className="w-4 h-4 text-[var(--accent)]" />
                  </div>
                  <div>
                    <h3 className="type-heading text-[var(--text-primary)]">Tell it when</h3>
                    <p className="type-body-sm text-[var(--text-secondary)] mt-0.5">
                      Tonight, next week, or whenever — exact or flexible, your call
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-[var(--surface-elevated)] border border-[var(--border)] flex items-start gap-3">
                  <div className="w-8 h-8 rounded-xl bg-[var(--accent-soft)] flex items-center justify-center shrink-0">
                    <Layers className="w-4 h-4 text-[var(--accent)]" />
                  </div>
                  <div>
                    <h3 className="type-heading text-[var(--text-primary)]">It comes back</h3>
                    <p className="type-body-sm text-[var(--text-secondary)] mt-0.5">
                      Right on time, with the context you need to act on it
                    </p>
                  </div>
                </div>
              </div>

              <div className="pb-6 pt-4">
                <OnboardingPrimaryButton onClick={() => setStep('try-it')} label="Give it a try" />
              </div>
            </motion.div>
          )}

          {step === 'try-it' && (
            <motion.div
              key="try-it"
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0, transition: { duration: 0.3 } }}
              exit={{ opacity: 0, x: -16, transition: { duration: 0.2 } }}
              className="flex-1 flex flex-col px-6 pt-10"
            >
              <div
                className="w-full rounded-full border border-[var(--border)] bg-[var(--surface-elevated)] px-5 py-4 flex items-center gap-3 focus-within:border-[var(--accent)] transition-colors"
                onClick={() => setTapHintDismissed(true)}
              >
                <input
                  id="onboarding-first-memory-input"
                  type="text"
                  value={firstMemoryText}
                  onChange={(e) => {
                    setFirstMemoryText(e.target.value);
                    setTapHintDismissed(true);
                  }}
                  placeholder="What do you want to remember?"
                  className="flex-1 bg-transparent type-body text-[var(--text-primary)] placeholder-[var(--text-tertiary)] outline-none"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => {
                    if (firstMemoryText.trim()) {
                      sounds.playTap();
                      setStep('permission');
                    }
                  }}
                  className="p-2 rounded-full bg-[var(--accent)] text-white shrink-0 disabled:opacity-40"
                  disabled={!firstMemoryText.trim()}
                  aria-label="Continue"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>

              {!tapHintDismissed && (
                <p className="text-center type-body mt-4">
                  <span className="text-[var(--accent)] font-semibold">Tap</span>{' '}
                  <span className="text-[var(--text-primary)]">the text box above</span>
                </p>
              )}

              {tapHintDismissed && (
                <div className="flex flex-wrap gap-2 mt-5 justify-center">
                  {[
                    'Read that article tonight',
                    'Call mom this weekend',
                    'Look into flight prices',
                  ].map((suggestion) => (
                    <button
                      key={suggestion}
                      type="button"
                      onClick={() => {
                        sounds.playTap();
                        setFirstMemoryText(suggestion);
                      }}
                      className="px-3 py-1.5 rounded-full type-body-sm bg-[var(--surface)] border border-[var(--border)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              )}

              <div className="flex-1" />

              <div className="pb-6">
                <button
                  type="button"
                  onClick={() => setStep('permission')}
                  className="w-full text-center type-body-sm text-[var(--text-tertiary)] hover:text-[var(--text-secondary)] py-2"
                >
                  I'll do this later
                </button>
              </div>
            </motion.div>
          )}

          {step === 'permission' && (
            <motion.div
              key="permission"
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0, transition: { duration: 0.3 } }}
              exit={{ opacity: 0, x: -16, transition: { duration: 0.2 } }}
              className="flex-1 flex flex-col px-6 pt-8"
            >
              <h2 className="type-onboarding-headline text-[var(--text-primary)] leading-tight">
                Let Later remind you on time
              </h2>
              <p className="type-body text-[var(--text-secondary)] mt-3">
                It can't bring things back to you without this
              </p>

              <div className="flex-1 flex items-center justify-center">
                <div className="w-20 h-20 rounded-3xl bg-[var(--accent-soft)] flex items-center justify-center">
                  <Bell className="w-9 h-9 text-[var(--accent)]" />
                </div>
              </div>

              <div className="pb-6 flex flex-col gap-2">
                <OnboardingPrimaryButton
                  onClick={handleRequestNotifications}
                  label="Allow notifications"
                />
                <button
                  type="button"
                  onClick={handleRequestNotifications}
                  className="w-full text-center type-body-sm text-[var(--text-tertiary)] hover:text-[var(--text-secondary)] py-2"
                >
                  Not now
                </button>
              </div>
            </motion.div>
          )}

          {step === 'auth' && (
            <motion.div
              key="auth"
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0, transition: { duration: 0.3 } }}
              exit={{ opacity: 0, x: -16, transition: { duration: 0.2 } }}
              className="flex-1 flex flex-col px-6 pt-8"
            >
              <div className="flex-1 flex flex-col items-center justify-center text-center">
                <div className="w-14 h-14 rounded-2xl bg-[var(--accent)] flex items-center justify-center mb-4">
                  <Layers className="w-6 h-6 text-white" />
                </div>
                <h2 className="type-heading-lg text-[var(--text-primary)]">Later</h2>
                <p className="type-caption text-[var(--text-tertiary)] uppercase tracking-wider mt-1">
                  Save your memory to your account
                </p>
              </div>

              {authError && (
                <div
                  id="onboarding-auth-error"
                  className="mb-3 px-3.5 py-2.5 rounded-xl bg-[var(--destructive)]/10 border border-[var(--destructive)]/30 type-body-sm text-[var(--destructive)]"
                >
                  {authError}
                </div>
              )}

              {authMode === 'options' && (
                <div className="flex flex-col gap-2.5 pb-6">
                  <button
                    id="onboarding-google-signin-btn"
                    type="button"
                    onClick={handleGoogleSignIn}
                    disabled={isGoogleLoading}
                    className="w-full py-3.5 rounded-2xl bg-[var(--text-primary)] text-[var(--bg)] type-button font-semibold flex items-center justify-center gap-2.5 disabled:opacity-60 transition-opacity"
                  >
                    <GoogleGlyph />
                    <span>{isGoogleLoading ? 'Connecting…' : 'Continue with Google'}</span>
                  </button>

                  <button
                    id="onboarding-email-option-btn"
                    type="button"
                    onClick={() => {
                      setAuthError(null);
                      setAuthMode('email');
                    }}
                    className="w-full py-3.5 rounded-2xl border border-[var(--border)] bg-[var(--surface-elevated)] text-[var(--text-primary)] type-button font-semibold transition-colors hover:bg-[var(--surface)]"
                  >
                    Continue with Email
                  </button>

                  <button
                    type="button"
                    onClick={handleSkipAuth}
                    className="w-full text-center type-body-sm text-[var(--text-tertiary)] hover:text-[var(--text-secondary)] py-2.5"
                  >
                    Continue as guest
                  </button>
                </div>
              )}

              {authMode === 'email' && (
                <form onSubmit={handleEmailContinue} className="flex flex-col gap-2.5 pb-6">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (authError) setAuthError(null);
                    }}
                    placeholder="you@example.com"
                    autoComplete="email"
                    className="w-full px-4 py-3.5 rounded-2xl border border-[var(--border)] bg-[var(--surface-elevated)] type-body text-[var(--text-primary)] placeholder-[var(--text-tertiary)] outline-none focus:border-[var(--accent)] transition-colors"
                  />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      if (authError) setAuthError(null);
                    }}
                    placeholder="Password"
                    autoComplete="current-password"
                    className="w-full px-4 py-3.5 rounded-2xl border border-[var(--border)] bg-[var(--surface-elevated)] type-body text-[var(--text-primary)] placeholder-[var(--text-tertiary)] outline-none focus:border-[var(--accent)] transition-colors"
                  />
                  <button
                    id="onboarding-email-continue-btn"
                    type="submit"
                    disabled={isAuthLoading}
                    className="w-full py-3.5 rounded-2xl bg-[var(--accent)] text-white type-button font-semibold flex items-center justify-center gap-2 disabled:opacity-60 transition-opacity"
                  >
                    {isAuthLoading ? 'Please wait…' : 'Continue'}
                    {!isAuthLoading && <ArrowRight className="w-4 h-4" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAuthMode('options');
                      setAuthError(null);
                    }}
                    className="w-full text-center type-body-sm text-[var(--text-tertiary)] hover:text-[var(--text-secondary)] py-2"
                  >
                    Back
                  </button>
                </form>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <HelpFaqModal isOpen={isFaqOpen} onClose={() => setIsFaqOpen(false)} />
    </div>
  );
};

const ValueScreen: React.FC<{
  accentBg: string;
  textColor: string;
  headline: string;
  onNext: () => void;
}> = ({ accentBg, textColor, headline, onNext }) => (
  <motion.div
    initial={{ opacity: 0, x: 16 }}
    animate={{ opacity: 1, x: 0, transition: { duration: 0.3 } }}
    exit={{ opacity: 0, x: -16, transition: { duration: 0.2 } }}
    className="flex-1 flex flex-col px-5 pt-2"
  >
    <div
      className="flex-1 rounded-[28px] flex items-center px-7 relative overflow-hidden"
      style={{ background: accentBg }}
    >
      <h1 className="type-onboarding-headline" style={{ color: textColor }}>
        {headline}
      </h1>

      <svg
        className="absolute -bottom-4 -left-4 w-40 h-40 opacity-30 pointer-events-none"
        viewBox="0 0 100 100"
        fill="none"
      >
        <path
          d="M5 20 Q 30 20 30 45 Q 30 65 50 65 Q 75 65 75 90"
          stroke={textColor}
          strokeWidth="7"
          strokeLinecap="round"
        />
      </svg>
    </div>

    <div className="py-6">
      <OnboardingPrimaryButton onClick={onNext} label="Next" />
    </div>
  </motion.div>
);

const OnboardingPrimaryButton: React.FC<{ onClick: () => void; label: string }> = ({
  onClick,
  label,
}) => (
  <button
    type="button"
    onClick={() => {
      sounds.playTap();
      onClick();
    }}
    className="w-full py-3.5 rounded-2xl bg-[var(--accent-soft)] border border-[var(--accent)]/25 text-[var(--text-primary)] type-button font-semibold flex items-center justify-center gap-2 transition-transform active:scale-[0.98]"
  >
    <span>{label}</span>
    <ArrowRight className="w-4 h-4" />
  </button>
);

const GoogleGlyph: React.FC = () => (
  <svg width="18" height="18" viewBox="0 0 48 48">
    <path
      fill="#FFC107"
      d="M43.6 20.5H42V20H24v8h11.3c-1.6 4.7-6.1 8-11.3 8-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.6 6.1 29.6 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.7-.4-3.5z"
    />
    <path
      fill="#FF3D00"
      d="M6.3 14.7l6.6 4.8C14.6 15.9 18.9 13 24 13c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.6 6.1 29.6 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"
    />
    <path
      fill="#4CAF50"
      d="M24 44c5.5 0 10.4-1.9 14.2-5.1l-6.6-5.4C29.6 35.2 26.9 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"
    />
    <path
      fill="#1976D2"
      d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.2 4.3-4.1 5.7l6.6 5.4C41.4 36.1 44 30.6 44 24c0-1.3-.1-2.7-.4-3.5z"
    />
  </svg>
);
