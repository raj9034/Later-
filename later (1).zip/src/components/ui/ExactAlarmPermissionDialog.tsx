import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlarmClock, X } from 'lucide-react';

interface ExactAlarmPermissionDialogProps {
  isOpen: boolean;
  onConfirm: () => void;
  onDismiss: () => void;
}

/**
 * A real, styled in-app dialog for the Android 14+ exact-alarm permission
 * ask. This replaces a raw window.confirm() call, which renders
 * unreliably (or not at all) across different manufacturers' WebView
 * implementations — the root cause of reminders silently never firing on
 * some real devices even after the user believed they'd granted
 * permission. Shown contextually (the first time a user actually sets a
 * reminder) rather than blindly on cold app launch, so the ask makes
 * sense to a first-time user instead of appearing out of nowhere.
 */
export const ExactAlarmPermissionDialog: React.FC<ExactAlarmPermissionDialogProps> = ({
  isOpen,
  onConfirm,
  onDismiss,
}) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div
        id="exact-alarm-permission-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="exact-alarm-dialog-title"
        className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center p-4"
      >
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="absolute inset-0 bg-black/55 backdrop-blur-[2px]"
          onClick={onDismiss}
        />

        <motion.div
          initial={{ opacity: 0, y: 24, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 12, scale: 0.98 }}
          transition={{ duration: 0.22, ease: [0, 0, 0.2, 1] }}
          className="relative w-full max-w-sm rounded-3xl bg-[var(--surface-elevated)] border border-[var(--border)] shadow-2xl p-6 flex flex-col gap-4"
        >
          <button
            id="exact-alarm-dialog-close-btn"
            type="button"
            onClick={onDismiss}
            className="absolute top-4 right-4 p-1.5 rounded-full text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
            aria-label="Not now"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="w-11 h-11 rounded-2xl glass-icon-square flex items-center justify-center text-[var(--accent)]">
            <AlarmClock className="w-5 h-5" />
          </div>

          <div className="space-y-1.5 pr-4">
            <h2 id="exact-alarm-dialog-title" className="type-heading-lg text-[var(--text-primary)]">
              Get reminders exactly on time
            </h2>
            <p className="type-body-sm text-[var(--text-secondary)] leading-relaxed">
              Android needs one extra permission to deliver reminders at the
              exact minute you set — otherwise your phone may delay them by
              several minutes to save battery. This takes a few seconds in
              Settings.
            </p>
          </div>

          <div className="flex items-center gap-2.5 pt-1">
            <button
              id="exact-alarm-dialog-dismiss-btn"
              type="button"
              onClick={onDismiss}
              className="flex-1 px-4 py-2.5 rounded-2xl bg-[var(--surface)] border border-[var(--border)] text-[var(--text-primary)] type-button hover:bg-[var(--surface-sunken)] active:scale-[0.98] press-interactive transition-all cursor-pointer"
            >
              Not now
            </button>
            <button
              id="exact-alarm-dialog-confirm-btn"
              type="button"
              onClick={onConfirm}
              className="flex-1 px-4 py-2.5 rounded-2xl bg-[var(--accent)] text-[var(--bg)] type-button font-semibold active:scale-[0.98] press-interactive transition-all cursor-pointer shadow-sm"
            >
              Enable in Settings
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
