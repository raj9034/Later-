import React from 'react';
import { SavedItem } from '../types';
import { useLater } from '../context/LaterContext';
import {
  Play,
  Camera,
  MapPin,
  Phone,
  ExternalLink,
  FileText,
  Flame,
  Star,
  Leaf,
  MoreVertical,
} from 'lucide-react';

interface ScheduleTimelineRowProps {
  item: SavedItem;
  /** Whether to show the time-of-day label + dot on the left rail. The
      reference only shows this in Today/Upcoming's per-item rows, not in
      every context, but here it's always true since Schedule always has
      a concrete time (it only lists scheduledItems). */
  showTimeLabel?: boolean;
  /** Whether this is the last row in its group — suppresses the
      connecting rail line below the dot so it doesn't dangle past the
      final item. */
  isLast?: boolean;
}

const renderTypeIcon = (type: string) => {
  switch (type) {
    case 'video':
      return <Play className="w-4 h-4 fill-current" />;
    case 'screenshot':
    case 'image':
      return <Camera className="w-4 h-4" />;
    case 'place':
      return <MapPin className="w-4 h-4" />;
    case 'person':
    case 'phone_number':
      return <Phone className="w-4 h-4" />;
    case 'link':
    case 'article':
    case 'product':
      return <ExternalLink className="w-4 h-4" />;
    default:
      return <FileText className="w-4 h-4" />;
  }
};

// Icon-chip background/color per content type, cloned from the reference
// (pink-red for calls, warm gold for documents, blue for links, green for
// video, purple for task-like items with no tag).
const getIconChipStyle = (type: string, hasUrgentTag: boolean, hasImportantTag: boolean) => {
  if (hasUrgentTag) return { bg: '#FDF1EF', color: '#D64545' };
  if (hasImportantTag) return { bg: 'var(--gold-soft)', color: '#A6740F' };
  switch (type) {
    case 'phone_number':
    case 'person':
      return { bg: '#FDF1EF', color: '#D64545' };
    case 'video':
      return { bg: 'var(--sage-soft)', color: 'var(--accent-deep)' };
    case 'link':
    case 'article':
    case 'product':
      return { bg: '#EEF1F7', color: '#3D5A80' };
    default:
      return { bg: 'var(--gold-soft)', color: '#A6740F' };
  }
};

const getTagPill = (tag: string | undefined) => {
  if (tag === 'urgent') {
    return { label: 'Priority', icon: Flame, bg: '#FDF1EF', color: '#D64545' };
  }
  if (tag === 'important') {
    return { label: 'Important', icon: Star, bg: 'var(--gold-soft)', color: '#A6740F' };
  }
  if (tag === 'chill') {
    return { label: 'Chill', icon: Leaf, bg: 'var(--sage-soft)', color: 'var(--accent-deep)' };
  }
  return null;
};

/**
 * Schedule-specific timeline row — a left time-rail (clock time + colored
 * dot + connecting line) alongside a compact card (icon chip, optional
 * tag pill, title, subtitle, menu, checkbox). This is a dedicated
 * component rather than reusing the general-purpose MemoryCard, since the
 * reference's Schedule layout is visually distinct enough (the rail, the
 * simpler single-line card) that forcing MemoryCard into this shape would
 * risk destabilizing its other use on the Home feed.
 */
export const ScheduleTimelineRow: React.FC<ScheduleTimelineRowProps> = ({
  item,
  showTimeLabel = true,
  isLast = false,
}) => {
  const { setSelectedItem, toggleDone } = useLater();

  const rawTime = item.reminderTime || item.scheduledFor;
  const timeLabel = rawTime
    ? new Date(rawTime).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
    : '';

  const contentType = item.contentType || item.type || 'note';
  const tag = item.urgencyTag || item.urgency;
  const tagPill = getTagPill(tag);
  const chipStyle = getIconChipStyle(contentType, tag === 'urgent', tag === 'important');

  const subtitleText = rawTime
    ? `Waiting recall · ${new Date(rawTime).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}, ${timeLabel}`
    : 'Waiting recall';

  return (
    <div className="flex items-stretch gap-3">
      {/* Time rail */}
      {showTimeLabel && (
        <div className="flex flex-col items-center w-14 shrink-0 pt-3.5">
          <span className="type-caption text-[var(--text-tertiary)] text-[11px] font-medium whitespace-nowrap">
            {timeLabel}
          </span>
          <span
            className="w-2 h-2 rounded-full mt-1.5 shrink-0"
            style={{ backgroundColor: tag === 'urgent' ? '#D64545' : 'var(--accent-deep)' }}
          />
          {!isLast && <div className="w-px flex-1 bg-[var(--divider)] mt-1.5" />}
        </div>
      )}

      {/* Card — a div with a click handler (not a <button>) since it
          contains its own real <button> for the checkbox; nesting
          interactive elements is invalid HTML and can cause unreliable
          tap targeting in some WebViews. */}
      <div
        role="button"
        tabIndex={0}
        onClick={() => setSelectedItem(item)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') setSelectedItem(item);
        }}
        className="flex-1 min-w-0 mb-3 flex items-center gap-3 px-3.5 py-3 rounded-2xl bg-[var(--surface-elevated)] border border-[var(--border)] text-left cursor-pointer transition-transform active:scale-[0.99]"
        style={{ boxShadow: 'var(--elevation-1)' }}
      >
        <span
          className="w-10 h-10 rounded-full flex items-center justify-center shrink-0"
          style={{ backgroundColor: chipStyle.bg, color: chipStyle.color }}
        >
          {renderTypeIcon(contentType)}
        </span>

        <div className="flex-1 min-w-0">
          {tagPill && (
            <span
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full type-caption text-[10px] font-bold mb-1"
              style={{ backgroundColor: tagPill.bg, color: tagPill.color }}
            >
              <tagPill.icon className="w-2.5 h-2.5" />
              {tagPill.label}
            </span>
          )}
          <p className="type-body-sm font-semibold text-[var(--text-primary)] truncate">
            {item.title}
          </p>
          <p className="type-caption text-[var(--text-tertiary)] truncate mt-0.5">
            {subtitleText}
          </p>
        </div>

        <span className="text-[var(--text-tertiary)] shrink-0">
          <MoreVertical className="w-4 h-4" />
        </span>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            toggleDone(item.id);
          }}
          className="w-6 h-6 rounded-full border-2 border-[var(--border)] shrink-0 cursor-pointer hover:border-[var(--accent)] transition-colors"
          aria-label="Mark done"
        />
      </div>
    </div>
  );
};
