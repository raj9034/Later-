import React, { useState, useEffect } from 'react';
import { useLater } from '../context/LaterContext';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { Calendar, Layers, Search, UserPlus, User as UserIcon, Sun, Moon } from 'lucide-react';
import { AccountMenu } from './AccountMenu';

interface HeaderProps {
  onOpenSearch?: () => void;
  onOpenHelp?: () => void;
  onOpenOnboarding?: () => void;
  onReplayTour?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSearch,
  onOpenHelp,
  onOpenOnboarding,
  onReplayTour,
}) => {
  const { items, viewMode, setViewMode, setIsSearchOpen } = useLater();
  const { user, setIsCreateAccountOpen } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [showOptions, setShowOptions] = useState(false);

  const activeCount = items.filter((i) => !i.isArchived && !i.isDone).length;

  const handleOpenSearch = () => {
    if (onOpenSearch) onOpenSearch();
    setIsSearchOpen(true);
  };

  // Keyboard shortcut listener (Cmd+K or Ctrl+K or /)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in an input or textarea
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA'
      ) {
        return;
      }

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        handleOpenSearch();
      } else if (e.key === '/' && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        handleOpenSearch();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <header className={`sticky top-0 ${showOptions ? 'z-50' : 'z-30'} bg-[var(--surface)]/80 backdrop-blur-xl border-b border-[var(--divider)] h-14 px-4 sm:px-6 flex items-center transition-colors duration-200`}>
      <div className="w-full max-w-xl mx-auto flex items-center justify-between">
        {/* Left: Brand + Subtle status */}
        <div className="flex items-baseline gap-2.5">
          <h1 className="type-heading font-bold text-[var(--text-primary)] tracking-tight">
            Later
          </h1>
          <span className="type-caption text-[var(--text-secondary)]">
            {activeCount === 0 ? 'empty' : `${activeCount} in memory`}
          </span>
        </div>

        {/* Right: Search, View mode toggle, Theme toggle & Auth / reset */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Universal Recall Search Button with 2:1 button ratio */}
          <button
            id="header-recall-search-btn"
            type="button"
            onClick={handleOpenSearch}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl type-body-sm font-semibold bg-[var(--surface)] text-[var(--text-primary)] hover:bg-[var(--surface-elevated)] border border-[var(--border)] transition-all active:scale-[0.98] cursor-pointer outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent)]"
            title="Recall Search (⌘K or /)"
            aria-label="Open Recall Search"
          >
            <Search className="w-3.5 h-3.5 text-[var(--text-secondary)] shrink-0" />
            <span className="hidden xs:inline whitespace-nowrap">Search</span>
          </button>

          {/* View Mode Toggle with 2:1 ratio */}
          <button
            id="header-view-mode-toggle-btn"
            type="button"
            onClick={() => setViewMode(viewMode === 'grouped' ? 'schedule' : 'grouped')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-2xl type-body-sm font-semibold transition-all active:scale-[0.98] cursor-pointer border outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent)] ${
              viewMode === 'schedule'
                ? 'bg-[var(--surface-elevated)] text-[var(--text-primary)] border-[var(--border)]'
                : 'bg-[var(--surface)] text-[var(--text-secondary)] border-[var(--border)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-elevated)]'
            }`}
            title={viewMode === 'grouped' ? 'Switch to Schedule view' : 'Switch to Memory Timeline'}
            aria-label={viewMode === 'grouped' ? 'Switch to Schedule view' : 'Switch to Memory Timeline'}
          >
            {viewMode === 'grouped' ? (
              <>
                <Calendar className="w-3.5 h-3.5 text-[var(--text-secondary)] shrink-0" />
                <span className="hidden xs:inline whitespace-nowrap">Schedule</span>
              </>
            ) : (
              <>
                <Layers className="w-3.5 h-3.5 text-[var(--text-secondary)] shrink-0" />
                <span className="hidden xs:inline whitespace-nowrap">Timeline</span>
              </>
            )}
          </button>

          {/* Theme Toggle Button with cross-fade & 15deg rotation */}
          <button
            id="header-theme-toggle-btn"
            type="button"
            onClick={toggleTheme}
            className="p-2 sm:px-3 sm:py-1.5 rounded-2xl type-body-sm font-medium bg-[var(--surface)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-elevated)] border border-[var(--border)] transition-all duration-[var(--duration-fast)] ease-[var(--ease-standard)] active:scale-[0.97] press-interactive cursor-pointer flex items-center justify-center outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent)] relative overflow-hidden"
            title={theme === 'light' ? 'Current: Light Mode (Soft Cloud) — Click for Dark Mode' : 'Current: Dark Mode (Dark Luxury) — Click for Light Mode'}
            aria-label="Toggle color theme"
          >
            <div className="relative w-4 h-4 flex items-center justify-center">
              <Sun
                className={`w-3.5 h-3.5 text-[var(--accent-gold)] absolute inset-0 m-auto transition-all duration-[var(--duration-base)] ease-[var(--ease-standard)] ${
                  theme === 'light'
                    ? 'opacity-100 rotate-0 scale-100'
                    : 'opacity-0 rotate-[15deg] scale-75 pointer-events-none'
                }`}
              />
              <Moon
                className={`w-3.5 h-3.5 text-[var(--accent)] absolute inset-0 m-auto transition-all duration-[var(--duration-base)] ease-[var(--ease-standard)] ${
                  theme === 'dark'
                    ? 'opacity-100 rotate-0 scale-100'
                    : 'opacity-0 -rotate-[15deg] scale-75 pointer-events-none'
                }`}
              />
            </div>
          </button>

          {/* Create Account / Auth Trigger */}
          {!user ? (
            <button
              id="header-create-account-btn"
              type="button"
              onClick={() => setIsCreateAccountOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl type-body-sm font-semibold bg-[var(--surface-elevated)] hover:bg-[var(--surface)] text-[var(--text-primary)] border border-[var(--border)] transition-all active:scale-[0.98] cursor-pointer outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent)]"
              title="Create Account"
              aria-label="Create Account"
            >
              <UserPlus className="w-3.5 h-3.5 text-[var(--accent)] shrink-0" />
              <span className="hidden sm:inline whitespace-nowrap">Sign up</span>
            </button>
          ) : (
            <button
              id="header-user-badge-btn"
              type="button"
              onClick={() => setShowOptions(!showOptions)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl type-caption bg-[var(--surface)] border border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--surface-elevated)] transition-colors cursor-pointer max-w-[130px] truncate outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent)]"
              title={`Signed in as ${user.email}`}
              aria-label={`Signed in as ${user.email}`}
            >
              <UserIcon className="w-3.5 h-3.5 text-[var(--success)] shrink-0" />
              <span className="truncate">{user.email?.split('@')[0]}</span>
            </button>
          )}

          {/* Person-icon Options / Account Button with anchored floating panel & tap-outside scrim */}
          <div className="relative">
            <button
              id="header-options-btn"
              type="button"
              onClick={() => setShowOptions(!showOptions)}
              className={`w-8 h-8 flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-2xl border border-[var(--border)] bg-[var(--surface)] hover:bg-[var(--surface-elevated)] transition-all duration-[var(--duration-fast)] ease-[var(--ease-standard)] cursor-pointer active:scale-[0.96] press-interactive outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent)] ${
                showOptions ? 'ring-2 ring-[var(--accent)] bg-[var(--surface-elevated)] text-[var(--text-primary)]' : ''
              }`}
              title="Account & Settings"
              aria-label="Account and Settings"
            >
              <UserIcon className="w-4 h-4" />
            </button>

            {/* Account dropdown menu floating panel */}
            <AccountMenu
              isOpen={showOptions}
              onClose={() => setShowOptions(false)}
              onOpenHelp={onOpenHelp}
              onReplayTour={onReplayTour}
            />
          </div>
        </div>
      </div>
    </header>
  );
};


