import React, { useEffect } from 'react';
import { Search, Plus, Menu } from 'lucide-react';
import { useLater } from '../context/LaterContext';
import { useAuth } from '../context/AuthContext';

interface HeaderProps {
  activeTab?: 'home' | 'schedule' | 'collections' | 'profile';
  onOpenSearch?: () => void;
  onOpenHelp?: () => void;
  onOpenOnboarding?: () => void;
  onReplayTour?: () => void;
  onOpenProfile?: () => void;
  onGoToCapture?: () => void;
  onOpenMenu?: () => void;
}

const TAGLINES: Record<string, string> = {
  home: 'A calmer mind for a brighter you.',
  schedule: 'Your upcoming things, at the right time.',
  profile: 'A calmer mind for a brighter you.',
};

/**
 * Top header — brand identity, a tagline that adapts per tab (matching
 * the reference's Schedule-specific copy), quick search access, and
 * either the signed-in person's avatar (Home/Profile) or a quick-add
 * button (Schedule — routes to Home's real capture bar rather than
 * duplicating a second capture mechanism, since only one actually
 * exists). No notification bell: there's no notification inbox/center
 * built in this app, so a bell icon here would be decorative chrome with
 * nothing behind it — left out rather than faked.
 */
export const Header: React.FC<HeaderProps> = ({
  activeTab = 'home',
  onOpenSearch,
  onOpenProfile,
  onGoToCapture,
  onOpenMenu,
}) => {
  const { setIsSearchOpen } = useLater();
  const { user } = useAuth();

  const handleOpenSearch = () => {
    if (onOpenSearch) onOpenSearch();
    setIsSearchOpen(true);
  };

  const displayName = user?.displayName?.trim();
  const photoURL = user?.photoURL;
  const avatarInitial = (displayName?.[0] || user?.email?.[0] || '?').toUpperCase();
  const tagline = TAGLINES[activeTab] || TAGLINES.home;

  // Keyboard shortcut listener (Cmd+K or Ctrl+K or /) — preserved from the
  // previous header implementation; still the fastest way to search on a
  // physical keyboard even though Search also lives in the bottom nav.
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA'
      ) {
        return;
      }

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        handleOpenSearch();
      } else if (e.key === '/' && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        handleOpenSearch();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <header
      className="sticky top-0 z-30 bg-[var(--surface)]/90 backdrop-blur-xl border-b border-[var(--divider)] px-4 sm:px-6 flex items-center transition-colors duration-200"
      style={{
        paddingTop: 'calc(12px + env(safe-area-inset-top, 0px))',
        paddingBottom: '12px',
        minHeight: 'var(--header-h)',
      }}
    >
      <div className="w-full max-w-xl mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          {onOpenMenu && (
            <button
              type="button"
              onClick={onOpenMenu}
              className="w-9 h-9 shrink-0 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors cursor-pointer"
              aria-label="Open menu"
            >
              <Menu className="w-4.5 h-4.5" />
            </button>
          )}
          <div className="min-w-0">
            <h1 className="font-onboarding-serif text-[22px] font-semibold text-[var(--text-primary)] tracking-tight leading-none">
              Later
            </h1>
            <p className="type-caption text-[var(--text-secondary)] mt-1 truncate">
              {tagline}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleOpenSearch}
            className="w-9 h-9 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors cursor-pointer"
            aria-label="Search"
          >
            <Search className="w-4 h-4" />
          </button>

          {activeTab === 'schedule' ? (
            <button
              type="button"
              onClick={onGoToCapture}
              className="w-9 h-9 rounded-full bg-[var(--accent)] flex items-center justify-center text-[var(--bg)] cursor-pointer active:scale-95 transition-transform"
              aria-label="Add a reminder"
              title="Add a reminder"
            >
              <Plus className="w-4.5 h-4.5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={onOpenProfile}
              className="w-9 h-9 rounded-full overflow-hidden shrink-0 cursor-pointer"
              aria-label="Profile"
            >
              {photoURL ? (
                <img src={photoURL} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-[var(--accent)] flex items-center justify-center text-[var(--bg)] font-display font-bold text-sm">
                  {avatarInitial}
                </div>
              )}
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
