import { useEffect, useRef } from 'react';
import { waitForPendingWrites } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { AuthProvider, useAuth } from '../../context/AuthContext';
import { LaterProvider, useLater } from '../../context/LaterContext';
import { TagProvider } from '../../context/TagContext';
import { CollectionProvider } from '../../context/CollectionContext';
import { QuickCapture } from '../../lib/quickCapture';
import {
  syncAllNativeNotifications,
  cancelNativeNotification,
  setNativeSyncAdditiveOnly,
} from '../../utils/nativeNotifications';

/**
 * QUICK CAPTURE — HEADLESS ENTRY POINT.
 *
 * This mounts the SAME, UNMODIFIED provider tree the real app uses
 * (AuthProvider → LaterProvider → TagProvider → CollectionProvider) and
 * calls the exact same `saveItem()` the in-app capture UI calls. It
 * renders nothing — no screens, no navigation, no visual output at all.
 *
 * Hosting context: this page is loaded by HeadlessCaptureActivity.java
 * — a real Capacitor BridgeActivity (so it has the genuine bridge, same
 * https://localhost origin, same shared IndexedDB/Firebase session as
 * the main app), just themed to never render a visible frame.
 *
 * WHY THIS IS SHAPED THE WAY IT IS (three real-device bugs, in order):
 *
 * 1. It used to call the full-RECONCILE syncAllNativeNotifications()
 *    with whatever `items` the page could see the instant the new item
 *    landed. Here that is NOT the user's real list: this is a brand-new
 *    WebView, so `items` is local guest storage plus the one new item —
 *    Firestore has not delivered anything yet. A reconcile treats its
 *    input as the complete truth and cancels every pending alarm not in
 *    it, so every capture silently cancelled all the user's OTHER
 *    reminders (including the previous Quick Capture reminder).
 *    Reproduced against the real function with a fake alarm store.
 *    Fixed two ways: (a) this page switches the scheduler to
 *    additive-only mode for its whole lifetime, so nothing in here —
 *    including LaterContext's own reconcile effect — can ever cancel an
 *    alarm it doesn't own, and (b) the capture schedules just its own
 *    new item.
 *
 * 2. "Saved" used to be reported the moment the item appeared in local
 *    React state. Firestore here uses the default in-memory cache (no
 *    offline persistence), and this WebView is destroyed right after we
 *    report — so a write that hadn't reached the server yet was simply
 *    lost with it. We now wait for Firestore to acknowledge the write
 *    (waitForPendingWrites) and report FAILURE if it doesn't within a
 *    bounded time, so the user gets the honest clipboard-fallback state
 *    instead of a false "Saved ✓".
 *
 * 3. Earlier versions inferred "settled" from `isSyncing` and then from
 *    comparing `items.length` to a count taken before the first
 *    Firestore snapshot. Neither is a real signal. This version doesn't
 *    infer anything: saveItem() returns the created item, and we act on
 *    that object directly.
 *
 * Loaded only when main.tsx detects the headless marker (see main.tsx).
 * Never reachable through normal in-app navigation.
 */

// How long we wait for the server to acknowledge the write before
// declaring failure. Must stay comfortably below the native activity's
// own 15s safety timeout (HeadlessCaptureActivity.SAFETY_TIMEOUT_MS).
const WRITE_ACK_TIMEOUT_MS = 9000;

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('timeout')), ms);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      }
    );
  });
}

function HeadlessCaptureInner({ text }: { text: string }) {
  const { user, loading: authLoading } = useAuth();
  const { saveItem } = useLater();
  const hasStartedRef = useRef(false);

  useEffect(() => {
    if (authLoading || hasStartedRef.current) return;
    hasStartedRef.current = true;

    // No signed-in user after auth has resolved: there is no guest
    // headless save path, same as the rest of the app.
    if (!user) {
      QuickCapture.reportResult({ success: false, error: 'not_signed_in', text });
      return;
    }

    (async () => {
      let saved: ReturnType<typeof saveItem>;
      try {
        saved = saveItem(text);
      } catch (e) {
        QuickCapture.reportResult({ success: false, error: String(e), text });
        return;
      }

      // Local alarm scheduling and the server acknowledgement are
      // independent, so run them together rather than back to back.
      const scheduling = syncAllNativeNotifications([saved], { additiveOnly: true }).catch(() => {
        // syncAllNativeNotifications already swallows and logs its own
        // errors; this is just belt-and-braces so it can never reject.
      });
      const acknowledged = withTimeout(waitForPendingWrites(db), WRITE_ACK_TIMEOUT_MS).then(
        () => true,
        () => false
      );

      const [, wasAcknowledged] = await Promise.all([scheduling, acknowledged]);

      if (wasAcknowledged) {
        QuickCapture.reportResult({ success: true, text });
      } else {
        // The write never reached the server and this WebView is about
        // to be destroyed, taking the in-memory copy with it. Don't
        // leave an alarm behind for an item that won't exist.
        await cancelNativeNotification(saved.id);
        QuickCapture.reportResult({ success: false, error: 'write_not_acknowledged', text });
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authLoading, user]);

  return null; // zero visual output, by design
}

export default function HeadlessCaptureRoot({ text }: { text: string }) {
  // Runs synchronously during the first render, before any child effect
  // (including LaterContext's own reconcile effect) can fire. Only ever
  // rendered on the headless page, so this can't leak into the main app.
  setNativeSyncAdditiveOnly(true);

  return (
    <AuthProvider>
      <LaterProvider>
        <TagProvider>
          <CollectionProvider>
            <HeadlessCaptureInner text={text} />
          </CollectionProvider>
        </TagProvider>
      </LaterProvider>
    </AuthProvider>
  );
}
