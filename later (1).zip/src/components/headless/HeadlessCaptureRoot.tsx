import { useEffect, useRef, useState } from 'react';
import { AuthProvider, useAuth } from '../../context/AuthContext';
import { LaterProvider, useLater } from '../../context/LaterContext';
import { TagProvider } from '../../context/TagContext';
import { CollectionProvider } from '../../context/CollectionContext';
import { QuickCapture } from '../../lib/quickCapture';
import { syncAllNativeNotifications } from '../../utils/nativeNotifications';

/**
 * QUICK CAPTURE — HEADLESS ENTRY POINT.
 *
 * This mounts the SAME, UNMODIFIED provider tree the real app uses
 * (AuthProvider → LaterProvider → TagProvider → CollectionProvider) and
 * calls the exact same `saveItem()` the in-app capture UI calls. It
 * renders nothing — no screens, no navigation, no visual output at all.
 *
 * Why this exists instead of extracting saveItem into a plain function:
 * saveItem() doesn't write to Firestore directly — it updates React
 * state, and a separate `useEffect` inside LaterProvider reacts to that
 * state change to do the actual sync. Re-implementing that as a
 * standalone function would mean duplicating a reactive pipeline that
 * already works correctly. Mounting the real provider tree means zero
 * new persistence logic exists anywhere — this is reuse, not a second
 * system.
 *
 * Hosting context: this page is loaded by HeadlessCaptureActivity.java
 * — a real Capacitor BridgeActivity (so it has the genuine bridge, same
 * https://localhost origin, same shared IndexedDB/Firebase session as
 * the main app), just themed to never render a visible frame. Because
 * it's a real bridge, the standard `QuickCapture` Capacitor plugin
 * works normally here — same call as the live/foregrounded path uses.
 *
 * IMPORTANT (fixed after a real-device bug report): this used to decide
 * "safe to close" by watching LaterContext's `isSyncing` flag. That flag
 * is misleadingly named for this purpose — it's only ever set around
 * the *initial* Firestore subscription bootstrap, not around individual
 * writes, so it could flip false almost immediately after mount,
 * unrelated to whether our new item's write (and the SEPARATE,
 * fire-and-forget `syncAllNativeNotifications` call LaterContext makes
 * once the item lands) had actually finished. In the long-lived main
 * app that fire-and-forget call is harmless — the process just stays
 * alive. Headless, closing early could kill it mid-flight, which is
 * exactly why reminders saved via Quick Capture were persisting
 * correctly but never scheduling their native alarm. Fixed by waiting
 * for the new item to actually appear in `items`, then explicitly
 * calling the same, already-exported `syncAllNativeNotifications`
 * again ourselves, awaited — idempotent (it reconciles desired vs.
 * pending alarms), so calling it a second time is always safe, and it's
 * still the one real scheduling function, not a second one.
 *
 * Loaded only when main.tsx detects the headless marker (see
 * main.tsx). Never reachable through normal in-app navigation.
 */

type Status = 'waiting-auth' | 'saving' | 'awaiting-item' | 'scheduling' | 'done' | 'error';

function HeadlessCaptureInner({ text }: { text: string }) {
  const { user, loading: authLoading } = useAuth();
  const { saveItem, items } = useLater();
  const [status, setStatus] = useState<Status>('waiting-auth');
  const hasSavedRef = useRef(false);
  const countBeforeSaveRef = useRef<number | null>(null);
  const startedAtRef = useRef<number>(Date.now());

  // Step 1: wait for auth to resolve. If there's genuinely no signed-in
  // user after auth finishes loading, report failure — there is no
  // "guest headless save" path, same as the rest of the app.
  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      QuickCapture.reportResult({ success: false, error: 'not_signed_in', text });
      setStatus('error');
      return;
    }
    if (!hasSavedRef.current) {
      hasSavedRef.current = true;
      countBeforeSaveRef.current = items.length;
      try {
        saveItem(text);
        setStatus('awaiting-item');
      } catch (e) {
        QuickCapture.reportResult({ success: false, error: String(e), text });
        setStatus('error');
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authLoading, user]);

  // Step 2: wait for the new item to actually show up in `items` — this
  // is the real, direct signal that saveItem()'s update landed, rather
  // than a proxy flag borrowed from an unrelated part of the context.
  // Once it has, explicitly (and safely — idempotent) run the same
  // native-notification reconciliation LaterContext's own effect
  // fires, and AWAIT it here, so the headless Activity cannot report
  // success/close until scheduling has genuinely finished.
  useEffect(() => {
    if (status !== 'awaiting-item') return;
    if (countBeforeSaveRef.current === null) return;

    const timedOutHardStop = Date.now() - startedAtRef.current > 12000; // don't hang forever headless
    if (items.length <= countBeforeSaveRef.current && !timedOutHardStop) {
      return; // new item hasn't landed yet — effect re-runs as `items` changes
    }

    setStatus('scheduling');
    (async () => {
      try {
        await syncAllNativeNotifications(items);
      } catch {
        // Scheduling failure shouldn't fail the whole capture — the
        // memory itself is already saved either way, same as the
        // in-app path's own fire-and-forget tolerance for this call.
      }
      QuickCapture.reportResult({ success: true, text, timedOut: timedOutHardStop });
      setStatus('done');
    })();
  }, [status, items, text]);

  return null; // zero visual output, by design
}

export default function HeadlessCaptureRoot({ text }: { text: string }) {
  return (
    <AuthProvider>
      <LaterProvider>
        <TagProvider>
          <CollectionProvider>
            <HeadlessCaptureInner text={text} />
          </CollectionProvider>
        </TagProvider>
      </LaterProvider>
    </AuthProvider>
  );
}
