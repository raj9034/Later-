import { useEffect, useRef, useState } from 'react';
import { AuthProvider, useAuth } from '../../context/AuthContext';
import { LaterProvider, useLater } from '../../context/LaterContext';
import { TagProvider } from '../../context/TagContext';
import { CollectionProvider } from '../../context/CollectionContext';
import { QuickCapture } from '../../lib/quickCapture';

/**
 * QUICK CAPTURE — HEADLESS ENTRY POINT.
 *
 * This mounts the SAME, UNMODIFIED provider tree the real app uses
 * (AuthProvider → LaterProvider → TagProvider → CollectionProvider) and
 * calls the exact same `saveItem()` the in-app capture UI calls. It
 * renders nothing — no screens, no navigation, no visual output at all.
 *
 * Why this exists instead of extracting saveItem into a plain function:
 * saveItem() doesn't write to Firestore directly — it updates React
 * state, and a separate `useEffect` inside LaterProvider reacts to that
 * state change to do the actual sync. Re-implementing that as a
 * standalone function would mean duplicating a reactive pipeline that
 * already works correctly. Mounting the real provider tree means zero
 * new persistence logic exists anywhere — this is reuse, not a second
 * system.
 *
 * Hosting context: this page is loaded by HeadlessCaptureActivity.java
 * — a real Capacitor BridgeActivity (so it has the genuine bridge, same
 * https://localhost origin, same shared IndexedDB/Firebase session as
 * the main app), just themed Theme.Translucent.NoDisplay so it never
 * renders a visible frame. Because it's a real bridge, the standard
 * `QuickCapture` Capacitor plugin works normally here — same call as
 * the live/foregrounded path uses.
 *
 * Loaded only when main.tsx detects the headless marker (see
 * main.tsx). Never reachable through normal in-app navigation.
 */

type Status = 'waiting-auth' | 'saving' | 'confirming-sync' | 'done' | 'error';

function HeadlessCaptureInner({ text }: { text: string }) {
  const { user, loading: authLoading } = useAuth();
  const { saveItem, isSyncing } = useLater();
  const [status, setStatus] = useState<Status>('waiting-auth');
  const hasSavedRef = useRef(false);
  const savedAtRef = useRef<number | null>(null);

  // Step 1: wait for auth to resolve. If there's genuinely no signed-in
  // user after auth finishes loading, report failure — there is no
  // "guest headless save" path, same as the rest of the app.
  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      QuickCapture.reportResult({ success: false, error: 'not_signed_in', text });
      setStatus('error');
      return;
    }
    if (!hasSavedRef.current) {
      hasSavedRef.current = true;
      try {
        saveItem(text);
        savedAtRef.current = Date.now();
        setStatus('confirming-sync');
      } catch (e) {
        QuickCapture.reportResult({ success: false, error: String(e), text });
        setStatus('error');
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authLoading, user]);

  // Step 2: saveItem() already updated local state + localStorage
  // synchronously (that part never fails). The remaining question is
  // just whether the Firestore sync attempt finished, so we can tell
  // native it's safe to tear this WebView down. We don't block success
  // on network sync succeeding — same as the in-app UI, a local save is
  // already durable and shows in the app next time it's opened; we
  // only wait for the *attempt* to settle so we're not killed mid-write.
  useEffect(() => {
    if (status !== 'confirming-sync') return;
    if (!savedAtRef.current) return;

    // isSyncing flips true then false around the write attempt. Poll
    // briefly rather than relying on a single effect firing, since the
    // flip can happen faster than a render.
    const start = Date.now();
    const interval = window.setInterval(() => {
      const settledByFlag = !isSyncing && Date.now() - savedAtRef.current! > 400;
      const timedOut = Date.now() - start > 8000; // don't hang forever headless
      if (settledByFlag || timedOut) {
        window.clearInterval(interval);
        QuickCapture.reportResult({ success: true, text, timedOut });
        setStatus('done');
      }
    }, 150);
    return () => window.clearInterval(interval);
  }, [status, isSyncing]);

  return null; // zero visual output, by design
}

export default function HeadlessCaptureRoot({ text }: { text: string }) {
  return (
    <AuthProvider>
      <LaterProvider>
        <TagProvider>
          <CollectionProvider>
            <HeadlessCaptureInner text={text} />
          </CollectionProvider>
        </TagProvider>
      </LaterProvider>
    </AuthProvider>
  );
}
