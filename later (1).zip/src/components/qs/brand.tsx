import React from 'react';

/**
 * The return mark: a thread that travels down and turns back toward a point.
 * Two offset strokes — the ink line and a short amber return stroke. No leaf,
 * no circle, no orb. It is always paired with text wherever it carries meaning.
 */
export const ReturnMark: React.FC<{ size?: number; className?: string; title?: string }> = ({ size = 22, className = '', title }) => (
  <svg
    className={`qs-mark ${className}`} width={size} height={size} viewBox="0 0 24 24" fill="none"
    role={title ? 'img' : undefined} aria-hidden={title ? undefined : true} aria-label={title}
  >
    <path d="M6 3.5v10.2a3.8 3.8 0 0 0 3.8 3.8H15" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
    <path className="qs-mark__thread" d="M12.6 14.2 16 17.5l-3.4 3.3" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const Wordmark: React.FC = () => (
  <span className="qs-brand" aria-label="Later">
    <ReturnMark size={24} />
    <span className="qs-brand__word">Later</span>
  </span>
);
