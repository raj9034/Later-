import React, { useEffect, useState } from 'react';
import { Archive, Bookmark, CalendarClock, Check, Clock, MapPin, Plus, Tag as TagIcon, Trash2, User, Hash, FolderPlus, RotateCcw, ExternalLink, Copy } from 'lucide-react';
import { useLater } from '../../context/LaterContext';
import { useTags } from '../../context/TagContext';
import { useCollections } from '../../context/CollectionContext';
import { SavedItem, UrgencyTag } from '../../types';
import { describeReturn, getClarification, getInterpretationChips, getProvenance, isActionMemory, typeLabel } from '../../utils/memoryView';
import { TagPickerSheet } from '../sidebar/TagScreens';
import { CollectionPickerSheet } from '../collections/CollectionScreens';
import { Sheet } from './sheet';
import { Chip, Notice } from './parts';
import { ReturnMark } from './brand';
import { useMemoryActions, useMemoryUi } from './memoryUi';
import { useFeedback } from './feedback';

const URGENCY: { key: UrgencyTag | null; label: string }[] = [
  { key: null, label: 'None' }, { key: 'urgent', label: 'Priority' }, { key: 'important', label: 'Important' }, { key: 'chill', label: 'Chill' },
];

type AddKind = 'people' | 'places' | 'topics';
const ADD_META: Record<AddKind, { label: string; icon: React.ReactNode }> = {
  people: { label: 'Person', icon: <User size={14} /> },
  places: { label: 'Place', icon: <MapPin size={14} /> },
  topics: { label: 'Topic', icon: <Hash size={14} /> },
};

/**
 * MemoryDetailSheet — capture → understood → returns.
 * The ORIGINAL capture is always shown first and stays editable as the source of
 * truth. Everything Later inferred is shown as editable chips/rows (not opaque
 * output); correcting an interpretation never touches the raw text.
 */
export const MemoryDetailSheet: React.FC = () => {
  const L = useLater();
  const item = L.selectedItem;
  const close = () => L.setSelectedItem(null);
  return <Sheet open={!!item} onClose={close} title="Memory">{item && <Body key={item.id} item={item} />}</Sheet>;
};

const Body: React.FC<{ item: SavedItem }> = ({ item }) => {
  const L = useLater();
  const { tags: allTags, getTagById } = useTags();
  const { collections: allCollections } = useCollections();
  const actions = useMemoryActions();
  const ui = useMemoryUi();
  const { notify } = useFeedback();
  const now = new Date();

  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(item.rawInput || item.title || '');
  const [adding, setAdding] = useState<AddKind | null>(null);
  const [addText, setAddText] = useState('');
  const [confirmedTime, setConfirmedTime] = useState(false);
  const [tagPicker, setTagPicker] = useState(false);
  const [collPicker, setCollPicker] = useState(false);
  useEffect(() => { setDraft(item.rawInput || item.title || ''); }, [item.rawInput, item.title]);

  const ret = describeReturn(item, now);
  const chips = getInterpretationChips(item, now);
  const clar = !confirmedTime ? getClarification(item, now) : null;
  const tagObjs = (item.tagIds || []).map((id) => getTagById(id)).filter(Boolean);
  const collObjs = (item.collectionIds || []).map((id) => allCollections.find((c) => c.id === id)).filter(Boolean);
  const related = (item.relatedMemoryIds || []).map((id) => L.items.find((i) => i.id === id)).filter(Boolean) as SavedItem[];
  const hasTime = ret.kind === 'scheduled' || ret.kind === 'due';

  const saveDraft = () => {
    const t = draft.trim();
    if (!t) return;
    L.updateItemContent(item.id, { rawInput: t });
    setEditing(false);
    notify({ message: 'Original text updated.' });
  };
  const removeFrom = (kind: AddKind, value: string) => {
    const before = (item[kind] as string[] | undefined) || [];
    L.updateItemInterpretation(item.id, { [kind]: before.filter((v) => v !== value) });
    notify({ message: `Removed “${value}”.`, actionLabel: 'Undo', onAction: () => L.updateItemInterpretation(item.id, { [kind]: before }) });
  };
  const addTo = () => {
    if (!adding || !addText.trim()) return;
    const before = (item[adding] as string[] | undefined) || [];
    L.updateItemInterpretation(item.id, { [adding]: [...before, addText.trim()] });
    setAdding(null); setAddText('');
  };
  const copyText = async () => { try { await navigator.clipboard.writeText(item.rawInput || item.title || ''); notify({ message: 'Copied.' }); } catch { notify({ message: 'Couldn’t copy on this device.' }); } };

  return (
    <>
      <div className="qs-thread-steps">
        {/* 1 — the original capture */}
        <section className="qs-thread-step" aria-labelledby="qs-d-cap">
          <p className="qs-thread-step__label" id="qs-d-cap">Captured</p>
          {editing ? (
            <>
              <textarea className="qs-field" data-autofocus value={draft} onChange={(e) => setDraft(e.target.value)} aria-label="Original text" />
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="qs-btn qs-btn--primary" disabled={!draft.trim()} onClick={saveDraft}>Save</button>
                <button className="qs-btn qs-btn--secondary" onClick={() => { setEditing(false); setDraft(item.rawInput || item.title || ''); }}>Cancel</button>
              </div>
            </>
          ) : (
            <>
              <p className="qs-capture-original">{item.rawInput || item.title}</p>
              <p className="qs-meta">{getProvenance(item, now).join(' · ')}</p>
              <div className="qs-chips">
                <button className="qs-btn qs-btn--quiet" onClick={() => setEditing(true)}>Edit text</button>
                <button className="qs-btn qs-btn--quiet" onClick={copyText}><Copy size={16} />Copy</button>
                {item.url && <a className="qs-btn qs-btn--quiet" href={item.url} target="_blank" rel="noreferrer"><ExternalLink size={16} />Open link</a>}
              </div>
            </>
          )}
          {item.imageAttachment && <img src={item.imageAttachment} alt="Attached to this memory" style={{ maxWidth: '100%', borderRadius: 14, border: '1px solid var(--qs-line)' }} />}
        </section>

        {/* 2 — what Later understood, editable */}
        <section className="qs-thread-step" aria-labelledby="qs-d-und">
          <p className="qs-thread-step__label" id="qs-d-und">Understood as</p>
          <div className="qs-chips">
            {chips.map((c, i) => {
              if (c.kind === 'time') return <Chip key={i} kind="time" icon={<ReturnMark size={14} />} onClick={() => ui.openTime(item, 'choose')}>{c.label}</Chip>;
              if (c.kind === 'person') return <Chip key={i} kind="info" icon={<User size={14} />} onRemove={() => removeFrom('people', c.label)} removeLabel={`Remove person ${c.label}`}>{c.label}</Chip>;
              if (c.kind === 'place') return <Chip key={i} kind="info" icon={<MapPin size={14} />} onRemove={() => removeFrom('places', c.label)} removeLabel={`Remove place ${c.label}`}>{c.label}</Chip>;
              if (c.kind === 'topic') return <Chip key={i} kind="signal" icon={<Hash size={14} />} onRemove={() => removeFrom('topics', c.label)} removeLabel={`Remove topic ${c.label}`}>{c.label}</Chip>;
              return <Chip key={i} icon={c.kind === 'type' ? <Bookmark size={14} /> : undefined}>{c.label}</Chip>;
            })}
          </div>
          {adding ? (
            <div style={{ display: 'flex', gap: 8 }}>
              <input className="qs-field" data-autofocus value={addText} onChange={(e) => setAddText(e.target.value)} placeholder={`${ADD_META[adding].label} name`} aria-label={`Add ${ADD_META[adding].label.toLowerCase()}`} onKeyDown={(e) => { if (e.key === 'Enter') addTo(); }} />
              <button className="qs-btn qs-btn--primary" disabled={!addText.trim()} onClick={addTo}>Add</button>
            </div>
          ) : (
            <div className="qs-chips">
              {(Object.keys(ADD_META) as AddKind[]).map((k) => (
                <button key={k} className="qs-btn qs-btn--quiet" onClick={() => { setAdding(k); setAddText(''); }}><Plus size={15} />{ADD_META[k].label}</button>
              ))}
            </div>
          )}
          {clar && (
            <Notice tone="return" icon={<Clock size={18} />}>
              <p>{clar.question}</p>
              <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
                <button className="qs-btn qs-btn--secondary" onClick={() => setConfirmedTime(true)}>Yes, that’s right</button>
                <button className="qs-btn qs-btn--secondary" onClick={() => ui.openTime(item, 'choose')}>Change time</button>
              </div>
            </Notice>
          )}
        </section>

        {/* 3 — when it returns */}
        <section className="qs-thread-step" data-kind="return" aria-labelledby="qs-d-ret">
          <p className="qs-thread-step__label" id="qs-d-ret">Returns</p>
          <p className="qs-body" style={{ fontWeight: 600 }}>{ret.label}</p>
          <div className="qs-chips">
            <button className="qs-btn qs-btn--secondary" onClick={() => ui.openTime(item, 'choose')}><CalendarClock size={17} />{hasTime ? 'Change time' : 'Choose a time'}</button>
            {hasTime && !item.isDone && <button className="qs-btn qs-btn--secondary" onClick={() => ui.openTime(item, 'snooze')}><Clock size={17} />Snooze</button>}
            {hasTime && !item.isDone && <button className="qs-btn qs-btn--secondary" onClick={() => { actions.keep(item); }}><Bookmark size={17} />Keep for reference</button>}
          </div>
        </section>
      </div>

      {/* Optional organisation — never required */}
      <section className="qs-group" aria-labelledby="qs-d-org">
        <p className="qs-group__title" id="qs-d-org">Organize (optional)</p>
        <div className="qs-chips" role="group" aria-label="Priority">
          {URGENCY.map((u) => {
            const current = (item.urgencyTag || item.urgency || null) as UrgencyTag | null;
            return <Chip key={String(u.key)} selected={current === u.key} onClick={() => L.setItemUrgency(item.id, u.key)}>{u.label}</Chip>;
          })}
        </div>
        <div className="qs-chips">
          {tagObjs.map((t) => t && <Chip key={t.id} icon={<TagIcon size={14} />}>{t.name}</Chip>)}
          <button className="qs-btn qs-btn--quiet" onClick={() => setTagPicker(true)}><TagIcon size={16} />{tagObjs.length ? 'Edit tags' : 'Add tag'}{allTags.length === 0 ? '' : ''}</button>
          {collObjs.map((c) => c && <Chip key={c.id} icon={<FolderPlus size={14} />}>{c.name}</Chip>)}
          <button className="qs-btn qs-btn--quiet" onClick={() => setCollPicker(true)}><FolderPlus size={16} />{collObjs.length ? 'Edit collections' : 'Add to collection'}</button>
        </div>
      </section>

      {related.length > 0 && (
        <section className="qs-group" aria-labelledby="qs-d-rel">
          <p className="qs-group__title" id="qs-d-rel">Related memories</p>
          <div className="qs-menu">
            {related.slice(0, 4).map((r) => (
              <button key={r.id} className="qs-menu__item" onClick={() => L.setSelectedItem(r)}><span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.rawInput || r.title}</span><small>{typeLabel(r)}</small></button>
            ))}
          </div>
        </section>
      )}

      <div className="qs-menu" role="group" aria-label="More actions">
        {isActionMemory(item) && (
          <button className="qs-menu__item" onClick={() => actions.toggleDone(item)}>{item.isDone ? <RotateCcw size={20} /> : <Check size={20} />}<span>{item.isDone ? 'Mark as not done' : 'Mark done'}</span></button>
        )}
        <button className="qs-menu__item" onClick={() => { actions.archive(item); L.setSelectedItem(null); }}><Archive size={20} /><span>Archive</span></button>
        <button className="qs-menu__item" data-tone="danger" onClick={() => ui.askDelete(item)}><Trash2 size={20} /><span>Delete permanently…</span></button>
      </div>

      {tagPicker && <TagPickerSheet itemId={item.id} currentTagIds={item.tagIds || []} onClose={() => setTagPicker(false)} />}
      {collPicker && <CollectionPickerSheet itemId={item.id} currentCollectionIds={item.collectionIds || []} onClose={() => setCollPicker(false)} />}
    </>
  );
};
