import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { useLater } from '../../context/LaterContext';

export interface Notice { message: string; actionLabel?: string; onAction?: () => void; durationMs?: number; }
interface FeedbackApi { notify: (n: Notice) => void; }
const Ctx = createContext<FeedbackApi>({ notify: () => {} });
export const useFeedback = () => useContext(Ctx);

/**
 * One feedback surface for the whole app. Toasts are specific, brief and — where
 * something can be undone — carry the Undo action. Messages the existing context
 * still emits through showToast() are mirrored here so they use the same surface,
 * unless a richer (undoable) notice was just shown for the same action.
 */
export const FeedbackProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { toastMessage } = useLater();
  const [notice, setNotice] = useState<Notice | null>(null);
  const timer = useRef<number | null>(null);
  const lastActionAt = useRef(0);

  const clear = useCallback(() => { if (timer.current) window.clearTimeout(timer.current); timer.current = null; setNotice(null); }, []);
  const notify = useCallback((n: Notice) => {
    if (n.onAction) lastActionAt.current = Date.now();
    if (timer.current) window.clearTimeout(timer.current);
    setNotice(n);
    timer.current = window.setTimeout(clear, n.durationMs ?? (n.onAction ? 6500 : 4000));
  }, [clear]);

  useEffect(() => {
    if (!toastMessage) return;
    if (Date.now() - lastActionAt.current < 1200) return; // an undoable notice already covers this action
    notify({ message: toastMessage });
  }, [toastMessage, notify]);

  useEffect(() => () => { if (timer.current) window.clearTimeout(timer.current); }, []);

  return (
    <Ctx.Provider value={{ notify }}>
      {children}
      <div className="qs-toast" aria-live="polite" role="status">
        {notice && (
          <div className="qs-toast__body" key={notice.message}>
            <span>{notice.message}</span>
            {notice.onAction && (
              <button className="qs-toast__action" onClick={() => { notice.onAction?.(); clear(); }}>{notice.actionLabel || 'Undo'}</button>
            )}
          </div>
        )}
      </div>
    </Ctx.Provider>
  );
};
