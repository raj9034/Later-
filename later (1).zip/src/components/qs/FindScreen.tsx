import React, { useMemo, useState } from 'react';
import { Search, X, Clock, History, Sparkles, ArrowRight } from 'lucide-react';
import { useLater } from '../../context/LaterContext';
import { SwipeView } from '../../types';
import { searchMemories, SearchHit } from '../../utils/memorySearch';
import { describeReturn, getMemoryText, getProvenance, matchesTypeView, TYPE_VIEW_LABEL } from '../../utils/memoryView';
import { Chip, EmptyState } from './parts';
import { MemoryRows } from './MemoryRow';
import { useMemoryActions } from './memoryUi';
import { clearRecentSearches, pushRecentSearch, readRecentOpened, readRecentSearches, useNow } from './hooks';
import { ReturnMark } from './brand';

const TYPE_FACETS: SwipeView[] = ['NOTES', 'LINKS', 'SCREENSHOTS', 'TASKS', 'PEOPLE', 'PLACES'];
type StateFacet = 'scheduled' | 'unscheduled' | null;

const Result: React.FC<{ hit: SearchHit; onOpen: () => void; query: string; now: Date }> = ({ hit, onOpen, now }) => {
  const ret = describeReturn(hit.item, now);
  return (
    <li>
      <button type="button" className="qs-result" onClick={onOpen}>
        <span className="qs-body" style={{ fontWeight: 600, overflowWrap: 'anywhere' }}>{getMemoryText(hit.item).slice(0, 110)}</span>
        {hit.evidence.length > 0 && (
          <span className="qs-result__evidence">{hit.evidence.map((s, i) => (s.hit ? <mark key={i}>{s.text}</mark> : <React.Fragment key={i}>{s.text}</React.Fragment>))}</span>
        )}
        <span className="qs-result__why"><Sparkles size={14} />{hit.why}</span>
        <span className="qs-row__meta">
          {[...getProvenance(hit.item, now), ret.kind !== 'none' ? ret.label : null].filter(Boolean).map((p, i) => <span key={i}>{p}</span>)}
        </span>
      </button>
    </li>
  );
};

export const FindScreen: React.FC<{ onOpenLibrary: () => void }> = ({ onOpenLibrary }) => {
  const { items } = useLater();
  const actions = useMemoryActions();
  const now = useNow();
  const [query, setQuery] = useState('');
  const [type, setType] = useState<SwipeView | null>(null);
  const [stateFacet, setStateFacet] = useState<StateFacet>(null);
  const [recent, setRecent] = useState<string[]>(readRecentSearches);

  const live = useMemo(() => items.filter((i) => !i.isArchived), [items]);
  const hits = useMemo(() => {
    let h = searchMemories(live, query);
    if (type) h = h.filter((x) => matchesTypeView(x.item, type));
    if (stateFacet === 'scheduled') h = h.filter((x) => !!(x.item.reminderTime || x.item.scheduledFor));
    if (stateFacet === 'unscheduled') h = h.filter((x) => !(x.item.reminderTime || x.item.scheduledFor));
    return h;
  }, [live, query, type, stateFacet]);

  const suggestions = useMemo(() => {
    const count = new Map<string, number>();
    live.forEach((i) => [...(i.places || []), ...(i.people || []), ...(i.topics || [])].forEach((v) => v && count.set(v, (count.get(v) || 0) + 1)));
    return [...count.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([v]) => v);
  }, [live]);
  const recentlyOpened = useMemo(() => readRecentOpened().map((id) => live.find((i) => i.id === id)).filter(Boolean).slice(0, 3) as typeof live, [live, query === '']); // eslint-disable-line react-hooks/exhaustive-deps

  const submit = () => { pushRecentSearch(query); setRecent(readRecentSearches()); };
  const hasQuery = query.trim().length > 0;
  const broaden = () => { const words = query.trim().split(/\s+/); if (words.length > 1) setQuery(words.slice(0, -1).join(' ')); };

  return (
    <div className="qs-screen">
      <header className="qs-screen-head">
        <h1 className="qs-title">Find</h1>
        <p className="qs-meta">Search everything you’ve saved — a word, a place, a person, a site.</p>
      </header>

      <form className="qs-search" role="search" onSubmit={(e) => { e.preventDefault(); submit(); }}>
        <Search className="qs-search__icon" size={22} aria-hidden="true" />
        <input className="qs-search__input" type="search" enterKeyHint="search" autoComplete="off" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Find something you remember" aria-label="Find something you remember" />
        {query && <button type="button" className="qs-btn qs-btn--icon qs-search__clear" aria-label="Clear search" onClick={() => setQuery('')}><X size={20} /></button>}
      </form>

      {hasQuery && (
        <div className="qs-chips qs-chips--scroll" role="group" aria-label="Refine results">
          {TYPE_FACETS.map((f) => <Chip key={f} selected={type === f} onClick={() => setType(type === f ? null : f)}>{TYPE_VIEW_LABEL[f]}</Chip>)}
          <Chip selected={stateFacet === 'scheduled'} icon={<ReturnMark size={14} />} onClick={() => setStateFacet(stateFacet === 'scheduled' ? null : 'scheduled')}>Has return time</Chip>
          <Chip selected={stateFacet === 'unscheduled'} icon={<Clock size={14} />} onClick={() => setStateFacet(stateFacet === 'unscheduled' ? null : 'unscheduled')}>No return time</Chip>
        </div>
      )}

      {!hasQuery && (
        <>
          {recent.length > 0 && (
            <section className="qs-section" aria-labelledby="qs-recent-s">
              <div className="qs-section__head"><h2 className="qs-section-title" id="qs-recent-s">Recent searches</h2><button className="qs-btn qs-btn--quiet" onClick={() => { clearRecentSearches(); setRecent([]); }}>Clear</button></div>
              <div className="qs-chips">{recent.map((r) => <Chip key={r} icon={<History size={14} />} onClick={() => setQuery(r)}>{r}</Chip>)}</div>
            </section>
          )}
          {recentlyOpened.length > 0 && (
            <section className="qs-section" aria-labelledby="qs-opened"><h2 className="qs-section-title" id="qs-opened">Recently opened</h2><MemoryRows items={recentlyOpened} label="Recently opened memories" now={now} /></section>
          )}
          <section className="qs-section" aria-labelledby="qs-try">
            <h2 className="qs-section-title" id="qs-try">{suggestions.length ? 'From your memories' : 'Try searching for'}</h2>
            {suggestions.length > 0
              ? <div className="qs-chips">{suggestions.map((s) => <Chip key={s} onClick={() => setQuery(s)}>{s}</Chip>)}</div>
              : <p className="qs-meta">A word from a note, a place, a person’s name, or a website. Matching is by words, not exact phrases.</p>}
          </section>
        </>
      )}

      {hasQuery && hits.length > 0 && (
        <section className="qs-section" aria-live="polite">
          <p className="qs-meta">{hits.length} {hits.length === 1 ? 'result' : 'results'}{hits[0].mode !== 'exact' ? ' — closest matches, not exact' : ''}</p>
          <ul className="qs-rows" aria-label="Search results">
            {hits.map((h) => <Result key={h.item.id} hit={h} query={query} now={now} onOpen={() => { pushRecentSearch(query); actions.open(h.item); }} />)}
          </ul>
        </section>
      )}

      {hasQuery && hits.length === 0 && (
        <EmptyState
          icon={<Search size={22} />} title="I couldn’t find that yet"
          body={`Nothing matched “${query.trim()}”${type || stateFacet ? ' with these refinements' : ''}. Try fewer words, a different word, or browse everything.`}
          action={
            <div className="qs-chips">
              {(type || stateFacet) && <button className="qs-btn qs-btn--secondary" onClick={() => { setType(null); setStateFacet(null); }}>Remove refinements</button>}
              {query.trim().split(/\s+/).length > 1 && <button className="qs-btn qs-btn--secondary" onClick={broaden}>Try fewer words</button>}
              <button className="qs-btn qs-btn--secondary" onClick={onOpenLibrary}>All memories <ArrowRight size={16} /></button>
            </div>
          }
        />
      )}
    </div>
  );
};
