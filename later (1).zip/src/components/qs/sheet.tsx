import React, { useEffect, useRef } from 'react';
import { X } from 'lucide-react';
import { useBackLayer } from './backStack';

interface SheetProps { open: boolean; onClose: () => void; title: string; children: React.ReactNode; hideTitle?: boolean; }

/** Bottom sheet: focus moves in, Tab stays inside, Escape / scrim / back button / Close all dismiss it. */
export const Sheet: React.FC<SheetProps> = ({ open, onClose, title, children, hideTitle }) => {
  const ref = useRef<HTMLDivElement>(null);
  useBackLayer(open, onClose);

  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const t = window.setTimeout(() => {
      const el = ref.current?.querySelector<HTMLElement>('[data-autofocus], textarea, input, button:not([data-close])');
      (el || ref.current)?.focus?.();
    }, 30);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.stopPropagation(); onClose(); return; }
      if (e.key !== 'Tab' || !ref.current) return;
      const f = Array.from(ref.current.querySelectorAll<HTMLElement>('button, [href], input, textarea, select, [tabindex]:not([tabindex="-1"])')).filter((n) => !n.hasAttribute('disabled'));
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', onKey);
    return () => { window.clearTimeout(t); document.removeEventListener('keydown', onKey); document.body.style.overflow = prevOverflow; previous?.focus?.(); };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="qs-sheet-root">
      <button className="qs-scrim" aria-label="Close" tabIndex={-1} onClick={onClose} />
      <div className="qs-sheet" role="dialog" aria-modal="true" aria-label={title} ref={ref} tabIndex={-1}>
        <div className="qs-sheet__grab" aria-hidden="true" />
        <div className="qs-sheet__head">
          <h2 className={`qs-title ${hideTitle ? 'qs-sr' : ''}`}>{title}</h2>
          <button className="qs-btn qs-btn--icon" data-close aria-label="Close" onClick={onClose}><X size={22} /></button>
        </div>
        <div className="qs-sheet__body">{children}</div>
      </div>
    </div>
  );
};

export interface MenuEntry { key: string; label: string; icon?: React.ReactNode; hint?: string; tone?: 'danger'; onSelect: () => void; }
/** Overflow / action menus are sheets too: large targets, no hover, reachable with one hand. */
export const ActionMenu: React.FC<{ open: boolean; onClose: () => void; title: string; entries: MenuEntry[] }> = ({ open, onClose, title, entries }) => (
  <Sheet open={open} onClose={onClose} title={title}>
    <div className="qs-menu" role="menu">
      {entries.map((e) => (
        <button key={e.key} role="menuitem" className="qs-menu__item" data-tone={e.tone} onClick={() => { onClose(); e.onSelect(); }}>
          {e.icon}<span>{e.label}</span>{e.hint && <small>{e.hint}</small>}
        </button>
      ))}
    </div>
  </Sheet>
);
