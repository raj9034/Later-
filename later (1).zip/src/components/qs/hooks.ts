import { useEffect, useState } from 'react';

/** A clock that re-renders once a minute so "Returning now" and relative times stay true. */
export function useNow(intervalMs = 60000): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), intervalMs);
    const onVis = () => { if (document.visibilityState === 'visible') setNow(new Date()); };
    document.addEventListener('visibilitychange', onVis);
    return () => { window.clearInterval(id); document.removeEventListener('visibilitychange', onVis); };
  }, [intervalMs]);
  return now;
}

export function useOnline(): boolean {
  const [online, setOnline] = useState(() => (typeof navigator === 'undefined' ? true : navigator.onLine));
  useEffect(() => {
    const up = () => setOnline(true), down = () => setOnline(false);
    window.addEventListener('online', up); window.addEventListener('offline', down);
    return () => { window.removeEventListener('online', up); window.removeEventListener('offline', down); };
  }, []);
  return online;
}

/* ---- tiny local histories for Find (recent searches / recently opened) ---- */
const RS = 'later_recent_searches_v1', RO = 'later_recent_opened_v1';
const read = (k: string): string[] => { try { const v = JSON.parse(localStorage.getItem(k) || '[]'); return Array.isArray(v) ? v : []; } catch { return []; } };
const write = (k: string, v: string[]) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage full/blocked: history is optional */ } };
export const readRecentSearches = () => read(RS);
export const pushRecentSearch = (q: string) => { const t = q.trim(); if (t.length < 2) return; write(RS, [t, ...read(RS).filter((x) => x.toLowerCase() !== t.toLowerCase())].slice(0, 6)); };
export const clearRecentSearches = () => write(RS, []);
export const readRecentOpened = () => read(RO);
export const pushRecentOpened = (id: string) => write(RO, [id, ...read(RO).filter((x) => x !== id)].slice(0, 8));
