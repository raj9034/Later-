import React, { useEffect, useRef, useState } from 'react';
import { Inbox, Search, CalendarClock, Layers } from 'lucide-react';
import { AuthProvider, useAuth, ONBOARDING_STORAGE_KEY } from '../../context/AuthContext';
import { LaterProvider, useLater } from '../../context/LaterContext';
import { TagProvider } from '../../context/TagContext';
import { CollectionProvider } from '../../context/CollectionContext';
import { ThemeProvider, useTheme } from '../../context/ThemeContext';
import { OnboardingModal } from '../onboarding/OnboardingModal';
import { HelpFaqModal } from '../onboarding/HelpFaqModal';
import { FeatureTourOverlay } from '../onboarding/FeatureTourOverlay';
import { CreateAccountModal } from '../auth/CreateAccountModal';
import { ExactAlarmPermissionDialog } from '../ui/ExactAlarmPermissionDialog';
import { NotificationRecoveryPrompt } from '../notifications/NotificationRecoveryPrompt';
import { ReminderNotificationGate } from '../notifications/ReminderNotificationGate';
import { SavedItem } from '../../types';
import { Wordmark } from './brand';
import { CaptureDock } from './CaptureDock';
import { InboxScreen } from './InboxScreen';
import { FindScreen } from './FindScreen';
import { PlanScreen } from './PlanScreen';
import { LibraryScreen } from './LibraryScreen';
import { AccountScreen, applyContrastPreference } from './AccountScreen';
import { MemoryDetailSheet } from './MemoryDetailSheet';
import { MemoryUiProvider } from './memoryUi';
import { FeedbackProvider } from './feedback';
import { useBackLayer } from './backStack';
import { useNow } from './hooks';
import type { Destination } from './types';
// Fast-path capture from the persistent Android notification, unchanged from
// the pre-redesign app (see App.tsx's QuickCaptureLiveBridge for full history).
// Must stay mounted for the whole session, independent of which screen is open.
import { QuickCaptureLiveBridge } from '../../App';

const TABS: { key: Destination; label: string; icon: React.ReactNode }[] = [
  { key: 'inbox', label: 'Inbox', icon: <Inbox size={22} /> },
  { key: 'find', label: 'Find', icon: <Search size={22} /> },
  { key: 'plan', label: 'Plan', icon: <CalendarClock size={22} /> },
  { key: 'library', label: 'Library', icon: <Layers size={22} /> },
];

const SplashGate: React.FC = () => (
  <div className="qs-app" data-theme="light" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20 }}>
    <span style={{ width: 64, height: 64, borderRadius: 20, background: 'var(--qs-action)', color: 'var(--qs-on-action)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Wordmark />
    </span>
  </div>
);

const Root: React.FC = () => {
  const { theme } = useTheme();
  const { loading: authLoading, hasSeenOnboarding, user } = useAuth();
  const { isExactAlarmDialogOpen, confirmExactAlarmDialog, dismissExactAlarmDialog, reminderNotificationGate } = useLater();
  const now = useNow();

  useEffect(() => { applyContrastPreference(); }, []);

  const [dest, setDest] = useState<Destination>('inbox');
  const [libraryInitial, setLibraryInitial] = useState<any>(null);
  const [findQuery, setFindQuery] = useState<string | undefined>(undefined);
  const [captureOpen, setCaptureOpen] = useState(false);
  const [latest, setLatest] = useState<SavedItem | null>(null);
  const [helpOpen, setHelpOpen] = useState(false);
  const [forceOnboarding, setForceOnboarding] = useState(false);
  const [forceTour, setForceTour] = useState(false);
  const [account, setAccount] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [scrolled, setScrolled] = useState(false);
  useBackLayer(account, () => setAccount(false));

  useEffect(() => {
    const el = scrollRef.current || window;
    const onScroll = () => setScrolled((window.scrollY || document.documentElement.scrollTop || 0) > 2);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const hasCompletedOnboarding = user
    ? hasSeenOnboarding === true
    : (() => { try { return !!localStorage.getItem(ONBOARDING_STORAGE_KEY); } catch { return false; } })();

  const goto = (d: Destination) => { setDest(d); setAccount(false); };
  const openLibraryAt = (v: any) => { setLibraryInitial(v); setDest('library'); setAccount(false); };
  const openFind = (q?: string) => { setFindQuery(q); setDest('find'); setAccount(false); };
  const replayTour = () => { setDest('inbox'); setAccount(false); setForceTour(true); };

  if (authLoading) return <SplashGate />;

  return (
    <div className="qs-app" data-theme={theme} data-capture-open={captureOpen}>
      {!account && (
        <header className="qs-topbar" data-scrolled={scrolled}>
          <div className="qs-topbar__inner">
            <Wordmark />
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              {!user && <span className="qs-sync">On this device</span>}
              <button type="button" className="qs-avatar" aria-label="Profile and settings" onClick={() => setAccount(true)}>
                {user?.photoURL ? <img src={user.photoURL} alt="" /> : (user?.displayName?.[0] || user?.email?.[0] || 'G').toUpperCase()}
              </button>
            </div>
          </div>
        </header>
      )}

      <main className="qs-main" ref={scrollRef}>
        {account ? (
          <AccountScreen onBack={() => setAccount(false)} onOpenHelp={() => setHelpOpen(true)} onReplayTour={replayTour} />
        ) : dest === 'inbox' ? (
          <InboxScreen latest={latest} onDismissLatest={() => setLatest(null)} onOpenLibrary={() => openLibraryAt({ kind: 'all' })} />
        ) : dest === 'find' ? (
          <FindScreen key={findQuery} onOpenLibrary={() => openLibraryAt({ kind: 'all' })} />
        ) : dest === 'plan' ? (
          <PlanScreen />
        ) : (
          <LibraryScreen initial={libraryInitial} onFind={openFind} />
        )}
      </main>

      {!account && <CaptureDock onSaved={(item) => { setLatest(item); setDest('inbox'); }} onOpenChange={setCaptureOpen} />}

      {!account && (
        <nav className="qs-tabbar" aria-label="Primary">
          <div className="qs-tabbar__list">
            {TABS.map((t) => (
              <button key={t.key} className="qs-tab" aria-current={dest === t.key ? 'page' : undefined} onClick={() => { setLibraryInitial(null); goto(t.key); }}>
                {t.icon}<span>{t.label}</span>
              </button>
            ))}
          </div>
        </nav>
      )}

      <MemoryDetailSheet />

      {/* Preserved system flows: onboarding, tour, auth modal, exact-alarm permission,
          the "notifications were revoked" recovery banner, and the reminder-permission
          gate the save pipeline waits on. None of these were redesigned — only restyled
          by inheriting the Quiet Signal tokens. */}
      <OnboardingModal forceOpen={forceOnboarding} onClose={() => setForceOnboarding(false)} />
      <HelpFaqModal isOpen={helpOpen} onClose={() => setHelpOpen(false)} onReplayTour={replayTour} />
      <FeatureTourOverlay forceOpen={forceTour} onClose={() => setForceTour(false)} />
      <CreateAccountModal />
      <ExactAlarmPermissionDialog isOpen={isExactAlarmDialogOpen} onConfirm={confirmExactAlarmDialog} onDismiss={dismissExactAlarmDialog} />
      <NotificationRecoveryPrompt suppressForOnboarding={!hasCompletedOnboarding} />
      <ReminderNotificationGate pending={reminderNotificationGate} />
      <QuickCaptureLiveBridge />
    </div>
  );
};

export default function QuietSignalApp() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <LaterProvider>
          <TagProvider>
            <CollectionProvider>
              <FeedbackProvider>
                <MemoryUiProvider>
                  <Root />
                </MemoryUiProvider>
              </FeedbackProvider>
            </CollectionProvider>
          </TagProvider>
        </LaterProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
