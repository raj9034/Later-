import React from 'react';
import { MoreHorizontal, Bookmark, Clock } from 'lucide-react';
import { SavedItem } from '../../types';
import { describeReturn, getMemoryText, getProvenance } from '../../utils/memoryView';
import { ReturnEntry } from './types';
import { ReturnMark } from './brand';
import { useMemoryActions, useMemoryUi } from './memoryUi';

/**
 * Recognition-first row: the captured content leads, then ONE state line that is
 * also the primary contextual action, then quiet provenance. Everything else is
 * behind the overflow menu (which is a sheet — no hover, no swipe required).
 */
export const MemoryRow: React.FC<{ item: SavedItem; now?: Date }> = ({ item, now }) => {
  const actions = useMemoryActions();
  const ui = useMemoryUi();
  const ret = describeReturn(item, now);
  const text = getMemoryText(item);

  let verb = '';
  let onState: () => void = () => ui.openTime(item, 'choose');
  if (ret.kind === 'none') verb = 'Choose a time';
  else if (ret.kind === 'scheduled') verb = 'Change';
  else if (ret.kind === 'due') { verb = 'Keep'; onState = () => actions.keep(item); }
  else if (ret.kind === 'done') { verb = 'Undo'; onState = () => actions.toggleDone(item); }

  return (
    <li className="qs-row" data-state={ret.kind}>
      <div className="qs-row__main">
        <button type="button" className="qs-row__text" onClick={() => actions.open(item)} aria-label={`Open memory: ${text.slice(0, 80)}`}>{text}</button>
        <button type="button" className="qs-row__state" data-kind={ret.kind} onClick={onState}>
          {ret.kind === 'scheduled' || ret.kind === 'due' ? <ReturnMark size={16} /> : ret.kind === 'done' ? null : <Clock size={15} />}
          <span>{ret.label}</span>
          {verb && <span aria-hidden="false" style={{ textDecoration: 'underline', textUnderlineOffset: 3, color: 'var(--qs-signal-text)', fontWeight: 700 }}>· {verb}</span>}
        </button>
        <p className="qs-row__meta">{getProvenance(item, now).map((p, i) => <span key={i}>{p}</span>)}</p>
      </div>
      {item.imageAttachment && <img className="qs-row__thumb" src={item.imageAttachment} alt="" />}
      <button type="button" className="qs-btn qs-btn--icon qs-row__more" aria-label={`More actions for ${text.slice(0, 40)}`} onClick={() => ui.openMenu(item)}>
        <MoreHorizontal size={22} />
      </button>
    </li>
  );
};

export const MemoryRows: React.FC<{ items: SavedItem[]; label: string; now?: Date }> = ({ items, label, now }) => (
  <ul className="qs-rows" aria-label={label}>{items.map((i) => <MemoryRow key={i.id} item={i} now={now} />)}</ul>
);

/** "Returning now": one memory, the reason it is here, its return context, and non-task actions. */
export const ReturnCard: React.FC<{ entry: ReturnEntry; now?: Date }> = ({ entry, now }) => {
  const { item } = entry;
  const actions = useMemoryActions();
  const ui = useMemoryUi();
  const ret = describeReturn(item, now);
  const text = getMemoryText(item);
  return (
    <article className="qs-return-card" aria-label={`${entry.label}: ${text.slice(0, 60)}`}>
      <p className="qs-return-card__why"><ReturnMark size={16} /><span>{entry.label} · {entry.why}</span></p>
      <button type="button" className="qs-return-card__text" onClick={() => actions.open(item)}>{text}</button>
      <p className="qs-row__meta">{[ret.kind !== 'none' ? ret.label : null, ...getProvenance(item, now)].filter(Boolean).map((p, i) => <span key={i}>{p}</span>)}</p>
      <div className="qs-return-card__actions">
        <button type="button" className="qs-btn qs-btn--primary" onClick={() => actions.open(item)}>Open</button>
        <button type="button" className="qs-btn qs-btn--secondary" onClick={() => actions.keep(item)}><Bookmark size={17} />Keep</button>
        <button type="button" className="qs-btn qs-btn--secondary" onClick={() => ui.openTime(item, 'snooze')}><Clock size={17} />Snooze</button>
        <button type="button" className="qs-btn qs-btn--icon" aria-label="More actions" onClick={() => ui.openMenu(item)}><MoreHorizontal size={22} /></button>
      </div>
    </article>
  );
};
