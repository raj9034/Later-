import React, { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { Archive, Clock, Pencil, ThumbsDown, Trash2, Check, RotateCcw, Bookmark, CalendarClock } from 'lucide-react';
import { useLater, snapshotSchedule } from '../../context/LaterContext';
import { SavedItem, SchedulePreset } from '../../types';
import { calculateDateFromPreset } from '../../utils/timeScheduler';
import { friendlyWhen, isActionMemory, getMemoryText } from '../../utils/memoryView';
import { keepItem, unkeepItem } from '../../utils/returningNow';
import { Sheet, ActionMenu, MenuEntry } from './sheet';
import { useFeedback } from './feedback';
import { pushRecentOpened } from './hooks';

/* ---------------------------------------------------------------- actions */

const PRESETS: { key: SchedulePreset; label: string; note: string }[] = [
  { key: 'later_today', label: 'Later today', note: 'in about 3 hours' },
  { key: 'tonight', label: 'Tonight', note: '' },
  { key: 'tomorrow', label: 'Tomorrow morning', note: '' },
  { key: 'this_weekend', label: 'This weekend', note: '' },
  { key: 'next_week', label: 'Next week', note: '' },
];
const SNOOZE_WORD: Record<string, string> = { later_today: 'later today', tonight: 'tonight', tomorrow: 'tomorrow morning', this_weekend: 'this weekend', next_week: 'next week' };

export function useMemoryActions() {
  const L = useLater();
  const { notify } = useFeedback();

  return useMemo(() => {
    const open = (item: SavedItem) => { pushRecentOpened(item.id); L.setSelectedItem(item); };

    const keep = (item: SavedItem) => {
      const snap = snapshotSchedule(item);
      L.clearItemReminder(item.id);
      keepItem(item.id);
      notify({ message: 'Kept for reference. It won’t return unless you set a time.', actionLabel: 'Undo', onAction: () => { L.restoreItemSchedule(item.id, snap); unkeepItem(item.id); } });
    };

    const snooze = async (item: SavedItem, preset: SchedulePreset, customIso?: string) => {
      void L.requestExactAlarmIfNeeded();
      const snap = snapshotSchedule(item);
      await L.snoozeItem(item.id, preset, customIso);
      unkeepItem(item.id);
      const when = preset === 'custom' && customIso ? friendlyWhen(new Date(customIso)) : SNOOZE_WORD[preset] || 'later';
      notify({ message: `Snoozed until ${when}.`, actionLabel: 'Undo', onAction: () => L.restoreItemSchedule(item.id, snap) });
    };

    const chooseTime = (item: SavedItem, preset: SchedulePreset, customIso?: string) => {
      const iso = preset === 'custom' ? customIso : calculateDateFromPreset(preset);
      if (!iso) {
        const snap = snapshotSchedule(item);
        L.clearItemReminder(item.id);
        notify({ message: 'Return time removed.', actionLabel: 'Undo', onAction: () => L.restoreItemSchedule(item.id, snap) });
        return;
      }
      const snap = snapshotSchedule(item);
      void L.requestExactAlarmIfNeeded();
      L.setReminderForItem(item.id, { type: 'scheduled', scheduledAt: iso, reminderStatus: 'waiting' });
      unkeepItem(item.id);
      notify({ message: `I’ll bring this back ${friendlyWhen(new Date(iso))}.`, actionLabel: 'Undo', onAction: () => L.restoreItemSchedule(item.id, snap) });
    };

    const toggleDone = (item: SavedItem) => {
      const wasDone = item.isDone;
      L.toggleDone(item.id);
      notify({ message: wasDone ? 'Marked as not done.' : 'Marked done.', actionLabel: 'Undo', onAction: () => L.toggleDone(item.id) });
    };

    const archive = (item: SavedItem) => {
      L.archiveItem(item.id);
      notify({ message: 'Archived.', actionLabel: 'Undo', onAction: () => L.unarchiveItem(item.id) });
    };

    const notUseful = (item: SavedItem) => {
      L.archiveItem(item.id);
      notify({ message: 'Marked not useful and archived.', actionLabel: 'Undo', onAction: () => L.unarchiveItem(item.id) });
    };

    return { open, keep, snooze, chooseTime, toggleDone, archive, notUseful, remove: (item: SavedItem) => L.deleteItem(item.id) };
  }, [L, notify]);
}

/* ------------------------------------------------------------- UI context */

type TimeMode = 'choose' | 'snooze';
interface MemoryUiApi {
  openTime: (item: SavedItem, mode: TimeMode) => void;
  openMenu: (item: SavedItem) => void;
  askDelete: (item: SavedItem) => void;
}
const Ctx = createContext<MemoryUiApi>({ openTime: () => {}, openMenu: () => {}, askDelete: () => {} });
export const useMemoryUi = () => useContext(Ctx);

/** Owns the shared sheets so every row/card/detail opens the SAME time picker, menu and confirmation. */
export const MemoryUiProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const actions = useMemoryActions();
  const { setSelectedItem } = useLater();
  const [time, setTime] = useState<{ item: SavedItem; mode: TimeMode } | null>(null);
  const [menu, setMenu] = useState<SavedItem | null>(null);
  const [del, setDel] = useState<SavedItem | null>(null);
  const [custom, setCustom] = useState('');

  const openTime = useCallback((item: SavedItem, mode: TimeMode) => { setCustom(''); setTime({ item, mode }); }, []);
  const openMenu = useCallback((item: SavedItem) => setMenu(item), []);
  const askDelete = useCallback((item: SavedItem) => setDel(item), []);
  const api = useMemo(() => ({ openTime, openMenu, askDelete }), [openTime, openMenu, askDelete]);

  const closeTime = () => setTime(null);
  const minLocal = (() => { const d = new Date(Date.now() + 60000); d.setSeconds(0, 0); const p = (n: number) => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`; })();

  const pick = (preset: SchedulePreset, iso?: string) => {
    if (!time) return;
    const { item, mode } = time;
    closeTime();
    if (mode === 'snooze') void actions.snooze(item, preset, iso);
    else actions.chooseTime(item, preset, iso);
  };

  const menuEntries = (item: SavedItem): MenuEntry[] => {
    const hasTime = !!(item.reminderTime || item.scheduledFor);
    const list: MenuEntry[] = [
      { key: 'open', label: 'Open and edit', icon: <Pencil size={20} />, onSelect: () => actions.open(item) },
      { key: 'time', label: hasTime ? 'Change return time' : 'Choose a return time', icon: <CalendarClock size={20} />, onSelect: () => openTime(item, 'choose') },
    ];
    if (hasTime && !item.isDone) list.push({ key: 'snooze', label: 'Snooze', icon: <Clock size={20} />, onSelect: () => openTime(item, 'snooze') });
    if (hasTime && !item.isDone) list.push({ key: 'keep', label: 'Keep for reference', icon: <Bookmark size={20} />, hint: 'stops returning', onSelect: () => actions.keep(item) });
    if (isActionMemory(item)) list.push({ key: 'done', label: item.isDone ? 'Mark as not done' : 'Mark done', icon: item.isDone ? <RotateCcw size={20} /> : <Check size={20} />, onSelect: () => actions.toggleDone(item) });
    list.push({ key: 'archive', label: 'Archive', icon: <Archive size={20} />, onSelect: () => actions.archive(item) });
    list.push({ key: 'notuseful', label: 'Not useful', icon: <ThumbsDown size={20} />, hint: 'archives it', onSelect: () => actions.notUseful(item) });
    list.push({ key: 'delete', label: 'Delete permanently…', icon: <Trash2 size={20} />, tone: 'danger', onSelect: () => askDelete(item) });
    return list;
  };

  return (
    <Ctx.Provider value={api}>
      {children}

      <ActionMenu open={!!menu} onClose={() => setMenu(null)} title="Memory actions" entries={menu ? menuEntries(menu) : []} />

      <Sheet open={!!time} onClose={closeTime} title={time?.mode === 'snooze' ? 'Snooze until' : 'When should this return?'}>
        {time && (
          <>
            <p className="qs-meta" style={{ marginTop: -8 }}>{getMemoryText(time.item).slice(0, 90)}</p>
            <div className="qs-menu">
              {PRESETS.map((p) => {
                const iso = calculateDateFromPreset(p.key);
                return (
                  <button key={p.key} className="qs-menu__item" onClick={() => pick(p.key)}>
                    <Clock size={20} /><span>{p.label}</span>{iso && <small>{friendlyWhen(new Date(iso))}</small>}
                  </button>
                );
              })}
            </div>
            <div>
              <label className="qs-label-text" htmlFor="qs-custom-time">Pick a date and time</label>
              <div style={{ display: 'flex', gap: 8 }}>
                <input id="qs-custom-time" className="qs-field" type="datetime-local" min={minLocal} value={custom} onChange={(e) => setCustom(e.target.value)} />
                <button className="qs-btn qs-btn--primary" disabled={!custom} onClick={() => custom && pick('custom', new Date(custom).toISOString())}>Set</button>
              </div>
            </div>
            {time.mode === 'choose' && (time.item.reminderTime || time.item.scheduledFor) && (
              <button className="qs-btn qs-btn--secondary qs-btn--block" onClick={() => pick('no_time')}>No return time</button>
            )}
          </>
        )}
      </Sheet>

      <Sheet open={!!del} onClose={() => setDel(null)} title="Delete this memory?">
        {del && (
          <>
            <p className="qs-body">“{getMemoryText(del).slice(0, 120)}” will be deleted permanently. This can’t be undone. If you might want it later, archive it instead.</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <button className="qs-btn qs-btn--danger qs-btn--block" onClick={() => { const d = del; setDel(null); setSelectedItem(null); actions.remove(d); }}>Delete permanently</button>
              <button className="qs-btn qs-btn--secondary qs-btn--block" onClick={() => { const d = del; setDel(null); actions.archive(d); }}>Archive instead</button>
            </div>
          </>
        )}
      </Sheet>
    </Ctx.Provider>
  );
};
