/**
 * Android back / browser back for overlays and sub-screens.
 *
 * The app had no back handling: pressing back from anywhere exited it. Capacitor's
 * BridgeActivity already calls webView.goBack() when history exists, so all we need
 * is to give each open layer (sheet, sub-screen, expanded dock) a history entry.
 * A single popstate listener closes the TOP layer only. When a layer is closed by
 * the UI instead (a close button), we pop its entry and swallow the resulting event
 * so layers underneath are not closed by accident.
 */
import { useEffect, useRef } from 'react';

interface Layer { close: () => void; }
const stack: Layer[] = [];
let ignore = 0;
let installed = false;

function install() {
  if (installed || typeof window === 'undefined') return;
  installed = true;
  window.addEventListener('popstate', () => {
    if (ignore > 0) { ignore--; return; }
    const top = stack.pop();
    top?.close();
  });
}

export function useBackLayer(active: boolean, onBack: () => void): void {
  const cb = useRef(onBack);
  cb.current = onBack;
  useEffect(() => {
    if (!active) return;
    install();
    const layer: Layer = { close: () => cb.current() };
    stack.push(layer);
    try { window.history.pushState({ qsLayer: true }, ''); } catch { /* history unavailable */ }
    return () => {
      const i = stack.indexOf(layer);
      if (i >= 0) {
        // closed by the UI, not by the back button: remove our entry quietly
        stack.splice(i, 1);
        ignore++;
        try { window.history.back(); } catch { ignore--; }
      }
    };
  }, [active]);
}
