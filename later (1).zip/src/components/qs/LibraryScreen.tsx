import React, { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Inbox, CalendarDays, CalendarClock, Clock, Star, Trash2, FolderOpen, Tag as TagIcon, Users, MapPin, Search } from 'lucide-react';
import { useLater } from '../../context/LaterContext';
import { useTags } from '../../context/TagContext';
import { useCollections } from '../../context/CollectionContext';
import { SavedItem, SwipeView } from '../../types';
import { SidebarView, buildPeopleDirectory, buildPlacesDirectory, groupByCaptureDay, groupUpcoming, isActive, isScheduledFuture, isScheduledToday, isUnscheduled } from '../sidebar/sidebarUtils';
import { SidebarScreenRouter } from '../sidebar/SidebarScreens';
import { CollectionsScreen } from '../collections/CollectionScreens';
import { matchesTypeView, TYPE_VIEW_LABEL } from '../../utils/memoryView';
import { Chip, EmptyState, SectionHead } from './parts';
import { MemoryRows } from './MemoryRow';
import { useBackLayer } from './backStack';
import { useNow } from './hooks';

type Sub = SidebarView | { kind: 'collections' } | { kind: 'starred' } | { kind: 'recentlyDeleted' };
const TYPE_CHIPS: SwipeView[] = ['ALL', 'NOTES', 'LINKS', 'SCREENSHOTS'];

const Back: React.FC<{ onBack: () => void; title: string; meta?: string }> = ({ onBack, title, meta }) => (
  <header className="qs-screen-head">
    <button className="qs-back" onClick={onBack}><ChevronLeft size={20} />Library</button>
    <h1 className="qs-title">{title}</h1>
    {meta && <p className="qs-meta">{meta}</p>}
  </header>
);

export const LibraryScreen: React.FC<{ initial?: Sub | null; onFind: (query?: string) => void }> = ({ initial = null, onFind }) => {
  const { items } = useLater();
  const { tags } = useTags();
  const { collections } = useCollections();
  const now = useNow();
  const [sub, setSub] = useState<Sub | null>(initial);
  const [q, setQ] = useState('');
  const [type, setType] = useState<SwipeView>('ALL');
  useBackLayer(sub !== null, () => setSub(null));

  const live = useMemo(() => items.filter(isActive), [items]);
  const counts = {
    all: live.length,
    today: live.filter(isScheduledToday).length,
    upcoming: live.filter(isScheduledFuture).length,
    unscheduled: live.filter(isUnscheduled).length,
    people: buildPeopleDirectory(live).length,
    places: buildPlacesDirectory(live).length,
  };

  /* -------------------------------------------------------------- sub-views */
  if (sub) {
    const back = () => setSub(null);
    switch (sub.kind) {
      case 'all': {
        const filtered = live.filter((i) => matchesTypeView(i, type));
        const groups = groupByCaptureDay(filtered);
        return (
          <div className="qs-screen">
            <Back onBack={back} title="All memories" meta={`${filtered.length} ${filtered.length === 1 ? 'memory' : 'memories'}`} />
            <div className="qs-chips qs-chips--scroll" role="group" aria-label="Filter by type">
              {TYPE_CHIPS.map((t) => <Chip key={t} selected={type === t} onClick={() => setType(t)}>{TYPE_VIEW_LABEL[t]}</Chip>)}
            </div>
            {groups.length === 0 && <EmptyState icon={<Inbox size={22} />} title="Nothing here" body="No memories match this filter." />}
            {groups.map((g) => <section className="qs-section" key={g.label}><SectionHead title={g.label} meta={`${g.items.length}`} /><MemoryRows items={g.items} label={g.label} now={now} /></section>)}
          </div>
        );
      }
      case 'today': {
        const list = live.filter(isScheduledToday);
        return (
          <div className="qs-screen">
            <Back onBack={back} title="Today" meta={`${list.length} returning today`} />
            {list.length ? <MemoryRows items={list} label="Returning today" now={now} /> : <EmptyState icon={<CalendarDays size={22} />} title="Nothing returns today" body="Memories set for today appear here." />}
          </div>
        );
      }
      case 'upcoming': {
        const groups = groupUpcoming(live.filter(isScheduledFuture));
        return (
          <div className="qs-screen">
            <Back onBack={back} title="Upcoming" meta={`${counts.upcoming} returning after today`} />
            {groups.length === 0 && <EmptyState icon={<CalendarClock size={22} />} title="Nothing upcoming" body="Save something with a day or time and it will show up here." />}
            {groups.map((g) => <section className="qs-section" key={g.label}><SectionHead title={g.label} /><MemoryRows items={g.items} label={g.label} now={now} /></section>)}
          </div>
        );
      }
      case 'unscheduled': {
        const list = live.filter(isUnscheduled).sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
        return (
          <div className="qs-screen">
            <Back onBack={back} title="No return time yet" meta={`${list.length} ${list.length === 1 ? 'memory' : 'memories'} — saved, not scheduled`} />
            <p className="qs-meta">These aren’t overdue. They’re simply waiting until you want them back.</p>
            {list.length ? <MemoryRows items={list} label="No return time yet" now={now} /> : <EmptyState icon={<Clock size={22} />} title="Everything has a return time" body="Nothing is waiting without a time." />}
          </div>
        );
      }
      case 'starred':
        return <div className="qs-screen"><Back onBack={back} title="Starred" /><EmptyState icon={<Star size={22} />} title="Starring isn’t available yet" body="Later can’t star memories yet, so there’s nothing to show here — and nothing has been lost. Until then, tag important memories or set them to Priority." /></div>;
      case 'recentlyDeleted':
        return <div className="qs-screen"><Back onBack={back} title="Recently deleted" /><EmptyState icon={<Trash2 size={22} />} title="Recovery isn’t available yet" body="Deleting a memory is permanent right now, so there’s no recovery bin. Archive is reversible: use Archive instead of Delete if you might want it back." /></div>;
      case 'collections':
        return <div className="qs-screen"><Back onBack={back} title="Collections" meta="Optional homes for related memories" /><CollectionsScreen /></div>;
      default:
        // People, Places, Tags and their detail views keep their existing, working screens.
        return <SidebarScreenRouter view={sub as SidebarView} onBack={back} onOpenSearch={() => onFind()} onNavigate={(v) => setSub(v)} />;
    }
  }

  /* ------------------------------------------------------------------ index */
  const rows: { key: string; icon: React.ReactNode; label: string; note?: string; count?: number; soon?: boolean; to: Sub }[] = [
    { key: 'all', icon: <Inbox size={20} />, label: 'All memories', count: counts.all, to: { kind: 'all' } },
    { key: 'today', icon: <CalendarDays size={20} />, label: 'Today', count: counts.today, to: { kind: 'today' } },
    { key: 'upcoming', icon: <CalendarClock size={20} />, label: 'Upcoming', count: counts.upcoming, to: { kind: 'upcoming' } },
    { key: 'unscheduled', icon: <Clock size={20} />, label: 'No return time yet', count: counts.unscheduled, to: { kind: 'unscheduled' } },
    { key: 'starred', icon: <Star size={20} />, label: 'Starred', soon: true, to: { kind: 'starred' } },
    { key: 'deleted', icon: <Trash2 size={20} />, label: 'Recently deleted', soon: true, to: { kind: 'recentlyDeleted' } },
  ];
  const organize = [
    { key: 'collections', icon: <FolderOpen size={20} />, label: 'Collections', note: 'Optional homes for related memories', count: collections.length, to: { kind: 'collections' } as Sub },
    { key: 'tags', icon: <TagIcon size={20} />, label: 'Tags', note: 'Optional labels across memories', count: tags.length, to: { kind: 'tags' } as Sub },
    { key: 'people', icon: <Users size={20} />, label: 'People', count: counts.people, to: { kind: 'people' } as Sub },
    { key: 'places', icon: <MapPin size={20} />, label: 'Places', count: counts.places, to: { kind: 'places' } as Sub },
  ];
  const Item = (r: { key: string; icon: React.ReactNode; label: string; note?: string; count?: number; soon?: boolean; to: Sub }) => (
    <button key={r.key} className="qs-index__item" onClick={() => setSub(r.to)}>
      <span className="qs-index__icon" aria-hidden="true">{r.icon}</span>
      <span className="qs-index__label">{r.label}{r.note && <small>{r.note}</small>}</span>
      {r.soon ? <span className="qs-index__soon">Not available yet</span> : <span className="qs-index__count">{r.count}</span>}
      <ChevronRight size={18} aria-hidden="true" style={{ color: 'var(--qs-ink-muted)' }} />
    </button>
  );

  return (
    <div className="qs-screen">
      <header className="qs-screen-head"><h1 className="qs-title">Library</h1><p className="qs-meta">Everything you’ve saved, and the optional ways to organize it.</p></header>
      <form className="qs-search" role="search" onSubmit={(e) => { e.preventDefault(); onFind(q); }}>
        <Search className="qs-search__icon" size={22} aria-hidden="true" />
        <input className="qs-search__input" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search your library" aria-label="Search your library" enterKeyHint="search" />
      </form>
      <section className="qs-group" aria-label="Memories"><div className="qs-index">{rows.map(Item)}</div></section>
      <section className="qs-group" aria-labelledby="qs-org"><p className="qs-group__title" id="qs-org">Organize (all optional)</p><div className="qs-index">{organize.map(Item)}</div></section>
    </div>
  );
};
