import React, { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Camera, Zap, Bell, AlarmClock, Moon, Sun, Contrast, HelpCircle, PlayCircle, Info, Mail, LogOut, Trash2, Smartphone, Cloud } from 'lucide-react';
import { useLater } from '../../context/LaterContext';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { QuickCapture } from '../../lib/quickCapture';
import { openExactAlarmSettings } from '../../utils/nativeNotifications';
import { attemptEnableNotifications, getNotificationPermissionStatus, openNotificationSettings, NotificationPermissionStatus } from '../../utils/notificationPermission';
import { Sheet } from './sheet';
import { useBackLayer } from './backStack';
import { useFeedback } from './feedback';

const CONTRAST_KEY = 'later_contrast_v1';
export const applyContrastPreference = (): boolean => {
  let stored: string | null = null;
  try { stored = localStorage.getItem(CONTRAST_KEY); } catch { /* ignore */ }
  const wantsHigh = stored ? stored === 'high' : typeof matchMedia !== 'undefined' && matchMedia('(prefers-contrast: more)').matches;
  document.documentElement.setAttribute('data-contrast', wantsHigh ? 'high' : 'normal');
  return wantsHigh;
};

interface Props { onBack: () => void; onOpenHelp: () => void; onReplayTour: () => void; }

const Row: React.FC<{ icon: React.ReactNode; label: string; note?: string; status?: React.ReactNode; onClick?: () => void; href?: string; tone?: 'danger' }> = ({ icon, label, note, status, onClick, href, tone }) => {
  const inner = (
    <>
      <span className="qs-index__icon" aria-hidden="true" style={tone === 'danger' ? { color: 'var(--qs-danger-text)', background: 'var(--qs-danger-tint)' } : undefined}>{icon}</span>
      <span className="qs-setting__label" style={tone === 'danger' ? { color: 'var(--qs-danger-text)' } : undefined}>{label}{note && <small>{note}</small>}</span>
      {status}
      {(onClick || href) && <ChevronRight size={18} aria-hidden="true" style={{ color: 'var(--qs-ink-muted)' }} />}
    </>
  );
  return href ? <a className="qs-setting" href={href}>{inner}</a> : <button type="button" className="qs-setting" onClick={onClick} disabled={!onClick}>{inner}</button>;
};

export const AccountScreen: React.FC<Props> = ({ onBack, onOpenHelp, onReplayTour }) => {
  const { items, resetData, showToast } = useLater();
  const { user, openAuthModal, signOutUser, updateDisplayName, updatePhoto } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { notify } = useFeedback();
  useBackLayer(true, onBack);

  const [qc, setQc] = useState(true);
  const [notif, setNotif] = useState<NotificationPermissionStatus | null>(null);
  const [contrast, setContrast] = useState(() => document.documentElement.getAttribute('data-contrast') === 'high');
  const [sheet, setSheet] = useState<null | 'edit' | 'qcoff' | 'reset' | 'about'>(null);
  const [name, setName] = useState('');
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => { QuickCapture.isEnabled().then((r) => setQc(r.enabled === true)).catch(() => {}); }, []);
  useEffect(() => { getNotificationPermissionStatus().then(setNotif).catch(() => setNotif(null)); }, []);

  const liveCount = items.filter((i) => !i.isArchived).length;
  const displayName = user?.displayName?.trim() || (user ? user.email?.split('@')[0] : 'Guest');
  const initial = (user?.displayName?.[0] || user?.email?.[0] || 'G').toUpperCase();

  const toggleQc = () => {
    if (qc) { setSheet('qcoff'); return; }
    QuickCapture.setEnabled({ enabled: true }).catch(() => {}); setQc(true); notify({ message: 'Quick Capture is on.' });
  };
  const toggleContrast = () => {
    const next = !contrast;
    try { localStorage.setItem(CONTRAST_KEY, next ? 'high' : 'normal'); } catch { /* ignore */ }
    document.documentElement.setAttribute('data-contrast', next ? 'high' : 'normal'); setContrast(next);
  };
  const allowNotifications = async () => { try { await attemptEnableNotifications(); } catch { /* dismissed */ } setNotif(await getNotificationPermissionStatus().catch(() => null)); };
  const saveName = async () => {
    if (!name.trim() || saving) return; setSaving(true);
    const r = await updateDisplayName(name); setSaving(false);
    if (r.success) { setSheet(null); notify({ message: 'Name updated.' }); } else showToast(r.error || 'Could not update name');
  };
  const onPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]; e.target.value = ''; if (!f) return;
    setUploading(true); const r = await updatePhoto(f); setUploading(false);
    if (r.success) notify({ message: 'Profile photo updated.' }); else showToast(r.error || 'Could not upload photo');
  };
  const signOut = async () => { const r = await signOutUser(); notify({ message: r.success ? 'Signed out.' : r.error || 'Sign out failed — please try again.' }); };

  const notifStatus = notif === null ? null : <span className="qs-status" data-ok={notif === 'granted'}>{notif === 'granted' ? '✓ On' : notif === 'denied' ? '! Blocked' : '! Off'}</span>;

  return (
    <div className="qs-screen">
      <header className="qs-screen-head">
        <button className="qs-back" onClick={onBack}><ChevronLeft size={20} />Back</button>
        <h1 className="qs-title">Profile & settings</h1>
      </header>

      <section className="qs-group" aria-labelledby="qs-g1">
        <p className="qs-group__title" id="qs-g1">Account and sync</p>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '4px 0 8px' }}>
          <span className="qs-avatar" style={{ width: 64, height: 64, fontSize: 24 }}>{user?.photoURL ? <img src={user.photoURL} alt="" /> : initial}</span>
          <div style={{ minWidth: 0 }}>
            <p className="qs-body" style={{ fontWeight: 650 }}>{displayName}</p>
            <p className="qs-meta">{user?.email || 'Not signed in'}</p>
          </div>
        </div>
        <Row icon={user ? <Cloud size={20} /> : <Smartphone size={20} />} label={user ? 'Synced to your account' : 'Saved on this device only'}
          note={`${liveCount} ${liveCount === 1 ? 'memory' : 'memories'}${user ? '' : ' — sign in to keep them safe and sync'}`} />
        {user ? (
          <>
            <Row icon={<Camera size={20} />} label="Edit name and photo" onClick={() => { setName(user.displayName || ''); setSheet('edit'); }} />
            <Row icon={<LogOut size={20} />} label="Sign out" onClick={signOut} />
          </>
        ) : (
          <div style={{ display: 'flex', gap: 8, padding: '8px 0' }}>
            <button className="qs-btn qs-btn--primary" onClick={() => openAuthModal('create')}>Create account</button>
            <button className="qs-btn qs-btn--secondary" onClick={() => openAuthModal('signin')}>Sign in</button>
          </div>
        )}
      </section>

      <section className="qs-group" aria-labelledby="qs-g2">
        <p className="qs-group__title" id="qs-g2">Capture and understanding</p>
        <Row icon={<Zap size={20} />} label="Quick Capture" note="Save from the notification shade without opening Later" status={<span className="qs-status" data-ok={qc}>{qc ? '✓ On' : 'Off'}</span>} onClick={toggleQc} />
      </section>

      <section className="qs-group" aria-labelledby="qs-g3">
        <p className="qs-group__title" id="qs-g3">Returning memories</p>
        <Row icon={<Bell size={20} />} label="Notifications" note={notif === 'granted' ? 'Reminders can reach you' : notif === 'denied' ? 'Blocked — reminders can’t reach you. Open settings to allow.' : 'Needed so memories can return on time'}
          status={notifStatus} onClick={notif === 'denied' ? () => void openNotificationSettings() : notif === 'granted' ? () => void openNotificationSettings() : () => void allowNotifications()} />
        <Row icon={<AlarmClock size={20} />} label="Exact-time reminders" note="Lets reminders arrive at the exact minute you chose" onClick={() => void openExactAlarmSettings()} />
      </section>

      <section className="qs-group" aria-labelledby="qs-g4">
        <p className="qs-group__title" id="qs-g4">Appearance and accessibility</p>
        <Row icon={theme === 'dark' ? <Moon size={20} /> : <Sun size={20} />} label="Theme" note={theme === 'dark' ? 'Dark' : 'Light'} onClick={toggleTheme} />
        <Row icon={<Contrast size={20} />} label="High contrast" note="Stronger text and borders" status={<span className="qs-status" data-ok={contrast}>{contrast ? '✓ On' : 'Off'}</span>} onClick={toggleContrast} />
        <p className="qs-meta" style={{ padding: '8px 0' }}>Text size and reduced motion follow your device’s accessibility settings.</p>
      </section>

      <section className="qs-group" aria-labelledby="qs-g5">
        <p className="qs-group__title" id="qs-g5">Data and privacy</p>
        <Row icon={<Trash2 size={20} />} tone="danger" label={user ? 'Delete all my memories' : 'Reset memories on this device'} note="Permanent. Archive is reversible; this is not." onClick={() => setSheet('reset')} />
      </section>

      <section className="qs-group" aria-labelledby="qs-g6">
        <p className="qs-group__title" id="qs-g6">Help and about</p>
        <Row icon={<HelpCircle size={20} />} label="Help & FAQ" onClick={onOpenHelp} />
        <Row icon={<PlayCircle size={20} />} label="Show the tips again" onClick={onReplayTour} />
        <Row icon={<Mail size={20} />} label="Send feedback" href="mailto:godsfavorite903@gmail.com?subject=Later%20app%20feedback" />
        <Row icon={<Info size={20} />} label="About Later" onClick={() => setSheet('about')} />
      </section>

      <Sheet open={sheet === 'edit'} onClose={() => setSheet(null)} title="Edit profile">
        <div>
          <label className="qs-label-text" htmlFor="qs-name">Display name</label>
          <input id="qs-name" className="qs-field" data-autofocus value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <button className="qs-btn qs-btn--secondary" onClick={() => fileRef.current?.click()} disabled={uploading}><Camera size={18} />{uploading ? 'Uploading…' : 'Change photo'}</button>
        <input ref={fileRef} type="file" accept="image/*" hidden onChange={onPhoto} />
        <button className="qs-btn qs-btn--primary qs-btn--block" disabled={!name.trim() || saving} onClick={saveName}>{saving ? 'Saving…' : 'Save'}</button>
      </Sheet>

      <Sheet open={sheet === 'qcoff'} onClose={() => setSheet(null)} title="Turn off Quick Capture?">
        <p className="qs-body">This only removes the persistent “Quick capture” notification. Your reminder notifications and Later’s notification permission are not affected. You can turn it back on here any time.</p>
        <button className="qs-btn qs-btn--danger qs-btn--block" onClick={() => { QuickCapture.setEnabled({ enabled: false }).catch(() => {}); setQc(false); setSheet(null); notify({ message: 'Quick Capture is off.' }); }}>Turn off</button>
        <button className="qs-btn qs-btn--secondary qs-btn--block" onClick={() => setSheet(null)}>Keep it on</button>
      </Sheet>

      <Sheet open={sheet === 'reset'} onClose={() => setSheet(null)} title={user ? 'Delete all memories?' : 'Reset memories?'}>
        <p className="qs-body">{user ? `All ${liveCount} memories will be permanently deleted from your account and this device. This can’t be undone.` : 'Memories on this device will be reset to the sample set. This can’t be undone.'}</p>
        <button className="qs-btn qs-btn--danger qs-btn--block" onClick={() => { setSheet(null); void resetData(); }}>{user ? 'Delete everything' : 'Reset'}</button>
        <button className="qs-btn qs-btn--secondary qs-btn--block" onClick={() => setSheet(null)}>Cancel</button>
      </Sheet>

      <Sheet open={sheet === 'about'} onClose={() => setSheet(null)} title="About Later">
        <p className="qs-body">Later is a memory inbox. Save the thought now; Later helps with the right moment. Your original words are always kept exactly as you wrote them.</p>
      </Sheet>
    </div>
  );
};
