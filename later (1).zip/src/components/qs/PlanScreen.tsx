import React, { useMemo, useState } from 'react';
import { Check, ChevronLeft, ChevronRight, MoreHorizontal, CalendarClock } from 'lucide-react';
import { useLater } from '../../context/LaterContext';
import { SavedItem } from '../../types';
import { describeReturn, getMemoryText, getScheduledAt, isActionMemory, isSameDay, typeLabel } from '../../utils/memoryView';
import { EmptyState, SectionHead } from './parts';
import { useMemoryActions, useMemoryUi } from './memoryUi';
import { ReturnMark } from './brand';
import { useNow } from './hooks';

type PlanTab = 'upcoming' | 'today' | 'calendar';
const timeOf = (d: Date) => d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
const dayLabel = (d: Date, now: Date) => {
  const t = new Date(now); t.setDate(now.getDate() + 1);
  if (isSameDay(d, now)) return 'Today';
  if (isSameDay(d, t)) return 'Tomorrow';
  return d.toLocaleDateString(undefined, { weekday: 'long' });
};

/** One entry on the return timeline. The node is a shape + a text label, never colour alone. */
const TimelineRow: React.FC<{ item: SavedItem; now: Date }> = ({ item, now }) => {
  const actions = useMemoryActions();
  const ui = useMemoryUi();
  const ret = describeReturn(item, now);
  const at = getScheduledAt(item);
  const state = ret.kind === 'done' ? 'done' : ret.kind === 'due' ? 'due' : 'waiting';
  const text = getMemoryText(item);
  const verb = ret.kind === 'due' ? 'Keep' : ret.kind === 'done' ? 'Undo' : isActionMemory(item) ? 'Mark done' : 'Change time';
  const onVerb = () => (ret.kind === 'due' ? actions.keep(item) : ret.kind === 'done' || isActionMemory(item) ? actions.toggleDone(item) : ui.openTime(item, 'choose'));
  return (
    <li className="qs-tl" data-state={state}>
      <span className="qs-tl__time">{at ? timeOf(at) : ''}</span>
      <span className="qs-tl__node" aria-hidden="true">{state === 'done' && <Check size={9} strokeWidth={4} />}</span>
      <div className="qs-tl__body">
        <button type="button" className="qs-row__text" onClick={() => actions.open(item)}>{text}</button>
        <button type="button" className="qs-row__state" data-kind={ret.kind} onClick={onVerb}>
          {ret.kind === 'due' && <ReturnMark size={16} />}
          <span>{ret.kind === 'due' ? 'Returning now' : ret.kind === 'done' ? 'Done' : 'Returns'}</span>
          <span className="qs-row__verb">· {verb}</span>
        </button>
        <span className="qs-row__meta"><span>{typeLabel(item)}</span>{(item.postponeCount || 0) > 0 && <span>Snoozed {item.postponeCount}×</span>}</span>
      </div>
      <button type="button" className="qs-btn qs-btn--icon" aria-label={`More actions for ${text.slice(0, 40)}`} onClick={() => ui.openMenu(item)}><MoreHorizontal size={22} /></button>
    </li>
  );
};

const Timeline: React.FC<{ items: SavedItem[]; now: Date; label: string }> = ({ items, now, label }) => (
  <ul className="qs-timeline" aria-label={label}>{items.map((i) => <TimelineRow key={i.id} item={i} now={now} />)}</ul>
);

export const PlanScreen: React.FC = () => {
  const { items } = useLater();
  const now = useNow();
  const [tab, setTab] = useState<PlanTab>('upcoming');
  const [month, setMonth] = useState(() => new Date(now.getFullYear(), now.getMonth(), 1));
  const [selected, setSelected] = useState<Date>(() => new Date());

  const scheduled = useMemo(() => items.filter((i) => !i.isArchived && getScheduledAt(i)).sort((a, b) => getScheduledAt(a)!.getTime() - getScheduledAt(b)!.getTime()), [items]);
  const open = scheduled.filter((i) => !i.isDone);
  const dueNow = open.filter((i) => getScheduledAt(i)!.getTime() <= now.getTime());
  const future = open.filter((i) => getScheduledAt(i)!.getTime() > now.getTime());
  const returningCount = open.length;

  const groups = useMemo(() => {
    const m = new Map<string, { date: Date; items: SavedItem[] }>();
    future.forEach((i) => { const d = getScheduledAt(i)!; const k = d.toDateString(); if (!m.has(k)) m.set(k, { date: d, items: [] }); m.get(k)!.items.push(i); });
    return [...m.values()];
  }, [future]);

  const todayItems = scheduled.filter((i) => isSameDay(getScheduledAt(i)!, now));
  const todayDue = todayItems.filter((i) => !i.isDone && getScheduledAt(i)!.getTime() <= now.getTime());
  const todayLater = todayItems.filter((i) => !i.isDone && getScheduledAt(i)!.getTime() > now.getTime());
  const todayDone = todayItems.filter((i) => i.isDone);

  const countOn = (d: Date) => open.filter((i) => isSameDay(getScheduledAt(i)!, d)).length;
  const selectedItems = scheduled.filter((i) => isSameDay(getScheduledAt(i)!, selected));
  const first = new Date(month.getFullYear(), month.getMonth(), 1);
  const dim = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const cells: (Date | null)[] = [...Array(first.getDay()).fill(null), ...Array.from({ length: dim }, (_, i) => new Date(month.getFullYear(), month.getMonth(), i + 1))];

  const tabs: { key: PlanTab; label: string }[] = [{ key: 'upcoming', label: 'Upcoming' }, { key: 'today', label: 'Today' }, { key: 'calendar', label: 'Calendar' }];

  return (
    <div className="qs-screen">
      <header className="qs-screen-head">
        <h1 className="qs-title">Returning soon</h1>
        <p className="qs-meta">{returningCount} {returningCount === 1 ? 'memory' : 'memories'} returning</p>
      </header>

      <div className="qs-tabs" role="tablist" aria-label="Plan views">
        {tabs.map((t) => <button key={t.key} role="tab" aria-selected={tab === t.key} className="qs-tabs__tab" onClick={() => setTab(t.key)}>{t.label}</button>)}
      </div>

      {tab === 'upcoming' && (
        <>
          {open.length === 0 && <EmptyState icon={<CalendarClock size={22} />} title="Nothing is set to return" body="When you save something with a time — “dentist Friday 3pm” — it will appear here on its day." />}
          {dueNow.length > 0 && <section className="qs-section"><SectionHead title="Returning now" meta="Set for earlier — still waiting for you" /><Timeline items={dueNow} now={now} label="Returning now" /></section>}
          {groups.map((g) => (
            <section className="qs-day" key={g.date.toDateString()}>
              <p className="qs-day__label"><span>{dayLabel(g.date, now)}</span><span className="qs-meta">{g.date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} · {g.items.length}</span></p>
              <Timeline items={g.items} now={now} label={`Returning ${dayLabel(g.date, now)}`} />
            </section>
          ))}
        </>
      )}

      {tab === 'today' && (
        <>
          {todayItems.length === 0 && <EmptyState icon={<CalendarClock size={22} />} title="Nothing returns today" body="Memories set for today show up here — including ones you’ve already handled." />}
          {todayDue.length > 0 && <section className="qs-section"><SectionHead title="Returning now" /><Timeline items={todayDue} now={now} label="Returning now" /></section>}
          {todayLater.length > 0 && <section className="qs-section"><SectionHead title="Later today" /><Timeline items={todayLater} now={now} label="Later today" /></section>}
          {todayDone.length > 0 && <section className="qs-section"><SectionHead title="Done today" /><Timeline items={todayDone} now={now} label="Done today" /></section>}
        </>
      )}

      {tab === 'calendar' && (
        <>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <button className="qs-btn qs-btn--icon" aria-label="Previous month" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))}><ChevronLeft size={22} /></button>
            <h2 className="qs-section-title" aria-live="polite">{month.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}</h2>
            <button className="qs-btn qs-btn--icon" aria-label="Next month" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))}><ChevronRight size={22} /></button>
          </div>
          <div className="qs-cal" role="grid" aria-label="Calendar">
            {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => <span key={i} className="qs-cal__dow" aria-hidden="true">{d}</span>)}
            {cells.map((d, i) => {
              if (!d) return <span key={`e${i}`} />;
              const c = countOn(d);
              const isSel = isSameDay(d, selected);
              return (
                <button key={i} type="button" className="qs-cal__day" data-today={isSameDay(d, now)} aria-pressed={isSel}
                  aria-label={`${d.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}${c ? `, ${c} ${c === 1 ? 'memory' : 'memories'} returning` : ', nothing returning'}`}
                  onClick={() => setSelected(d)}>
                  <span>{d.getDate()}</span>{c > 0 && <span className="qs-cal__count" aria-hidden="true">{c}</span>}
                </button>
              );
            })}
          </div>
          <section className="qs-section" aria-live="polite">
            <SectionHead title={selected.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })} meta={selectedItems.length ? `${selectedItems.length} returning` : 'Nothing returning this day'} />
            {selectedItems.length > 0 && <Timeline items={selectedItems} now={now} label="Selected day" />}
          </section>
        </>
      )}
    </div>
  );
};
