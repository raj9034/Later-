import { ReturningEntry } from '../../utils/returningNow';
export type ReturnEntry = ReturningEntry;
export type Destination = 'inbox' | 'find' | 'plan' | 'library';
