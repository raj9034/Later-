import React from 'react';
import { ArrowUp, Image as ImageIcon, ClipboardPaste, Mic, Square, X, PenLine } from 'lucide-react';
import { SavedItem } from '../../types';
import { friendlyWhen } from '../../utils/memoryView';
import { Chip } from './parts';
import { ReturnMark } from './brand';
import { useBackLayer } from './backStack';
import { useCaptureComposer } from './useCaptureComposer';

/**
 * CaptureDock — the persistent capture entry, docked above the navigation.
 * Collapsed: a single "Remember something" bar (+ voice). Expanded: multiline
 * field, live "what I understood" chip from the real parser, attach / paste /
 * voice, and ONE primary action: Remember. No priority / type / tag /
 * collection / scheduling controls before save.
 */
export const CaptureDock: React.FC<{ onSaved?: (item: SavedItem) => void; onOpenChange?: (open: boolean) => void }> = ({ onSaved, onOpenChange }) => {
  const c = useCaptureComposer(onSaved);
  useBackLayer(c.open, c.close);
  React.useEffect(() => { onOpenChange?.(c.open); }, [c.open, onOpenChange]);
  React.useEffect(() => { if (c.open) window.setTimeout(() => c.textareaRef.current?.focus(), 30); }, [c.open]); // eslint-disable-line react-hooks/exhaustive-deps

  const onKey = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Escape') { c.close(); return; }
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); c.save(); }
  };

  return (
    <>
      {c.open && <button className="qs-scrim" aria-label="Close capture" tabIndex={-1} onClick={c.close} />}
      <section className="qs-dock" aria-label="Capture">
        <div className="qs-dock__surface">
          {!c.open ? (
            <div className="qs-dock__bar">
              <button type="button" className="qs-dock__prompt" onClick={() => c.setOpen(true)}>
                <span className="qs-sr">Open capture. </span>Remember something…
              </button>
              {c.voiceSupported && (
                <button type="button" className="qs-btn qs-btn--icon" aria-label="Capture by voice" onClick={() => { c.setOpen(true); void c.toggleVoice(); }}><Mic size={22} /></button>
              )}
              <button type="button" className="qs-btn qs-btn--primary qs-btn--icon" aria-label="Write a memory" onClick={() => c.setOpen(true)}><PenLine size={20} /></button>
            </div>
          ) : (
            <div className="qs-dock__panel">
              <label className="qs-sr" htmlFor="qs-capture-field">What do you want to remember?</label>
              <textarea
                id="qs-capture-field" ref={c.textareaRef} className="qs-dock__field" rows={2} value={c.content}
                placeholder="What do you want to remember?" onChange={(e) => { c.setContent(e.target.value); c.setIgnoreDetected(false); }} onKeyDown={onKey}
              />
              {(c.image || c.detected || c.listening) && (
                <div className="qs-dock__preview">
                  {c.image && (
                    <div className="qs-dock__image"><img src={c.image} alt="Attached" /><button type="button" aria-label="Remove image" onClick={() => c.setImage(null)}><X size={16} /></button></div>
                  )}
                  {c.listening && <span className="qs-listening" role="status"><span className="qs-listening__dot" />Listening…</span>}
                  {c.detected && (
                    <Chip kind="time" icon={<ReturnMark size={14} />} onRemove={() => c.setIgnoreDetected(true)} removeLabel="Don’t schedule this">
                      Returns {friendlyWhen(new Date(c.detected.scheduledAt))}
                    </Chip>
                  )}
                </div>
              )}
              <div className="qs-dock__tools">
                <button type="button" className="qs-btn qs-btn--icon" aria-label="Attach an image" onClick={() => c.fileRef.current?.click()}><ImageIcon size={22} /></button>
                <button type="button" className="qs-btn qs-btn--icon" aria-label="Paste from clipboard" onClick={() => void c.paste()}><ClipboardPaste size={22} /></button>
                {c.voiceSupported && (
                  <button type="button" className="qs-btn qs-btn--icon" data-active={c.listening} aria-pressed={c.listening} aria-label={c.listening ? 'Stop voice capture' : 'Capture by voice'} onClick={() => void c.toggleVoice()}>
                    {c.listening ? <Square size={20} /> : <Mic size={22} />}
                  </button>
                )}
                <span className="qs-dock__spacer" />
                <button type="button" className="qs-btn qs-btn--primary" disabled={!c.canSave} onClick={c.save}>Remember <ArrowUp size={18} /></button>
              </div>
              <input ref={c.fileRef} type="file" accept="image/*" hidden onChange={c.onFile} />
            </div>
          )}
        </div>
      </section>
    </>
  );
};
