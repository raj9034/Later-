import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { useLater } from '../../context/LaterContext';
import { parseNaturalDateTime } from '../../utils/naturalLanguageTime';
import { ItemReminder, SavedItem } from '../../types';

/**
 * The capture contract: ONE composer behaviour for the in-app dock.
 * It is a port of the previous UniversalCapture logic — same share-sheet
 * prefill, same image/clipboard/voice handling, same call into saveItem() —
 * minus the pre-save priority/scheduler controls (timing is written naturally;
 * everything else is adjustable AFTER saving). The raw capture is saved
 * immediately and the composer clears without waiting for interpretation.
 */
export function useCaptureComposer(onSaved?: (item: SavedItem) => void) {
  const { saveItem, sharedPrefill, setSharedPrefill, showToast } = useLater();
  const [open, setOpen] = useState(false);
  const [content, setContent] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [ignoreDetected, setIgnoreDetected] = useState(false);
  const [listening, setListening] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  // Android share sheet pre-fill: open the dock with the shared text / image.
  useEffect(() => {
    if (!sharedPrefill) return;
    if (sharedPrefill.text) { setContent(sharedPrefill.text); setIgnoreDetected(false); }
    if (sharedPrefill.image) setImage(sharedPrefill.image);
    setOpen(true);
    window.setTimeout(() => textareaRef.current?.focus(), 150);
    setSharedPrefill(null);
  }, [sharedPrefill, setSharedPrefill]);

  // Live "what I understood" preview from the SAME parser the pipeline uses.
  const detected = useMemo(() => {
    if (!content.trim() || ignoreDetected) return null;
    const res = parseNaturalDateTime(content);
    return res.hasExplicitTime ? res : null;
  }, [content, ignoreDetected]);

  const canSave = !!content.trim() || !!image;

  const save = useCallback(() => {
    const trimmed = content.trim();
    if (!trimmed && !image) return;
    const reminder: ItemReminder | undefined = ignoreDetected ? { type: 'none', reminderStatus: 'waiting' } : undefined;
    try {
      const saved = saveItem(trimmed, image || undefined, reminder, undefined);
      setContent(''); setImage(null); setIgnoreDetected(false); setOpen(false);
      onSaved?.(saved);
    } catch (err) {
      // Never lose what the user typed: keep it in the field and say so.
      console.error('Save failed in CaptureDock:', err);
      showToast('Couldn’t save just now — your text is still here. Try again.');
    }
  }, [content, image, ignoreDetected, saveItem, onSaved, showToast]);

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => { if (ev.target?.result) setImage(ev.target.result as string); };
    reader.readAsDataURL(file);
  };

  const paste = async () => {
    try {
      if (!navigator.clipboard) return;
      const clip = await navigator.clipboard.read().catch(() => null);
      if (clip) {
        for (const it of clip) {
          const type = it.types.find((t) => t.startsWith('image/'));
          if (type) {
            const blob = await it.getType(type);
            const reader = new FileReader();
            reader.onload = (ev) => { if (ev.target?.result) setImage(ev.target.result as string); };
            reader.readAsDataURL(blob);
            return;
          }
        }
      }
      const text = await navigator.clipboard.readText();
      if (text) { setContent((p) => (p ? `${p} ${text}` : text)); setIgnoreDetected(false); }
    } catch { /* clipboard permission denied: nothing to paste */ }
  };

  /* ------------------------------------------------------------- voice */
  const speechRef = useRef<{ remove: () => Promise<void> } | null>(null);
  const errRef = useRef<{ remove: () => Promise<void> } | null>(null);
  const baseline = useRef('');
  const voiceSupported = Capacitor.isNativePlatform();

  const cleanup = async () => {
    await speechRef.current?.remove(); await errRef.current?.remove();
    speechRef.current = null; errRef.current = null;
  };
  const stopVoice = useCallback(async () => {
    try { const { SpeechRecognition } = await import('@capgo/capacitor-speech-recognition'); await SpeechRecognition.stop(); } catch { /* already stopped */ }
    await cleanup(); setListening(false);
  }, []);
  const toggleVoice = async () => {
    if (!voiceSupported) return;
    if (listening) { await stopVoice(); return; }
    try {
      const { SpeechRecognition } = await import('@capgo/capacitor-speech-recognition');
      const { available } = await SpeechRecognition.available();
      if (!available) { showToast('Voice input isn’t available on this device.'); return; }
      const perm = await SpeechRecognition.requestPermissions();
      if (perm.speechRecognition !== 'granted') { showToast('Microphone permission is needed for voice input.'); return; }
      baseline.current = content;
      setListening(true);
      speechRef.current = await SpeechRecognition.addListener('partialResults', (d: { matches?: string[] }) => {
        const partial = d.matches?.[0];
        if (!partial) return;
        setContent(baseline.current ? `${baseline.current} ${partial}` : partial);
        setIgnoreDetected(false);
      });
      errRef.current = await SpeechRecognition.addListener('error', (ev: { message?: string }) => {
        showToast(ev?.message ? `Voice input error: ${ev.message}` : 'Voice input stopped. Please try again.');
        setListening(false); void cleanup();
      });
      await SpeechRecognition.start({ popup: false, partialResults: true, maxResults: 1 });
    } catch (e) {
      console.error('Voice capture error:', e);
      showToast('Couldn’t start voice input. Please try again.');
      setListening(false); await cleanup();
    }
  };

  useEffect(() => () => { void stopVoice(); }, [stopVoice]);

  // Auto-grow the field up to its CSS max-height.
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, window.innerHeight * 0.38)}px`;
  }, [content, open]);

  const close = useCallback(() => { setOpen(false); void stopVoice(); }, [stopVoice]);

  return { open, setOpen, close, content, setContent, image, setImage, detected, setIgnoreDetected, listening, voiceSupported, canSave, save, onFile, paste, toggleVoice, textareaRef, fileRef };
}
