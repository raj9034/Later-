import React, { useMemo, useState } from 'react';
import { Check, Clock, SlidersHorizontal, ArrowRight, Inbox as InboxIcon, X, Hash, MapPin, User } from 'lucide-react';
import { useLater } from '../../context/LaterContext';
import { SavedItem, SwipeView } from '../../types';
import { pickReturningNow } from '../../utils/returningNow';
import { describeReturn, getClarification, getInterpretationChips, getMemoryText, matchesTypeView, TYPE_VIEW_LABEL } from '../../utils/memoryView';
import { MemoryRows, ReturnCard } from './MemoryRow';
import { Chip, EmptyState, Notice, SectionHead, Skeleton } from './parts';
import { Sheet } from './sheet';
import { useMemoryUi } from './memoryUi';
import { ReturnMark } from './brand';
import { useNow } from './hooks';

const FILTERS: SwipeView[] = ['ALL', 'NOTES', 'LINKS', 'SCREENSHOTS', 'TASKS', 'PEOPLE', 'PLACES', 'URGENT', 'IMPORTANT', 'CHILL'];

/** Visible capture state for the memory you just saved: saved → understood as → (one question) → return time. */
const CaptureStateCard: React.FC<{ item: SavedItem; onDismiss: () => void }> = ({ item, onDismiss }) => {
  const ui = useMemoryUi();
  const now = useNow();
  const ret = describeReturn(item, now);
  const clar = getClarification(item, now);
  const chips = getInterpretationChips(item, now).filter((c) => c.kind !== 'type');
  return (
    <section className="qs-return-card" data-tone="signal" aria-label="Just saved" role="status">
      <p className="qs-return-card__why" style={{ color: 'var(--qs-signal-text)' }}><Check size={16} /><span>Saved · understood as</span></p>
      <p className="qs-body" style={{ fontWeight: 600, overflowWrap: 'anywhere' }}>{getMemoryText(item).slice(0, 160)}</p>
      <div className="qs-chips">
        {chips.length === 0 && <Chip>No details detected — your text is saved as written</Chip>}
        {chips.map((c, i) => (
          <Chip key={i} kind={c.kind === 'time' ? 'time' : c.kind === 'topic' ? 'signal' : 'info'} icon={c.kind === 'time' ? <ReturnMark size={14} /> : c.kind === 'place' ? <MapPin size={14} /> : c.kind === 'person' ? <User size={14} /> : c.kind === 'topic' ? <Hash size={14} /> : undefined}>{c.label}</Chip>
        ))}
      </div>
      {clar && <Notice tone="return" icon={<Clock size={18} />}><p>{clar.question}</p></Notice>}
      <div className="qs-return-card__actions">
        <button className="qs-btn qs-btn--secondary" onClick={() => ui.openTime(item, 'choose')}><Clock size={17} />{ret.kind === 'none' ? 'Choose a time' : 'Change time'}</button>
        <button className="qs-btn qs-btn--quiet" onClick={() => ui.openMenu(item)}>More</button>
        <span style={{ flex: 1 }} />
        <button className="qs-btn qs-btn--icon" aria-label="Dismiss" onClick={onDismiss}><X size={20} /></button>
      </div>
    </section>
  );
};

export const InboxScreen: React.FC<{ latest: SavedItem | null; onDismissLatest: () => void; onOpenLibrary: () => void }> = ({ latest, onDismissLatest, onOpenLibrary }) => {
  const { items, activeSwipeView, setActiveSwipeView, isSyncing, setSharedPrefill } = useLater();
  const now = useNow();
  const [filterOpen, setFilterOpen] = useState(false);

  const live = useMemo(() => items.filter((i) => !i.isArchived), [items]);
  const returning = useMemo(() => pickReturningNow(live, now, 3), [live, now]);
  const latestFresh = latest ? live.find((i) => i.id === latest.id) : null;
  const returningIds = new Set(returning.map((r) => r.item.id));
  const recent = useMemo(
    () => live.filter((i) => matchesTypeView(i, activeSwipeView) && !returningIds.has(i.id) && i.id !== latestFresh?.id)
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()).slice(0, 12),
    [live, activeSwipeView, returning, latestFresh] // eslint-disable-line react-hooks/exhaustive-deps
  );

  const n = returning.length;
  const headline = live.length === 0 ? 'Your memory is clear.' : n > 0 ? `${n} ${n === 1 ? 'memory is' : 'memories are'} returning.` : 'Nothing needs you right now.';

  return (
    <div className="qs-screen">
      <header className="qs-screen-head">
        <h1 className="qs-display">{headline}</h1>
        <p className="qs-meta">{live.length === 0 ? 'Capture something you want back later.' : `${live.length} ${live.length === 1 ? 'memory' : 'memories'} saved`}</p>
      </header>

      {latestFresh && <CaptureStateCard item={latestFresh} onDismiss={onDismissLatest} />}

      {isSyncing && live.length === 0 && <Skeleton rows={3} />}

      {!isSyncing && live.length === 0 && (
        <EmptyState
          icon={<InboxIcon size={22} />} title="Nothing saved yet"
          body="Type a thought, paste a link, or say it out loud. You don’t need to organize anything first."
          action={<button className="qs-btn qs-btn--secondary" onClick={() => setSharedPrefill({ text: 'Call mom this weekend' })}>Try “Call mom this weekend”</button>}
        />
      )}

      {returning.length > 0 && (
        <section className="qs-section" aria-labelledby="qs-returning">
          <SectionHead id="qs-returning" title="Returning now" meta="A small set, with the reason each is here" />
          <div className="qs-returns">{returning.map((e) => <ReturnCard key={e.item.id} entry={e} now={now} />)}</div>
        </section>
      )}

      {live.length > 0 && (
        <section className="qs-section" aria-labelledby="qs-recent">
          <SectionHead
            id="qs-recent" title="Recently captured"
            action={<button className="qs-btn qs-btn--quiet" onClick={() => setFilterOpen(true)}><SlidersHorizontal size={17} />Filter</button>}
          />
          {activeSwipeView !== 'ALL' && (
            <div className="qs-chips"><Chip selected onRemove={() => setActiveSwipeView('ALL')} removeLabel="Clear filter">{TYPE_VIEW_LABEL[activeSwipeView]}</Chip></div>
          )}
          {recent.length === 0
            ? <EmptyState icon={<SlidersHorizontal size={22} />} title="Nothing matches this filter" body="Clear the filter to see everything you’ve saved." action={<button className="qs-btn qs-btn--secondary" onClick={() => setActiveSwipeView('ALL')}>Clear filter</button>} />
            : <MemoryRows items={recent} label="Recently captured" now={now} />}
          <button className="qs-btn qs-btn--quiet" style={{ alignSelf: 'flex-start' }} onClick={onOpenLibrary}>All memories <ArrowRight size={16} /></button>
        </section>
      )}

      <Sheet open={filterOpen} onClose={() => setFilterOpen(false)} title="Filter recent memories">
        <div className="qs-chips" role="group" aria-label="Filter by">
          {FILTERS.map((f) => (
            <Chip key={f} selected={activeSwipeView === f} onClick={() => { setActiveSwipeView(f); setFilterOpen(false); }}>{TYPE_VIEW_LABEL[f]}</Chip>
          ))}
        </div>
        <p className="qs-meta">Filters only narrow this list. To search everything, use Find.</p>
      </Sheet>
    </div>
  );
};
