import React from 'react';
import { X } from 'lucide-react';

export const EmptyState: React.FC<{ icon: React.ReactNode; title: string; body?: string; action?: React.ReactNode }> = ({ icon, title, body, action }) => (
  <div className="qs-empty">
    <div className="qs-empty__icon" aria-hidden="true">{icon}</div>
    <p className="qs-empty__title">{title}</p>
    {body && <p className="qs-empty__body">{body}</p>}
    {action}
  </div>
);

export const SectionHead: React.FC<{ title: string; meta?: React.ReactNode; action?: React.ReactNode; id?: string }> = ({ title, meta, action, id }) => (
  <div className="qs-section__head">
    <div>
      <h2 className="qs-section-title" id={id}>{title}</h2>
      {meta && <p className="qs-meta">{meta}</p>}
    </div>
    {action}
  </div>
);

type ChipKind = 'time' | 'info' | 'signal' | 'attention' | undefined;
export const Chip: React.FC<{ children: React.ReactNode; icon?: React.ReactNode; kind?: ChipKind; onRemove?: () => void; removeLabel?: string; selected?: boolean; onClick?: () => void }> = ({ children, icon, kind, onRemove, removeLabel, selected, onClick }) => {
  const cls = `qs-chip ${kind ? `qs-chip--${kind}` : ''}`;
  if (onClick) return <button type="button" className={cls} aria-pressed={selected} onClick={onClick}>{icon}{children}</button>;
  return (
    <span className={cls} data-selected={selected}>
      {icon}{children}
      {onRemove && <button type="button" className="qs-chip__x" aria-label={removeLabel || 'Remove'} onClick={onRemove}><X size={14} /></button>}
    </span>
  );
};

export const Skeleton: React.FC<{ rows?: number }> = ({ rows = 3 }) => (
  <div aria-busy="true" aria-label="Loading your memories" role="status" className="qs-rows">
    {Array.from({ length: rows }).map((_, i) => (
      <div key={i} className="qs-row" style={{ flexDirection: 'column', gap: 8 }}>
        <div className="qs-skel" style={{ height: 18, width: `${88 - i * 12}%` }} />
        <div className="qs-skel" style={{ height: 14, width: '42%' }} />
      </div>
    ))}
  </div>
);

export const Notice: React.FC<{ tone?: 'return' | 'danger'; icon?: React.ReactNode; children: React.ReactNode }> = ({ tone, icon, children }) => (
  <div className="qs-notice" data-tone={tone} role={tone === 'danger' ? 'alert' : undefined}>{icon}<div>{children}</div></div>
);
