import { useEffect, useRef, useState } from 'react';
import { OrbPoc, type OrbPocDiagnostics } from '../../lib/orbPoc';

/**
 * LATER ORB POC — EXPERIMENTAL, TEMPORARY.
 *
 * Reachable only via the URL hash "#orb-poc" (wired in App.tsx as one
 * isolated `if` block). Not part of normal navigation, not linked from
 * anywhere in the app UI. Exists solely to test whether a focusable
 * overlay can read the clipboard, and whether doing so disrupts the
 * app underneath. Delete this file + the App.tsx hash check + the two
 * native POC files to fully remove the experiment.
 */

const emptyDiagnostics: OrbPocDiagnostics = {
  androidVersion: '—',
  device: '—',
  overlayPermission: false,
  serviceRunning: false,
  foregroundServiceActive: false,
  overlayCreated: false,
  overlayFocus: false,
  clipboardListenerFired: false,
  hasPrimaryClip: false,
  getPrimaryClipSuccess: false,
  clipboardText: '',
  lastDetectionTimeMs: 0,
};

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-2.5 border-b border-[var(--border)] last:border-0">
      <span className="text-[13px] text-[var(--text-secondary)]">{label}</span>
      <span className="text-[13px] font-mono font-semibold text-[var(--text-primary)] text-right max-w-[60%] break-words">
        {value}
      </span>
    </div>
  );
}

function boolStr(v: boolean) {
  return v ? 'YES' : 'NO';
}

export default function OrbPocTestScreen() {
  const [diag, setDiag] = useState<OrbPocDiagnostics>(emptyDiagnostics);
  const [running, setRunning] = useState(false);
  const [overlayPermGranted, setOverlayPermGranted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const pollRef = useRef<number | null>(null);

  const refreshPermission = async () => {
    try {
      const res = await OrbPoc.checkOverlayPermission();
      setOverlayPermGranted(res.granted);
    } catch (e) {
      setError(String(e));
    }
  };

  const refreshDiagnostics = async () => {
    try {
      const d = await OrbPoc.getDiagnostics();
      setDiag(d);
      setRunning(d.serviceRunning);
    } catch (e) {
      setError(String(e));
    }
  };

  useEffect(() => {
    refreshPermission();
    refreshDiagnostics();
    pollRef.current = window.setInterval(refreshDiagnostics, 1500);
    return () => {
      if (pollRef.current) window.clearInterval(pollRef.current);
    };
  }, []);

  const handleEnable = async () => {
    setError(null);
    try {
      if (!overlayPermGranted) {
        await OrbPoc.requestOverlayPermission();
        return; // user needs to grant it in Settings, then come back and tap Enable again
      }
      await OrbPoc.startOrbTest();
      setRunning(true);
    } catch (e) {
      setError(String(e));
    }
  };

  const handleDisable = async () => {
    setError(null);
    try {
      await OrbPoc.stopOrbTest();
      setRunning(false);
      setDiag(emptyDiagnostics);
    } catch (e) {
      setError(String(e));
    }
  };

  const overallResult = (() => {
    if (!diag.clipboardListenerFired) return 'Not tested yet — copy something in another app';
    if (diag.getPrimaryClipSuccess && diag.overlayFocus) return 'A + B PASS — check underlying-app disruption manually';
    if (diag.getPrimaryClipSuccess && !diag.overlayFocus) return 'Clipboard read without focus (unexpected — recheck)';
    return 'FAIL — clipboard blocked';
  })();

  return (
    <div className="min-h-screen bg-[var(--bg)] px-5 pt-8 pb-10">
      <div className="mb-5">
        <p className="text-[11px] uppercase tracking-wide font-semibold text-[#D64545]">
          Temporary — experimental
        </p>
        <h1 className="text-[22px] font-bold text-[var(--text-primary)] mt-1">
          Orb POC Test
        </h1>
        <p className="text-[13px] text-[var(--text-secondary)] mt-1">
          Tests clipboard detection via a focusable overlay. Not the final Orb.
        </p>
      </div>

      {error && (
        <div className="mb-4 rounded-2xl bg-[#FDF1EF] border border-[#D64545]/20 px-4 py-3 text-[12px] text-[#D64545]">
          {error}
        </div>
      )}

      <div className="rounded-3xl border border-[var(--border)] bg-[var(--surface-elevated)] px-4 py-1 mb-5">
        <Row label="Android version" value={diag.androidVersion} />
        <Row label="Device" value={diag.device} />
        <Row label="Overlay permission" value={boolStr(overlayPermGranted)} />
        <Row label="Foreground service" value={boolStr(diag.foregroundServiceActive)} />
        <Row label="Overlay created" value={boolStr(diag.overlayCreated)} />
        <Row label="Overlay focus" value={boolStr(diag.overlayFocus)} />
        <Row label="Clipboard listener fired" value={boolStr(diag.clipboardListenerFired)} />
        <Row label="hasPrimaryClip" value={boolStr(diag.hasPrimaryClip)} />
        <Row label="getPrimaryClip" value={boolStr(diag.getPrimaryClipSuccess)} />
        <Row label="Clipboard text" value={diag.clipboardText || '(none)'} />
        <Row
          label="Last detection time"
          value={diag.lastDetectionTimeMs ? new Date(diag.lastDetectionTimeMs).toLocaleTimeString() : '(none)'}
        />
        <Row label="Underlying-app disruption" value="OBSERVE MANUALLY" />
      </div>

      <div className="rounded-2xl bg-[var(--surface-sunken)] px-4 py-3 mb-6">
        <p className="text-[11px] uppercase tracking-wide text-[var(--text-tertiary)] mb-1">
          Overall result
        </p>
        <p className="text-[14px] font-semibold text-[var(--text-primary)]">{overallResult}</p>
      </div>

      <div className="flex flex-col gap-3">
        <button
          type="button"
          onClick={handleEnable}
          disabled={running}
          className="w-full py-3.5 rounded-2xl bg-[var(--accent)] text-white font-semibold disabled:opacity-40"
        >
          {overlayPermGranted ? 'Enable Orb Test' : 'Grant overlay permission'}
        </button>
        <button
          type="button"
          onClick={handleDisable}
          disabled={!running}
          className="w-full py-3.5 rounded-2xl border border-[var(--border)] text-[var(--text-primary)] font-semibold disabled:opacity-40"
        >
          Disable Orb Test
        </button>
      </div>

      <p className="text-[11px] text-[var(--text-tertiary)] mt-6 leading-relaxed">
        Procedure: Enable Orb Test → grant "Display over other apps" if prompted →
        confirm Foreground service reads YES → leave Later → open YouTube/Chrome →
        copy a link or text → do NOT reopen Later → watch for the test bubble and
        watch whether YouTube/Chrome itself stutters, pauses, or loses keyboard
        focus → come back here to read the recorded diagnostics.
      </p>
    </div>
  );
}
