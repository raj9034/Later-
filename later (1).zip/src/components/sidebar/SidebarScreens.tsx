import React, { useMemo, useState } from 'react';
import { ChevronLeft, Search, User, MapPin, ChevronRight, Leaf } from 'lucide-react';
import { useLater } from '../../context/LaterContext';
import { SavedItem, UrgencyTag } from '../../types';
import { TimelineItemRow } from '../TimelineItemRow';
import { FilterChip } from '../ui/FilterChip';
import {
  SidebarView,
  isActive,
  isScheduledToday,
  isScheduledFuture,
  isUnscheduled,
  groupByCaptureDay,
  groupUpcoming,
  URGENCY_CHIP_LABELS,
  buildPeopleDirectory,
  buildPlacesDirectory,
  itemsForPerson,
  itemsForPlace,
} from './sidebarUtils';

interface ScreenShellProps {
  title: string;
  count: number;
  countNoun: string;
  onBack: () => void;
  onOpenSearch: () => void;
  children: React.ReactNode;
  filters?: React.ReactNode;
}

const ScreenShell: React.FC<ScreenShellProps> = ({
  title,
  count,
  countNoun,
  onBack,
  onOpenSearch,
  children,
  filters,
}) => {
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between gap-2 pb-3">
        <div className="flex items-center gap-2 min-w-0">
          <button
            type="button"
            onClick={onBack}
            className="w-9 h-9 shrink-0 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors cursor-pointer active:scale-95"
            aria-label="Back"
          >
            <ChevronLeft className="w-4.5 h-4.5" />
          </button>
          <div className="min-w-0">
            <h2 className="type-heading-lg font-semibold text-[var(--text-primary)] truncate">{title}</h2>
            <p className="type-caption text-[var(--text-secondary)]">
              {count} {countNoun}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onOpenSearch}
          className="w-9 h-9 shrink-0 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors cursor-pointer"
          aria-label="Search"
        >
          <Search className="w-4 h-4" />
        </button>
      </div>

      {filters && <div className="pb-3 -mx-1 overflow-x-auto no-scrollbar">{filters}</div>}

      <div className="flex-1 overflow-y-auto space-y-5 pb-6">{children}</div>
    </div>
  );
};

const EmptyRow: React.FC<{ label: string; description?: string }> = ({ label, description }) => (
  <div className="py-12">
    <p className="text-sm font-medium text-[var(--text-secondary)] text-center">{label}</p>
    {description && (
      <p className="text-xs text-[var(--text-tertiary)] mt-1 font-mono text-center">{description}</p>
    )}
  </div>
);

const GroupedItemList: React.FC<{ groups: { label: string; items: SavedItem[] }[] }> = ({ groups }) => {
  if (groups.length === 0) {
    return <EmptyRow label="Nothing here yet" description="Items will show up here once saved" />;
  }
  return (
    <>
      {groups.map((group) => (
        <div key={group.label} className="space-y-3">
          <div className="flex items-center gap-2.5 px-2.5 py-1.5 rounded-xl bg-[var(--surface-resting)]/90 border border-[var(--border-subtle)]/60">
            <span className="type-label text-[var(--text-primary)]">{group.label}</span>
            <div className="h-px flex-1 bg-[var(--divider)]" />
            <span className="type-caption text-[var(--text-tertiary)]">{group.items.length}</span>
          </div>
          <div className="space-y-3">
            {group.items.map((item, idx) => (
              <TimelineItemRow key={item.id} item={item} index={idx} />
            ))}
          </div>
        </div>
      ))}
    </>
  );
};

const FlatItemList: React.FC<{ items: SavedItem[]; emptyLabel: string; emptyDescription?: string }> = ({
  items,
  emptyLabel,
  emptyDescription,
}) => {
  if (items.length === 0) {
    return <EmptyRow label={emptyLabel} description={emptyDescription} />;
  }
  return (
    <div className="space-y-3">
      {items.map((item, idx) => (
        <TimelineItemRow key={item.id} item={item} index={idx} />
      ))}
    </div>
  );
};

type ContentFilter = 'all' | 'notes' | 'links' | 'screenshots';

const matchesContentFilter = (item: SavedItem, filter: ContentFilter): boolean => {
  if (filter === 'all') return true;
  const t = item.contentType || item.type;
  if (filter === 'notes') return t === 'note' || t === 'idea';
  if (filter === 'links') return t === 'link' || t === 'video' || t === 'product' || t === 'article';
  if (filter === 'screenshots') return t === 'screenshot' || t === 'image';
  return true;
};

const AllMemoriesScreen: React.FC<{ onBack: () => void; onOpenSearch: () => void }> = ({
  onBack,
  onOpenSearch,
}) => {
  const { items } = useLater();
  const [filter, setFilter] = useState<ContentFilter>('all');

  const active = useMemo(() => items.filter(isActive), [items]);
  const filtered = useMemo(() => active.filter((i) => matchesContentFilter(i, filter)), [active, filter]);
  const groups = useMemo(() => groupByCaptureDay(filtered), [filtered]);

  return (
    <ScreenShell
      title="All memories"
      count={active.length}
      countNoun="items"
      onBack={onBack}
      onOpenSearch={onOpenSearch}
      filters={
        <div className="flex items-center gap-1.5 px-0.5 min-w-max">
          {(
            [
              ['all', 'All'],
              ['notes', 'Notes'],
              ['links', 'Links'],
              ['screenshots', 'Screenshots'],
            ] as [ContentFilter, string][]
          ).map(([value, label]) => (
            <FilterChip
              key={value}
              label={label}
              isActive={filter === value}
              onClick={() => setFilter(value)}
            />
          ))}
        </div>
      }
    >
      <GroupedItemList groups={groups} />
    </ScreenShell>
  );
};

const TodayScreen: React.FC<{ onBack: () => void; onOpenSearch: () => void }> = ({ onBack, onOpenSearch }) => {
  const { items } = useLater();
  const [urgency, setUrgency] = useState<UrgencyTag | 'all'>('all');

  const todayItems = useMemo(
    () =>
      items
        .filter((i) => isActive(i) && isScheduledToday(i))
        .sort(
          (a, b) =>
            new Date(a.reminderTime || a.scheduledFor || 0).getTime() -
            new Date(b.reminderTime || b.scheduledFor || 0).getTime()
        ),
    [items]
  );

  const filtered = useMemo(
    () => (urgency === 'all' ? todayItems : todayItems.filter((i) => (i.urgencyTag || i.urgency) === urgency)),
    [todayItems, urgency]
  );

  return (
    <ScreenShell
      title="Today"
      count={todayItems.length}
      countNoun="items"
      onBack={onBack}
      onOpenSearch={onOpenSearch}
      filters={
        <div className="flex items-center gap-1.5 px-0.5 min-w-max">
          <FilterChip label="All" isActive={urgency === 'all'} onClick={() => setUrgency('all')} />
          {(Object.keys(URGENCY_CHIP_LABELS) as UrgencyTag[]).map((tag) => (
            <FilterChip
              key={tag}
              label={URGENCY_CHIP_LABELS[tag]}
              isActive={urgency === tag}
              onClick={() => setUrgency(tag)}
            />
          ))}
        </div>
      }
    >
      <FlatItemList items={filtered} emptyLabel="Nothing for today" description="Enjoy the clear day" />
    </ScreenShell>
  );
};

const UpcomingScreen: React.FC<{ onBack: () => void; onOpenSearch: () => void }> = ({
  onBack,
  onOpenSearch,
}) => {
  const { items } = useLater();
  const upcomingItems = useMemo(() => items.filter((i) => isActive(i) && isScheduledFuture(i)), [items]);
  const groups = useMemo(() => groupUpcoming(upcomingItems), [upcomingItems]);

  return (
    <ScreenShell title="Upcoming" count={upcomingItems.length} countNoun="items" onBack={onBack} onOpenSearch={onOpenSearch}>
      <GroupedItemList groups={groups} />
    </ScreenShell>
  );
};

const UnscheduledScreen: React.FC<{ onBack: () => void; onOpenSearch: () => void }> = ({
  onBack,
  onOpenSearch,
}) => {
  const { items } = useLater();
  const unscheduledItems = useMemo(() => items.filter((i) => isActive(i) && isUnscheduled(i)), [items]);

  return (
    <ScreenShell
      title="Unscheduled"
      count={unscheduledItems.length}
      countNoun="items"
      onBack={onBack}
      onOpenSearch={onOpenSearch}
    >
      <FlatItemList
        items={unscheduledItems}
        emptyLabel="Nothing unscheduled"
        description="Everything here has a time"
      />
    </ScreenShell>
  );
};

const DIRECTORY_CHIP_COLORS = [
  'bg-[var(--sage-soft)] text-[var(--accent-deep)]',
  'bg-[var(--gold-soft)] text-[var(--accent-deep)]',
  'bg-[var(--accent-soft)] text-[var(--accent)]',
];

const DirectoryScreen: React.FC<{
  title: string;
  icon: React.ReactNode;
  entries: { name: string; count: number }[];
  onBack: () => void;
  onOpenSearch: () => void;
  onSelect: (name: string) => void;
  emptyLabel: string;
  emptyDescription: string;
}> = ({ title, icon, entries, onBack, onOpenSearch, onSelect, emptyLabel, emptyDescription }) => {
  return (
    <ScreenShell title={title} count={entries.length} countNoun={title.toLowerCase()} onBack={onBack} onOpenSearch={onOpenSearch}>
      {entries.length === 0 ? (
        <EmptyRow label={emptyLabel} description={emptyDescription} />
      ) : (
        <div className="space-y-2.5">
          {entries.map((entry, idx) => (
            <button
              key={entry.name}
              type="button"
              onClick={() => onSelect(entry.name)}
              className="w-full min-h-[52px] flex items-center gap-3 px-3.5 py-3 rounded-2xl bg-[var(--surface)] border border-[var(--border-subtle)] hover:bg-[var(--surface-resting-hover)] transition-colors text-left cursor-pointer active:scale-[0.99]"
            >
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                  DIRECTORY_CHIP_COLORS[idx % DIRECTORY_CHIP_COLORS.length]
                }`}
              >
                {icon}
              </div>
              <div className="flex-1 min-w-0">
                <p className="type-body font-semibold text-[var(--text-primary)] truncate">{entry.name}</p>
              </div>
              <span className="type-caption text-[var(--text-tertiary)] shrink-0">{entry.count} items</span>
              <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)] shrink-0" />
            </button>
          ))}
        </div>
      )}
    </ScreenShell>
  );
};

const PeopleScreen: React.FC<{
  onBack: () => void;
  onOpenSearch: () => void;
  onSelect: (name: string) => void;
}> = ({ onBack, onOpenSearch, onSelect }) => {
  const { items } = useLater();
  const entries = useMemo(() => buildPeopleDirectory(items), [items]);
  return (
    <DirectoryScreen
      title="People"
      icon={<User className="w-4.5 h-4.5" />}
      entries={entries}
      onBack={onBack}
      onOpenSearch={onOpenSearch}
      onSelect={onSelect}
      emptyLabel="No people yet"
      emptyDescription="People mentioned in your memories show up here"
    />
  );
};

const PlacesScreen: React.FC<{
  onBack: () => void;
  onOpenSearch: () => void;
  onSelect: (name: string) => void;
}> = ({ onBack, onOpenSearch, onSelect }) => {
  const { items } = useLater();
  const entries = useMemo(() => buildPlacesDirectory(items), [items]);
  return (
    <DirectoryScreen
      title="Places"
      icon={<MapPin className="w-4.5 h-4.5" />}
      entries={entries}
      onBack={onBack}
      onOpenSearch={onOpenSearch}
      onSelect={onSelect}
      emptyLabel="No places yet"
      emptyDescription="Places mentioned in your memories show up here"
    />
  );
};

const PersonDetailScreen: React.FC<{ name: string; onBack: () => void; onOpenSearch: () => void }> = ({
  name,
  onBack,
  onOpenSearch,
}) => {
  const { items } = useLater();
  const filtered = useMemo(() => itemsForPerson(items, name), [items, name]);
  return (
    <ScreenShell title={name} count={filtered.length} countNoun="items" onBack={onBack} onOpenSearch={onOpenSearch}>
      <FlatItemList items={filtered} emptyLabel="Nothing here yet" />
    </ScreenShell>
  );
};

const PlaceDetailScreen: React.FC<{ name: string; onBack: () => void; onOpenSearch: () => void }> = ({
  name,
  onBack,
  onOpenSearch,
}) => {
  const { items } = useLater();
  const filtered = useMemo(() => itemsForPlace(items, name), [items, name]);
  return (
    <ScreenShell title={name} count={filtered.length} countNoun="items" onBack={onBack} onOpenSearch={onOpenSearch}>
      <FlatItemList items={filtered} emptyLabel="Nothing here yet" />
    </ScreenShell>
  );
};

/** Honest placeholder for features that need real data-model work
 * (tags, collections, starred, soft-delete) which hasn't shipped yet —
 * rather than faking a screen with data that doesn't actually exist. */
const ComingSoonScreen: React.FC<{ label: string; description: string; onBack: () => void }> = ({
  label,
  description,
  onBack,
}) => {
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-2 pb-3">
        <button
          type="button"
          onClick={onBack}
          className="w-9 h-9 shrink-0 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors cursor-pointer active:scale-95"
          aria-label="Back"
        >
          <ChevronLeft className="w-4.5 h-4.5" />
        </button>
        <h2 className="type-heading-lg font-semibold text-[var(--text-primary)]">{label}</h2>
      </div>
      <div className="flex-1 flex flex-col items-center justify-center gap-3 text-center px-6">
        <Leaf className="w-7 h-7 text-[var(--sage)] rotate-[18deg]" strokeWidth={1.5} />
        <p className="type-body font-semibold text-[var(--text-primary)]">{label} is on the way</p>
        <p className="type-body-sm text-[var(--text-secondary)] max-w-[260px]">{description}</p>
      </div>
    </div>
  );
};

interface SidebarScreenRouterProps {
  view: Exclude<SidebarView, never>;
  onBack: () => void;
  onOpenSearch: () => void;
  onNavigate: (view: SidebarView) => void;
}

export const SidebarScreenRouter: React.FC<SidebarScreenRouterProps> = ({
  view,
  onBack,
  onOpenSearch,
  onNavigate,
}) => {
  switch (view.kind) {
    case 'all':
      return <AllMemoriesScreen onBack={onBack} onOpenSearch={onOpenSearch} />;
    case 'today':
      return <TodayScreen onBack={onBack} onOpenSearch={onOpenSearch} />;
    case 'upcoming':
      return <UpcomingScreen onBack={onBack} onOpenSearch={onOpenSearch} />;
    case 'unscheduled':
      return <UnscheduledScreen onBack={onBack} onOpenSearch={onOpenSearch} />;
    case 'people':
      return (
        <PeopleScreen
          onBack={onBack}
          onOpenSearch={onOpenSearch}
          onSelect={(name) => onNavigate({ kind: 'personDetail', name })}
        />
      );
    case 'places':
      return (
        <PlacesScreen
          onBack={onBack}
          onOpenSearch={onOpenSearch}
          onSelect={(name) => onNavigate({ kind: 'placeDetail', name })}
        />
      );
    case 'personDetail':
      return (
        <PersonDetailScreen
          name={view.name}
          onBack={() => onNavigate({ kind: 'people' })}
          onOpenSearch={onOpenSearch}
        />
      );
    case 'placeDetail':
      return (
        <PlaceDetailScreen
          name={view.name}
          onBack={() => onNavigate({ kind: 'places' })}
          onOpenSearch={onOpenSearch}
        />
      );
    case 'comingSoon':
      return <ComingSoonScreen label={view.label} description={view.description} onBack={onBack} />;
    default:
      return null;
  }
};
