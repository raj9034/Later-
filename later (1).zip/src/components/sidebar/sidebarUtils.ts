import { SavedItem, UrgencyTag } from '../../types';

/** Local, sidebar-only date helpers. Deliberately kept separate from
 * utils/timeScheduler.ts (a protected file) rather than extending it —
 * these are simple calendar-day comparisons, not reminder/scheduling
 * logic, so there's no need to touch protected business logic to get
 * them. */

const getScheduledDate = (item: SavedItem): Date | null => {
  const raw = item.reminderTime || item.scheduledFor;
  return raw ? new Date(raw) : null;
};

const isSameCalendarDay = (a: Date, b: Date): boolean =>
  a.getDate() === b.getDate() &&
  a.getMonth() === b.getMonth() &&
  a.getFullYear() === b.getFullYear();

export const isActive = (item: SavedItem): boolean => !item.isArchived;

export const isScheduledToday = (item: SavedItem): boolean => {
  const d = getScheduledDate(item);
  if (!d) return false;
  return isSameCalendarDay(d, new Date());
};

export const isScheduledFuture = (item: SavedItem): boolean => {
  const d = getScheduledDate(item);
  if (!d) return false;
  const now = new Date();
  const startOfTomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  return d.getTime() >= startOfTomorrow.getTime();
};

export const isUnscheduled = (item: SavedItem): boolean =>
  !item.reminderTime && !item.scheduledFor;

export interface SidebarGroup {
  label: string;
  items: SavedItem[];
}

/** Groups by capture date (createdAt) — Today / Yesterday / Earlier. */
export function groupByCaptureDay(items: SavedItem[]): SidebarGroup[] {
  const now = new Date();
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);

  const today: SavedItem[] = [];
  const yest: SavedItem[] = [];
  const earlier: SavedItem[] = [];

  [...items]
    .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
    .forEach((item) => {
      const d = new Date(item.createdAt);
      if (isSameCalendarDay(d, now)) today.push(item);
      else if (isSameCalendarDay(d, yesterday)) yest.push(item);
      else earlier.push(item);
    });

  return [
    { label: 'Today', items: today },
    { label: 'Yesterday', items: yest },
    { label: 'Earlier', items: earlier },
  ].filter((g) => g.items.length > 0);
}

/** Groups upcoming (future-scheduled) items — Tomorrow / This week / Later. */
export function groupUpcoming(items: SavedItem[]): SidebarGroup[] {
  const now = new Date();
  const tomorrowStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  const tomorrowEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 2);
  const weekEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 7);

  const tomorrow: SavedItem[] = [];
  const thisWeek: SavedItem[] = [];
  const later: SavedItem[] = [];

  const sorted = [...items].sort((a, b) => {
    const da = new Date(a.reminderTime || a.scheduledFor || 0).getTime();
    const db = new Date(b.reminderTime || b.scheduledFor || 0).getTime();
    return da - db;
  });

  sorted.forEach((item) => {
    const d = new Date(item.reminderTime || item.scheduledFor || 0);
    if (d >= tomorrowStart && d < tomorrowEnd) tomorrow.push(item);
    else if (d >= tomorrowEnd && d < weekEnd) thisWeek.push(item);
    else later.push(item);
  });

  return [
    { label: 'Tomorrow', items: tomorrow },
    { label: 'This week', items: thisWeek },
    { label: 'Later', items: later },
  ].filter((g) => g.items.length > 0);
}

export const URGENCY_CHIP_LABELS: Record<UrgencyTag, string> = {
  urgent: 'Priority',
  important: 'Important',
  chill: 'Chill',
};

export interface DirectoryEntry {
  name: string;
  count: number;
}

function buildDirectory(items: SavedItem[], field: 'people' | 'places'): DirectoryEntry[] {
  const map = new Map<string, number>();
  items
    .filter((i) => isActive(i))
    .forEach((item) => {
      (item[field] || []).forEach((raw) => {
        const name = raw.trim();
        if (!name) return;
        map.set(name, (map.get(name) || 0) + 1);
      });
    });
  return Array.from(map.entries())
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
}

export const buildPeopleDirectory = (items: SavedItem[]): DirectoryEntry[] =>
  buildDirectory(items, 'people');

export const buildPlacesDirectory = (items: SavedItem[]): DirectoryEntry[] =>
  buildDirectory(items, 'places');

export const itemsForPerson = (items: SavedItem[], name: string): SavedItem[] =>
  items.filter(
    (i) => isActive(i) && (i.people || []).some((p) => p.trim().toLowerCase() === name.toLowerCase())
  );

export const itemsForPlace = (items: SavedItem[], name: string): SavedItem[] =>
  items.filter(
    (i) => isActive(i) && (i.places || []).some((p) => p.trim().toLowerCase() === name.toLowerCase())
  );

export type SidebarView =
  | { kind: 'all' }
  | { kind: 'today' }
  | { kind: 'upcoming' }
  | { kind: 'unscheduled' }
  | { kind: 'people' }
  | { kind: 'places' }
  | { kind: 'personDetail'; name: string }
  | { kind: 'placeDetail'; name: string }
  | { kind: 'comingSoon'; label: string; description: string };
