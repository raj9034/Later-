import React, { useMemo, useState } from 'react';
import { ChevronLeft, Search, ChevronRight, Plus, MoreVertical, Check, Trash2, Tag as TagIcon, X } from 'lucide-react';
import { useLater } from '../../context/LaterContext';
import { useTags, Tag, TagColor, TAG_COLOR_SWATCHES, TAG_COLOR_ORDER } from '../../context/TagContext';
import { TimelineItemRow } from '../TimelineItemRow';
import { isActive } from './sidebarUtils';

export const TagDot: React.FC<{ color: TagColor; size?: number }> = ({ color, size = 10 }) => (
  <span
    className="rounded-full shrink-0 inline-block"
    style={{ width: size, height: size, backgroundColor: TAG_COLOR_SWATCHES[color] }}
  />
);

const ColorPalettePicker: React.FC<{ value: TagColor; onChange: (c: TagColor) => void }> = ({
  value,
  onChange,
}) => (
  <div className="flex flex-wrap gap-2.5">
    {TAG_COLOR_ORDER.map((color) => (
      <button
        key={color}
        type="button"
        onClick={() => onChange(color)}
        aria-label={color}
        className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 transition-transform active:scale-90 cursor-pointer"
        style={{
          backgroundColor: TAG_COLOR_SWATCHES[color],
          boxShadow: value === color ? `0 0 0 2px var(--surface), 0 0 0 4px ${TAG_COLOR_SWATCHES[color]}` : 'none',
        }}
      >
        {value === color && <Check className="w-4 h-4 text-white stroke-[3]" />}
      </button>
    ))}
  </div>
);

/** Shared create/edit sheet. When editingTag is provided it operates in
 * rename/recolor/delete mode; otherwise it creates a brand-new tag. */
export const TagEditorSheet: React.FC<{
  editingTag?: Tag;
  onClose: () => void;
}> = ({ editingTag, onClose }) => {
  const { createTag, renameTag, recolorTag, deleteTag } = useTags();
  const [name, setName] = useState(editingTag?.name || '');
  const [color, setColor] = useState<TagColor>(editingTag?.color || 'green');
  const [confirmDelete, setConfirmDelete] = useState(false);

  const handleSave = () => {
    if (!name.trim()) return;
    if (editingTag) {
      renameTag(editingTag.id, name);
      recolorTag(editingTag.id, color);
    } else {
      createTag(name, color);
    }
    onClose();
  };

  const handleDelete = () => {
    if (!editingTag) return;
    if (!confirmDelete) {
      setConfirmDelete(true);
      return;
    }
    deleteTag(editingTag.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 sheet-backdrop" onClick={onClose} />
      <div className="relative w-full max-w-sm bg-[var(--surface)] border-t sm:border border-[var(--border)] rounded-t-[24px] sm:rounded-[24px] elevation-3 z-10 p-5 space-y-5">
        <div className="flex items-center justify-between">
          <h3 className="type-heading-lg font-semibold text-[var(--text-primary)]">
            {editingTag ? 'Edit tag' : 'Create tag'}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-2">
          <label className="type-caption text-[11px] font-medium text-[var(--text-tertiary)] uppercase tracking-wider block">
            Name
          </label>
          <div className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-2xl bg-[var(--surface-sunken)] border border-[var(--border)]">
            <TagDot color={color} size={12} />
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSave()}
              placeholder="e.g. NEET PG, Ideas, Travel"
              autoFocus
              maxLength={40}
              className="flex-1 bg-transparent outline-none text-[var(--text-primary)] type-body font-medium"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="type-caption text-[11px] font-medium text-[var(--text-tertiary)] uppercase tracking-wider block">
            Color
          </label>
          <ColorPalettePicker value={color} onChange={setColor} />
        </div>

        <div className="flex items-center gap-2 pt-1">
          <button
            type="button"
            onClick={handleSave}
            disabled={!name.trim()}
            className="flex-1 py-3 rounded-2xl bg-[var(--accent)] text-white type-button font-semibold cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-[0.98]"
          >
            {editingTag ? 'Save changes' : 'Create tag'}
          </button>
          {editingTag && (
            <button
              type="button"
              onClick={handleDelete}
              className={`px-4 py-3 rounded-2xl border type-button font-medium cursor-pointer transition-all active:scale-[0.98] flex items-center gap-1.5 ${
                confirmDelete
                  ? 'bg-[var(--destructive)] border-[var(--destructive)] text-white'
                  : 'border-[var(--border)] text-[var(--destructive)]'
              }`}
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{confirmDelete ? 'Confirm' : 'Delete'}</span>
            </button>
          )}
        </div>
        {editingTag && confirmDelete && (
          <p className="type-caption text-[var(--text-tertiary)] -mt-2">
            This removes the tag only — memories carrying it are kept.
          </p>
        )}
      </div>
    </div>
  );
};

export const TagsScreen: React.FC<{
  onBack: () => void;
  onOpenSearch: () => void;
  onSelectTag: (tagId: string) => void;
}> = ({ onBack, onOpenSearch, onSelectTag }) => {
  const { tags, countForTag } = useTags();
  const [editorTag, setEditorTag] = useState<Tag | 'new' | null>(null);
  const [menuOpenFor, setMenuOpenFor] = useState<string | null>(null);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between gap-2 pb-3">
        <div className="flex items-center gap-2 min-w-0">
          <button
            type="button"
            onClick={onBack}
            className="w-9 h-9 shrink-0 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] cursor-pointer active:scale-95"
            aria-label="Back"
          >
            <ChevronLeft className="w-4.5 h-4.5" />
          </button>
          <div className="min-w-0">
            <h2 className="type-heading-lg font-semibold text-[var(--text-primary)]">Tags</h2>
            <p className="type-caption text-[var(--text-secondary)]">{tags.length} tags</p>
          </div>
        </div>
        <button
          type="button"
          onClick={onOpenSearch}
          className="w-9 h-9 shrink-0 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] cursor-pointer"
          aria-label="Search"
        >
          <Search className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto pb-4">
        {tags.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 text-center px-6 py-16">
            <div className="w-12 h-12 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-tertiary)]">
              <TagIcon className="w-5 h-5" />
            </div>
            <p className="type-body font-semibold text-[var(--text-primary)]">No tags yet</p>
            <button
              type="button"
              onClick={() => setEditorTag('new')}
              className="mt-1 px-4 py-2.5 rounded-2xl bg-[var(--accent)] text-white type-button font-semibold cursor-pointer active:scale-[0.98] transition-all"
            >
              Create your first tag
            </button>
          </div>
        ) : (
          <div className="space-y-2.5">
            {tags.map((tag) => (
              <div
                key={tag.id}
                className="relative w-full min-h-[52px] flex items-center gap-3 px-3.5 py-3 rounded-2xl bg-[var(--surface)] border border-[var(--border-subtle)] hover:bg-[var(--surface-resting-hover)] transition-colors"
              >
                <button
                  type="button"
                  onClick={() => onSelectTag(tag.id)}
                  className="flex items-center gap-3 flex-1 min-w-0 text-left cursor-pointer"
                >
                  <TagDot color={tag.color} size={12} />
                  <span className="type-body font-semibold text-[var(--text-primary)] truncate flex-1">
                    {tag.name}
                  </span>
                  <span className="type-caption text-[var(--text-tertiary)] shrink-0">
                    {countForTag(tag.id)}
                  </span>
                  <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)] shrink-0" />
                </button>
                <button
                  type="button"
                  onClick={() => setMenuOpenFor(menuOpenFor === tag.id ? null : tag.id)}
                  className="w-8 h-8 shrink-0 rounded-full flex items-center justify-center text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-elevated)] cursor-pointer"
                  aria-label="Tag options"
                >
                  <MoreVertical className="w-4 h-4" />
                </button>

                {menuOpenFor === tag.id && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setMenuOpenFor(null)} />
                    <div className="absolute right-2 top-12 z-20 w-40 rounded-2xl bg-[var(--surface-elevated)] border border-[var(--border)] elevation-3 py-1.5 overflow-hidden">
                      <button
                        type="button"
                        onClick={() => {
                          setEditorTag(tag);
                          setMenuOpenFor(null);
                        }}
                        className="w-full text-left px-3.5 py-2.5 type-body-sm text-[var(--text-primary)] hover:bg-[var(--surface-resting-hover)] cursor-pointer"
                      >
                        Edit tag
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {tags.length > 0 && (
        <button
          type="button"
          onClick={() => setEditorTag('new')}
          className="mt-1 mb-1 w-full py-3.5 rounded-2xl bg-[var(--accent)] text-white type-button font-semibold cursor-pointer active:scale-[0.98] transition-all flex items-center justify-center gap-2 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>New tag</span>
        </button>
      )}

      {editorTag && (
        <TagEditorSheet
          editingTag={editorTag === 'new' ? undefined : editorTag}
          onClose={() => setEditorTag(null)}
        />
      )}
    </div>
  );
};

export const TagPickerSheet: React.FC<{
  itemId: string;
  currentTagIds: string[];
  onClose: () => void;
}> = ({ itemId, currentTagIds, onClose }) => {
  const { tags } = useTags();
  const { addTagToItem, removeTagFromItem } = useTags();
  const [creating, setCreating] = useState(false);

  const toggleTag = (tagId: string) => {
    if (currentTagIds.includes(tagId)) {
      removeTagFromItem(itemId, tagId);
    } else {
      addTagToItem(itemId, tagId);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 sheet-backdrop" onClick={onClose} />
      <div className="relative w-full max-w-sm bg-[var(--surface)] border-t sm:border border-[var(--border)] rounded-t-[24px] sm:rounded-[24px] elevation-3 z-10 p-5 space-y-4 max-h-[70vh] flex flex-col">
        <div className="flex items-center justify-between shrink-0">
          <h3 className="type-heading-lg font-semibold text-[var(--text-primary)]">Tags</h3>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-2 -mx-1 px-1">
          {tags.length === 0 && !creating && (
            <p className="type-body-sm text-[var(--text-secondary)] text-center py-6">
              No tags yet — create your first one below.
            </p>
          )}
          {tags.map((tag) => {
            const active = currentTagIds.includes(tag.id);
            return (
              <button
                key={tag.id}
                type="button"
                onClick={() => toggleTag(tag.id)}
                className={`w-full min-h-[44px] flex items-center gap-3 px-3.5 py-2.5 rounded-2xl border transition-colors cursor-pointer text-left ${
                  active
                    ? 'bg-[var(--accent-soft)] border-[var(--accent)]/30'
                    : 'bg-[var(--surface-sunken)] border-[var(--border)] hover:border-[var(--border-strong)]'
                }`}
              >
                <TagDot color={tag.color} size={11} />
                <span className="type-body font-medium text-[var(--text-primary)] flex-1 truncate">
                  {tag.name}
                </span>
                {active && <Check className="w-4 h-4 text-[var(--accent)] stroke-[3] shrink-0" />}
              </button>
            );
          })}
        </div>

        {creating ? (
          <InlineCreateTagRow onDone={() => setCreating(false)} />
        ) : (
          <button
            type="button"
            onClick={() => setCreating(true)}
            className="shrink-0 w-full py-3 rounded-2xl border border-dashed border-[var(--border)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:border-[var(--border-strong)] type-button font-medium cursor-pointer transition-all flex items-center justify-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Add tag</span>
          </button>
        )}
      </div>
    </div>
  );
};

const InlineCreateTagRow: React.FC<{ onDone: () => void }> = ({ onDone }) => {
  const { createTag } = useTags();
  const [name, setName] = useState('');
  const [color, setColor] = useState<TagColor>('green');

  const handleCreate = () => {
    if (!name.trim()) return;
    createTag(name, color);
    onDone();
  };

  return (
    <div className="shrink-0 space-y-2.5 p-3 rounded-2xl bg-[var(--surface-sunken)] border border-[var(--border)]">
      <div className="flex items-center gap-2">
        <TagDot color={color} size={11} />
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
          placeholder="New tag name"
          autoFocus
          maxLength={40}
          className="flex-1 bg-transparent outline-none text-[var(--text-primary)] type-body-sm font-medium"
        />
      </div>
      <div className="flex flex-wrap gap-1.5">
        {TAG_COLOR_ORDER.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setColor(c)}
            aria-label={c}
            className="w-6 h-6 rounded-full shrink-0 cursor-pointer transition-transform active:scale-90"
            style={{
              backgroundColor: TAG_COLOR_SWATCHES[c],
              boxShadow: color === c ? `0 0 0 2px var(--surface-sunken), 0 0 0 3.5px ${TAG_COLOR_SWATCHES[c]}` : 'none',
            }}
          />
        ))}
      </div>
      <div className="flex items-center gap-2 pt-0.5">
        <button
          type="button"
          onClick={handleCreate}
          disabled={!name.trim()}
          className="flex-1 py-2 rounded-xl bg-[var(--accent)] text-white type-body-sm font-semibold cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Create
        </button>
        <button
          type="button"
          onClick={onDone}
          className="px-3 py-2 rounded-xl text-[var(--text-secondary)] type-body-sm font-medium cursor-pointer"
        >
          Cancel
        </button>
      </div>
    </div>
  );
};

export const TagDetailScreen: React.FC<{
  tagId: string;
  onBack: () => void;
  onOpenSearch: () => void;
}> = ({ tagId, onBack, onOpenSearch }) => {
  const { items } = useLater();
  const { getTagById } = useTags();
  const tag = getTagById(tagId);

  const filtered = useMemo(
    () => items.filter((i) => isActive(i) && (i.tagIds || []).includes(tagId)),
    [items, tagId]
  );

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between gap-2 pb-3">
        <div className="flex items-center gap-2 min-w-0">
          <button
            type="button"
            onClick={onBack}
            className="w-9 h-9 shrink-0 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] cursor-pointer active:scale-95"
            aria-label="Back"
          >
            <ChevronLeft className="w-4.5 h-4.5" />
          </button>
          <div className="min-w-0 flex items-center gap-2">
            {tag && <TagDot color={tag.color} size={11} />}
            <div className="min-w-0">
              <h2 className="type-heading-lg font-semibold text-[var(--text-primary)] truncate">
                {tag?.name || 'Tag'}
              </h2>
              <p className="type-caption text-[var(--text-secondary)]">{filtered.length} items</p>
            </div>
          </div>
        </div>
        <button
          type="button"
          onClick={onOpenSearch}
          className="w-9 h-9 shrink-0 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] cursor-pointer"
          aria-label="Search"
        >
          <Search className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto space-y-3 pb-6">
        {filtered.length === 0 ? (
          <div className="py-12">
            <p className="text-sm font-medium text-[var(--text-secondary)] text-center">Nothing tagged yet</p>
          </div>
        ) : (
          filtered.map((item, idx) => <TimelineItemRow key={item.id} item={item} index={idx} />)
        )}
      </div>
    </div>
  );
};
