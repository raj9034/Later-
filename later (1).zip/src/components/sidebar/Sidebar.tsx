import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Search,
  Inbox,
  Target,
  CalendarDays,
  CalendarClock,
  Star,
  Trash2,
  Tag,
  FolderOpen,
  Users,
  MapPin,
  PenSquare,
  ScanLine,
  Settings,
  Leaf,
  ChevronRight,
} from 'lucide-react';
import { useLater } from '../../context/LaterContext';
import { useAuth } from '../../context/AuthContext';
import {
  SidebarView,
  isActive,
  isScheduledToday,
  isScheduledFuture,
  isUnscheduled,
} from './sidebarUtils';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: SidebarView) => void;
  onOpenSearch: () => void;
  onOpenProfile: () => void;
  onRememberSomething: () => void;
}

interface NavRowProps {
  icon: React.ReactNode;
  label: string;
  count?: number;
  onClick: () => void;
}

const NavRow: React.FC<NavRowProps> = ({ icon, label, count, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className="w-full min-h-[44px] flex items-center gap-3 px-2.5 py-2 rounded-xl text-[var(--text-primary)] hover:bg-[var(--surface-resting-hover)] transition-colors cursor-pointer text-left active:scale-[0.99]"
  >
    <span className="w-8 h-8 rounded-full bg-[var(--surface-elevated)] border border-[var(--border-subtle)] flex items-center justify-center text-[var(--accent)] shrink-0">
      {icon}
    </span>
    <span className="type-body font-medium flex-1 truncate">{label}</span>
    {count !== undefined && (
      <span className="type-caption text-[var(--text-tertiary)] shrink-0">{count}</span>
    )}
    <ChevronRight className="w-3.5 h-3.5 text-[var(--text-tertiary)] shrink-0" />
  </button>
);

const SectionLabel: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <p className="type-label text-[var(--text-tertiary)] px-2.5 pt-4 pb-1.5">{children}</p>
);

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onOpenSearch,
  onOpenProfile,
  onRememberSomething,
}) => {
  const { items } = useLater();
  const { user } = useAuth();

  const activeItems = items.filter(isActive);
  const allCount = activeItems.length;
  const todayCount = activeItems.filter(isScheduledToday).length;
  const upcomingCount = activeItems.filter(isScheduledFuture).length;
  const unscheduledCount = activeItems.filter(isUnscheduled).length;

  const displayName = user?.displayName?.trim();
  const photoURL = user?.photoURL;
  const avatarInitial = (displayName?.[0] || user?.email?.[0] || '?').toUpperCase();

  const go = (view: SidebarView) => {
    onNavigate(view);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div id="later-sidebar-container" className="fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1, transition: { duration: 0.2, ease: [0.4, 0, 0.2, 1] } }}
            exit={{ opacity: 0, transition: { duration: 0.15, ease: [0.4, 0, 1, 1] } }}
            onClick={onClose}
            className="absolute inset-0 sheet-backdrop"
            aria-hidden="true"
          />

          {/* Drawer panel */}
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0, transition: { duration: 0.28, ease: [0, 0, 0.2, 1] } }}
            exit={{ x: '-100%', transition: { duration: 0.2, ease: [0.4, 0, 1, 1] } }}
            role="dialog"
            aria-modal="true"
            aria-label="Navigation"
            className="relative z-10 w-[86%] max-w-[320px] h-full bg-[var(--surface)] border-r border-[var(--border)] elevation-4 flex flex-col"
            style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}
          >
            {/* Header: brand + close + avatar */}
            <div className="flex items-start justify-between gap-2 px-4 pt-4 pb-3 border-b border-[var(--divider)]">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <Leaf className="w-4.5 h-4.5 text-[var(--sage)]" strokeWidth={1.8} />
                  <h1 className="font-onboarding-serif text-[20px] font-semibold text-[var(--text-primary)] tracking-tight leading-none">
                    Later
                  </h1>
                </div>
                <p className="type-caption text-[var(--text-secondary)] mt-1">Your memory, your way.</p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    onOpenProfile();
                    onClose();
                  }}
                  className="w-8 h-8 rounded-full overflow-hidden shrink-0 cursor-pointer"
                  aria-label="Profile"
                >
                  {photoURL ? (
                    <img src={photoURL} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-[var(--accent)] flex items-center justify-center text-[var(--bg)] font-display font-bold text-xs">
                      {avatarInitial}
                    </div>
                  )}
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="w-8 h-8 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors cursor-pointer"
                  aria-label="Close menu"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Search field (opens global search) */}
            <div className="px-4 pt-3">
              <button
                type="button"
                onClick={() => {
                  onOpenSearch();
                  onClose();
                }}
                className="w-full min-h-[44px] flex items-center gap-2.5 px-3.5 rounded-full bg-[var(--surface-elevated)] border border-[var(--border)] text-[var(--text-tertiary)] cursor-pointer text-left"
              >
                <Search className="w-4 h-4 shrink-0" />
                <span className="type-body-sm">Search your memory…</span>
              </button>
            </div>

            {/* Scrollable nav content */}
            <div className="flex-1 overflow-y-auto px-4 pb-3 pt-1">
              <div className="pt-2 space-y-0.5">
                <NavRow icon={<Inbox className="w-4 h-4" />} label="All memories" count={allCount} onClick={() => go({ kind: 'all' })} />
                <NavRow icon={<Target className="w-4 h-4" />} label="Today" count={todayCount} onClick={() => go({ kind: 'today' })} />
                <NavRow icon={<CalendarDays className="w-4 h-4" />} label="Upcoming" count={upcomingCount} onClick={() => go({ kind: 'upcoming' })} />
                <NavRow icon={<CalendarClock className="w-4 h-4" />} label="Unscheduled" count={unscheduledCount} onClick={() => go({ kind: 'unscheduled' })} />
                <NavRow
                  icon={<Star className="w-4 h-4" />}
                  label="Starred"
                  onClick={() =>
                    go({
                      kind: 'comingSoon',
                      label: 'Starred',
                      description: 'Starring your most important memories is coming in a future update.',
                    })
                  }
                />
                <NavRow
                  icon={<Trash2 className="w-4 h-4" />}
                  label="Recently deleted"
                  onClick={() =>
                    go({
                      kind: 'comingSoon',
                      label: 'Recently deleted',
                      description: 'A 30-day recovery bin for deleted memories is coming in a future update.',
                    })
                  }
                />
              </div>

              <SectionLabel>Organize</SectionLabel>
              <div className="space-y-0.5">
                <NavRow
                  icon={<Tag className="w-4 h-4" />}
                  label="Tags"
                  onClick={() =>
                    go({
                      kind: 'comingSoon',
                      label: 'Tags',
                      description: 'Color-coded custom tags are coming in a future update.',
                    })
                  }
                />
                <NavRow
                  icon={<FolderOpen className="w-4 h-4" />}
                  label="Collections"
                  onClick={() =>
                    go({
                      kind: 'comingSoon',
                      label: 'Collections',
                      description: 'Grouping memories into collections is coming in a future update.',
                    })
                  }
                />
                <NavRow icon={<Users className="w-4 h-4" />} label="People" onClick={() => go({ kind: 'people' })} />
                <NavRow icon={<MapPin className="w-4 h-4" />} label="Places" onClick={() => go({ kind: 'places' })} />
              </div>

              <SectionLabel>Quick actions</SectionLabel>
              <div className="space-y-0.5">
                <NavRow
                  icon={<PenSquare className="w-4 h-4" />}
                  label="Remember something"
                  onClick={() => {
                    onRememberSomething();
                    onClose();
                  }}
                />
                <NavRow
                  icon={<ScanLine className="w-4 h-4" />}
                  label="Scan or capture"
                  onClick={() => {
                    onRememberSomething();
                    onClose();
                  }}
                />
                <NavRow
                  icon={<Settings className="w-4 h-4" />}
                  label="Settings & support"
                  onClick={() => {
                    onOpenProfile();
                    onClose();
                  }}
                />
              </div>
            </div>

            {/* Footer branding */}
            <div className="px-4 py-3.5 border-t border-[var(--divider)] flex items-center gap-2">
              <Leaf className="w-3.5 h-3.5 text-[var(--sage)] rotate-[18deg] shrink-0" strokeWidth={1.5} />
              <p className="font-onboarding-serif italic text-[11px] text-[var(--text-tertiary)] leading-tight">
                Small captures. A calmer tomorrow.
              </p>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
