import React, { useMemo, useState } from 'react';
import { useLater } from '../context/LaterContext';
import { SavedItem } from '../types';
import { TimelineItemRow } from './TimelineItemRow';
import { SystemState } from './ui/SystemState';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react';

type ScheduleTab = 'upcoming' | 'today' | 'calendar';

const isSameDay = (a: Date, b: Date) =>
  a.getFullYear() === b.getFullYear() &&
  a.getMonth() === b.getMonth() &&
  a.getDate() === b.getDate();

const getItemDate = (item: SavedItem): Date | null => {
  const raw = item.reminderTime || item.scheduledFor;
  if (!raw) return null;
  const d = new Date(raw);
  return isNaN(d.getTime()) ? null : d;
};

export const ScheduleView: React.FC = () => {
  const { items, isSyncing } = useLater();
  const [activeScheduleTab, setActiveScheduleTab] = useState<ScheduleTab>('upcoming');
  const [calendarMonth, setCalendarMonth] = useState<Date>(() => {
    const d = new Date();
    d.setDate(1);
    return d;
  });
  const [selectedCalendarDay, setSelectedCalendarDay] = useState<Date | null>(null);

  // Filter unarchived items that have scheduled times, sort strictly chronologically
  const scheduledItems = useMemo(
    () =>
      items
        .filter((i) => !i.isArchived && (i.reminderTime || i.scheduledFor))
        .sort((a, b) => {
          const timeA = new Date(a.reminderTime || a.scheduledFor!).getTime();
          const timeB = new Date(b.reminderTime || b.scheduledFor!).getTime();
          return timeA - timeB;
        }),
    [items]
  );

  const now = new Date();
  const todayStr = now.toDateString();

  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toDateString();

  // Group by specific calendar day / label — used by the Upcoming tab
  const groupedByDay: { label: string; items: SavedItem[] }[] = useMemo(() => {
    const groups: { label: string; items: SavedItem[] }[] = [];
    scheduledItems.forEach((item) => {
      const rawTime = item.reminderTime || item.scheduledFor!;
      const itemDate = new Date(rawTime);
      const itemDateStr = itemDate.toDateString();

      let dayLabel = '';
      if (itemDateStr === todayStr) {
        dayLabel = 'Today';
      } else if (itemDateStr === tomorrowStr) {
        dayLabel = 'Tomorrow';
      } else {
        dayLabel = itemDate.toLocaleDateString('en-US', {
          weekday: 'long',
          month: 'short',
          day: 'numeric',
        });
      }

      const existingGroup = groups.find((g) => g.label === dayLabel);
      if (existingGroup) {
        existingGroup.items.push(item);
      } else {
        groups.push({ label: dayLabel, items: [item] });
      }
    });
    return groups;
  }, [scheduledItems, todayStr, tomorrowStr]);

  // Today tab — just today's scheduled items, already chronological
  const todaysItems = useMemo(
    () => scheduledItems.filter((item) => new Date(item.reminderTime || item.scheduledFor!).toDateString() === todayStr),
    [scheduledItems, todayStr]
  );

  // Calendar tab — build a 6-row month grid (42 cells) starting on Sunday,
  // and map each day to its scheduled item count so days with reminders
  // can show a dot.
  const calendarCells = useMemo(() => {
    const year = calendarMonth.getFullYear();
    const month = calendarMonth.getMonth();
    const firstOfMonth = new Date(year, month, 1);
    const startOffset = firstOfMonth.getDay(); // 0 = Sunday
    const gridStart = new Date(year, month, 1 - startOffset);

    const cells: { date: Date; inMonth: boolean; items: SavedItem[] }[] = [];
    for (let i = 0; i < 42; i++) {
      const cellDate = new Date(gridStart);
      cellDate.setDate(gridStart.getDate() + i);
      const dayItems = scheduledItems.filter((item) => {
        const d = getItemDate(item);
        return d && isSameDay(d, cellDate);
      });
      cells.push({ date: cellDate, inMonth: cellDate.getMonth() === month, items: dayItems });
    }
    return cells;
  }, [calendarMonth, scheduledItems]);

  const selectedDayItems = useMemo(() => {
    if (!selectedCalendarDay) return [];
    return scheduledItems.filter((item) => {
      const d = getItemDate(item);
      return d && isSameDay(d, selectedCalendarDay);
    });
  }, [selectedCalendarDay, scheduledItems]);

  const goToPrevMonth = () => {
    setCalendarMonth((prev) => {
      const next = new Date(prev);
      next.setMonth(next.getMonth() - 1);
      return next;
    });
    setSelectedCalendarDay(null);
  };

  const goToNextMonth = () => {
    setCalendarMonth((prev) => {
      const next = new Date(prev);
      next.setMonth(next.getMonth() + 1);
      return next;
    });
    setSelectedCalendarDay(null);
  };

  if (isSyncing) {
    return (
      <div id="schedule-view-container" className="w-full space-y-6 pt-2">
        <div className="flex items-center justify-between px-2 py-1">
          <span className="type-label text-[var(--text-secondary)]">Future Schedule</span>
        </div>
        <SystemState
          type="loading"
          className="later-skeleton"
          title="Loading your schedule…"
          description="Syncing your scheduled memories…"
        />
      </div>
    );
  }

  const scheduleTabs: { id: ScheduleTab; label: string }[] = [
    { id: 'upcoming', label: 'Upcoming' },
    { id: 'today', label: 'Today' },
    { id: 'calendar', label: 'Calendar' },
  ];

  return (
    <div id="schedule-view-container" className="w-full space-y-5 pt-2">
      {/* Schedule mode tabs — Upcoming / Today / Calendar */}
      <div className="flex items-center gap-2 px-1">
        {scheduleTabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveScheduleTab(tab.id)}
            className={`px-4 py-2 rounded-full type-body-sm font-semibold transition-colors cursor-pointer ${
              activeScheduleTab === tab.id
                ? 'theme-tab-active'
                : 'bg-[var(--surface-elevated)] border border-[var(--border)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeScheduleTab === 'upcoming' && (
        <>
          <div className="flex items-center justify-between px-2 py-1">
            <span className="type-label text-[var(--text-secondary)]">Future Schedule</span>
            <span className="type-caption text-[var(--text-tertiary)]">
              {scheduledItems.length} {scheduledItems.length === 1 ? 'reminder' : 'reminders'}
            </span>
          </div>

          {groupedByDay.length === 0 ? (
            <SystemState
              type="empty"
              icon={<CalendarIcon className="w-8 h-8 text-[var(--text-tertiary)]" />}
              title="No scheduled reminders"
              description="Items saved with dates will appear here chronologically"
            />
          ) : (
            <div className="space-y-6">
              {groupedByDay.map((group) => (
                <div key={group.label} className="space-y-3">
                  <div className="flex items-center gap-2.5 px-1 py-1">
                    <span className="type-label text-[var(--text-primary)]">
                      {group.label}
                    </span>
                    <div className="h-px flex-1 bg-[var(--divider)]" />
                    <span className="type-caption text-[var(--text-tertiary)]">
                      {group.items.length}
                    </span>
                  </div>

                  <div className="space-y-3">
                    {group.items.map((item) => (
                      <TimelineItemRow key={item.id} item={item} />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {activeScheduleTab === 'today' && (
        <>
          <div className="flex items-center justify-between px-2 py-1">
            <span className="type-label text-[var(--text-secondary)]">
              {now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
            </span>
            <span className="type-caption text-[var(--text-tertiary)]">
              {todaysItems.length} {todaysItems.length === 1 ? 'reminder' : 'reminders'}
            </span>
          </div>

          {todaysItems.length === 0 ? (
            <SystemState
              type="empty"
              icon={<CalendarIcon className="w-8 h-8 text-[var(--text-tertiary)]" />}
              title="Nothing scheduled today"
              description="Items due today will show up here"
            />
          ) : (
            <div className="space-y-3">
              {todaysItems.map((item) => (
                <TimelineItemRow key={item.id} item={item} />
              ))}
            </div>
          )}
        </>
      )}

      {activeScheduleTab === 'calendar' && (
        <div className="space-y-4">
          {/* Month navigation */}
          <div className="flex items-center justify-between px-1">
            <button
              type="button"
              onClick={goToPrevMonth}
              className="w-9 h-9 rounded-full flex items-center justify-center bg-[var(--surface-elevated)] border border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
              aria-label="Previous month"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="type-section-title font-onboarding-serif text-[var(--text-primary)]">
              {calendarMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
            </span>
            <button
              type="button"
              onClick={goToNextMonth}
              className="w-9 h-9 rounded-full flex items-center justify-center bg-[var(--surface-elevated)] border border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
              aria-label="Next month"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Weekday labels */}
          <div className="grid grid-cols-7 gap-1 px-1">
            {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
              <div key={i} className="type-caption text-center text-[var(--text-tertiary)] font-semibold py-1">
                {d}
              </div>
            ))}
          </div>

          {/* Month grid */}
          <div className="grid grid-cols-7 gap-1 px-1">
            {calendarCells.map((cell, i) => {
              const isToday = isSameDay(cell.date, now);
              const isSelected = selectedCalendarDay && isSameDay(cell.date, selectedCalendarDay);
              const hasItems = cell.items.length > 0;
              return (
                <button
                  key={i}
                  type="button"
                  disabled={!cell.inMonth}
                  onClick={() => setSelectedCalendarDay(cell.date)}
                  className={`relative aspect-square rounded-2xl flex flex-col items-center justify-center gap-0.5 transition-colors cursor-pointer ${
                    !cell.inMonth
                      ? 'opacity-0 pointer-events-none'
                      : isSelected
                        ? 'bg-[var(--accent)] text-[var(--bg)]'
                        : isToday
                          ? 'bg-[var(--accent-soft)] text-[var(--accent-deep)] font-semibold'
                          : 'text-[var(--text-primary)] hover:bg-[var(--surface-elevated)]'
                  }`}
                >
                  <span className="type-body-sm">{cell.date.getDate()}</span>
                  {hasItems && (
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        isSelected ? 'bg-[var(--bg)]' : 'bg-[var(--clay)]'
                      }`}
                    />
                  )}
                </button>
              );
            })}
          </div>

          {/* Selected day detail */}
          <div className="pt-2 space-y-3">
            <div className="flex items-center gap-2.5 px-1">
              <span className="type-label text-[var(--text-primary)]">
                {selectedCalendarDay
                  ? selectedCalendarDay.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })
                  : 'Tap a day to see what\u2019s scheduled'}
              </span>
              {selectedCalendarDay && (
                <>
                  <div className="h-px flex-1 bg-[var(--divider)]" />
                  <span className="type-caption text-[var(--text-tertiary)]">
                    {selectedDayItems.length}
                  </span>
                </>
              )}
            </div>

            {selectedCalendarDay && selectedDayItems.length === 0 && (
              <SystemState
                type="empty"
                icon={<CalendarIcon className="w-8 h-8 text-[var(--text-tertiary)]" />}
                title="Nothing scheduled"
                description="No reminders for this day"
              />
            )}

            {selectedDayItems.length > 0 && (
              <div className="space-y-3">
                {selectedDayItems.map((item) => (
                  <TimelineItemRow key={item.id} item={item} />
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
