import React, { useMemo, useState } from 'react';
import { useLater } from '../context/LaterContext';
import { SavedItem } from '../types';
import { ScheduleTimelineRow } from './ScheduleTimelineRow';
import { HomeQuoteCard } from './HomeHero';
import { SystemState } from './ui/SystemState';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Plus, ChevronDown, Leaf } from 'lucide-react';

type ScheduleTab = 'upcoming' | 'today' | 'calendar';

const isSameDay = (a: Date, b: Date) =>
  a.getFullYear() === b.getFullYear() &&
  a.getMonth() === b.getMonth() &&
  a.getDate() === b.getDate();

const getItemDate = (item: SavedItem): Date | null => {
  const raw = item.reminderTime || item.scheduledFor;
  if (!raw) return null;
  const d = new Date(raw);
  return isNaN(d.getTime()) ? null : d;
};

export const ScheduleView: React.FC = () => {
  const { items, isSyncing, saveItem, showToast } = useLater();
  const [activeScheduleTab, setActiveScheduleTab] = useState<ScheduleTab>('upcoming');
  const [calendarMonth, setCalendarMonth] = useState<Date>(() => {
    const d = new Date();
    d.setDate(1);
    return d;
  });
  const [selectedCalendarDay, setSelectedCalendarDay] = useState<Date | null>(null);
  const [isMonthPickerOpen, setIsMonthPickerOpen] = useState(false);
  const [quickAddText, setQuickAddText] = useState('');
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);

  // Filter unarchived items that have scheduled times, sort strictly chronologically
  const scheduledItems = useMemo(
    () =>
      items
        .filter((i) => !i.isArchived && (i.reminderTime || i.scheduledFor))
        .sort((a, b) => {
          const timeA = new Date(a.reminderTime || a.scheduledFor!).getTime();
          const timeB = new Date(b.reminderTime || b.scheduledFor!).getTime();
          return timeA - timeB;
        }),
    [items]
  );

  const now = new Date();
  const todayStr = now.toDateString();

  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toDateString();

  // Group by specific calendar day / label — used by the Upcoming tab
  const groupedByDay: { label: string; items: SavedItem[] }[] = useMemo(() => {
    const groups: { label: string; items: SavedItem[] }[] = [];
    scheduledItems.forEach((item) => {
      const rawTime = item.reminderTime || item.scheduledFor!;
      const itemDate = new Date(rawTime);
      const itemDateStr = itemDate.toDateString();

      let dayLabel = '';
      if (itemDateStr === todayStr) {
        dayLabel = 'Today';
      } else if (itemDateStr === tomorrowStr) {
        dayLabel = 'Tomorrow';
      } else {
        dayLabel = itemDate.toLocaleDateString('en-US', {
          weekday: 'long',
          month: 'short',
          day: 'numeric',
        });
      }

      const existingGroup = groups.find((g) => g.label === dayLabel);
      if (existingGroup) {
        existingGroup.items.push(item);
      } else {
        groups.push({ label: dayLabel, items: [item] });
      }
    });
    return groups;
  }, [scheduledItems, todayStr, tomorrowStr]);

  // Today tab — just today's scheduled items, already chronological
  const todaysItems = useMemo(
    () => scheduledItems.filter((item) => new Date(item.reminderTime || item.scheduledFor!).toDateString() === todayStr),
    [scheduledItems, todayStr]
  );

  // Calendar tab — build a 6-row month grid (42 cells) starting on Sunday,
  // and map each day to its scheduled item count so days with reminders
  // can show a dot.
  const calendarCells = useMemo(() => {
    const year = calendarMonth.getFullYear();
    const month = calendarMonth.getMonth();
    const firstOfMonth = new Date(year, month, 1);
    const startOffset = firstOfMonth.getDay(); // 0 = Sunday
    const gridStart = new Date(year, month, 1 - startOffset);

    const cells: { date: Date; inMonth: boolean; items: SavedItem[] }[] = [];
    for (let i = 0; i < 42; i++) {
      const cellDate = new Date(gridStart);
      cellDate.setDate(gridStart.getDate() + i);
      const dayItems = scheduledItems.filter((item) => {
        const d = getItemDate(item);
        return d && isSameDay(d, cellDate);
      });
      cells.push({ date: cellDate, inMonth: cellDate.getMonth() === month, items: dayItems });
    }
    return cells;
  }, [calendarMonth, scheduledItems]);

  const selectedDayItems = useMemo(() => {
    if (!selectedCalendarDay) return [];
    return scheduledItems.filter((item) => {
      const d = getItemDate(item);
      return d && isSameDay(d, selectedCalendarDay);
    });
  }, [selectedCalendarDay, scheduledItems]);

  const goToPrevMonth = () => {
    setCalendarMonth((prev) => {
      const next = new Date(prev);
      next.setMonth(next.getMonth() - 1);
      return next;
    });
    setSelectedCalendarDay(null);
  };

  const goToNextMonth = () => {
    setCalendarMonth((prev) => {
      const next = new Date(prev);
      next.setMonth(next.getMonth() + 1);
      return next;
    });
    setSelectedCalendarDay(null);
  };

  const jumpToMonth = (monthIndex: number, year: number) => {
    setCalendarMonth(new Date(year, monthIndex, 1));
    setSelectedCalendarDay(null);
    setIsMonthPickerOpen(false);
  };

  const jumpToToday = () => {
    const d = new Date();
    d.setDate(1);
    setCalendarMonth(d);
    setSelectedCalendarDay(new Date());
    setIsMonthPickerOpen(false);
  };

  const handleSelectCalendarDay = (date: Date) => {
    setSelectedCalendarDay(date);
    setIsQuickAddOpen(false);
    setQuickAddText('');
  };

  const handleQuickAddSave = () => {
    const trimmed = quickAddText.trim();
    if (!trimmed || !selectedCalendarDay) return;

    // Default new reminders from the Calendar to 9:00 AM on the picked day
    // — a specific, editable time rather than an ambiguous all-day entry,
    // since the rest of the app's reminder model is always time-based.
    const scheduledAt = new Date(selectedCalendarDay);
    scheduledAt.setHours(9, 0, 0, 0);

    saveItem(trimmed, undefined, {
      type: 'exact',
      scheduledAt: scheduledAt.toISOString(),
    });

    showToast(`Saved for ${selectedCalendarDay.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`);
    setQuickAddText('');
    setIsQuickAddOpen(false);
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
  ];

  if (isSyncing) {
    return (
      <div id="schedule-view-container" className="w-full space-y-6 pt-2">
        <div className="flex items-center justify-between px-2 py-1">
          <span className="type-label text-[var(--text-secondary)]">Future Schedule</span>
        </div>
        <SystemState
          type="loading"
          className="later-skeleton"
          title="Loading your schedule…"
          description="Syncing your scheduled memories…"
        />
      </div>
    );
  }

  const scheduleTabs: { id: ScheduleTab; label: string }[] = [
    { id: 'upcoming', label: 'Upcoming' },
    { id: 'today', label: 'Today' },
    { id: 'calendar', label: 'Calendar' },
  ];

  return (
    <div id="schedule-view-container" className="w-full space-y-5 pt-2 relative">
      <Leaf
        className="absolute -top-1 right-0 w-16 h-16 text-[var(--sage)] opacity-30 rotate-[25deg] pointer-events-none"
        strokeWidth={1}
      />

      {/* Schedule mode tabs — Upcoming / Today / Calendar */}
      <div className="flex items-center gap-2 px-1 relative">
        {scheduleTabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveScheduleTab(tab.id)}
            className={`px-4 py-2 rounded-full type-body-sm font-semibold transition-colors cursor-pointer ${
              activeScheduleTab === tab.id
                ? 'theme-tab-active'
                : 'bg-[var(--surface-elevated)] border border-[var(--border)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Summary card — real computed count + a small reassurance line,
          cloned from the reference's "4 things coming up" card. */}
      <div
        className="rounded-3xl p-4 flex items-center gap-3.5"
        style={{ background: 'linear-gradient(135deg, #F4FAF6 0%, #E9F2EC 100%)' }}
      >
        <span className="w-11 h-11 rounded-2xl bg-[var(--sage-soft)] flex items-center justify-center shrink-0">
          <CalendarIcon className="w-5 h-5 text-[var(--accent-deep)]" />
        </span>
        <div>
          <p className="font-onboarding-serif text-[17px] font-bold text-[var(--text-primary)] leading-tight">
            {scheduledItems.length} {scheduledItems.length === 1 ? 'thing' : 'things'} coming up
          </p>
          <p className="type-caption text-[var(--text-secondary)] mt-0.5">
            Stay on track. A calmer you. ♡
          </p>
        </div>
      </div>

      {activeScheduleTab === 'upcoming' && (
        <>
          <div className="flex items-center justify-between px-2 py-1">
            <span className="type-label text-[var(--text-secondary)]">Future Schedule</span>
            <span className="type-caption text-[var(--text-tertiary)]">
              {scheduledItems.length} {scheduledItems.length === 1 ? 'reminder' : 'reminders'}
            </span>
          </div>

          {groupedByDay.length === 0 ? (
            <SystemState
              type="empty"
              icon={<CalendarIcon className="w-8 h-8 text-[var(--text-tertiary)]" />}
              title="No scheduled reminders"
              description="Items saved with dates will appear here chronologically"
            />
          ) : (
            <div className="space-y-6">
              {groupedByDay.map((group) => (
                <div key={group.label}>
                  <div className="flex items-center gap-2.5 px-1 py-1 mb-1">
                    <span className="font-onboarding-serif text-[19px] font-bold text-[var(--text-primary)]">
                      {group.label}
                    </span>
                    <div className="h-px flex-1 bg-[var(--divider)]" />
                    <span className="type-caption text-[var(--text-tertiary)]">
                      {group.items.length} {group.items.length === 1 ? 'reminder' : 'reminders'}
                    </span>
                  </div>

                  <div>
                    {group.items.map((item, idx) => (
                      <ScheduleTimelineRow
                        key={item.id}
                        item={item}
                        isLast={idx === group.items.length - 1}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {activeScheduleTab === 'today' && (
        <>
          <div className="flex items-center justify-between px-2 py-1">
            <span className="type-label text-[var(--text-secondary)]">
              {now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
            </span>
            <span className="type-caption text-[var(--text-tertiary)]">
              {todaysItems.length} {todaysItems.length === 1 ? 'reminder' : 'reminders'}
            </span>
          </div>

          {todaysItems.length === 0 ? (
            <SystemState
              type="empty"
              icon={<CalendarIcon className="w-8 h-8 text-[var(--text-tertiary)]" />}
              title="Nothing scheduled today"
              description="Items due today will show up here"
            />
          ) : (
            <div>
              {todaysItems.map((item, idx) => (
                <ScheduleTimelineRow
                  key={item.id}
                  item={item}
                  isLast={idx === todaysItems.length - 1}
                />
              ))}
            </div>
          )}
        </>
      )}

      {activeScheduleTab === 'calendar' && (
        <div className="space-y-4">
          {/* Month navigation — tapping the month/year label opens a quick
              jump picker instead of only stepping one month at a time */}
          <div className="flex items-center justify-between px-1 relative">
            <button
              type="button"
              onClick={goToPrevMonth}
              className="w-9 h-9 rounded-full flex items-center justify-center bg-[var(--surface-elevated)] border border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
              aria-label="Previous month"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => setIsMonthPickerOpen((v) => !v)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl hover:bg-[var(--surface-elevated)] transition-colors cursor-pointer"
            >
              <span className="type-section-title font-onboarding-serif text-[var(--text-primary)]">
                {calendarMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </span>
              <ChevronDown className={`w-4 h-4 text-[var(--text-tertiary)] transition-transform ${isMonthPickerOpen ? 'rotate-180' : ''}`} />
            </button>

            <button
              type="button"
              onClick={goToNextMonth}
              className="w-9 h-9 rounded-full flex items-center justify-center bg-[var(--surface-elevated)] border border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer"
              aria-label="Next month"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Month/year jump picker */}
          {isMonthPickerOpen && (
            <div className="rounded-3xl border border-[var(--border)] bg-[var(--surface-elevated)] p-4 space-y-3">
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={() =>
                    setCalendarMonth((prev) => new Date(prev.getFullYear() - 1, prev.getMonth(), 1))
                  }
                  className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer text-[var(--text-primary)]"
                  aria-label="Previous year"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="type-body font-semibold text-[var(--text-primary)]">
                  {calendarMonth.getFullYear()}
                </span>
                <button
                  type="button"
                  onClick={() =>
                    setCalendarMonth((prev) => new Date(prev.getFullYear() + 1, prev.getMonth(), 1))
                  }
                  className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-[var(--surface-sunken)] transition-colors cursor-pointer text-[var(--text-primary)]"
                  aria-label="Next year"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-4 gap-2">
                {monthNames.map((name, idx) => (
                  <button
                    key={name}
                    type="button"
                    onClick={() => jumpToMonth(idx, calendarMonth.getFullYear())}
                    className={`py-2 rounded-xl type-caption font-semibold transition-colors cursor-pointer ${
                      idx === calendarMonth.getMonth()
                        ? 'bg-[var(--accent)] text-[var(--bg)]'
                        : 'bg-[var(--surface)] text-[var(--text-secondary)] hover:bg-[var(--surface-sunken)]'
                    }`}
                  >
                    {name.slice(0, 3)}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={jumpToToday}
                className="w-full py-2 rounded-xl type-caption font-semibold bg-[var(--accent-soft)] text-[var(--accent-deep)] dark:text-[var(--accent)] transition-colors cursor-pointer hover:opacity-80"
              >
                Jump to today
              </button>
            </div>
          )}

          {/* Weekday labels */}
          <div className="grid grid-cols-7 gap-1 px-1">
            {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
              <div key={i} className="type-caption text-center text-[var(--text-tertiary)] font-semibold py-1">
                {d}
              </div>
            ))}
          </div>

          {/* Month grid */}
          <div className="grid grid-cols-7 gap-1 px-1">
            {calendarCells.map((cell, i) => {
              const isToday = isSameDay(cell.date, now);
              const isSelected = selectedCalendarDay && isSameDay(cell.date, selectedCalendarDay);
              const hasItems = cell.items.length > 0;
              return (
                <button
                  key={i}
                  type="button"
                  disabled={!cell.inMonth}
                  onClick={() => handleSelectCalendarDay(cell.date)}
                  className={`relative aspect-square rounded-2xl flex flex-col items-center justify-center gap-0.5 transition-colors cursor-pointer ${
                    !cell.inMonth
                      ? 'opacity-0 pointer-events-none'
                      : isSelected
                        ? 'bg-[var(--accent)] text-[var(--bg)]'
                        : isToday
                          ? 'bg-[var(--accent-soft)] text-[var(--accent-deep)] font-semibold'
                          : 'text-[var(--text-primary)] hover:bg-[var(--surface-elevated)]'
                  }`}
                >
                  <span className="type-body-sm">{cell.date.getDate()}</span>
                  {hasItems && (
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        isSelected ? 'bg-[var(--bg)]' : 'bg-[#D64545]'
                      }`}
                    />
                  )}
                </button>
              );
            })}
          </div>

          {/* Selected day detail */}
          <div className="pt-2 space-y-3">
            <div className="flex items-center gap-2.5 px-1">
              <span className="type-label text-[var(--text-primary)]">
                {selectedCalendarDay
                  ? selectedCalendarDay.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })
                  : 'Tap a day to see what\u2019s scheduled'}
              </span>
              {selectedCalendarDay && (
                <>
                  <div className="h-px flex-1 bg-[var(--divider)]" />
                  <span className="type-caption text-[var(--text-tertiary)]">
                    {selectedDayItems.length}
                  </span>
                </>
              )}
            </div>

            {selectedCalendarDay && !isQuickAddOpen && (
              <button
                type="button"
                onClick={() => setIsQuickAddOpen(true)}
                className="w-full flex items-center gap-2 px-4 py-3 rounded-2xl border border-dashed border-[var(--border)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:border-[var(--accent)]/40 transition-colors cursor-pointer"
              >
                <span className="w-6 h-6 rounded-full bg-[var(--accent-soft)] flex items-center justify-center shrink-0">
                  <Plus className="w-3.5 h-3.5 text-[var(--accent-deep)] dark:text-[var(--accent)]" />
                </span>
                <span className="type-body-sm font-medium">
                  Add a reminder for this day
                </span>
              </button>
            )}

            {selectedCalendarDay && isQuickAddOpen && (
              <div className="rounded-2xl border border-[var(--accent)]/30 bg-[var(--accent-soft)] p-3 space-y-2.5">
                <textarea
                  autoFocus
                  value={quickAddText}
                  onChange={(e) => setQuickAddText(e.target.value)}
                  placeholder="What do you want me to remember?"
                  rows={2}
                  className="w-full bg-transparent border-none outline-none resize-none type-body-sm text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)]"
                />
                <div className="flex items-center justify-between">
                  <span className="type-caption text-[var(--accent-deep)] dark:text-[var(--accent)] opacity-80">
                    Defaults to 9:00 AM on this day
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setIsQuickAddOpen(false);
                        setQuickAddText('');
                      }}
                      className="px-3 py-1.5 rounded-xl type-caption font-semibold text-[var(--text-secondary)] hover:bg-[var(--surface-elevated)] transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleQuickAddSave}
                      disabled={!quickAddText.trim()}
                      className="px-3.5 py-1.5 rounded-xl type-caption font-semibold bg-[var(--accent)] text-[var(--bg)] disabled:opacity-40 transition-opacity cursor-pointer"
                    >
                      Remember
                    </button>
                  </div>
                </div>
              </div>
            )}

            {selectedCalendarDay && selectedDayItems.length === 0 && !isQuickAddOpen && (
              <SystemState
                type="empty"
                icon={<CalendarIcon className="w-8 h-8 text-[var(--text-tertiary)]" />}
                title="Nothing scheduled"
                description="No reminders for this day"
              />
            )}

            {selectedDayItems.length > 0 && (
              <div>
                {selectedDayItems.map((item, idx) => (
                  <ScheduleTimelineRow
                    key={item.id}
                    item={item}
                    isLast={idx === selectedDayItems.length - 1}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      <HomeQuoteCard />
    </div>
  );
};
