import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import HeadlessCaptureRoot from './components/headless/HeadlessCaptureRoot.tsx';
import './index.css';

// QUICK CAPTURE — headless entry check. Native loads the headless
// WebView instance (used only when the real app's WebView isn't
// already alive) at this same origin with ?headless_capture=<text> in
// the URL. When present, mount ONLY the headless root — no App, no
// screens, no navigation. Not reachable through any normal in-app link.
const headlessCaptureText = new URLSearchParams(window.location.search).get(
  'headless_capture'
);

const root = createRoot(document.getElementById('root')!);

if (headlessCaptureText !== null) {
  root.render(<HeadlessCaptureRoot text={headlessCaptureText} />);
} else {
  root.render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}
