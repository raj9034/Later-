import { registerPlugin } from '@capacitor/core';

/**
 * LATER ORB POC — EXPERIMENTAL, TEMPORARY.
 *
 * Thin wrapper around the native OrbPoc plugin (see
 * android/.../OrbPocPlugin.java + OrbPocForegroundService.java). Used
 * only by OrbPocTestScreen.tsx. Safe to delete this whole file, that
 * screen, and the two native files together with no effect on the rest
 * of Later.
 */

export interface OrbPocDiagnostics {
  androidVersion: string;
  device: string;
  overlayPermission: boolean;
  serviceRunning: boolean;
  foregroundServiceActive: boolean;
  overlayCreated: boolean;
  overlayFocus: boolean;
  clipboardListenerFired: boolean;
  hasPrimaryClip: boolean;
  getPrimaryClipSuccess: boolean;
  clipboardText: string;
  lastDetectionTimeMs: number;
}

export interface OrbPocPlugin {
  checkOverlayPermission(): Promise<{ granted: boolean }>;
  requestOverlayPermission(): Promise<void>;
  startOrbTest(): Promise<void>;
  stopOrbTest(): Promise<void>;
  getDiagnostics(): Promise<OrbPocDiagnostics>;
}

export const OrbPoc = registerPlugin<OrbPocPlugin>('OrbPoc');
