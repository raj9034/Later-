import { registerPlugin } from '@capacitor/core';

/**
 * QUICK CAPTURE — persistent notification input.
 *
 * Bridges JS to the native QuickCapturePlugin. Two call directions:
 *  - JS -> native: reportResult() — called once by HeadlessCaptureRoot
 *    (or by the live-bridge listener below) after a capture attempt
 *    settles, so native can update the notification to "Saved ✓" (or
 *    a preserved-text failure state) and tear down any headless WebView.
 *  - native -> JS: 'captureTextReceived' — fired only on the FAST path,
 *    when the app's real WebView is already alive (foregrounded or
 *    backgrounded-but-not-destroyed) and native chose to hand the text
 *    straight to it instead of spinning up a headless WebView. Nothing
 *    in the normal app screens needs to listen for this except the one
 *    small bootstrap wired in main.tsx.
 */

export interface QuickCaptureResult {
  success: boolean;
  text: string;
  error?: string;
  timedOut?: boolean;
}

export interface QuickCapturePlugin {
  reportResult(result: QuickCaptureResult): Promise<void>;
  ensureNotificationPosted(): Promise<void>;
  removeNotification(): Promise<void>;
  setEnabled(options: { enabled: boolean }): Promise<void>;
  isEnabled(): Promise<{ enabled: boolean }>;
  addListener(
    eventName: 'captureTextReceived',
    listenerFunc: (data: { text: string }) => void
  ): Promise<{ remove: () => Promise<void> }>;
}

export const QuickCapture = registerPlugin<QuickCapturePlugin>('QuickCapture');
