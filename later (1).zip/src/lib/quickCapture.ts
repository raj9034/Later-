import { registerPlugin } from '@capacitor/core';
import type { ReminderOutcome } from '../utils/nativeNotifications';

/**
 * QUICK CAPTURE — persistent notification input.
 *
 * Bridges JS to the native QuickCapturePlugin. Two call directions:
 *  - JS -> native: reportResult() — called once by HeadlessCaptureRoot
 *    (or by the live-bridge listener below) after a capture attempt
 *    settles, so native can update the notification to "Saved ✓" (or
 *    a preserved-text failure state) and tear down any headless WebView.
 *  - native -> JS: 'captureTextReceived' — fired only on the FAST path,
 *    when the app's real WebView is already alive (foregrounded or
 *    backgrounded-but-not-destroyed) and native chose to hand the text
 *    straight to it instead of spinning up a headless WebView. Nothing
 *    in the normal app screens needs to listen for this except the one
 *    small bootstrap wired in main.tsx.
 */

export interface QuickCaptureResult {
  /** EVERYTHING the user asked for worked: saved, and — if the text asked for a reminder — the alarm was confirmed. */
  success: boolean;
  /** The memory itself persisted. Defaults to `success` natively. `saved && !success` = "saved, reminder not set". */
  saved?: boolean;
  text: string;
  error?: string;
  timedOut?: boolean;
  /**
   * Shown in the notification. When `success`: the confirmed reminder
   * label ("Reminder set for 10:47 pm"), if any. When `saved && !success`:
   * a short explanation of why the reminder isn't set.
   */
  detail?: string;
}

export interface QuickCapturePlugin {
  reportResult(result: QuickCaptureResult): Promise<void>;
  /** Fast path only: tell native the page received the text, so it doesn't re-route to the headless page. */
  ackCapture(): Promise<void>;
  ensureNotificationPosted(): Promise<void>;
  removeNotification(): Promise<void>;
  setEnabled(options: { enabled: boolean }): Promise<void>;
  isEnabled(): Promise<{ enabled: boolean }>;
  addListener(
    eventName: 'captureTextReceived',
    listenerFunc: (data: { text: string; sentAt?: number }) => void
  ): Promise<{ remove: () => Promise<void> }>;
}

export const QuickCapture = registerPlugin<QuickCapturePlugin>('QuickCapture');

function reminderFailureDetail(reason: string): string {
  switch (reason) {
    case 'channel_blocked':
      return 'Reminders are turned off for Later in Android settings';
    case 'time_already_passed':
      return 'That time has already passed — tap to open Later';
    default:
      return 'Tap to open Later and check the reminder';
  }
}

/**
 * The ONE place that decides what a capture reports, shared by the live and
 * headless paths so they can't drift apart. "Success" is only claimed when
 * the memory saved AND any reminder the text asked for was confirmed.
 */
export function buildQuickCaptureResult(
  text: string,
  saved: boolean,
  reminder: ReminderOutcome
): QuickCaptureResult {
  if (!saved) return { success: false, saved: false, text, error: 'not_saved' };
  if (reminder.status === 'failed') {
    return {
      success: false,
      saved: true,
      text,
      error: reminder.reason,
      detail: reminderFailureDetail(reminder.reason),
    };
  }
  return {
    success: true,
    saved: true,
    text,
    detail: reminder.status === 'set' ? reminder.label : undefined,
  };
}
