import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { collection, doc, setDoc, deleteDoc, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthContext';
import { useLater } from './LaterContext';

export type TagColor =
  | 'rose'
  | 'orange'
  | 'gold'
  | 'green'
  | 'blue'
  | 'violet'
  | 'pink'
  | 'cyan'
  | 'slate';

export interface Tag {
  id: string;
  name: string;
  color: TagColor;
  createdAt: string;
}

/** Curated color palette — mid-saturation swatches that read clearly as a
 * small dot/chip on both white and dark cards, independent of theme. */
export const TAG_COLOR_SWATCHES: Record<TagColor, string> = {
  rose: '#F43F5E',
  orange: '#F97316',
  gold: '#EAB308',
  green: '#22C55E',
  blue: '#3B82F6',
  violet: '#8B5CF6',
  pink: '#EC4899',
  cyan: '#06B6D4',
  slate: '#64748B',
};

export const TAG_COLOR_ORDER: TagColor[] = [
  'rose',
  'orange',
  'gold',
  'green',
  'blue',
  'violet',
  'pink',
  'cyan',
  'slate',
];

interface TagContextType {
  tags: Tag[];
  isSyncing: boolean;
  createTag: (name: string, color: TagColor) => Tag;
  renameTag: (id: string, name: string) => void;
  recolorTag: (id: string, color: TagColor) => void;
  deleteTag: (id: string) => void;
  addTagToItem: (itemId: string, tagId: string) => void;
  removeTagFromItem: (itemId: string, tagId: string) => void;
  getTagById: (id: string) => Tag | undefined;
  countForTag: (id: string) => number;
}

const TagContext = createContext<TagContextType | undefined>(undefined);

const GUEST_TAGS_KEY = 'later_universal_tags_v1';
const getTagsStorageKey = (uid?: string | null) => (uid ? `later_user_tags_${uid}` : GUEST_TAGS_KEY);

const loadStoredTags = (uid?: string | null): Tag[] => {
  try {
    const stored = localStorage.getItem(getTagsStorageKey(uid));
    if (stored) return JSON.parse(stored);
  } catch {
    // ignore malformed cache
  }
  return [];
};

const generateTagId = () => `tag_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

export const TagProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading: authLoading } = useAuth();
  const { items, setItemTags } = useLater();

  const [tags, setTags] = useState<Tag[]>(() => loadStoredTags(null));
  const [isSyncing, setIsSyncing] = useState(false);
  const itemsRef = useRef(items);
  itemsRef.current = items;

  // Persist to localStorage as a local cache any time tags change (mirrors
  // LaterContext's item persistence pattern).
  useEffect(() => {
    try {
      localStorage.setItem(getTagsStorageKey(user?.uid || null), JSON.stringify(tags));
    } catch {
      // ignore quota errors
    }
  }, [tags, user?.uid]);

  // Load local cache / subscribe to Firestore on auth change.
  useEffect(() => {
    if (authLoading) return;
    const currentUid = user?.uid || null;

    if (currentUid) {
      setIsSyncing(true);
      const tagsColRef = collection(db, 'users', currentUid, 'tags');
      const unsubscribe = onSnapshot(
        tagsColRef,
        (snapshot) => {
          const firestoreTags: Tag[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as Tag;
            firestoreTags.push({ ...data, id: docSnap.id });
          });
          firestoreTags.sort((a, b) => a.name.localeCompare(b.name));
          setTags(firestoreTags);
          setIsSyncing(false);
        },
        (error) => {
          console.warn('Tag Firestore subscription notice, using local cache:', error);
          setTags(loadStoredTags(currentUid));
          setIsSyncing(false);
        }
      );
      return () => unsubscribe();
    } else {
      setTags(loadStoredTags(null));
      setIsSyncing(false);
    }
  }, [user?.uid, authLoading]);

  const writeTagDoc = useCallback(
    async (tagId: string, data: Partial<Tag>) => {
      if (!user?.uid) return;
      try {
        const tagRef = doc(db, 'users', user.uid, 'tags', tagId);
        await setDoc(tagRef, JSON.parse(JSON.stringify(data)), { merge: true });
      } catch (err) {
        console.error('Tag Firestore write failure:', err);
      }
    },
    [user?.uid]
  );

  const deleteTagDoc = useCallback(
    async (tagId: string) => {
      if (!user?.uid) return;
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'tags', tagId));
      } catch (err) {
        console.error('Tag Firestore delete failure:', err);
      }
    },
    [user?.uid]
  );

  const createTag = (name: string, color: TagColor): Tag => {
    const trimmed = name.trim();
    const newTag: Tag = {
      id: generateTagId(),
      name: trimmed || 'Untitled tag',
      color,
      createdAt: new Date().toISOString(),
    };
    setTags((prev) => [...prev, newTag].sort((a, b) => a.name.localeCompare(b.name)));
    writeTagDoc(newTag.id, newTag);
    return newTag;
  };

  const renameTag = (id: string, name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    setTags((prev) =>
      prev
        .map((t) => (t.id === id ? { ...t, name: trimmed } : t))
        .sort((a, b) => a.name.localeCompare(b.name))
    );
    writeTagDoc(id, { name: trimmed });
  };

  const recolorTag = (id: string, color: TagColor) => {
    setTags((prev) => prev.map((t) => (t.id === id ? { ...t, color } : t)));
    writeTagDoc(id, { color });
  };

  // Deleting a tag never deletes memories — it only removes the tag itself
  // and strips the (now-invalid) reference from any item that had it.
  const deleteTag = (id: string) => {
    setTags((prev) => prev.filter((t) => t.id !== id));
    deleteTagDoc(id);
    itemsRef.current
      .filter((it) => (it.tagIds || []).includes(id))
      .forEach((it) => {
        setItemTags(it.id, (it.tagIds || []).filter((tagId) => tagId !== id));
      });
  };

  const addTagToItem = (itemId: string, tagId: string) => {
    const item = itemsRef.current.find((it) => it.id === itemId);
    const current = item?.tagIds || [];
    if (current.includes(tagId)) return;
    setItemTags(itemId, [...current, tagId]);
  };

  const removeTagFromItem = (itemId: string, tagId: string) => {
    const item = itemsRef.current.find((it) => it.id === itemId);
    const current = item?.tagIds || [];
    setItemTags(itemId, current.filter((id) => id !== tagId));
  };

  const getTagById = (id: string) => tags.find((t) => t.id === id);

  const countForTag = (id: string) =>
    itemsRef.current.filter((it) => !it.isArchived && (it.tagIds || []).includes(id)).length;

  return (
    <TagContext.Provider
      value={{
        tags,
        isSyncing,
        createTag,
        renameTag,
        recolorTag,
        deleteTag,
        addTagToItem,
        removeTagFromItem,
        getTagById,
        countForTag,
      }}
    >
      {children}
    </TagContext.Provider>
  );
};

export const useTags = (): TagContextType => {
  const ctx = useContext(TagContext);
  if (!ctx) throw new Error('useTags must be used within a TagProvider');
  return ctx;
};
