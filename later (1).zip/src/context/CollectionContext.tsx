import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { collection, doc, setDoc, deleteDoc, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthContext';
import { useLater } from './LaterContext';

export type CollectionIcon =
  | 'leaf'
  | 'graduation'
  | 'plane'
  | 'heart'
  | 'briefcase'
  | 'idea'
  | 'dumbbell'
  | 'home'
  | 'people'
  | 'star'
  | 'coffee'
  | 'folder';

export const COLLECTION_ICON_ORDER: CollectionIcon[] = [
  'leaf',
  'graduation',
  'plane',
  'heart',
  'briefcase',
  'idea',
  'dumbbell',
  'home',
  'people',
  'star',
  'coffee',
  'folder',
];

export type CollectionColor =
  | 'green'
  | 'blue'
  | 'violet'
  | 'gold'
  | 'rose'
  | 'mint'
  | 'lavender'
  | 'peach'
  | 'pink'
  | 'sky';

/** Curated palette — 5 saturated + 5 pastel, matching the reference design.
 * "green" deliberately reuses the app's own --accent hex so a green
 * collection reads as a natural extension of the brand, not a coincidence. */
export const COLLECTION_COLOR_SWATCHES: Record<CollectionColor, string> = {
  green: '#1F5A46',
  blue: '#3B82F6',
  violet: '#8B5CF6',
  gold: '#EAB308',
  rose: '#F76C6C',
  mint: '#8FD9B0',
  lavender: '#C9B8F0',
  peach: '#F6C89F',
  pink: '#F5B8C4',
  sky: '#A9D3F5',
};

export const COLLECTION_COLOR_ORDER: CollectionColor[] = [
  'green',
  'blue',
  'violet',
  'gold',
  'rose',
  'mint',
  'lavender',
  'peach',
  'pink',
  'sky',
];

const hexToRgb = (hex: string): [number, number, number] => {
  const clean = hex.replace('#', '');
  return [
    parseInt(clean.substring(0, 2), 16),
    parseInt(clean.substring(2, 4), 16),
    parseInt(clean.substring(4, 6), 16),
  ];
};

/** Soft translucent tint of a collection color — used for icon-chip
 * backgrounds so every color reads as a pale square with a colored icon,
 * regardless of theme. */
export const collectionColorTint = (color: CollectionColor, alpha = 0.16): string => {
  const [r, g, b] = hexToRgb(COLLECTION_COLOR_SWATCHES[color]);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
};

export interface Collection {
  id: string;
  name: string;
  icon: CollectionIcon;
  color: CollectionColor;
  createdAt: string;
}

interface CollectionContextType {
  collections: Collection[];
  isSyncing: boolean;
  createCollection: (name: string, icon: CollectionIcon, color: CollectionColor) => Collection;
  renameCollection: (id: string, name: string) => void;
  recolorCollection: (id: string, color: CollectionColor) => void;
  reiconCollection: (id: string, icon: CollectionIcon) => void;
  deleteCollection: (id: string) => void;
  addMemoryToCollection: (itemId: string, collectionId: string) => void;
  removeMemoryFromCollection: (itemId: string, collectionId: string) => void;
  getCollectionById: (id: string) => Collection | undefined;
  /** Derived, not stored — a collection's "memory IDs" are computed from
   * each item's own collectionIds[] (mirrors how Tags work) rather than
   * kept as a second, duplicate list that could drift out of sync. */
  memoryIdsForCollection: (id: string) => string[];
  countForCollection: (id: string) => number;
}

const CollectionContext = createContext<CollectionContextType | undefined>(undefined);

const GUEST_COLLECTIONS_KEY = 'later_universal_collections_v1';
const getCollectionsStorageKey = (uid?: string | null) =>
  uid ? `later_user_collections_${uid}` : GUEST_COLLECTIONS_KEY;

const loadStoredCollections = (uid?: string | null): Collection[] => {
  try {
    const stored = localStorage.getItem(getCollectionsStorageKey(uid));
    if (stored) return JSON.parse(stored);
  } catch {
    // ignore malformed cache
  }
  return [];
};

const generateCollectionId = () => `col_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

export const CollectionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading: authLoading } = useAuth();
  const { items, setItemCollections } = useLater();

  const [collections, setCollections] = useState<Collection[]>(() => loadStoredCollections(null));
  const [isSyncing, setIsSyncing] = useState(false);
  const itemsRef = useRef(items);
  itemsRef.current = items;

  useEffect(() => {
    try {
      localStorage.setItem(getCollectionsStorageKey(user?.uid || null), JSON.stringify(collections));
    } catch {
      // ignore quota errors
    }
  }, [collections, user?.uid]);

  useEffect(() => {
    if (authLoading) return;
    const currentUid = user?.uid || null;

    if (currentUid) {
      setIsSyncing(true);
      const colRef = collection(db, 'users', currentUid, 'collections');
      const unsubscribe = onSnapshot(
        colRef,
        (snapshot) => {
          const firestoreCollections: Collection[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as Collection;
            firestoreCollections.push({ ...data, id: docSnap.id });
          });
          firestoreCollections.sort(
            (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
          );
          setCollections(firestoreCollections);
          setIsSyncing(false);
        },
        (error) => {
          console.warn('Collection Firestore subscription notice, using local cache:', error);
          setCollections(loadStoredCollections(currentUid));
          setIsSyncing(false);
        }
      );
      return () => unsubscribe();
    } else {
      setCollections(loadStoredCollections(null));
      setIsSyncing(false);
    }
  }, [user?.uid, authLoading]);

  const writeCollectionDoc = useCallback(
    async (id: string, data: Partial<Collection>) => {
      if (!user?.uid) return;
      try {
        const ref = doc(db, 'users', user.uid, 'collections', id);
        await setDoc(ref, JSON.parse(JSON.stringify(data)), { merge: true });
      } catch (err) {
        console.error('Collection Firestore write failure:', err);
      }
    },
    [user?.uid]
  );

  const deleteCollectionDoc = useCallback(
    async (id: string) => {
      if (!user?.uid) return;
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'collections', id));
      } catch (err) {
        console.error('Collection Firestore delete failure:', err);
      }
    },
    [user?.uid]
  );

  const createCollection = (name: string, icon: CollectionIcon, color: CollectionColor): Collection => {
    const trimmed = name.trim();
    const newCollection: Collection = {
      id: generateCollectionId(),
      name: trimmed || 'Untitled collection',
      icon,
      color,
      createdAt: new Date().toISOString(),
    };
    setCollections((prev) => [newCollection, ...prev]);
    writeCollectionDoc(newCollection.id, newCollection);
    return newCollection;
  };

  const renameCollection = (id: string, name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    setCollections((prev) => prev.map((c) => (c.id === id ? { ...c, name: trimmed } : c)));
    writeCollectionDoc(id, { name: trimmed });
  };

  const recolorCollection = (id: string, color: CollectionColor) => {
    setCollections((prev) => prev.map((c) => (c.id === id ? { ...c, color } : c)));
    writeCollectionDoc(id, { color });
  };

  const reiconCollection = (id: string, icon: CollectionIcon) => {
    setCollections((prev) => prev.map((c) => (c.id === id ? { ...c, icon } : c)));
    writeCollectionDoc(id, { icon });
  };

  // Deleting a collection never deletes memories — it only removes the
  // collection itself and strips the (now-invalid) reference from any item
  // that belonged to it.
  const deleteCollection = (id: string) => {
    setCollections((prev) => prev.filter((c) => c.id !== id));
    deleteCollectionDoc(id);
    itemsRef.current
      .filter((it) => (it.collectionIds || []).includes(id))
      .forEach((it) => {
        setItemCollections(it.id, (it.collectionIds || []).filter((cid) => cid !== id));
      });
  };

  const addMemoryToCollection = (itemId: string, collectionId: string) => {
    const item = itemsRef.current.find((it) => it.id === itemId);
    const current = item?.collectionIds || [];
    if (current.includes(collectionId)) return;
    setItemCollections(itemId, [...current, collectionId]);
  };

  const removeMemoryFromCollection = (itemId: string, collectionId: string) => {
    const item = itemsRef.current.find((it) => it.id === itemId);
    const current = item?.collectionIds || [];
    setItemCollections(itemId, current.filter((id) => id !== collectionId));
  };

  const getCollectionById = (id: string) => collections.find((c) => c.id === id);

  const memoryIdsForCollection = (id: string) =>
    itemsRef.current.filter((it) => !it.isArchived && (it.collectionIds || []).includes(id)).map((it) => it.id);

  const countForCollection = (id: string) => memoryIdsForCollection(id).length;

  return (
    <CollectionContext.Provider
      value={{
        collections,
        isSyncing,
        createCollection,
        renameCollection,
        recolorCollection,
        reiconCollection,
        deleteCollection,
        addMemoryToCollection,
        removeMemoryFromCollection,
        getCollectionById,
        memoryIdsForCollection,
        countForCollection,
      }}
    >
      {children}
    </CollectionContext.Provider>
  );
};

export const useCollections = (): CollectionContextType => {
  const ctx = useContext(CollectionContext);
  if (!ctx) throw new Error('useCollections must be used within a CollectionProvider');
  return ctx;
};
