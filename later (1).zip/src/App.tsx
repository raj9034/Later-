/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext';
import { LaterProvider, useLater } from './context/LaterContext';
import { ThemeProvider } from './context/ThemeContext';
import { Header } from './components/Header';
import { UniversalCapture } from './components/UniversalCapture';
import { HorizontalSwipeNav } from './components/HorizontalSwipeNav';
import { TimelineList } from './components/TimelineList';
import { ScheduleView } from './components/ScheduleView';
import { WhenToBringBackModal } from './components/WhenToBringBackModal';
import { ItemDetailSheet } from './components/ItemDetailSheet';
import { Toast } from './components/Toast';
import { InstantCaptureOrb } from './components/instant-capture/InstantCaptureOrb';
import { UniversalRecallSearch } from './components/UniversalRecallSearch';
import { CreateAccountModal } from './components/auth/CreateAccountModal';
import { OnboardingModal } from './components/onboarding/OnboardingModal';
import { HelpFaqModal } from './components/onboarding/HelpFaqModal';
import { FeatureTourOverlay } from './components/onboarding/FeatureTourOverlay';
import { BackgroundGrainOverlay } from './components/BackgroundGrainOverlay';
import { BottomNav, BottomNavTab } from './components/ui/BottomNav';
import { ProfileScreen } from './components/ProfileScreen';
import { ExactAlarmPermissionDialog } from './components/ui/ExactAlarmPermissionDialog';
import { HomeHero, HomeQuoteCard } from './components/HomeHero';
import { Sidebar } from './components/sidebar/Sidebar';
import { SidebarScreenRouter } from './components/sidebar/SidebarScreens';
import { SidebarView } from './components/sidebar/sidebarUtils';

const HomeScreen: React.FC = () => {
  const {
    isSearchOpen,
    setIsSearchOpen,
    isExactAlarmDialogOpen,
    confirmExactAlarmDialog,
    dismissExactAlarmDialog,
  } = useLater();
  const [isHelpOpen, setIsHelpOpen] = useState<boolean>(false);
  const [isForceOnboardingOpen, setIsForceOnboardingOpen] = useState<boolean>(false);
  const [isForceTourOpen, setIsForceTourOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<BottomNavTab>('home');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [sidebarView, setSidebarView] = useState<SidebarView | null>(null);
  const captureSectionRef = useRef<HTMLElement | null>(null);

  // Dynamically sync capture bar height for downstream sticky section headers
  useEffect(() => {
    if (!captureSectionRef.current) return;
    const updateHeight = () => {
      if (captureSectionRef.current) {
        const rect = captureSectionRef.current.getBoundingClientRect();
        if (rect.height > 0) {
          document.documentElement.style.setProperty('--capture-bar-height', `${Math.round(rect.height)}px`);
        }
      }
    };
    updateHeight();
    const observer = new ResizeObserver(updateHeight);
    observer.observe(captureSectionRef.current);
    return () => observer.disconnect();
  }, []);

  // Search is rendered as a real conditional branch inside <main> (see
  // below), mounted/unmounted exactly like Home/Schedule/Profile — not an
  // overlay. Switching to any other tab must still close isSearchOpen so
  // that branch stops rendering.
  const handleTabChange = (tab: BottomNavTab) => {
    setSidebarView(null);
    if (tab === 'search') {
      setIsSearchOpen(true);
      return;
    }
    setIsSearchOpen(false);
    setActiveTab(tab);
  };

  const handleSidebarNavigate = (view: SidebarView) => {
    setIsSearchOpen(false);
    setSidebarView(view);
  };

  const handleSidebarOpenSearch = () => {
    setSidebarView(null);
    setIsSearchOpen(true);
  };

  // Manually replaying the tour (e.g. from Profile) must first return to the
  // Home tab, since several tour steps target elements (capture bar, "What
  // Should I Deal With") that only exist while Home is the active screen.
  const handleReplayTour = () => {
    setActiveTab('home');
    setIsSearchOpen(false);
    setIsForceTourOpen(true);
  };

  // Fires the moment a brand-new user finishes onboarding. The tour's own
  // auto-trigger effect (based on hasSeenOnboarding/hasSeenFeatureTour from
  // AuthContext) depends on Firestore round-trip state that can race against
  // Google Sign-In's own onAuthStateChanged handler — on a fresh account,
  // both fire close together and can interleave unpredictably, which was
  // silently swallowing the tour on some first launches. Force-opening it
  // directly here, from a plain local state flip with no async dependency,
  // makes the tour deterministic regardless of how that race resolves.
  const handleOnboardingComplete = () => {
    setActiveTab('home');
    setIsForceTourOpen(true);
  };

  const handleCloseSearch = () => {
    setIsSearchOpen(false);
  };

  return (
    <div
      id="app-root-container"
      className="min-h-screen text-[var(--text-primary)] flex flex-col font-sans relative selection:bg-[var(--accent-soft)] selection:text-[var(--text-primary)] transition-colors duration-200"
      style={{ background: 'var(--bg-gradient)' }}
    >
      {/* Light Mode SVG feTurbulence Grain / Noise Texture Overlay */}
      <BackgroundGrainOverlay />

      {/* Toast Feedback */}
      <Toast />

      {/* Floating Instant Capture Orb for Cross-App Clipboard Experience */}
      <InstantCaptureOrb />

      {/* Header with Brand & Help Entry (account controls now live in Profile tab) */}
      <Header
        activeTab={activeTab}
        onOpenHelp={() => setIsHelpOpen(true)}
        onOpenOnboarding={() => setIsForceOnboardingOpen(true)}
        onReplayTour={handleReplayTour}
        onOpenProfile={() => handleTabChange('profile')}
        onGoToCapture={() => handleTabChange('home')}
        onOpenMenu={() => setIsSidebarOpen(true)}
      />

      {/* Secondary Navigation Drawer — quick access to All memories, Today,
          Upcoming, Unscheduled, People, Places, and quick actions. Does not
          replace the bottom-tab navigation; opens on top of it. */}
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onNavigate={handleSidebarNavigate}
        onOpenSearch={handleSidebarOpenSearch}
        onOpenProfile={() => handleTabChange('profile')}
        onRememberSomething={() => handleTabChange('home')}
      />

      {/* Main Content: switches by active bottom-nav tab. Bottom padding
          reserves room for the fixed bottom nav bar plus safe-area inset. */}
      <main
        className="flex-1 w-full max-w-xl mx-auto px-4 sm:px-6 pt-5 flex flex-col gap-4"
        style={{ paddingBottom: 'calc(72px + env(safe-area-inset-bottom, 0px))' }}
      >
        {sidebarView && !isSearchOpen && (
          <section className="flex-1">
            <SidebarScreenRouter
              view={sidebarView}
              onBack={() => setSidebarView(null)}
              onOpenSearch={handleSidebarOpenSearch}
              onNavigate={setSidebarView}
            />
          </section>
        )}

        {isSearchOpen && (
          <section className="flex-1 -mx-4 sm:-mx-6 -mt-5">
            <UniversalRecallSearch onClose={handleCloseSearch} />
          </section>
        )}

        {!isSearchOpen && !sidebarView && activeTab === 'home' && (
          <>
            <section>
              <HomeHero />
            </section>

            {/* Dominant Universal Capture - Sticky below Header, height
                driven by --header-h so it stays correctly offset across
                phones with different status bar heights */}
            <section
              ref={captureSectionRef}
              className="sticky z-20 pt-1 pb-2 bg-[var(--bg)]/90 backdrop-blur-md -mx-1 px-1 transition-colors"
              style={{ top: 'var(--header-h)' }}
            >
              <UniversalCapture />
            </section>

            <section>
              <HorizontalSwipeNav />
            </section>

            <section className="flex-1">
              <TimelineList />
            </section>

            <section>
              <HomeQuoteCard />
            </section>
          </>
        )}

        {!isSearchOpen && !sidebarView && activeTab === 'schedule' && (
          <section className="flex-1">
            <ScheduleView />
          </section>
        )}

        {!isSearchOpen && !sidebarView && activeTab === 'profile' && (
          <ProfileScreen
            onOpenHelp={() => setIsHelpOpen(true)}
            onReplayTour={handleReplayTour}
          />
        )}
      </main>

      {/* Persistent Bottom Navigation */}
      <BottomNav
        activeTab={isSearchOpen ? 'search' : activeTab}
        onChange={handleTabChange}
      />

      {/* Interactive Sheets & Modals */}
      <WhenToBringBackModal />
      <ItemDetailSheet />
      <CreateAccountModal />
      <OnboardingModal
        forceOpen={isForceOnboardingOpen}
        onClose={() => {
          setIsForceOnboardingOpen(false);
          handleOnboardingComplete();
        }}
      />
      <HelpFaqModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
        onOpenTutorial={() => setIsForceOnboardingOpen(true)}
        onReplayTour={handleReplayTour}
      />
      <FeatureTourOverlay
        forceOpen={isForceTourOpen}
        onClose={() => setIsForceTourOpen(false)}
      />
      <ExactAlarmPermissionDialog
        isOpen={isExactAlarmDialogOpen}
        onConfirm={confirmExactAlarmDialog}
        onDismiss={dismissExactAlarmDialog}
      />
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <LaterProvider>
          <HomeScreen />
        </LaterProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

