/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext';
import { LaterProvider, useLater } from './context/LaterContext';
import { ThemeProvider } from './context/ThemeContext';
import { Header } from './components/Header';
import { UniversalCapture } from './components/UniversalCapture';
import { HorizontalSwipeNav } from './components/HorizontalSwipeNav';
import { TimelineList } from './components/TimelineList';
import { ScheduleView } from './components/ScheduleView';
import { WhenToBringBackModal } from './components/WhenToBringBackModal';
import { ItemDetailSheet } from './components/ItemDetailSheet';
import { Toast } from './components/Toast';
import { InstantCaptureOrb } from './components/instant-capture/InstantCaptureOrb';
import { UniversalRecallSearch } from './components/UniversalRecallSearch';
import { CreateAccountModal } from './components/auth/CreateAccountModal';
import { OnboardingModal } from './components/onboarding/OnboardingModal';
import { HelpFaqModal } from './components/onboarding/HelpFaqModal';
import { FeatureTourOverlay } from './components/onboarding/FeatureTourOverlay';
import { BackgroundGrainOverlay } from './components/BackgroundGrainOverlay';

const HomeScreen: React.FC = () => {
  const { viewMode, isSearchOpen, setIsSearchOpen } = useLater();
  const [isHelpOpen, setIsHelpOpen] = useState<boolean>(false);
  const [isForceOnboardingOpen, setIsForceOnboardingOpen] = useState<boolean>(false);
  const [isForceTourOpen, setIsForceTourOpen] = useState<boolean>(false);
  const captureSectionRef = useRef<HTMLElement | null>(null);

  // Dynamically sync capture bar height for downstream sticky section headers
  useEffect(() => {
    if (!captureSectionRef.current) return;
    const updateHeight = () => {
      if (captureSectionRef.current) {
        const rect = captureSectionRef.current.getBoundingClientRect();
        if (rect.height > 0) {
          document.documentElement.style.setProperty('--capture-bar-height', `${Math.round(rect.height)}px`);
        }
      }
    };
    updateHeight();
    const observer = new ResizeObserver(updateHeight);
    observer.observe(captureSectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div id="app-root-container" className="min-h-screen bg-[var(--bg)] text-[var(--text-primary)] flex flex-col font-sans relative selection:bg-[var(--accent-soft)] selection:text-[var(--text-primary)] transition-colors duration-200">
      {/* Light Mode SVG feTurbulence Grain / Noise Texture Overlay */}
      <BackgroundGrainOverlay />

      {/* Toast Feedback */}
      <Toast />

      {/* Floating Instant Capture Orb for Cross-App Clipboard Experience */}
      <InstantCaptureOrb />

      {/* Universal Recall Search Overlay */}
      <UniversalRecallSearch
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
      />

      {/* Header with Account Management & Help Entry */}
      <Header
        onOpenHelp={() => setIsHelpOpen(true)}
        onOpenOnboarding={() => setIsForceOnboardingOpen(true)}
        onReplayTour={() => setIsForceTourOpen(true)}
      />

      {/* Main Single Stream Experience */}
      <main className="flex-1 w-full max-w-xl mx-auto px-4 sm:px-6 pt-5 flex flex-col gap-4">
        {/* Dominant Universal Capture - Sticky below Header (top-14, z-20) */}
        <section
          ref={captureSectionRef}
          className="sticky top-14 z-20 pt-1 pb-2 bg-[var(--bg)]/90 backdrop-blur-md -mx-1 px-1 transition-colors"
        >
          <UniversalCapture />
        </section>

        {/* Horizontal Perspective Horizon */}
        {viewMode === 'grouped' && (
          <section>
            <HorizontalSwipeNav />
          </section>
        )}

        {/* Main Content Stream: Grouped Timeline or Agenda Schedule */}
        <section className="flex-1">
          {viewMode === 'grouped' ? <TimelineList /> : <ScheduleView />}
        </section>
      </main>

      {/* Interactive Sheets & Modals */}
      <WhenToBringBackModal />
      <ItemDetailSheet />
      <CreateAccountModal />
      <OnboardingModal
        forceOpen={isForceOnboardingOpen}
        onClose={() => setIsForceOnboardingOpen(false)}
      />
      <HelpFaqModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
        onOpenTutorial={() => setIsForceOnboardingOpen(true)}
        onReplayTour={() => setIsForceTourOpen(true)}
      />
      <FeatureTourOverlay
        forceOpen={isForceTourOpen}
        onClose={() => setIsForceTourOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <LaterProvider>
          <HomeScreen />
        </LaterProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

