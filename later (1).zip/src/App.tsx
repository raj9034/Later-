/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Leaf } from 'lucide-react';
import { AuthProvider, useAuth, ONBOARDING_STORAGE_KEY } from './context/AuthContext';
import { LaterProvider, useLater } from './context/LaterContext';
import { TagProvider } from './context/TagContext';
import { CollectionProvider } from './context/CollectionContext';
import { ThemeProvider } from './context/ThemeContext';
import { Header } from './components/Header';
import { UniversalCapture } from './components/UniversalCapture';
import { HorizontalSwipeNav } from './components/HorizontalSwipeNav';
import { TimelineList } from './components/TimelineList';
import { ScheduleView } from './components/ScheduleView';
import { WhenToBringBackModal } from './components/WhenToBringBackModal';
import { ItemDetailSheet } from './components/ItemDetailSheet';
import { Toast } from './components/Toast';
import { InstantCaptureOrb } from './components/instant-capture/InstantCaptureOrb';
import { UniversalRecallSearch } from './components/UniversalRecallSearch';
import { CreateAccountModal } from './components/auth/CreateAccountModal';
import { OnboardingModal } from './components/onboarding/OnboardingModal';
import { HelpFaqModal } from './components/onboarding/HelpFaqModal';
import { FeatureTourOverlay } from './components/onboarding/FeatureTourOverlay';
import { BackgroundGrainOverlay } from './components/BackgroundGrainOverlay';
import { BottomNav, BottomNavTab } from './components/ui/BottomNav';
import { ProfileScreen } from './components/ProfileScreen';
import { ExactAlarmPermissionDialog } from './components/ui/ExactAlarmPermissionDialog';
import { HomeHero, HomeQuoteCard } from './components/HomeHero';
import { Sidebar } from './components/sidebar/Sidebar';
import { SidebarScreenRouter } from './components/sidebar/SidebarScreens';
import { SidebarView } from './components/sidebar/sidebarUtils';
import { CollectionsScreen } from './components/collections/CollectionScreens';
import { QuickCapture, buildQuickCaptureResult } from './lib/quickCapture';
import { scheduleAndVerifyReminder } from './utils/nativeNotifications';
import { NotificationRecoveryPrompt } from './components/notifications/NotificationRecoveryPrompt';
import { ReminderNotificationGate } from './components/notifications/ReminderNotificationGate';

const HomeScreen: React.FC = () => {
  const {
    isSearchOpen,
    setIsSearchOpen,
    isExactAlarmDialogOpen,
    confirmExactAlarmDialog,
    dismissExactAlarmDialog,
    reminderNotificationGate,
  } = useLater();
  const { loading: authLoading, user, hasSeenOnboarding } = useAuth();

  // Mirrors OnboardingModal's own initial-state check exactly, so the
  // recovery prompt and onboarding never disagree about whether onboarding
  // is done. Only relevant once authLoading is false (see the splash gate
  // below), by which point both `user` and `hasSeenOnboarding` are settled.
  const hasCompletedOnboarding = user
    ? hasSeenOnboarding === true
    : (() => {
        try {
          return !!localStorage.getItem(ONBOARDING_STORAGE_KEY);
        } catch {
          return false;
        }
      })();
  const [isHelpOpen, setIsHelpOpen] = useState<boolean>(false);
  const [isForceOnboardingOpen, setIsForceOnboardingOpen] = useState<boolean>(false);
  const [isForceTourOpen, setIsForceTourOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<BottomNavTab>('home');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [sidebarView, setSidebarView] = useState<SidebarView | null>(null);
  const captureSectionRef = useRef<HTMLElement | null>(null);

  // Dynamically sync capture bar height for downstream sticky section headers
  useEffect(() => {
    if (!captureSectionRef.current) return;
    const updateHeight = () => {
      if (captureSectionRef.current) {
        const rect = captureSectionRef.current.getBoundingClientRect();
        if (rect.height > 0) {
          document.documentElement.style.setProperty('--capture-bar-height', `${Math.round(rect.height)}px`);
        }
      }
    };
    updateHeight();
    const observer = new ResizeObserver(updateHeight);
    observer.observe(captureSectionRef.current);
    return () => observer.disconnect();
  }, []);

  // Search is rendered as a real conditional branch inside <main> (see
  // below), mounted/unmounted exactly like Home/Schedule/Profile — not an
  // overlay. Switching to any other tab must still close isSearchOpen so
  // that branch stops rendering.
  const handleTabChange = (tab: BottomNavTab) => {
    setSidebarView(null);
    if (tab === 'search') {
      setIsSearchOpen(true);
      return;
    }
    setIsSearchOpen(false);
    setActiveTab(tab);
  };

  const handleSidebarNavigate = (view: SidebarView) => {
    setIsSearchOpen(false);
    setSidebarView(view);
  };

  const handleSidebarOpenSearch = () => {
    setSidebarView(null);
    setIsSearchOpen(true);
  };

  // Manually replaying the tour (e.g. from Profile) must first return to the
  // Home tab, since several tour steps target elements (capture bar, "What
  // Should I Deal With") that only exist while Home is the active screen.
  const handleReplayTour = () => {
    setActiveTab('home');
    setIsSearchOpen(false);
    setIsForceTourOpen(true);
  };

  // Fires the moment a brand-new user finishes onboarding. The tour's own
  // auto-trigger effect (based on hasSeenOnboarding/hasSeenFeatureTour from
  // AuthContext) depends on Firestore round-trip state that can race against
  // Google Sign-In's own onAuthStateChanged handler — on a fresh account,
  // both fire close together and can interleave unpredictably, which was
  // silently swallowing the tour on some first launches. Force-opening it
  // directly here, from a plain local state flip with no async dependency,
  // makes the tour deterministic regardless of how that race resolves.
  const handleOnboardingComplete = () => {
    setActiveTab('home');
    setIsForceTourOpen(true);
  };

  const handleCloseSearch = () => {
    setIsSearchOpen(false);
  };

  // First-launch sequencing fix: while Firebase auth is still resolving
  // its initial state (the same `authLoading` AuthContext already tracks,
  // not a new timer), we don't yet know whether this is a returning user
  // (skip onboarding) or a fresh one (must see onboarding before Home).
  // Rendering Home unconditionally here — as this used to do — let Home
  // paint first and onboarding "catch up" ~2-3s later once auth resolved,
  // which is exactly the flash this fixes. This branded loading state
  // reuses the identical badge treatment as OnboardingModal's own splash
  // step, so the visual handoff from here into onboarding (or straight to
  // Home for a returning user) is seamless either way.
  if (authLoading) {
    return (
      <div
        className="min-h-screen flex flex-col items-center justify-center gap-5"
        style={{ background: 'var(--bg-gradient)' }}
      >
        <div className="w-16 h-16 rounded-2xl bg-[var(--accent)] flex items-center justify-center">
          <Leaf className="w-7 h-7 text-white" />
        </div>
        <h1 className="type-page-title text-[var(--text-primary)]">Later</h1>
      </div>
    );
  }

  return (
    <div
      id="app-root-container"
      className="min-h-screen text-[var(--text-primary)] flex flex-col font-sans relative selection:bg-[var(--accent-soft)] selection:text-[var(--text-primary)] transition-colors duration-200"
      style={{ background: 'var(--bg-gradient)' }}
    >
      {/* Light Mode SVG feTurbulence Grain / Noise Texture Overlay */}
      <BackgroundGrainOverlay />

      {/* Toast Feedback */}
      <Toast />

      {/* Floating Instant Capture Orb for Cross-App Clipboard Experience */}
      <InstantCaptureOrb />

      {/* Header with Brand & Help Entry (account controls now live in Profile tab) */}
      <Header
        activeTab={activeTab}
        onOpenHelp={() => setIsHelpOpen(true)}
        onOpenOnboarding={() => setIsForceOnboardingOpen(true)}
        onReplayTour={handleReplayTour}
        onOpenProfile={() => handleTabChange('profile')}
        onGoToCapture={() => handleTabChange('home')}
        onOpenMenu={() => setIsSidebarOpen(true)}
      />

      {/* Secondary Navigation Drawer — quick access to All memories, Today,
          Upcoming, Unscheduled, People, Places, and quick actions. Does not
          replace the bottom-tab navigation; opens on top of it. */}
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onNavigate={handleSidebarNavigate}
        onOpenSearch={handleSidebarOpenSearch}
        onOpenProfile={() => handleTabChange('profile')}
        onRememberSomething={() => handleTabChange('home')}
        onOpenCollections={() => handleTabChange('collections')}
      />

      {/* Main Content: switches by active bottom-nav tab. Bottom padding
          reserves room for the fixed bottom nav bar plus safe-area inset. */}
      <main
        className="flex-1 w-full max-w-xl mx-auto px-4 sm:px-6 pt-5 flex flex-col gap-4"
        style={{ paddingBottom: 'calc(72px + env(safe-area-inset-bottom, 0px))' }}
      >
        {sidebarView && !isSearchOpen && (
          <section className="flex-1">
            <SidebarScreenRouter
              view={sidebarView}
              onBack={() => setSidebarView(null)}
              onOpenSearch={handleSidebarOpenSearch}
              onNavigate={setSidebarView}
            />
          </section>
        )}

        {isSearchOpen && (
          <section className="flex-1 -mx-4 sm:-mx-6 -mt-5">
            <UniversalRecallSearch onClose={handleCloseSearch} />
          </section>
        )}

        {!isSearchOpen && !sidebarView && activeTab === 'home' && (
          <>
            <section>
              <HomeHero />
            </section>

            {/* Dominant Universal Capture - Sticky below Header, height
                driven by --header-h so it stays correctly offset across
                phones with different status bar heights */}
            <section
              ref={captureSectionRef}
              className="sticky z-20 pt-1 pb-2 bg-[var(--bg)]/90 backdrop-blur-md -mx-1 px-1 transition-colors"
              style={{ top: 'var(--header-h)' }}
            >
              <UniversalCapture />
            </section>

            <section>
              <HorizontalSwipeNav />
            </section>

            <section className="flex-1">
              <TimelineList />
            </section>

            <section>
              <HomeQuoteCard />
            </section>
          </>
        )}

        {!isSearchOpen && !sidebarView && activeTab === 'schedule' && (
          <section className="flex-1">
            <ScheduleView />
          </section>
        )}

        {!isSearchOpen && !sidebarView && activeTab === 'collections' && (
          <section className="flex-1">
            <CollectionsScreen />
          </section>
        )}

        {!isSearchOpen && !sidebarView && activeTab === 'profile' && (
          <ProfileScreen
            onOpenHelp={() => setIsHelpOpen(true)}
            onReplayTour={handleReplayTour}
          />
        )}
      </main>

      {/* Persistent Bottom Navigation */}
      <BottomNav
        activeTab={isSearchOpen ? 'search' : activeTab}
        onChange={handleTabChange}
      />

      {/* Interactive Sheets & Modals */}
      <WhenToBringBackModal />
      <ItemDetailSheet />
      <CreateAccountModal />
      <OnboardingModal
        forceOpen={isForceOnboardingOpen}
        onClose={() => {
          setIsForceOnboardingOpen(false);
          handleOnboardingComplete();
        }}
      />
      <HelpFaqModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
        onOpenTutorial={() => setIsForceOnboardingOpen(true)}
        onReplayTour={handleReplayTour}
      />
      <FeatureTourOverlay
        forceOpen={isForceTourOpen}
        onClose={() => setIsForceTourOpen(false)}
      />
      <ExactAlarmPermissionDialog
        isOpen={isExactAlarmDialogOpen}
        onConfirm={confirmExactAlarmDialog}
        onDismiss={dismissExactAlarmDialog}
      />
      <NotificationRecoveryPrompt
        suppressForOnboarding={!hasCompletedOnboarding || isForceOnboardingOpen}
      />
      <ReminderNotificationGate pending={reminderNotificationGate} />
    </div>
  );
};

/**
 * QUICK CAPTURE — live-bridge fast path. Mounted inside the real
 * provider tree so it can call the exact same saveItem() the in-app
 * UniversalCapture screen uses. Only fires when native decided the
 * app's real WebView was already alive and handed the text straight
 * here instead of spinning up a headless WebView. Renders nothing.
 *
 * WHY THIS IS SHAPED THE WAY IT IS (real-device bugs, traced from code):
 *
 * 1. STALE saveItem. The native-event listener below is registered once
 *    (empty dependency array — it must not re-subscribe on every render).
 *    Anything it referenced directly was therefore frozen at the FIRST
 *    render, including `saveItem`. On that first render auth hasn't
 *    resolved, so `user` is null, and saveItem() only writes to
 *    Firestore when `user?.uid` is set — meaning every fast-path capture
 *    for a signed-in user skipped the Firestore write entirely and
 *    existed only in local React state. The next Firestore snapshot
 *    replaces that state wholesale, so the item vanished, and
 *    LaterContext's own reconcile then cancelled its alarm. Fixed with
 *    the standard "latest ref" pattern: the listener stays registered
 *    once, but always calls whatever saveItem the most recent render
 *    produced (with the current user).
 *
 * 2. AUTH NOT READY. If native delivers text before auth has resolved
 *    (app just cold-started, process alive from the foreground
 *    service), there is no `user` yet either. Captures that arrive in
 *    that window are queued and flushed the moment auth resolves.
 *
 * 3. NO HEURISTICS. Earlier versions inferred "the save landed" from
 *    `items.length` (and before that from isSyncing / a setInterval
 *    poll that background WebViews throttle). saveItem() returns the
 *    created item, so we act on that object directly: schedule ITS
 *    alarm, then report. Nothing waits on a re-render.
 *
 * Scheduling is additive-only (see nativeNotifications.ts): this path
 * only ever needs to add its own alarm, never to reconcile everyone
 * else's, and LaterContext's own reconcile keeps running as normal. The
 * alarm is then READ BACK from Android before anything is reported, and
 * the text is acknowledged to native the instant it is accepted so native
 * knows this page really is alive (QuickCaptureEntryActivity falls back to
 * the headless page if it doesn't hear that within 3s).
 */
// Keep in sync with QuickCaptureEntryActivity.ACK_TIMEOUT_MS (native).
const FAST_PATH_MAX_AGE_MS = 3000;

function QuickCaptureLiveBridge() {
  const { saveItem } = useLater();
  const { loading: authLoading } = useAuth();

  // Updated during render, so these always hold the newest closures.
  const saveItemRef = useRef(saveItem);
  saveItemRef.current = saveItem;
  const authLoadingRef = useRef(authLoading);
  authLoadingRef.current = authLoading;

  const queuedTextsRef = useRef<string[]>([]);

  const processCaptureRef = useRef<(text: string) => Promise<void>>(async () => {});
  processCaptureRef.current = async (text: string) => {
    let saved: ReturnType<typeof saveItem>;
    try {
      saved = saveItemRef.current(text);
    } catch (e) {
      QuickCapture.reportResult({ success: false, saved: false, error: String(e), text });
      return;
    }
    // Schedules the alarm (additive-only) AND reads it back from Android.
    // Success is only reported if the memory saved and any reminder the
    // text asked for is confirmed to exist — see buildQuickCaptureResult.
    const reminder = await scheduleAndVerifyReminder(saved);
    QuickCapture.reportResult(buildQuickCaptureResult(text, true, reminder));
  };

  useEffect(() => {
    let removeListener: (() => void) | undefined;
    let cancelled = false;

    QuickCapture.addListener('captureTextReceived', ({ text, sentAt }) => {
      if (!text || !text.trim()) return;
      // Native re-routes a capture to the headless page if this page hasn't
      // acknowledged it within FAST_PATH_MAX_AGE_MS. A page that wakes up
      // late (throttled/frozen WebView) must NOT also save it, or the same
      // text would be captured twice.
      if (typeof sentAt === 'number' && Date.now() - sentAt > FAST_PATH_MAX_AGE_MS) return;
      // Tell native we have it, so it doesn't fall back to the headless page.
      QuickCapture.ackCapture().catch(() => {});
      if (authLoadingRef.current) {
        queuedTextsRef.current.push(text);
        return;
      }
      void processCaptureRef.current(text);
    }).then((handle) => {
      if (cancelled) {
        handle.remove();
      } else {
        removeListener = () => {
          handle.remove();
        };
      }
    });

    return () => {
      cancelled = true;
      removeListener?.();
    };
  }, []);

  // Flush anything that arrived while auth was still resolving.
  useEffect(() => {
    if (authLoading) return;
    const queued = queuedTextsRef.current.splice(0);
    queued.forEach((text) => {
      void processCaptureRef.current(text);
    });
  }, [authLoading]);

  return null;
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <LaterProvider>
          <TagProvider>
            <CollectionProvider>
              <HomeScreen />
              <QuickCaptureLiveBridge />
            </CollectionProvider>
          </TagProvider>
        </LaterProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

