import { registerPlugin, Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { requestNotificationPermission } from './nativeNotifications';

export type NotificationPermissionStatus = 'granted' | 'denied' | 'prompt';

interface NotificationSettingsPlugin {
  open(): Promise<{ opened: boolean }>;
}

const NotificationSettings = registerPlugin<NotificationSettingsPlugin>('NotificationSettings');

/**
 * Live, authoritative read of Android's actual notification permission
 * state — always queried fresh from the OS, never from a cached/stored
 * value. This is the single source of truth the whole recovery flow is
 * built on.
 */
export async function getNotificationPermissionStatus(): Promise<NotificationPermissionStatus> {
  if (!Capacitor.isNativePlatform()) {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'granted') return 'granted';
      if (Notification.permission === 'denied') return 'denied';
      return 'prompt';
    }
    return 'prompt';
  }

  try {
    const status = await LocalNotifications.checkPermissions();
    if (status.display === 'granted') return 'granted';
    if (status.display === 'denied') return 'denied';
    return 'prompt';
  } catch {
    return 'prompt';
  }
}

// --- "Have we already used our one shot at the real OS dialog?" ---
// Auxiliary UX state ONLY — used to decide whether calling Android's
// requestPermissions() is likely to actually show a dialog, or whether
// Android will silently no-op because the user already answered before.
// This is never treated as the permission truth itself; every decision
// still starts with a fresh getNotificationPermissionStatus() call above.
const REQUESTED_BEFORE_KEY = 'later_notif_permission_requested_before';

export function hasRequestedNotificationPermissionBefore(): boolean {
  try {
    return localStorage.getItem(REQUESTED_BEFORE_KEY) === 'true';
  } catch {
    return false;
  }
}

function markNotificationPermissionRequested(): void {
  try {
    localStorage.setItem(REQUESTED_BEFORE_KEY, 'true');
  } catch {
    // ignore quota/storage errors — worst case we ask via the real dialog
    // one extra time, which Android itself will just no-op if blocked
  }
}

/**
 * Opens Android's notification settings screen for Later. No-op (resolves
 * quietly) on web/non-native, since there's no equivalent deep link there.
 */
export async function openNotificationSettings(): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;
  try {
    await NotificationSettings.open();
  } catch (error) {
    console.warn('[Later Notifications] Failed to open notification settings:', error);
  }
}

export interface EnableNotificationsResult {
  granted: boolean;
  /** True if we routed the user to Android Settings instead of calling
   * requestPermissions(), because we'd already used our one shot at the
   * real dialog and it's very likely Android will no longer show it. */
  routedToSettings: boolean;
}

/**
 * The single, shared "try to turn notifications on" action used by both
 * the onboarding permission step and the recovery prompts, so the
 * "have we asked before" bookkeeping only ever happens in one place.
 *
 * - Already granted -> returns immediately, no UI at all.
 * - Never asked via the real dialog before -> calls requestPermissions()
 *   (this is what actually shows Android's system dialog).
 * - Already asked before and still not granted -> Android will very
 *   likely no longer show the dialog at all, so this skips straight to
 *   opening Settings instead of calling requestPermissions() again.
 */
export async function attemptEnableNotifications(): Promise<EnableNotificationsResult> {
  const current = await getNotificationPermissionStatus();
  if (current === 'granted') {
    return { granted: true, routedToSettings: false };
  }

  if (hasRequestedNotificationPermissionBefore()) {
    await openNotificationSettings();
    return { granted: false, routedToSettings: true };
  }

  markNotificationPermissionRequested();
  const granted = await requestNotificationPermission();
  return { granted, routedToSettings: false };
}
