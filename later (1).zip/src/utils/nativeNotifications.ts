import { Capacitor } from '@capacitor/core';
import { LocalNotifications, Channel } from '@capacitor/local-notifications';
import { SavedItem } from '../types';

export const LATER_REMINDER_CHANNEL_ID = 'later_reminders';

// Hash string item ID into a deterministic 32-bit positive integer for Android Notification IDs
export function hashItemIdToNotificationId(id: string): number {
  let hash = 0;
  for (let i = 0; i < id.length; i++) {
    hash = (hash << 5) - hash + id.charCodeAt(i);
    hash |= 0; // Convert to 32bit integer
  }
  const positive = Math.abs(hash) % 2147483000;
  return positive > 0 ? positive : 1;
}

let isChannelCreated = false;
let isListenerRegistered = false;

/**
 * Ensures the Android notification channel exists (required for Android 8.0+ / API 26+)
 */
export async function setupNotificationChannel(): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;
  if (isChannelCreated) return;

  try {
    const channel: Channel = {
      id: LATER_REMINDER_CHANNEL_ID,
      name: 'Later Reminders',
      description: 'Scheduled reminders and resurfaced memories from Later',
      importance: 5, // High importance (heads-up notification)
      visibility: 1, // Public visibility
      vibration: true,
      lights: true,
      lightColor: '#FFAA33',
    };

    await LocalNotifications.createChannel(channel);
    isChannelCreated = true;
  } catch (error) {
    console.warn('[Later Native Notifications] Failed to create notification channel:', error);
  }
}

/**
 * Requests runtime notification permission (Required for Android 13+ / API 33+ POST_NOTIFICATIONS)
 */
export async function requestNotificationPermission(): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) {
    // Web fallback
    if ('Notification' in window) {
      if (Notification.permission === 'granted') return true;
      if (Notification.permission !== 'denied') {
        const result = await Notification.requestPermission();
        return result === 'granted';
      }
    }
    return false;
  }

  try {
    await setupNotificationChannel();
    const currentStatus = await LocalNotifications.checkPermissions();
    if (currentStatus.display === 'granted') {
      return true;
    }

    const requestResult = await LocalNotifications.requestPermissions();
    return requestResult.display === 'granted';
  } catch (error) {
    console.warn('[Later Native Notifications] Error requesting permission:', error);
    return false;
  }
}

/**
 * Initializes notification listeners (e.g. user taps on a notification to open the item)
 */
export function initNativeNotificationListeners(): void {
  if (!Capacitor.isNativePlatform() || isListenerRegistered) return;

  try {
    LocalNotifications.addListener('localNotificationActionPerformed', (action) => {
      const itemId = action.notification?.extra?.itemId;
      if (itemId) {
        window.dispatchEvent(
          new CustomEvent('later-open-item-detail', {
            detail: { itemId },
          })
        );
      }
    });
    isListenerRegistered = true;
  } catch (error) {
    console.warn('[Later Native Notifications] Error setting up notification listener:', error);
  }
}

/**
 * Determines the target notification timestamp for a SavedItem if scheduled
 */
function getTargetReminderTimestamp(item: SavedItem): number | null {
  if (item.isArchived || item.isDone) return null;

  // 1. Explicit reminder target
  if (
    item.reminder &&
    item.reminder.type !== 'none' &&
    item.reminder.reminderStatus === 'waiting' &&
    item.reminder.scheduledAt
  ) {
    const time = new Date(item.reminder.scheduledAt).getTime();
    if (!isNaN(time)) return time;
  }

  // 2. Scheduled date/time
  if (item.reminderTime) {
    const scheduledTime = new Date(item.reminderTime).getTime();
    if (!isNaN(scheduledTime)) {
      return scheduledTime;
    }
  }

  if (item.scheduledFor) {
    const scheduledTime = new Date(item.scheduledFor).getTime();
    if (!isNaN(scheduledTime)) {
      return scheduledTime;
    }
  }

  return null;
}

/**
 * Schedules or updates a native Android local notification for a specific memory item
 */
export async function scheduleNativeNotification(item: SavedItem): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;

  const targetTimestamp = getTargetReminderTimestamp(item);
  const now = Date.now();
  const notifId = hashItemIdToNotificationId(item.id);

  try {
    // Ensure channel is ready
    await setupNotificationChannel();

    // Cancel existing scheduled notification for this item first to avoid duplicates
    try {
      await LocalNotifications.cancel({ notifications: [{ id: notifId }] });
    } catch {
      // ignore
    }

    // Only schedule if the target time is in the future
    if (targetTimestamp && targetTimestamp > now) {
      await LocalNotifications.schedule({
        notifications: [
          {
            id: notifId,
            title: item.title ? item.title : 'Later Reminder',
            body: item.summary || item.rawInput || 'Scheduled memory for Later',
            schedule: {
              at: new Date(targetTimestamp),
              allowWhileIdle: true, // Fire even in Android Doze mode
            },
            channelId: LATER_REMINDER_CHANNEL_ID,
            extra: {
              itemId: item.id,
            },
          },
        ],
      });
    }
  } catch (error) {
    console.warn(`[Later Native Notifications] Failed to schedule notification for item ${item.id}:`, error);
  }
}

/**
 * Cancels a scheduled native notification when an item is completed, archived, or deleted
 */
export async function cancelNativeNotification(itemId: string): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;

  try {
    const notifId = hashItemIdToNotificationId(itemId);
    await LocalNotifications.cancel({ notifications: [{ id: notifId }] });
  } catch (error) {
    console.warn(`[Later Native Notifications] Failed to cancel notification for item ${itemId}:`, error);
  }
}

/**
 * Syncs the entire set of items with Android LocalNotifications
 */
export async function syncAllNativeNotifications(items: SavedItem[]): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;

  try {
    await setupNotificationChannel();
    const now = Date.now();
    const notificationsToSchedule = [];

    for (const item of items) {
      const targetTimestamp = getTargetReminderTimestamp(item);
      if (targetTimestamp && targetTimestamp > now) {
        notificationsToSchedule.push({
          id: hashItemIdToNotificationId(item.id),
          title: item.title ? item.title : 'Later Reminder',
          body: item.summary || item.rawInput || 'Scheduled memory for Later',
          schedule: {
            at: new Date(targetTimestamp),
            allowWhileIdle: true,
          },
          channelId: LATER_REMINDER_CHANNEL_ID,
          extra: {
            itemId: item.id,
          },
        });
      }
    }

    // Cancel all previously pending notifications to prevent stale ghost alarms
    const pending = await LocalNotifications.getPending();
    if (pending.notifications.length > 0) {
      await LocalNotifications.cancel({
        notifications: pending.notifications.map((n) => ({ id: n.id })),
      });
    }

    // Schedule the active set
    if (notificationsToSchedule.length > 0) {
      await LocalNotifications.schedule({
        notifications: notificationsToSchedule,
      });
    }
  } catch (error) {
    console.warn('[Later Native Notifications] Error in syncAllNativeNotifications:', error);
  }
}
