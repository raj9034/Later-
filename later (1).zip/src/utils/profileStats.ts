import { SavedItem } from '../types';

/**
 * Real, computed Profile-page stats. Every number here is derived from the
 * person's actual saved items — nothing is a placeholder or a fabricated
 * "demo" figure.
 */

const dayKey = (d: Date): string =>
  `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;

/**
 * Current streak, in days. A day counts if at least one memory was
 * captured on it. The streak counts backward from today; if nothing has
 * been captured yet today, it starts counting from yesterday instead (the
 * day isn't over yet, so a streak that was alive yesterday shouldn't read
 * as broken at 12:01am) but never fabricates a day with no capture in it.
 */
export function computeStreakDays(items: SavedItem[], now: Date = new Date()): number {
  const days = new Set<string>();
  for (const item of items) {
    if (!item.createdAt) continue;
    const d = new Date(item.createdAt);
    if (isNaN(d.getTime())) continue;
    days.add(dayKey(d));
  }
  if (days.size === 0) return 0;

  const cursor = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (!days.has(dayKey(cursor))) {
    cursor.setDate(cursor.getDate() - 1);
    if (!days.has(dayKey(cursor))) return 0;
  }

  let streak = 0;
  while (days.has(dayKey(cursor))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

/** Memories captured in the last 7 days (rolling window, not calendar week). */
export function countCapturedThisWeek(items: SavedItem[], now: Date = new Date()): number {
  const weekAgo = now.getTime() - 7 * 24 * 60 * 60 * 1000;
  return items.filter((i) => {
    if (!i.createdAt) return false;
    const t = new Date(i.createdAt).getTime();
    return !isNaN(t) && t >= weekAgo && t <= now.getTime();
  }).length;
}

/** Active (not done, not archived) memories with a reminder due in the next 24 hours. */
export function countReturningSoon(items: SavedItem[], now: Date = new Date()): number {
  const in24h = now.getTime() + 24 * 60 * 60 * 1000;
  return items.filter((i) => {
    if (i.isDone || i.isArchived) return false;
    const raw = i.reminderTime || i.scheduledFor;
    if (!raw) return false;
    const t = new Date(raw).getTime();
    return !isNaN(t) && t >= now.getTime() && t <= in24h;
  }).length;
}
