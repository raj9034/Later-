import { registerPlugin, PluginListenerHandle, Capacitor } from '@capacitor/core';

export interface SharedContent {
  hasContent: boolean;
  type?: 'text' | 'image' | 'images' | 'file';
  value?: string; // Raw text/URL or base64 image data URL (single image/text)
  images?: string[]; // Multiple shared images (base64 data URLs) — ACTION_SEND_MULTIPLE
  fileName?: string; // Display name of a shared document (PDF/Word/Excel/etc.)
  mimeType?: string; // MIME type of a shared document
  text?: string;  // Accompanying note or text for image/file shares
  subject?: string; // Subject / title if provided by the sharing app
}

export interface SendIntentPlugin {
  getSharedContent(): Promise<SharedContent>;
  clearSharedContent(): Promise<void>;
  getWidgetCaptureRequest(): Promise<{ requested: boolean }>;
  updateWidgetCount(options: { count: number }): Promise<void>;
  addListener(
    eventName: 'sharedContentReceived',
    listenerFunc: (data: SharedContent) => void
  ): Promise<PluginListenerHandle>;
  addListener(
    eventName: 'widgetCaptureRequested',
    listenerFunc: () => void
  ): Promise<PluginListenerHandle>;
  removeAllListeners(): Promise<void>;
}

export const SendIntent = registerPlugin<SendIntentPlugin>('SendIntent');

export interface ParsedSharedPayload {
  text?: string;
  image?: string;
  images?: string[]; // Present only for a multi-image share — each entry is
                      // saved as its own memory (see LaterContext), since
                      // the single capture bar can only preview one image.
  sourceType: 'text' | 'image' | 'link' | 'file';
}

/**
 * Normalizes incoming Android share sheet intent data to pre-fill the UniversalCapture UI.
 * Reuses the same link/note detection principles used by saveItem() and analyzeContent().
 */
export function parseSharedContent(data: SharedContent): ParsedSharedPayload | null {
  if (!data || !data.hasContent) return null;

  if (data.type === 'images' && data.images && data.images.length > 0) {
    return {
      images: data.images,
      text: data.text?.trim() || '',
      sourceType: 'image',
    };
  }

  if (data.type === 'image' && data.value) {
    return {
      image: data.value,
      text: data.text?.trim() || '',
      sourceType: 'image',
    };
  }

  if (data.type === 'file') {
    // Later never stores the shared file itself — only a readable
    // reference (name + type) becomes the note text, same as any other
    // text capture. The user can still enrich or reschedule it normally.
    const label = data.fileName || 'Shared file';
    const kindHint = friendlyMimeLabel(data.mimeType);
    const noteLines = [kindHint ? `${label} (${kindHint})` : label];
    const extra = data.text?.trim() || data.subject?.trim();
    if (extra) noteLines.push(extra);
    return {
      text: noteLines.join('\n'),
      sourceType: 'file',
    };
  }

  // Text or link sharing
  const rawText = data.value?.trim() || data.subject?.trim() || '';
  if (!rawText) return null;

  // Determine if it is a link or note
  const isUrl =
    /^https?:\/\//i.test(rawText) ||
    /^(www\.)?[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(\/.*)?$/i.test(rawText);

  return {
    text: rawText,
    sourceType: isUrl ? 'link' : 'text',
  };
}

/** Short, human-readable label for a document MIME type — used only to
 * annotate the text reference Later saves; never used to read the file. */
function friendlyMimeLabel(mimeType?: string): string | null {
  if (!mimeType) return null;
  const map: Record<string, string> = {
    'application/pdf': 'PDF',
    'application/msword': 'Word document',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'Word document',
    'application/vnd.ms-excel': 'Excel file',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'Excel file',
    'application/vnd.ms-powerpoint': 'PowerPoint file',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'PowerPoint file',
    'text/csv': 'CSV file',
    'application/rtf': 'RTF document',
  };
  return map[mimeType] || mimeType;
}
