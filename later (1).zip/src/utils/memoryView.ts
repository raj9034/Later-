/**
 * View-model adapters for the Quiet Signal UI.
 *
 * These are PURE functions that read a SavedItem exactly as the existing
 * intelligence + save pipeline produced it and describe it for display. They
 * never interpret content themselves (no second parser) and never change
 * what is stored — the raw capture stays the source of truth.
 *
 * Dates are formatted with the device locale (not a hard-coded en-US).
 */
import { ContentType, SavedItem, SwipeView } from '../types';
import { normalizeItemReminder } from './reminderService';

/* ---------------------------------------------------------------- basics */

const TYPE_LABEL: Record<string, string> = {
  note: 'Note', idea: 'Idea', link: 'Link', video: 'Video', article: 'Article', product: 'Product',
  screenshot: 'Screenshot', image: 'Image', task: 'Task', person: 'Person', phone_number: 'Phone number',
  place: 'Place', event: 'Event',
};
export const typeLabel = (item: SavedItem): string => TYPE_LABEL[item.contentType || item.type || 'note'] || 'Note';

const isOnlyUrl = (s: string) => /^https?:\/\/\S+$/i.test(s.trim());

/** The captured content, shown as written. Falls back to a faithful short title only when there is no text. */
export function getMemoryText(item: SavedItem): string {
  const raw = (item.rawInput || item.rawContent || '').trim();
  if (raw && !(item.url && isOnlyUrl(raw) && item.title && item.title !== raw)) return raw;
  if (item.title) return item.title;
  if (raw) return raw;
  return item.imageAttachment ? 'Image' : 'Untitled memory';
}

export function getScheduledAt(item: SavedItem): Date | null {
  const raw = item.reminderTime || item.scheduledFor || item.reminder?.scheduledAt;
  if (!raw) return null;
  const d = new Date(raw);
  return isNaN(d.getTime()) ? null : d;
}

export const isSameDay = (a: Date, b: Date) =>
  a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();

const timeOf = (d: Date) => d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

/** "today at 6:00 PM", "tomorrow at 9:00 AM", "Fri at 9:00 AM", "Sep 30 at 9:00 AM" */
export function friendlyWhen(date: Date, now: Date = new Date()): string {
  const tomorrow = new Date(now); tomorrow.setDate(now.getDate() + 1);
  const yesterday = new Date(now); yesterday.setDate(now.getDate() - 1);
  if (isSameDay(date, now)) return `today at ${timeOf(date)}`;
  if (isSameDay(date, tomorrow)) return `tomorrow at ${timeOf(date)}`;
  if (isSameDay(date, yesterday)) return `yesterday at ${timeOf(date)}`;
  const days = (date.getTime() - now.getTime()) / 86400000;
  if (days > 0 && days < 7) return `${date.toLocaleDateString(undefined, { weekday: 'short' })} at ${timeOf(date)}`;
  return `${date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} at ${timeOf(date)}`;
}

export function timeAgo(iso: string | undefined, now: Date = new Date()): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  const mins = Math.round((now.getTime() - d.getTime()) / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24 && isSameDay(d, now)) return `${hrs}h ago`;
  const yesterday = new Date(now); yesterday.setDate(now.getDate() - 1);
  if (isSameDay(d, yesterday)) return 'yesterday';
  const days = Math.round(mins / 1440);
  if (days < 7) return `${days} days ago`;
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

/* ------------------------------------------------------- lifecycle state */

export type ReturnKind = 'done' | 'due' | 'scheduled' | 'none';
export interface ReturnDescription {
  kind: ReturnKind;
  /** Full sentence-ish label, always includes text (never colour-only). */
  label: string;
  /** Short label for compact chips. */
  short: string;
  date: Date | null;
}

export function describeReturn(item: SavedItem, now: Date = new Date()): ReturnDescription {
  if (item.isDone) {
    const when = item.completedAt ? new Date(item.completedAt) : null;
    return { kind: 'done', label: when ? `Done ${friendlyWhen(when, now)}` : 'Done', short: 'Done', date: when };
  }
  const date = getScheduledAt(item);
  const reminder = normalizeItemReminder(item);
  if (date) {
    if (date.getTime() <= now.getTime()) {
      return { kind: 'due', label: `Returning now · set for ${friendlyWhen(date, now)}`, short: 'Returning now', date };
    }
    const word = reminder.type === 'flexible' ? 'Returns' : 'Returns';
    return { kind: 'scheduled', label: `${word} ${friendlyWhen(date, now)}`, short: friendlyWhen(date, now), date };
  }
  return { kind: 'none', label: 'No return time yet', short: 'No return time', date: null };
}

export const isActionMemory = (item: SavedItem): boolean => {
  const t = item.contentType || item.type;
  return t === 'task' || t === 'event' || item.intent === 'complete' || item.intent === 'call' || item.intent === 'buy' || item.intent === 'meet';
};

/** Quiet provenance: type · when captured · link domain. */
export function getProvenance(item: SavedItem, now: Date = new Date()): string[] {
  const parts = [typeLabel(item)];
  const ago = timeAgo(item.createdAt, now);
  if (ago) parts.push(`Captured ${ago}`);
  if (item.sourceDomain) parts.push(item.sourceDomain);
  return parts;
}

/* -------------------------------------------------- "Understood as" chips */

export interface InterpretationChip {
  kind: 'time' | 'person' | 'place' | 'topic' | 'intent' | 'type';
  label: string;
}

const INTENT_LABEL: Record<string, string> = {
  watch: 'To watch', read: 'To read', visit: 'To visit', call: 'To call', buy: 'To buy', research: 'To research',
  remember: 'To remember', complete: 'To complete', meet: 'To meet', explore: 'To explore',
};

/** Reads what the existing pipeline stored. Nothing here is inferred by the UI. */
export function getInterpretationChips(item: SavedItem, now: Date = new Date()): InterpretationChip[] {
  const chips: InterpretationChip[] = [];
  const ret = describeReturn(item, now);
  if (ret.kind === 'scheduled' || ret.kind === 'due') chips.push({ kind: 'time', label: ret.kind === 'due' ? `Set for ${friendlyWhen(ret.date!, now)}` : ret.label });
  (item.people || []).filter(Boolean).forEach((p) => chips.push({ kind: 'person', label: p }));
  (item.places || []).filter(Boolean).forEach((p) => chips.push({ kind: 'place', label: p }));
  (item.topics || []).filter(Boolean).slice(0, 4).forEach((t) => chips.push({ kind: 'topic', label: t }));
  if (item.intent && item.intent !== 'remember' && INTENT_LABEL[item.intent]) chips.push({ kind: 'intent', label: INTENT_LABEL[item.intent] });
  chips.push({ kind: 'type', label: typeLabel(item) });
  return chips;
}

/**
 * ONE focused clarification, only where it is genuinely checkable from what was
 * stored: a clock time typed with no am/pm that the parser turned into a
 * reminder. (The parser has already chosen a time; we are asking the user to
 * confirm the guess — we are not re-parsing.)
 */
export function getClarification(item: SavedItem, now: Date = new Date()): { question: string } | null {
  const ret = describeReturn(item, now);
  if (ret.kind !== 'scheduled' || !ret.date) return null;
  const raw = item.rawInput || '';
  const m = raw.match(/\b(?:at|@|by|around)\s+(\d{1,2})(?::(\d{2}))?(?!\s*(?:am|pm|a\.m\.|p\.m\.|:\d|\d|\s*(?:min|hour|hr|day|week|month)))/i);
  if (!m) return null;
  const hour = parseInt(m[1], 10);
  if (hour === 0 || hour > 12) return null; // 24-hour style is unambiguous
  return { question: `You didn't say AM or PM. I set this for ${friendlyWhen(ret.date, now)}. Is that right?` };
}

/* -------------------------------------------------------------- filters */

export function matchesTypeView(item: SavedItem, view: SwipeView): boolean {
  if (view === 'ALL') return true;
  const t = (item.contentType || item.type) as ContentType;
  if (view === 'LINKS') return t === 'link' || t === 'video' || t === 'product' || t === 'article';
  if (view === 'SCREENSHOTS') return t === 'screenshot' || t === 'image';
  if (view === 'NOTES') return t === 'note' || t === 'idea';
  if (view === 'TASKS') return t === 'task' || t === 'event';
  if (view === 'PEOPLE') return t === 'person' || t === 'phone_number';
  if (view === 'PLACES') return t === 'place';
  if (view === 'URGENT') return (item.urgencyTag || item.urgency) === 'urgent';
  if (view === 'IMPORTANT') return (item.urgencyTag || item.urgency) === 'important';
  if (view === 'CHILL') return (item.urgencyTag || item.urgency) === 'chill';
  return true;
}

export const TYPE_VIEW_LABEL: Partial<Record<SwipeView, string>> = {
  ALL: 'All', LINKS: 'Links', SCREENSHOTS: 'Screenshots', NOTES: 'Notes', TASKS: 'Tasks', PEOPLE: 'People', PLACES: 'Places',
  URGENT: 'Priority', IMPORTANT: 'Important', CHILL: 'Chill',
};
