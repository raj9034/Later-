/**
 * Find — retrieval with evidence.
 *
 * What this is, honestly: lexical matching (whole words + prefixes + light
 * stemming, so "flights" finds "flight") across every stored field, ranked by
 * where the match landed, plus two fallbacks that are also derived from data
 * the app already has: PARTIAL matches (only some of the words), and RELATED
 * memories (the `relatedMemoryIds` the save pipeline already computed).
 * It is not embedding-based semantic search and never claims to be.
 *
 * Every hit carries the evidence that explains it, so "why did this appear?"
 * always has a concrete answer.
 */
import { SavedItem } from '../types';
import { getMemoryText } from './memoryView';

export type MatchMode = 'exact' | 'partial' | 'related';
export interface Segment { text: string; hit: boolean; }
export interface SearchHit {
  item: SavedItem;
  mode: MatchMode;
  score: number;
  /** Human reason the memory appeared. */
  why: string;
  /** The text shown as evidence, split so matches can be highlighted without HTML injection. */
  evidence: Segment[];
}

const STOP = new Set(['the', 'a', 'an', 'and', 'or', 'of', 'to', 'in', 'on', 'for', 'my', 'that', 'this', 'with', 'about', 'i', 'it', 'is']);

export function stem(w: string): string {
  let s = w.toLowerCase();
  if (s.length > 5 && s.endsWith('ing')) s = s.slice(0, -3);
  else if (s.length > 4 && s.endsWith('ed')) s = s.slice(0, -2);
  else if (s.length > 4 && s.endsWith('es')) s = s.slice(0, -2);
  else if (s.length > 3 && s.endsWith('s')) s = s.slice(0, -1);
  return s;
}
export function tokenize(q: string): string[] {
  return (q.toLowerCase().match(/[\p{L}\p{N}]+/gu) || []).filter((t) => t.length > 1 && !STOP.has(t));
}

interface Field { key: string; label: (item: SavedItem) => string; weight: number; text: (item: SavedItem) => string; }
const FIELDS: Field[] = [
  { key: 'raw', weight: 5, text: (i) => i.rawInput || i.rawContent || '', label: () => 'Matched what you wrote' },
  { key: 'title', weight: 4, text: (i) => i.title || '', label: () => 'Matched the title' },
  { key: 'people', weight: 4, text: (i) => (i.people || []).join(' · '), label: () => 'Matched a person' },
  { key: 'places', weight: 4, text: (i) => (i.places || []).join(' · '), label: () => 'Matched a place' },
  { key: 'topics', weight: 3, text: (i) => (i.topics || []).join(' · '), label: () => 'Matched a topic' },
  { key: 'summary', weight: 3, text: (i) => i.summary || '', label: () => 'Matched the summary' },
  { key: 'link', weight: 2, text: (i) => `${i.url || ''} ${i.sourceDomain || ''}`.trim(), label: (i) => `Matched the link${i.sourceDomain ? ` (${i.sourceDomain})` : ''}` },
  { key: 'meta', weight: 2, text: (i) => Object.values(i.extractedMeta || {}).filter(Boolean).join(' '), label: () => 'Matched saved details' },
  { key: 'kind', weight: 1, text: (i) => `${i.contentType || ''} ${i.intent || ''}`, label: () => 'Matched the type' },
];

const wordMatches = (fieldText: string, term: string): boolean => {
  const st = stem(term);
  for (const w of fieldText.toLowerCase().match(/[\p{L}\p{N}]+/gu) || []) {
    if (w === term || stem(w) === st || (term.length >= 3 && w.startsWith(term))) return true;
  }
  return term.length >= 4 && fieldText.toLowerCase().includes(term); // substring for fragments (matches old behaviour)
};

function snippet(text: string, terms: string[], radius = 70): Segment[] {
  const clean = text.replace(/\s+/g, ' ').trim();
  if (!clean) return [];
  const lower = clean.toLowerCase();
  let first = -1;
  for (const t of terms) { const idx = lower.indexOf(t); if (idx >= 0 && (first < 0 || idx < first)) first = idx; }
  if (first < 0) for (const t of terms) { const st = stem(t); const idx = lower.indexOf(st); if (idx >= 0 && (first < 0 || idx < first)) first = idx; }
  const start = Math.max(0, first < 0 ? 0 : first - radius);
  const end = Math.min(clean.length, (first < 0 ? 0 : first) + radius * 2);
  const slice = (start > 0 ? '…' : '') + clean.slice(start, end) + (end < clean.length ? '…' : '');
  const stems = terms.map(stem).filter(Boolean);
  const re = new RegExp(`(${stems.map((s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})`, 'giu');
  return slice.split(re).filter((s) => s !== '').map((s) => ({ text: s, hit: stems.some((st) => s.toLowerCase() === st) }));
}

interface Scored { item: SavedItem; score: number; fieldKey: string; fieldsHit: string[]; matchedTerms: string[]; }

function scoreItem(item: SavedItem, terms: string[], requireAll: boolean): Scored | null {
  const matched = new Set<string>();
  const fieldsHit = new Set<string>();
  let best: { key: string; w: number } | null = null;
  let score = 0;
  for (const f of FIELDS) {
    const text = f.text(item);
    if (!text) continue;
    for (const term of terms) {
      if (wordMatches(text, term)) {
        matched.add(term);
        fieldsHit.add(f.key);
        score += f.weight;
        if (!best || f.weight > best.w) best = { key: f.key, w: f.weight };
      }
    }
  }
  if (!best || matched.size === 0) return null;
  if (requireAll && matched.size < terms.length) return null;
  return { item, score: score + matched.size * 2, fieldKey: best.key, fieldsHit: [...fieldsHit], matchedTerms: [...matched] };
}

const recency = (i: SavedItem) => new Date(i.createdAt || 0).getTime();

export function searchMemories(items: SavedItem[], query: string, opts: { includeArchived?: boolean } = {}): SearchHit[] {
  const terms = tokenize(query);
  if (terms.length === 0) return [];
  const pool = items.filter((i) => opts.includeArchived || !i.isArchived);

  const build = (s: Scored, mode: MatchMode, whyOverride?: string): SearchHit => {
    // Explain with the most INFORMATIVE field that matched (a named person/place beats "somewhere in the text"),
    // but show the user's own words as the evidence whenever they matched there.
    const WHY_ORDER = ['people', 'places', 'topics', 'link', 'raw', 'title', 'summary', 'meta', 'kind'];
    const whyKey = WHY_ORDER.find((k) => s.fieldsHit.includes(k)) || s.fieldKey;
    const f = FIELDS.find((x) => x.key === whyKey)!;
    const source = f.text(s.item) || getMemoryText(s.item);
    const shown = s.fieldsHit.includes('raw') || s.fieldsHit.includes('title') || s.fieldsHit.includes('summary') ? (s.fieldsHit.includes('raw') ? (s.item.rawInput || getMemoryText(s.item)) : source) : getMemoryText(s.item);
    const quoted = s.matchedTerms.map((t) => `“${t}”`).join(', ');
    const why = whyOverride || (mode === 'partial' ? `Partly matches — only ${quoted}` : `${f.label(s.item)}: ${quoted}${['people', 'places', 'topics'].includes(f.key) ? ` — ${source}` : ''}`);
    return { item: s.item, mode, score: s.score, why, evidence: snippet(shown, s.matchedTerms) };
  };

  const exact = pool.map((i) => scoreItem(i, terms, true)).filter(Boolean) as Scored[];
  if (exact.length > 0) {
    return exact.sort((a, b) => b.score - a.score || recency(b.item) - recency(a.item)).map((s) => build(s, 'exact'));
  }

  // Fallback 1: partial matches (some words), clearly labelled as such.
  const partial = terms.length > 1 ? (pool.map((i) => scoreItem(i, terms, false)).filter(Boolean) as Scored[]) : [];
  // Fallback 2: memories the save pipeline already linked to a partial match.
  const byId = new Map(pool.map((i) => [i.id, i]));
  const related: SearchHit[] = [];
  const seen = new Set(partial.map((p) => p.item.id));
  partial.sort((a, b) => b.score - a.score).slice(0, 3).forEach((p) => {
    (p.item.relatedMemoryIds || []).forEach((rid) => {
      const r = byId.get(rid);
      if (r && !seen.has(rid)) {
        seen.add(rid);
        related.push({ item: r, mode: 'related', score: 1, why: `Related to “${getMemoryText(p.item).slice(0, 40)}”`, evidence: snippet(getMemoryText(r), []) });
      }
    });
  });
  return [...partial.sort((a, b) => b.score - a.score || recency(b.item) - recency(a.item)).map((s) => build(s, 'partial')), ...related];
}
