/**
 * "Returning now" selection.
 *
 * This is the SAME ranking the app already used for "What should I deal with?"
 * (same rules, same scores, same 45-point threshold), moved out of a component
 * so the new Inbox can reuse it rather than growing a second ranker. Two
 * additions, both about honesty of the explanation and reversibility:
 *  - reminders that already FIRED (reminderStatus 'pending_recall') always
 *    qualify — that is the literal meaning of "returning now";
 *  - `why` is written as a reason in the user's own terms ("You set this to
 *    return at 12:31 AM"), not a task label.
 * "Keep" hides an item from this list for a while WITHOUT touching the memory
 * (local UI state only), so it can never destroy or complete anything.
 */
import { SavedItem } from '../types';
import { normalizeItemReminder } from './reminderService';
import { getMemoryMomentHeading } from './reminderService';
import { friendlyWhen, timeAgo } from './memoryView';

export interface ReturningEntry {
  item: SavedItem;
  score: number;
  /** Short state label, e.g. "Returning now". */
  label: string;
  /** Why it is here now — always a reason, never just a count. */
  why: string;
  isUrgent: boolean;
}

const ACTION_KEYWORDS = [
  'tax', 'taxes', 'receipt', 'receipts', 'application', 'invoice', 'submit', 'pay', 'doctor', 'dentist', 'interview',
  'flight', 'passport', 'visa', 'rent', 'bill', 'exam', 'exams', 'urgent', 'asap',
];

const KEPT_KEY = 'later_returning_kept_v1';
export const DEFAULT_KEEP_DAYS = 7;

export function readKept(now: Date = new Date()): Record<string, string> {
  try {
    const raw = JSON.parse(localStorage.getItem(KEPT_KEY) || '{}') as Record<string, string>;
    const live: Record<string, string> = {};
    for (const [id, until] of Object.entries(raw)) if (new Date(until).getTime() > now.getTime()) live[id] = until;
    return live;
  } catch { return {}; }
}
export function keepItem(id: string, days = DEFAULT_KEEP_DAYS, now: Date = new Date()): void {
  try {
    const map = readKept(now);
    map[id] = new Date(now.getTime() + days * 86400000).toISOString();
    localStorage.setItem(KEPT_KEY, JSON.stringify(map));
  } catch { /* non-fatal: it will simply resurface again */ }
}
export function unkeepItem(id: string): void {
  try {
    const map = readKept();
    delete map[id];
    localStorage.setItem(KEPT_KEY, JSON.stringify(map));
  } catch { /* ignore */ }
}

export function evaluateReturning(items: SavedItem[], now: Date = new Date()): ReturningEntry[] {
  const out: ReturningEntry[] = [];
  const timeStr = (d: Date) => d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

  items.forEach((item) => {
    if (item.isDone || item.isArchived) return;
    const tag = item.urgencyTag || item.urgency;
    const created = item.createdAt ? new Date(item.createdAt) : null;
    const daysAgo = created ? Math.max(0, Math.floor((now.getTime() - created.getTime()) / 86400000)) : 0;
    const savedWhen = created ? timeAgo(item.createdAt, now) : '';

    let score = 0;
    let label = '';
    let why = '';
    let isUrgent = false;

    if (tag === 'urgent') { score = 85; label = 'Priority'; why = `You marked this Priority${savedWhen ? ` (saved ${savedWhen})` : ''}.`; isUrgent = true; }
    else if (tag === 'important') { score = 70; label = 'Important'; why = "You marked this Important and haven't come back to it yet."; }
    else if (tag === 'chill') { score = 65; label = 'Worth a look'; why = 'You marked this Chill — a good moment to look at it.'; }

    const postponeCount = item.postponeCount || 0;
    const lower = `${item.title || ''} ${item.rawInput || ''}`.toLowerCase();
    const isActionable =
      item.contentType === 'task' || item.contentType === 'event' || item.intent === 'complete' || item.intent === 'call' || item.intent === 'buy' ||
      ACTION_KEYWORDS.some((k) => lower.includes(k));

    const reminder = normalizeItemReminder(item);
    const scheduledRaw = item.reminderTime || item.scheduledFor || item.reminder?.scheduledAt;
    const sched = scheduledRaw ? new Date(scheduledRaw) : null;

    // A reminder that already fired is, by definition, returning now.
    if (reminder.reminderStatus === 'pending_recall') {
      score = Math.max(score, 125);
      label = 'Returning now';
      why = sched ? `You set this to return ${friendlyWhen(sched, now)}.` : 'Its reminder just fired.';
      isUrgent = true;
    } else if (sched && !isNaN(sched.getTime())) {
      const diffHours = (sched.getTime() - now.getTime()) / 3600000;
      const today = sched.toDateString() === now.toDateString();
      if (today) {
        if (diffHours <= 0) { score = 120; label = 'Returning now'; why = `You set this to return at ${timeStr(sched)}.`; isUrgent = true; }
        else if (diffHours <= 2) { score = 115; label = 'Returning soon'; why = `Set to return at ${timeStr(sched)} — soon.`; isUrgent = true; }
        else { score = 100; label = 'Returns today'; why = `Set to return today at ${timeStr(sched)}.`; }
      } else if (diffHours > 0 && diffHours <= 6) {
        score = 90; label = 'Returning soon'; why = `Set to return ${friendlyWhen(sched, now)}.`; isUrgent = true;
      }
    }

    if (postponeCount >= 2) {
      const s = 95 + postponeCount * 5;
      if (s >= score) { score = s; label = 'Snoozed before'; why = `You've snoozed this ${postponeCount} times.`; isUrgent = false; }
    } else if (postponeCount === 1 && score < 70) {
      score = 70; label = 'Snoozed before'; why = "You snoozed this once — it's back."; isUrgent = false;
    }

    if (score < 80 && isActionable && item.createdAt && daysAgo >= 3) {
      const s = 65 + Math.min(daysAgo * 2, 20);
      if (s > score) { score = s; label = 'Still open'; why = `Saved ${daysAgo} days ago and not revisited.`; isUrgent = false; }
    }
    if (score < 60 && isActionable && ACTION_KEYWORDS.some((k) => lower.includes(k))) {
      score = 60; label = 'Worth a look'; why = 'This looks like something with a deadline attached.'; isUrgent = true;
    }
    if (score < 50 && created && isActionable) {
      const hoursOld = (now.getTime() - created.getTime()) / 3600000;
      if (hoursOld < 24) { score = 50; label = 'Fresh'; why = `You saved this ${savedWhen || 'recently'} and it looks time-sensitive.`; isUrgent = false; }
    }

    if (!why) why = getMemoryMomentHeading(item) + '.';
    if (score >= 45) out.push({ item, score, label, why, isUrgent });
  });

  return out.sort((a, b) => b.score - a.score);
}

/** The small, high-confidence set shown at the top of Inbox (never more than `max`). */
export function pickReturningNow(items: SavedItem[], now: Date = new Date(), max = 3): ReturningEntry[] {
  const kept = readKept(now);
  return evaluateReturning(items, now).filter((e) => !kept[e.item.id]).slice(0, max);
}
